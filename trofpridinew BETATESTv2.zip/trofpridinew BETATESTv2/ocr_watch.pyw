# -*- coding: utf-8 -*-
"""
TrofPridi — запуск OCR-наблюдателя без консоли (.pyw).

Вся логика живёт в ocr_watch.py — искать и править нужно ТОЛЬКО там.
Этот файл — тонкая запускалка: выполняет ocr_watch.py в режиме
__main__, как делает команда «python ocr_watch.py», поэтому все
аргументы (например --calibrate) работают и здесь.

Раньше .pyw был побайтовой копией .py — две правки вместо одной и
вечный риск рассинхронизации. Больше так не делаем.
"""
import os
import runpy

runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "ocr_watch.py"), run_name="__main__")

# -*- coding: utf-8 -*-
"""
TrofPridi — создание ярлыков с нормальной иконкой.

Зачем это нужно
---------------
Значок у файла .ahk в проводнике задаёт не скрипт, а сама Windows:
все файлы этого типа показываются с иконкой AutoHotkey, и повлиять на
это изнутри нельзя. `Menu, Tray, Icon` меняет только трей и Alt+Tab.

Обходной путь — ярлык. У ярлыка иконка своя, задаётся явно. Кладём два
на рабочий стол: запуск бота и открытие статистики.

Запуск: двойной клик.
"""

import os
import sys

APP = "TrofPridi"
BOT = "TrofPridiV3.5.ahk"
STATS = "stats.pyw"
ICON = "trofpridi.ico"

BG = "#11151A"
CARD = "#1A2027"
FG = "#FFFFFF"
DIM = "#6C7B8B"
ACCENT = "#00A2FF"
GREEN = "#00E6B8"
RED = "#FF5555"
FONT = "Segoe UI"


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def desktop():
    """Путь к рабочему столу. У русской Windows он может называться
    по-разному, поэтому спрашиваем у самой системы."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            from ctypes import wintypes
            buf = ctypes.create_unicode_buffer(260)
            # 0 = CSIDL_DESKTOP
            ctypes.windll.shell32.SHGetFolderPathW(None, 0, None, 0, buf)
            if buf.value and os.path.isdir(buf.value):
                return buf.value
        except Exception:
            pass
    p = os.path.join(os.path.expanduser("~"), "Desktop")
    return p if os.path.isdir(p) else os.path.expanduser("~")


def make_shortcut(dst, target, icon, args="", workdir=""):
    """Создаёт ярлык через COM-интерфейс Windows.

    Ставить внешние пакеты ради этого не нужно: WScript.Shell есть в
    любой Windows и вызывается через стандартный ctypes/COM.
    """
    import subprocess
    # Через VBScript: не требует ни pywin32, ни winshell, работает
    # одинаково на всех версиях Windows.
    vbs = (
        'Set sh = CreateObject("WScript.Shell")\n'
        f'Set lnk = sh.CreateShortcut("{dst}")\n'
        f'lnk.TargetPath = "{target}"\n'
        + (f'lnk.Arguments = "{args}"\n' if args else "")
        + f'lnk.WorkingDirectory = "{workdir or os.path.dirname(target)}"\n'
        f'lnk.IconLocation = "{icon}"\n'
        'lnk.Save\n'
    )
    tmp = os.path.join(os.environ.get("TEMP", script_dir()),
                       "_trofpridi_lnk.vbs")
    with open(tmp, "w", encoding="utf-8-sig") as f:
        f.write(vbs)
    try:
        subprocess.run(["cscript", "//nologo", tmp], timeout=60,
                       capture_output=True,
                       creationflags=getattr(subprocess,
                                             "CREATE_NO_WINDOW", 0))
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass
    return os.path.exists(dst)


def build():
    """Создаёт оба ярлыка. Возвращает список (имя, получилось, почему)."""
    d = script_dir()
    icon = os.path.join(d, ICON)
    dsk = desktop()
    out = []

    bot = os.path.join(d, BOT)
    if os.path.exists(bot):
        dst = os.path.join(dsk, f"{APP} — бот.lnk")
        try:
            ok = make_shortcut(dst, bot, icon, workdir=d)
            out.append(("Бот", ok, dst if ok else "не удалось создать"))
        except Exception as e:
            out.append(("Бот", False, str(e)))
    else:
        out.append(("Бот", False, f"не найден {BOT}"))

    st = os.path.join(d, STATS)
    if os.path.exists(st):
        dst = os.path.join(dsk, f"{APP} — статистика.lnk")
        # Запускаем через pythonw, чтобы не мелькала консоль.
        pyw = sys.executable.replace("python.exe", "pythonw.exe")
        if not os.path.exists(pyw):
            pyw = sys.executable
        try:
            ok = make_shortcut(dst, pyw, icon, args=f'""{st}""', workdir=d)
            out.append(("Статистика", ok,
                        dst if ok else "не удалось создать"))
        except Exception as e:
            out.append(("Статистика", False, str(e)))
    else:
        out.append(("Статистика", False, f"не найден {STATS}"))
    return out


def main():
    import tkinter as tk

    root = tk.Tk()
    root.title(f"{APP} — ярлыки")
    root.configure(bg=BG)
    root.resizable(False, False)
    W, H = 520, 300
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{max(0, (sh - H) // 3)}")

    tk.Label(root, text="Ярлыки на рабочий стол", bg=BG, fg=FG,
             font=(FONT, 16, "bold")).pack(pady=(22, 4))
    tk.Label(root,
             text="У файлов .ahk иконку задаёт Windows, изменить её нельзя.\n"
                  "Ярлык показывает нашу — и запускает то же самое.",
             bg=BG, fg=DIM, font=(FONT, 9), justify="center").pack()

    box = tk.Frame(root, bg=CARD)
    box.pack(fill="both", expand=True, padx=24, pady=(14, 4))
    status = tk.Label(root, text="", bg=BG, fg=ACCENT, font=(FONT, 9),
                      wraplength=W - 50, justify="center")
    status.pack(pady=(6, 2))

    rows = tk.Frame(box, bg=CARD)
    rows.pack(pady=14)

    def run():
        for wdg in rows.winfo_children():
            wdg.destroy()
        res = build()
        for name, ok, why in res:
            fr = tk.Frame(rows, bg=CARD)
            fr.pack(fill="x", padx=10, pady=3)
            tk.Label(fr, text="•", bg=CARD, fg=GREEN if ok else RED,
                     font=(FONT, 13)).pack(side="left")
            tk.Label(fr, text=f"  {name}", bg=CARD, fg=FG, font=(FONT, 10),
                     width=14, anchor="w").pack(side="left")
            tk.Label(fr, text="создан" if ok else why, bg=CARD,
                     fg=GREEN if ok else RED, font=(FONT, 9),
                     anchor="w").pack(side="left")
        good = sum(1 for _, ok, _ in res if ok)
        status.config(text=(f"Готово: {good} из {len(res)}. "
                            "Ярлыки на рабочем столе."
                            if good else "Не получилось создать ярлыки."),
                      fg=GREEN if good else RED)
        btn.config(state="disabled")

    btns = tk.Frame(root, bg=BG)
    btns.pack(pady=(4, 16))
    btn = tk.Button(btns, text="Создать", command=run, bg="#17567F", fg=FG,
                    relief="flat", padx=28, pady=6, font=(FONT, 10, "bold"),
                    cursor="hand2", activebackground="#2A8FD0",
                    activeforeground=FG)
    btn.pack(side="left", padx=6)
    tk.Button(btns, text="Закрыть", command=root.destroy, bg=CARD, fg=FG,
              relief="flat", padx=24, pady=6, font=(FONT, 10),
              cursor="hand2", activebackground="#222A33",
              activeforeground=FG).pack(side="left", padx=6)

    root.mainloop()


if __name__ == "__main__":
    if not sys.platform.startswith("win"):
        print("Ярлыки создаются только в Windows.")
        sys.exit(1)
    try:
        main()
    except Exception as e:
        try:
            import tkinter as tk
            from tkinter import messagebox
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror(f"{APP} — ярлыки", str(e))
        except Exception:
            print(e)

# -*- coding: utf-8 -*-
"""
TrofPridi — установка всего необходимого одним запуском.

Что делает
----------
Проверяет Python, ставит недостающие пакеты и сразу их испытывает:
делает снимок экрана, распознаёт на нём текст, загружает точный чтец
опыта. В конце показывает, что работает, а что нет и почему.

Запуск: двойной клик по файлу. Консоль не появляется (.pyw).
Если окно не открылось вовсе — значит не установлен Python,
об этом будет сказано в окне ошибки или в install.log.

Ставятся:
    pillow                 — работа с картинками
    mss                    — быстрые снимки экрана
    winsdk                 — встроенное распознавание текста Windows
    rapidocr-onnxruntime   — точное чтение опыта по плашкам (~380 МБ)

Последний пакет тяжёлый, поэтому ставится последним и его неудача не
считается критической: без него всё работает, только опыт читается
менее надёжным способом.
"""

import os
import subprocess
import sys
import threading
import time

APP = "TrofPridi"
DATA_DIR = "TrofPridi_data"
LOG_NAME = "install.log"

# Привязка к Windows Runtime — через неё работает встроенное
# распознавание текста. Пакет называется по-разному:
#
#   Python 3.8-3.12 — winsdk, один большой пакет. Его последняя сборка
#       вышла в августе 2023 и колёс для 3.13+ не содержит: pip пробует
#       собрать из исходников, требует Visual Studio и падает с
#       «Failed building wheel for winsdk».
#
#   Python 3.13+ — раздельные winrt-*, тот же проект, но обновляемый.
#       Колёса есть вплоть до 3.14.
#
# Имена модулей внутри одинаковые, поэтому коду всё равно, что стоит.
NEW_PY = sys.version_info >= (3, 13)

_WINRT = [
    ("winrt.windows.media.ocr", "winrt-Windows.Media.Ocr",
     "распознавание текста Windows", True),
    ("winrt.windows.globalization", "winrt-Windows.Globalization",
     "выбор языка распознавания", True),
    ("winrt.windows.graphics.imaging", "winrt-Windows.Graphics.Imaging",
     "работа с растром для распознавания", True),
    ("winrt.windows.storage.streams", "winrt-Windows.Storage.Streams",
     "передача картинки в распознавание", True),
]

# (модуль для проверки, имя для pip, описание, обязателен ли)
PACKAGES = (
    [("PIL", "pillow", "работа с картинками", True),
     ("mss", "mss", "снимки экрана", True)]
    + (_WINRT if NEW_PY
       else [("winsdk", "winsdk", "распознавание текста Windows", True)])
    + [("rapidocr_onnxruntime", "rapidocr-onnxruntime",
        "точное чтение опыта (~380 МБ)", False)]
)

BG = "#11151A"
CARD = "#1A2027"
FG = "#FFFFFF"
DIM = "#6C7B8B"
ACCENT = "#00A2FF"
GREEN = "#00E6B8"
RED = "#FF5555"
GOLD = "#FFB300"
FONT = "Segoe UI"


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def data_path(name):
    d = os.path.join(script_dir(), DATA_DIR)
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        return os.path.join(script_dir(), name)
    return os.path.join(d, name)


def log(msg):
    """Пишем ход установки в файл: если окно закроется, останется след."""
    try:
        with open(data_path(LOG_NAME), "a", encoding="utf-8") as f:
            f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')}  {msg}\n")
    except Exception:
        pass


def have(mod):
    """Установлен ли модуль. Импортируем в отдельном процессе.

    Свой процесс нужен для честной проверки: пакет, поставленный только
    что, в текущем процессе может не подхватиться из-за кеша путей.
    """
    try:
        r = subprocess.run([sys.executable, "-c", f"import {mod}"],
                           capture_output=True, timeout=120,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        return r.returncode == 0
    except Exception:
        return False


def pip_install(name):
    """Ставит пакет. Возвращает (успех, текст вывода)."""
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade",
           "--disable-pip-version-check", "--no-input", name]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=1800, errors="replace",
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        out = (r.stdout or "") + (r.stderr or "")
        return r.returncode == 0, out[-4000:]
    except FileNotFoundError:
        return False, ("Не найден pip. Переустанови Python с python.org "
                       "и отметь «Add python.exe to PATH».")
    except subprocess.TimeoutExpired:
        return False, "Установка идёт слишком долго — проверь интернет."
    except Exception as e:
        return False, str(e)


# --------------------------------------------------------------- проверки
def check_screenshot():
    """Снимок экрана действительно делается?"""
    code = ("import mss\n"
            "with mss.mss() as s:\n"
            "    im = s.grab(s.monitors[0])\n"
            "print(im.width, im.height)\n")
    try:
        r = subprocess.run([sys.executable, "-c", code],
                           capture_output=True, text=True, timeout=120,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        if r.returncode == 0 and r.stdout.strip():
            return True, f"экран {r.stdout.strip().replace(' ', 'x')}"
        return False, (r.stderr or "").strip()[-200:]
    except Exception as e:
        return False, str(e)


def check_win_ocr():
    """Есть ли русский языковой пакет распознавания."""
    root = "winrt" if NEW_PY else "winsdk"
    code = (
        f"from {root}.windows.media.ocr import OcrEngine\n"
        f"from {root}.windows.globalization import Language\n"
        "e = OcrEngine.try_create_from_language(Language('ru'))\n"
        "if e is None:\n"
        "    e = OcrEngine.try_create_from_user_profile_languages()\n"
        "print('ok' if e else 'no')\n")
    try:
        r = subprocess.run([sys.executable, "-c", code],
                           capture_output=True, text=True, timeout=180,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        if "ok" in (r.stdout or ""):
            return True, "русский язык доступен"
        return False, ("нет языкового пакета: Параметры → Время и язык → "
                       "Язык → Русский → Параметры → "
                       "Распознавание текста → Установить")
    except Exception as e:
        return False, str(e)


def check_rapid():
    """Точный чтец опыта загружается? Модели скачиваются при первом запуске."""
    code = ("from rapidocr_onnxruntime import RapidOCR\n"
            "RapidOCR()\n"
            "print('ok')\n")
    try:
        r = subprocess.run([sys.executable, "-c", code],
                           capture_output=True, text=True, timeout=900,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        if "ok" in (r.stdout or ""):
            return True, "модели загружены"
        return False, (r.stderr or "").strip()[-200:]
    except Exception as e:
        return False, str(e)


# ------------------------------------------------------------------- окно
def main():
    import tkinter as tk

    root = tk.Tk()
    root.title(f"{APP} — установка")
    root.configure(bg=BG)
    root.resizable(False, False)
    # Высота зависит от числа пакетов: на Python 3.13+ их семь вместо
    # четырёх (привязка к Windows Runtime разбита на отдельные пакеты),
    # и при фиксированной высоте список не помещался.
    W = 560
    H = 250 + 54 * len(PACKAGES)
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{max(0, (sh - H) // 3)}")

    tk.Label(root, text=APP, bg=BG, fg=FG,
             font=(FONT, 20, "bold")).pack(pady=(22, 0))
    tk.Label(root, text="Установка всего необходимого", bg=BG, fg=DIM,
             font=(FONT, 10)).pack(pady=(2, 2))
    # Показываем версию Python и какой набор пакетов под неё подобран:
    # если что-то пойдёт не так, это первое, что нужно знать.
    tk.Label(root,
             text=f"Python {sys.version.split()[0]}  ·  "
                  + ("новый набор winrt-*" if NEW_PY else "пакет winsdk"),
             bg=BG, fg=DIM, font=(FONT, 8)).pack(pady=(0, 12))

    box = tk.Frame(root, bg=CARD)
    box.pack(fill="both", expand=True, padx=22)

    rows = {}
    for mod, pip_name, desc, need in PACKAGES:
        fr = tk.Frame(box, bg=CARD)
        fr.pack(fill="x", padx=16, pady=(10, 0))
        dot = tk.Label(fr, text="•", bg=CARD, fg=DIM, font=(FONT, 13))
        dot.pack(side="left")
        tk.Label(fr, text=f"  {pip_name}", bg=CARD, fg=FG,
                 font=(FONT, 10), width=22, anchor="w").pack(side="left")
        st = tk.Label(fr, text="ожидает", bg=CARD, fg=DIM,
                      font=(FONT, 9), anchor="w")
        st.pack(side="left", fill="x", expand=True)
        rows[pip_name] = (dot, st)
        tk.Label(box, text=f"     {desc}", bg=CARD, fg=DIM,
                 font=(FONT, 8), anchor="w").pack(fill="x", padx=16)

    tk.Frame(box, bg=CARD, height=6).pack()
    status = tk.Label(root, text="Готовим установку…", bg=BG, fg=ACCENT,
                      font=(FONT, 10), wraplength=W - 60, justify="center")
    status.pack(pady=(12, 4))
    hint = tk.Label(root, text="", bg=BG, fg=DIM, font=(FONT, 8),
                    wraplength=W - 60, justify="center")
    hint.pack()

    btn = tk.Button(root, text="Закрыть", command=root.destroy, bg=CARD,
                    fg=FG, relief="flat", padx=26, pady=6,
                    font=(FONT, 10), activebackground="#222A33",
                    activeforeground=FG, cursor="hand2")

    state = {"done": False, "fail_required": [], "fail_optional": []}

    def set_row(pip_name, color, text):
        dot, st = rows[pip_name]
        dot.config(fg=color)
        st.config(text=text, fg=color)

    def ui(fn, *a):
        try:
            root.after(0, lambda: fn(*a))
        except Exception:
            pass

    def worker():
        log("=== запуск установщика ===")
        log(f"Python {sys.version.split()[0]} — {sys.executable}")

        for mod, pip_name, desc, need in PACKAGES:
            ui(status.config, {"text": f"Проверяем {pip_name}…"})
            ui(set_row, pip_name, GOLD, "проверка")
            if have(mod):
                log(f"{pip_name}: уже установлен")
                ui(set_row, pip_name, GREEN, "уже установлен")
                continue

            ui(status.config, {"text": f"Скачиваем и ставим {pip_name}…"})
            if not need:
                ui(hint.config,
                   {"text": "Пакет большой, около 380 МБ — "
                            "это займёт минуту-две."})
            ui(set_row, pip_name, ACCENT, "установка…")
            ok, out = pip_install(pip_name)
            log(f"{pip_name}: {'установлен' if ok else 'ОШИБКА'}")
            if out:
                log(out.strip()[-1500:])
            ui(hint.config, {"text": ""})

            if ok and have(mod):
                ui(set_row, pip_name, GREEN, "установлен")
            else:
                ui(set_row, pip_name, RED if need else GOLD,
                   "не удалось" if need else "пропущен")
                (state["fail_required"] if need
                 else state["fail_optional"]).append(pip_name)

        # ---- проверяем, что оно правда работает --------------------
        ui(status.config, {"text": "Проверяем снимок экрана…"})
        ok, msg = check_screenshot()
        log(f"снимок экрана: {'ok' if ok else 'ошибка'} — {msg}")
        if not ok:
            state["fail_required"].append("снимок экрана")

        ui(status.config, {"text": "Проверяем распознавание текста…"})
        ok2, msg2 = check_win_ocr()
        log(f"Windows OCR: {'ok' if ok2 else 'ошибка'} — {msg2}")
        if not ok2:
            state["fail_required"].append("распознавание текста")
            ui(hint.config, {"text": msg2})

        if "rapidocr-onnxruntime" not in state["fail_optional"]:
            ui(status.config,
               {"text": "Загружаем модели точного чтения опыта…"})
            ui(hint.config, {"text": "Первый раз скачивается ~90 МБ."})
            ok3, msg3 = check_rapid()
            log(f"RapidOCR: {'ok' if ok3 else 'ошибка'} — {msg3}")
            if not ok3:
                state["fail_optional"].append("модели RapidOCR")
                ui(set_row, "rapidocr-onnxruntime", GOLD, "без моделей")
            ui(hint.config, {"text": ""})

        # ---- итог ---------------------------------------------------
        state["done"] = True
        if state["fail_required"]:
            ui(status.config,
               {"text": "Не установлено: "
                        + ", ".join(state["fail_required"]),
                "fg": RED})
            ui(hint.config,
               {"text": "Подробности в TrofPridi_data\\install.log. "
                        "Обычно помогает запуск от имени администратора "
                        "или отключение антивируса на время установки."})
        elif state["fail_optional"]:
            ui(status.config,
               {"text": "Готово. Всё основное работает.", "fg": GREEN})
            ui(hint.config,
               {"text": "Не поставилось: "
                        + ", ".join(state["fail_optional"])
                        + ". Это не страшно: опыт будет читаться "
                          "обычным способом."})
        else:
            ui(status.config,
               {"text": "Готово! Всё установлено и проверено.",
                "fg": GREEN})
            ui(hint.config,
               {"text": "Можно закрывать окно и запускать бота: "
                        "TrofPridiV3.5.ahk"})
        log("=== установка завершена ===")
        ui(btn.pack, {"pady": (10, 16)})

    threading.Thread(target=worker, daemon=True).start()
    root.mainloop()


def fatal(text):
    """Показывает ошибку, из-за которой установка невозможна."""
    log("КРИТИЧЕСКАЯ ОШИБКА: " + text)
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror(f"{APP} — установка", text)
        r.destroy()
    except Exception:
        print(text)


if __name__ == "__main__":
    if sys.version_info < (3, 8):
        fatal("Нужен Python 3.8 или новее.\n\n"
              f"Сейчас установлен: {sys.version.split()[0]}\n\n"
              "Скачай свежий с python.org и при установке отметь\n"
              "«Add python.exe to PATH».")
        sys.exit(1)
    if not sys.platform.startswith("win"):
        fatal("Программа рассчитана на Windows:\n"
              "распознавание текста берётся из самой системы.")
        sys.exit(1)
    try:
        main()
    except Exception as e:
        import traceback
        log(traceback.format_exc())
        fatal(f"Установка прервалась:\n\n{e}\n\n"
              f"Подробности в {DATA_DIR}\\{LOG_NAME}")

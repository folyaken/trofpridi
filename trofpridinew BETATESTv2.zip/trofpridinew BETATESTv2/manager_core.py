# -*- coding: utf-8 -*-
"""
TrofPridi Manager — логика без интерфейса (manager_core).

Здесь живёт всё, что Менеджер умеет, не рисуя окна:
  * INI-конфиги в TrofPridi_data\\configs\\ (stats.ini, bot_spin.ini,
    bot_feeder.ini, bot_marine.ini, bot_craft.ini);
  * статус и запуск/остановка ботов;
  * активация (пока ЛОКАЛЬНАЯ ЗАГЛУШКА, сервер прилетит позже);
  * HWID и заготовка Telegram-уведомлений;
  * связка процессов (№53): маяки bot_state.ini / alive.txt /
    manager_alive.txt, проверка процессов, замки от двойных окон.

Окно (manager.py) только вызывает эти функции — поэтому всё здесь
можно гонять автотестами без графики.
"""

import configparser
import hashlib
import secrets
import hmac
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timedelta

DATA_DIR = "TrofPridi_data"
CONFIGS_NAME = "configs"
APP_VERSION = "v3.30.1"

# ---------------------------------------------------------- помощники
# Схема карточек Менеджера и полей их настроек. field:
#   (секция, ключ, тип(bool/int/text), подпись, подсказка, умолчание)
HELPERS = (
    {
        "key": "spin",
        "title": "Спиннинг",
        "ini": "bot_spin.ini",
        "ini_title": "настройки помощника «Спиннинг»",
        "available": True,               # единственный живой бот на сегодня
        "bot_file": "TrofPridiV3.5.ahk",
        "desc": "Активная ловля на спиннинг: заброс, проводка "
              "приманки, подсечка и вываживание рыбы.",
        "fields": [
            ("bot", "variability", "bool",
             "Safe Mode (человечность)",
             "Случайные паузы и рывки таймингов — бот ведёт себя "
             "живее, как человек. ВЫКЛ — ровно, как часы.",
             False),
            ("retrieving", "style", ("choice", [
                ("even", "Равномерная проводка"),
                ("twitch", "Твичинг"),
                ("roam", "Рыскание"),
                ("jig", "Джиггинг"),
             ]), "Вид проводки",
             "Как ведём приманку после заброса.", "even"),
            ("retrieving", "reel_delay_sec", "int",
             "Интервал подсечки, сек",
             "Пауза от заброса до начала ведения (зажатие ЛКМ).", 2),
            ("retrieving", "shift_hold_sec", "int",
             "Зажатие Shift после поклёвки, сек",
             "Сколько держать Shift, когда рыба клюнула.", 3),
            ("retrieving", "rmb_hold_sec", "int",
             "Зажатие ПКМ после поклёвки, сек",
             "Сколько держать правую кнопку мыши после поклёвки.", 5),
        ],
    },
    {
        "key": "feeder",
        "title": "Фидер",
        "ini": "bot_feeder.ini",
        "ini_title": "настройки помощника «Фидер»",
        "available": False,
        "bot_file": "",
        "desc": "Донная ловля на фидерные оснастки: слежение за "
              "кормушкой и поклёвками.",
        "fields": [
            ("bot", "enabled", "bool", "Включить помощника",
             "Параметры заработают с выходом бота — файл уже "
             "готов под него.", False),
            ("timers", "check_ms", "int", "Проверка кормушки, мс",
             "Как часто смотреть кончик удилища.", 2000),
            ("bite", "patience_sec", "int", "Терпение поклёвки, сек",
             "Столько ждём клёв перед перезабросом.", 45),
        ],
    },
    {
        "key": "marine",
        "title": "Море",
        "ini": "bot_marine.ini",
        "ini_title": "настройки помощника «Море»",
        "available": False,
        "bot_file": "",
        "desc": "Морская ловля с лодки: глубина, джиг, крупняк.",
        "fields": [
            ("bot", "enabled", "bool", "Включить помощника",
             "Параметры заработают с выходом бота — файл уже "
             "готов под него.", False),
            ("sea", "depth_m", "int", "Глубина ловли, м",
             "Ориентир для выбора веса и шага джига.", 50),
            ("sea", "spot", "text", "Точка лова",
             "Заметка для себя: где стоим.", "default"),
        ],
    },
    {
        "key": "craft",
        "title": "Крафт",
        "ini": "bot_craft.ini",
        "ini_title": "настройки помощника «Крафт»",
        "available": False,
        "bot_file": "",
        "desc": "Изготовление насадок, бойлов и прикормки между "
              "сессиями.",
        "fields": [
            ("bot", "enabled", "bool", "Включить помощника",
             "Параметры заработают с выходом бота — файл уже "
             "готов под него.", False),
            ("craft", "batch", "int", "Партия за цикл, шт",
             "Сколько изделий делаем за один проход.", 10),
            ("craft", "alt_recipes", "bool", "Альтернативные рецепты",
             "Разрешить вторичные составы, если нет основных "
             "компонентов.", False),
        ],
    },
)

HELPER_BY_KEY = {h["key"]: h for h in HELPERS}


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def data_dir(base=None):
    return os.path.join(base or script_dir(), DATA_DIR)


def configs_dir(base=None, create=False):
    """Папка конфигов: TrofPridi_data\\configs\\ (создаётся по запросу)."""
    d = os.path.join(data_dir(base), CONFIGS_NAME)
    if create:
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass
    return d


def ini_path(ini_name, base=None, create=False):
    return os.path.join(configs_dir(base, create), ini_name)


# ------------------------------------------------------------ INI
def read_ini(ini_name, base=None):
    """ConfigParser с содержимым INI (пустой, если файла нет)."""
    cp = configparser.ConfigParser()
    cp.optionxform = str            # ключи сохраняем как есть (нижний регистр)
    try:
        cp.read(ini_path(ini_name, base), encoding="utf-8")
    except Exception:
        pass
    return cp


def read_value(ini_name, section, key, default=None, base=None):
    cp = read_ini(ini_name, base)
    try:
        return cp.get(section, key)
    except Exception:
        return default


def _ini_header(ini_name):
    title = ini_name
    for h in HELPERS:
        if h["ini"] == ini_name:
            title = h["ini_title"]
            break
    else:
        if ini_name == "stats.ini":
            title = "настройки статистики и оформления"
    return ("# %s — %s\r\n"
            "# Пишет TrofPridi. Можно править и в Блокноте:\r\n"
            "# 1 — включено, 0 — выключено. Порядок ключей не важен.\r\n"
            % (ini_name, title))


def write_ini(ini_name, values, base=None, header=None):
    """Перезаписывает INI целиком: values = {секция: {ключ: значение}}.

    Пишем аккуратно, с заголовком-комментарием и CRLF — файл часто
    открывают в Блокноте. Директория создаётся сама. Возвращает путь.
    """
    path = ini_path(ini_name, base, create=True)
    lines = [header if header is not None else _ini_header(ini_name)]
    for section in values:
        lines.append("\r\n[%s]\r\n" % section)
        for key, val in values[section].items():
            if isinstance(val, bool):
                val = "1" if val else "0"
            lines.append("%s = %s\r\n" % (key, val))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write("".join(lines))
    os.replace(tmp, path)
    return path


def update_values(ini_name, updates, base=None):
    """Точечная правка: читает INI, обновляет ключи, пишет обратно.

    updates — {(секция, ключ): значение}. Между чужими правками и
    нашей записью окно гонки минимально — а ручные правки в Блокноте
    переживают целиком (секции и ключи сохраняются).
    """
    cp = read_ini(ini_name, base)
    for section in cp.sections():
        pass
    values = {s: dict(cp.items(s)) for s in cp.sections()}
    for (section, key), val in updates.items():
        if isinstance(val, bool):
            val = "1" if val else "0"
        values.setdefault(section, {})[key] = str(val)
    return write_ini(ini_name, values, base)


def _legacy_settings(base=None):
    """Старый общий settings.txt (до №51) — источник для миграции."""
    out = {}
    path = os.path.join(data_dir(base), "settings.txt")
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.split("#")[0].strip()
                if "=" not in line:
                    continue
                k, v = (p.strip() for p in line.split("=", 1))
                out[k] = v
    except OSError:
        pass
    return out


def _bool(v, default=False):
    if isinstance(v, bool):
        return v
    if v is None:
        return default
    return str(v).strip().lower() in ("1", "да", "true", "on", "yes")


def ensure_default_inis(base=None):
    """Создаёт недостающие INI с умолчаниями (миграция со settings.txt).

    Существующие файлы НЕ трогаем: чужие правки святое. Новые ключи,
    которых не хватает в существующем файле, дописываются мягко.
    Возвращает список созданных/дописанных файлов (для лога).
    """
    touched = []
    legacy = _legacy_settings(base)

    # --- stats.ini: тема, защита от скриншотов, внутренние фото-ключи
    st_path = ini_path("stats.ini", base)
    if not os.path.exists(st_path):
        write_ini("stats.ini", {
            "ui": {
                "theme": legacy.get("theme", "dark"),
                "capture_guard": legacy.get("capture_guard", "1"),
            },
            "photos": {
                "auto_purge": legacy.get("auto_purge", "1"),
                "keep_photos": legacy.get("keep_photos", "300"),
            },
        }, base)
        touched.append("stats.ini")

    # --- ini помощников
    for helper in HELPERS:
        path = ini_path(helper["ini"], base)
        values = {}
        for field in helper["fields"]:
            section, key, default = field[0], field[1], field[-1]
            # вариативность раньше жила в общем settings.txt — забираем
            if helper["key"] == "spin" and key == "variability":
                default = _bool(legacy.get("variability"), False)
            values.setdefault(section, {})[key] = default
        if not os.path.exists(path):
            write_ini(helper["ini"], values, base)
            touched.append(helper["ini"])
            continue
        # Файл есть: мягко дописываем ключи, которых не хватает (№54).
        # Существующие значения не трогаем — чужие правки святое.
        cp = read_ini(helper["ini"], base)
        merged = {s: dict(cp.items(s)) for s in cp.sections()}
        added = 0
        for section, kv in values.items():
            tgt = merged.setdefault(section, {})
            for key, val in kv.items():
                if key not in tgt:
                    tgt[key] = ("1" if val is True
                                else ("0" if val is False else str(val)))
                    added += 1
        if added:
            write_ini(helper["ini"], merged, base)
            touched.append("%s (+%d ключ.)" % (helper["ini"], added))
    return touched


# ------------------------------------------------------------ данные
def stats_csv_path(base=None):
    """Путь к stats.csv (та же логика, что в окне статистики)."""
    p = os.path.join(data_dir(base), "stats.csv")
    if not os.path.exists(p):
        legacy = os.path.join(base or script_dir(), "stats.csv")
        if os.path.exists(legacy):
            p = legacy
    return p


# ------------------------------------------------------------ маяки
# Кто кому сигналит файлом (№53):
#   бот        -> Менеджеру:  bot_state.ini  (каждую секунду)
#   статистика -> боту/нам:   alive.txt      (каждую секунду)
#   менеджер   -> боту:       manager_alive.txt (каждые 2 секунды)
BOT_STATE_NAME = "bot_state.ini"
ALIVE_STATS = "alive.txt"
ALIVE_MANAGER = "manager_alive.txt"


def alive_fresh(alive_name, max_age=6, base=None):
    """Файл-маяк свежий? У мертвого окна файл просто «протухает»."""
    path = os.path.join(data_dir(base), alive_name)
    try:
        return (time.time() - os.path.getmtime(path)) <= max_age
    except OSError:
        return False


def stats_alive(base=None):
    return alive_fresh(ALIVE_STATS, 6, base)


def manager_alive(base=None):
    return alive_fresh(ALIVE_MANAGER, 6, base)


def touch_manager_alive(base=None):
    """Менеджер отмечается «я жив» — это видит бот (№53)."""
    try:
        d = data_dir(base)
        os.makedirs(d, exist_ok=True)
        path = os.path.join(d, ALIVE_MANAGER)
        with open(path, "w", encoding="ascii") as f:
            f.write(str(int(time.time())))
    except Exception:
        pass


def clear_manager_alive(base=None):
    try:
        os.remove(os.path.join(data_dir(base), ALIVE_MANAGER))
    except OSError:
        pass
    except Exception:
        pass


# ------------------------------------------------------- процессы
def _pid_alive(pid):
    """Жив ли процесс с таким PID (кроссплатформенно)."""
    try:
        pid = int(pid or 0)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True        # сигналить нельзя, но процесс точно жив
    except (OSError, OverflowError):
        return False


_MUTEX_HANDLES = {}


def _mutex_guard(name):
    """Именованный mutex Windows (№58): одно окно на весь TrofPridi.

    В отличие от PID-файла, система отпускает mutex САМА, даже если
    процесс упал мгновенно и без finally — залочкой мёртвого окна,
    из-за которой менеджер «вообще не открывается», больше не грозит.
    True — мы первые, False — близнец уже жив, None — mutex недоступен
    (откат на PID-файл)."""
    if os.name != "nt":
        return None
    try:
        import ctypes
        ERROR_ALREADY_EXISTS = 183
        h = ctypes.windll.kernel32.CreateMutexW(
            None, False, "TrofPridi-single-%s-v1" % name)
        if not h:
            return None
        if ctypes.GetLastError() == ERROR_ALREADY_EXISTS:
            ctypes.windll.kernel32.CloseHandle(h)
            return False
        _MUTEX_HANDLES[name] = h           # держим до выхода процесса
        return True
    except Exception:
        return None


def single_instance_guard(name, base=None):
    """Одно окно приложения на весь TrofPridi (№53)."""
    got = _mutex_guard(name)
    if got is not None:
        return got
    try:
        d = data_dir(base)
        os.makedirs(d, exist_ok=True)
        lock = os.path.join(d, "%s.lock" % name)
        try:
            with open(lock, "r", encoding="ascii") as f:
                old = int((f.read() or "0").strip())
        except Exception:
            old = 0
        if old and old != os.getpid() and _pid_alive(old):
            return False
        with open(lock, "w", encoding="ascii") as f:
            f.write(str(os.getpid()))
        return True
    except Exception:
        return True


def release_instance(name, base=None):
    """Снимаем замок, если он наш (выход окна)."""
    h = _MUTEX_HANDLES.pop(name, None)
    if h:
        try:
            import ctypes
            ctypes.windll.kernel32.CloseHandle(h)
        except Exception:
            pass
    try:
        lock = os.path.join(data_dir(base), "%s.lock" % name)
        with open(lock, "r", encoding="ascii") as f:
            old = int((f.read() or "0").strip())
        if old == os.getpid():
            os.remove(lock)
    except Exception:
        pass


# ------------------------------------------------------------- №58
def boot_log(text, base=None):
    """Строчка в журнал загрузки менеджера (№58).

    Когда окно «вообще не открывается», гадать по телефону тяжело —
    процесс сам пишет каждый шаг в TrofPridi_data\\manager_boot.log,
    этот файл легко прислать. Журнал не растёт бесконечно."""
    try:
        os.makedirs(data_dir(base), exist_ok=True)
        p = os.path.join(data_dir(base), "manager_boot.log")
        try:
            if os.path.getsize(p) > 200 * 1024:
                with open(p, "rb") as f:
                    f.seek(-100 * 1024, os.SEEK_END)
                    tail = f.read().decode("utf-8", "ignore")
                with open(p, "w", encoding="utf-8") as f:
                    f.write("[обрезан журнал]\n" + tail)
        except OSError:
            pass
        with open(p, "a", encoding="utf-8") as f:
            f.write("%s  %s\n" % (time.strftime("%d.%m %H:%M:%S"), text))
    except Exception:
        pass


def wv_state(base=None):
    """Режим окна №57-58: 'ok' (своё окно работает), 'off' (только
    откат), 'try' (попытка была и умерла под ней). Файл-маркер —
    страховка от тихих падений: если прошлая попытка не дошла до
    'ok', больше своё окно не дергаем — открываемся старым режимом."""
    try:
        with open(os.path.join(data_dir(base), "manager_wv.txt"),
                  "r", encoding="ascii") as f:
            v = (f.read() or "").strip()
        return v if v in ("ok", "try", "off") else ""
    except Exception:
        return ""


def wv_state_set(value, base=None):
    try:
        os.makedirs(data_dir(base), exist_ok=True)
        with open(os.path.join(data_dir(base), "manager_wv.txt"),
                  "w", encoding="ascii") as f:
            f.write(value)
    except Exception:
        pass


# PowerShell-опрос процессов стоит сотни миллисекунд — кэшируем ответ.
_PROC_CACHE = {}
_PROC_CACHE_TTL = 3.5

_PROC_QUERIES = {
    "ahk": ("Name='AutoHotkey.exe'", "TrofPridiV3\\.5"),
    "stats": ("Name='pythonw.exe' OR Name='python.exe'",
              "stats\\.pyw|stats_app\\.py"),
    # 'manager.py' подстрокой покрывает и manager.pyw, и manager_core.py
    "manager": ("Name='pythonw.exe' OR Name='python.exe'",
                "manager\\.py"),
}


def clear_status_cache():
    """Сбросить кэш процессов — зовём сразу после Запустить/Остановить,
    чтобы карточка показала свежий статус мгновенно, а не через 3 с."""
    _PROC_CACHE.clear()


def process_running(what, base=None):
    """Есть ли в системе процесс нашего приложения(CIM/WMI, Windows).

    what: 'ahk' (бот), 'stats', 'manager'. Ищем по имени exe + куску
    командной строки — чужие python и AutoHotkey не считаем.
    """
    if os.name != "nt":
        return False
    q = _PROC_QUERIES.get(what)
    if not q:
        return False
    now = time.time()
    ent = _PROC_CACHE.get(what)
    if ent and now - ent[0] < _PROC_CACHE_TTL:
        return ent[1]
    name_filter, pattern = q
    ps = ("$m='%s';$n=0;" % pattern
          + "Get-CimInstance Win32_Process -Filter \"%s\"" % name_filter
          + " | Where-Object { $_.CommandLine -match $m }"
          + " | ForEach-Object { $n++ }; Write-Output $n")
    found = False
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            capture_output=True, text=True, timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        found = int((r.stdout or "0").strip() or "0") > 0
    except Exception:
        found = False
    _PROC_CACHE[what] = (now, found)
    return found


def _read_ini_loose(path):
    """INI с маяком ТЕРПИМО к кодировке (№78): AHK-IniWrite пишет
    новые ini в UTF-16 с BOM, а читали мы их ровно как utf-8 —
    маяк «не виделся», режим уезжал в запасную ветку, и в ТГ-меню
    вечно красовалась одна «⏸ Пауза». utf-8 → utf-16 → cp1251."""
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    for enc in ("utf-8-sig", "utf-16", "cp1251"):
        try:
            cp = configparser.ConfigParser()
            cp.read_string(raw.decode(enc))
            return cp
        except Exception:
            continue
    return None


def bot_status(base=None):
    """(состояние, подпись): running/paused/stopped для карточки.

    №53 — честный статус. ГЛАВНЫЙ источник — маяк бота: раз в секунду
    AHK пишет TrofPridi_data\\bot_state.ini (время и режим). Маяк свежий
    — это истина. Маяка нет (запущен старый бот без маяка) — смотрим
    сам процесс AutoHotkey. Ни того ни другого — бот не запущен.
    (Раньше судили по последней строке stats.csv — и запущенный бот
    выглядел «Не запущен», пока не поймает что-нибудь.)
    """
    try:
        cp = _read_ini_loose(os.path.join(data_dir(base),
                                          BOT_STATE_NAME))
        if cp is not None:
            tick = cp.get("state", "tick")
            mode = cp.get("state", "mode", fallback="running")
            ts = datetime.strptime(tick.strip(), "%Y%m%d%H%M%S")
            if (datetime.now() - ts).total_seconds() <= 6:
                if mode.strip() == "paused":
                    return "paused", "Запущен · на паузе"
                return "running", "Запущен · ловит"
    except Exception:
        pass
    if process_running("ahk"):
        return "running", "Запущен"
    return "stopped", "Не запущен"


# ------------------------------------------------------------ запуск
def _popen_no_window(args, cwd=None):
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    return subprocess.Popen(args, cwd=cwd, creationflags=flags)


def launch_bot(key, base=None):
    """Старт бота одной кнопкой. Спиннинг — по-настоящему, остальные
    пока честно отвечают «скоро» (карточка-то на месте)."""
    helper = HELPER_BY_KEY.get(key)
    if helper is None:
        return False, "Неизвестный помощник"
    if not helper["available"] or not helper["bot_file"]:
        return False, "Этот помощник ещё в разработке — скоро"
    ahk = os.path.join(base or script_dir(), helper["bot_file"])
    if not os.path.isfile(ahk):
        return False, "Файл %s не найден рядом с программой" % helper["bot_file"]
    try:
        os.startfile(ahk)                    # Windows: как двойной щелчок
        return True, "Запущен"
    except Exception:
        try:
            _popen_no_window(["cmd", "/c", "start", "", ahk],
                             cwd=base or script_dir())
            return True, "Запущен"
        except Exception as e:
            return False, "Не удалось запустить: %s" % e


def stop_bot(base=None):
    """Останавливает ТОЛЬКО нашего бота (по имени скрипта в командной
    строке процесса AutoHotkey) — чужие AHK-скрипты не задеваем.

    Точный путь — PowerShell + CIM: wmic в новых Windows 11 вырезали.
    Если и это не вышло — честно советуем F8: у бота это штатный стоп.
    """
    if os.name != "nt":
        return False, "Остановка автоматически работает только в Windows"
    ps = (
        "$m='TrofPridiV3\\.5';"
        "$p=Get-CimInstance Win32_Process -Filter \"Name='AutoHotkey.exe'\""
        " | Where-Object { $_.CommandLine -match $m };"
        "$n=($p | Measure-Object).Count;"
        "$p | ForEach-Object { Stop-Process -Id $_.ProcessId -Force };"
        "Write-Output $n")
    try:
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", ps],
            capture_output=True, text=True, timeout=30,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        n = int((r.stdout or "0").strip() or "0")
    except Exception:
        n = 0
    if n:
        return True, "Остановлен"
    st = bot_status(base)[0]
    if st == "stopped":
        return True, "Он и так не запущен"
    return False, ("Процесс не нашёлся сам — останови бота клавишей "
                   "F8 (штатный стоп)")


def launch_stats(base=None):
    """Кнопка «Открыть статистику»: поднимает stats.pyw без консоли."""
    root = base or script_dir()
    exe = os.path.join(root, "stats.pyw")
    if not os.path.isfile(exe):
        return False, "stats.pyw не найден рядом с программой"
    for runner in ("pythonw.exe", "python.exe", sys.executable):
        try:
            _popen_no_window([runner, exe], cwd=root)
            return True, "Открывается…"
        except Exception:
            continue
    return False, "Не удалось запустить статистику"


def ensure_stats_running(base=None):
    """Правило связки (№53): вместе с Менеджером поднимается и
    статистика. Уже жива (свежий alive.txt) — ничего не делаем.

    Возвращает (запускали_ли_мы, текст для статус-бара). Двойного
    окна не боимся: у статистики замок на одно окно — лишняя копия
    просто тихо выйдет.
    """
    if stats_alive(base):
        return False, "Статистика уже запущена"
    ok, msg = launch_stats(base)
    # №57: удачный запуск сообщает коротко, без лишнего текста
    # в статус-баре (старое «...стартует вместе с менеджером»
    # людям не нужно — важен только результат).
    return ok, ("Статистика запущена" if ok else msg)


def open_data_dir(base=None):
    """Открывает папку TrofPridi_data в Проводнике."""
    d = data_dir(base)
    try:
        os.makedirs(d, exist_ok=True)
        os.startfile(d)
        return True, "Открываю папку данных"
    except Exception as e:
        return False, "Не удалось открыть папку: %s" % e


# ------------------------------------------------------------ HWID
def hwid():
    """Короткий отпечаток машины: XXXX-XXXX.

    Windows: MachineGuid из реестра. Linux: /etc/machine-id.
    Полного GUID наружу не светим — хватает хвоста хеша, он стабилен
    и для сервера активации этого достаточно.
    """
    raw = ""
    try:
        if os.name == "nt":
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                               r"SOFTWARE\Microsoft\Cryptography")
            raw, _ = winreg.QueryValueEx(k, "MachineGuid")
        else:
            with open("/etc/machine-id") as f:
                raw = f.read().strip()
    except Exception:
        raw = "unknown-" + os.environ.get("COMPUTERNAME", "pc")
    h = hashlib.sha256(raw.encode("utf-8", "ignore")).hexdigest().upper()
    return "%s-%s" % (h[:4], h[4:8])


# ------------------------------------------------------------ лицензия
# №72: НАСТОЯЩИЕ подписанные ключи + триал 7 дней (до этого была
# заглушка «любой текст с дефисами = 30 дней» — оттого «всё работало
# без подписки»). Формат ключа: TP-XXXX-XXXX-XXXX-XXXX (16 знаков):
#   знаки 1-8   — HWID машины (как в карточке активации, без дефиса);
#   знак  9     — план: 1, 7 (дней), M=30 (месяц), F=навсегда;
#   знаки 10-16 — укороченная подпись HMAC-SHA256 от «hwid:план».
# Ключ действует только на машине, на чей HWID выписан. Подделка без
# секрета не считается: перебор 36^7 — миллиарды суток. Честно: AHK —
# открытый текст, от ВЗЛОМЩИКА не защитит ни одна офлайн-схема; замок
# держит обычное «скачал и ушёл», а настоящая приёмка оплаты — через
# магазин-бота (появится следующим шагом).

LICENSE_NAME = "license.json"
TRIAL_DAYS = 7
_PLAN_DAYS = {"1": 1, "7": 7, "M": 30, "F": 365000}
_PLAN_NAMES = {"1": "1 день", "7": "7 дней", "M": "30 дней",
               "F": "навсегда"}
KEY_RE = re.compile(r"^TP-(?:[0-9A-Z]{4}-){2,3}[0-9A-Z]{4}$")
KEY2_RE = re.compile(r"^TP-[0-9A-Z]{4}-[0-9A-Z]{4}-[0-9A-Z]{4}"
                     r"-[0-9A-Z]{4}$")
_KEY_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_SEC_WRAP = "Dig1PAooMz4zJiooMz4zdzc1KD8mKjU+KjMpMTt3aGpobCY+PzR3ND8+PzYjO3c3PykjOzl3NDssKT89PjsmMTYvOTIzdzQ/dyo1Pj4/Njsu"
_GEN_HASH = "2f238508bb00e502da29be19db498497674601757f1a666b0653ac56c54e07a7"


def _secret():
    import base64
    return bytes(b ^ 0x5A for b in base64.b64decode(_SEC_WRAP))


def is_keygen_password(text):
    """Пароль скрытого генератора ключей (вводится в поле ключа)."""
    t = (text or "").strip()
    if not t:
        return False
    return hashlib.sha256(t.encode("utf-8")).hexdigest() == _GEN_HASH


def _sig(hw8, plan):
    """Подпись ключа: HMAC-SHA256(hwid:план) → 7 знаков base36."""
    raw = hmac.new(_secret(), ("%s:%s" % (hw8, plan)).encode("ascii"),
                   hashlib.sha256).digest()
    n = int.from_bytes(raw[:5], "big")          # 40 бит ≥ 36^7
    chars = []
    for _ in range(7):
        chars.append(_KEY_ALPHABET[n % 36])
        n //= 36
    return "".join(reversed(chars))


def check_signed_key(key):
    """Проверка ключа на ЭТОЙ машине → (ok, план|None, ошибка)."""
    k = re.sub(r"[^0-9A-Z-]", "", (key or "").upper())
    k = re.sub(r"-{2,}", "-", k).strip("-")
    if not KEY2_RE.match(k):
        return False, None, "Ключ не похож на TP-XXXX-XXXX-XXXX-XXXX"
    g = k.split("-")[1:]
    hw, plan = g[0] + g[1], g[2][0]
    sig = g[2][1:] + g[3]
    if plan not in _PLAN_DAYS:
        return False, None, "Неизвестный план в ключе"
    if hw.startswith("FP"):
        # №83: плавучий FunPay-ключ — привязки к машине НЕТ,
        # проверяется только честная подпись свободного хвоста.
        if not hmac.compare_digest(_sig_fp(hw, plan), sig):
            return False, None, ("Подпись не сошлась — ключ не отсюда")
        return True, plan, ""
    if hw != hwid().replace("-", ""):
        return False, None, ("Ключ выписан на ДРУГОЙ компьютер — "
                             "HWID не совпадает. Попроси переписать "
                             "ключ на твой HWID (он на этой же вкладке)")
    if not hmac.compare_digest(_sig(hw, plan), sig):
        return False, None, "Подпись не сошлась — ключ не отсюда"
    return True, plan, ""


# --- плавучие ключи для FunPay (№83): БЕЗ привязки к компьютеру.
# Формат тот же TP-XXXX-XXXX-XXXX-XXXX, но вместо HWID живёт
# «FP» + 6 случайных знаков; свободный хвост подписан тем же HMAC
# с пометкой «fp:», подделать стороной не выйдет. Каждый такой
# ключ = один лот-товар на FunPay: площадка сама выдаёт покупателю
# следующий из списка. Ограничение честно: офлайн ключ не
# погасить — теоретически им можно поделиться (на цене лота
# это терпимо; привязанные ключи — через TG-магазин как раньше).

def _sig_fp(fp8, plan):
    """Подпись плавучего ключа: HMAC-SHA256("fp:FPxxxxxx:план")."""
    raw = hmac.new(_secret(), ("fp:%s:%s" % (fp8, plan))
                   .encode("ascii"), hashlib.sha256).digest()
    n = int.from_bytes(raw[:5], "big")
    chars = []
    for _ in range(7):
        chars.append(_KEY_ALPHABET[n % 36])
        n //= 36
    return "".join(reversed(chars))


def keygen_float(plan, count=5):
    """Пачка плавучих ключей для лота FunPay → список строк."""
    if plan not in _PLAN_DAYS or count < 1:
        return []
    keys, seen = [], set()
    count = min(count, 100)
    while len(keys) < count:
        rnd = "FP" + "".join(secrets.choice(_KEY_ALPHABET)
                             for _ in range(6))
        if rnd in seen:
            continue
        seen.add(rnd)
        sig = _sig_fp(rnd, plan)
        keys.append("TP-%s-%s-%s%s-%s" % (rnd[:4], rnd[4:], plan,
                                          sig[:3], sig[3:]))
    return keys


def funpay_pool(base=None):
    """Реестр выданных плавучих ключей (кто/когда — просто журнал)."""
    pool = load_license(base).get("funpay_pool") or []
    return [x for x in pool if isinstance(x, dict)]


def funpay_pool_add(keys, plan, base=None):
    lic = load_license(base)
    pool = funpay_pool(base)
    now = datetime.now().isoformat(timespec="seconds")
    for k in keys:
        pool.append({"key": k, "plan": plan, "ts": now})
    lic["funpay_pool"] = pool[-300:]          # журналируем последние 300
    return save_license(lic, base)


def keygen_make(hwid_text, plan):
    """Выписать ключ на ЧУЖОЙ HWID — скрытый генератор в Менеджере."""
    hw = re.sub(r"[^0-9A-Za-z]", "", hwid_text or "").upper()
    if len(hw) != 8 or any(c not in "0123456789ABCDEF" for c in hw):
        return None
    if plan not in _PLAN_DAYS:
        return None
    sig = _sig(hw, plan)
    return "TP-%s-%s-%s%s-%s" % (hw[:4], hw[4:], plan,
                                      sig[:3], sig[3:])


def activate_key(key, base=None):
    """Активация подписанным ключом → (ok, план-в-днях | ошибка).

    Записывает реквизиты лицензии в license.json, НЕ трогая прочие
    секции (телеграм и прочее — старая заглушка их затирала, засада).
    """
    key = re.sub(r"[^0-9A-Z-]", "", (key or "").upper())
    key = re.sub(r"-{2,}", "-", key).strip("-")
    ok, plan, err = check_signed_key(key)
    if not ok:
        return False, err
    days = _PLAN_DAYS[plan]
    now = datetime.now()
    lic = load_license(base)
    lic.update({"key": key, "hwid": hwid(), "plan_days": days,
                "activated": now.strftime("%Y-%m-%d %H:%M:%S"),
                "valid_until": (now + timedelta(days=days)).strftime(
                    "%Y-%m-%d %H:%M:%S")})
    save_license(lic, base)
    sync_license_state(base)
    return True, days


# ------------------------- триал 7 дней (№72) -------------------------
def _trial_sidecar():
    """Второй, «прятаный» маркер начала триала (рядом с системными
    конфигами пользователя): вайп папки программы его не сносит."""
    root = (os.environ.get("APPDATA")
            or os.path.join(os.path.expanduser("~"), ".config"))
    d = os.path.join(root, "TrofPridi")
    try:
        os.makedirs(d, exist_ok=True)
    except OSError:
        pass
    return os.path.join(d, "trial.dat")


def _read_trial_mark(lic, sidecar):
    """Раньшая из двух дат маркеров (anti-reset); None если ни одной."""
    fmt = "%Y-%m-%d %H:%M:%S"
    marks = []
    try:
        marks.append(datetime.strptime(
            str(lic.get("trial_start", "")).strip(), fmt))
    except Exception:
        pass
    try:
        with open(sidecar, encoding="ascii") as f:
            marks.append(datetime.strptime(f.read().strip(), fmt))
    except Exception:
        pass
    now = datetime.now()
    marks = [m if m <= now else now for m in marks]  # часы вперёд → now
    return min(marks) if marks else None


def _trial_start(base=None):
    """Дата-время старта триала (первый запуск любой программы)."""
    lic = load_license(base)
    side = _trial_sidecar()
    start = _read_trial_mark(lic, side)
    if start is None:
        start = datetime.now()
        lic["trial_start"] = start.strftime("%Y-%m-%d %H:%M:%S")
        try:
            save_license(lic, base)
        except Exception:
            pass
        try:
            with open(side, "w", encoding="ascii") as f:
                f.write(start.strftime("%Y-%m-%d %H:%M:%S"))
        except Exception:
            pass
    return start


def license_state(base=None):
    """Единая картина для замков: ("active"|"trial"|"expired", дней).

    active   — действует оплаченный ключ (left ≥ 1);
    trial    — ключа не было, триал 7 дней ещё идёт;
    expired  — триал вышел ИЛИ когда-то был ключ, но он протух
               (триал после протухшего ключа не воскресает).
    """
    active, _txt, left = activation_status(base)
    if active:
        return "active", max(1, left)
    if (load_license(base) or {}).get("key"):
        return "expired", 0
    spent = int((datetime.now() - _trial_start(base)).total_seconds()
                // 86400)
    if spent < 0:            # только что посаженный маркер = миг будущего
        spent = 0
    left = TRIAL_DAYS - spent
    return ("trial", left) if left > 0 else ("expired", 0)


def license_display(base=None):
    """(ok?, строка-статус) для карточки активации (№73).

    Раньше вечный ключ красовался «Активна до 31.12.9999 · 365000
    дн.» — дичь. Платная подписка показывается настоящая: срок и
    дата; триал — честный триал.
    """
    mode, left = license_state(base)
    if mode == "active":
        try:
            days = int((load_license(base) or {}).get("plan_days", 0)
                       or 0)
        except (TypeError, ValueError):
            days = 0
        if days >= 365000:
            return True, "Подписка: навсегда 🎉"
        try:
            end = datetime.strptime(
                str((load_license(base) or {}).get("valid_until", "")),
                "%Y-%m-%d %H:%M:%S")
            return True, ("Подписка: осталось %d дн. (до %s)"
                          % (left, end.strftime("%d.%m.%Y")))
        except (ValueError, TypeError):
            return True, "Подписка: осталось %d дн." % left
    if mode == "trial":
        return False, "Триал: осталось %d дн." % left
    return False, "Подписка не активна — нужен ключ"


LIC_STATE_NAME = "lic_state.ini"


def sync_license_state(base=None):
    """Плоский маяк замка для AHK-бота: TrofPridi_data\\lic_state.ini.

    AHK читает его на старте и раз в час: active=0 → бот молча встаёт
    (а старт показывает, чего не хватает). Файла нет (свежая установка)
    — бот работает, это триал.
    """
    try:
        mode, left = license_state(base)
        cp = configparser.ConfigParser()
        cp["lic"] = {"active": "1" if mode != "expired" else "0",
                     "mode": mode, "left": str(left)}
        d = data_dir(base)
        try:
            os.makedirs(d, exist_ok=True)
        except OSError:
            pass
        tmp = os.path.join(d, LIC_STATE_NAME + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            cp.write(f)
        os.replace(tmp, os.path.join(d, LIC_STATE_NAME))
    except Exception:
        pass


class LocalLicenseServer:
    """СОВМЕСТИМОСТЬ старого интерфейса (№72).

    Раньше было заглушкой «любой ключ вида TP-XXXX = 30 дней» — из-за
    неё «всё работало без подписки». Теперь принимает только подписан-
    ные ключи; логика в check_signed_key()/activate_key().
    """

    def activate(self, key, hw):
        key = (key or "").strip().upper()
        ok, plan, err = check_signed_key(key)
        if not ok:
            return False, err
        days = _PLAN_DAYS[plan]
        now = datetime.now()
        return True, {
            "key": key, "hwid": hw, "plan_days": days,
            "activated": now.strftime("%Y-%m-%d %H:%M:%S"),
            "valid_until": (now + timedelta(days=days)).strftime(
                "%Y-%m-%d %H:%M:%S"),
        }

    def status(self, key, hw):
        """Перепроверка записи: подпись ключа на этом железе."""
        ok, _plan, _err = check_signed_key(key)
        return ok, ("ok" if ok else _err)


def license_path(base=None):
    return os.path.join(configs_dir(base, create=True), LICENSE_NAME)


def load_license(base=None):
    try:
        with open(license_path(base), "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def save_license(data, base=None):
    path = license_path(base)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)
    return path


def activation_status(base=None):
    """(активна?, строка для интерфейса, сколько дней осталось)."""
    import math
    lic = load_license(base)
    until = lic.get("valid_until", "")
    try:
        end = datetime.strptime(until, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        return False, "Не активирована", 0
    secs = (end - datetime.now()).total_seconds()
    if secs <= 0:
        return False, ("Истекла %s — введи новый ключ"
                       % end.strftime("%d.%m.%Y")), 0
    # вверх до целых суток: план на 7 дней не должен показывать «6»
    left = int(math.ceil(secs / 86400.0))
    return True, ("Активна до %s · %d дн."
                  % (end.strftime("%d.%m.%Y"), left)), left


# ------------------------------------------------------------ telegram
# №61: Telegram-бот по-настоящему. Всё на стандартной библиотеке
# (urllib) — никаких новых зависимостей. Настройки лежат в
# license.json, секция telegram: токен бота (от @BotFather),
# chat_id пользователя и фильтры уведомлений.
TG_API = "https://api.telegram.org"


def telegram_config(base=None):
    """Настройки Telegram с безопасными значениями по умолчанию.

    photos: all — фото каждого улова; marks — только трофеи и
    зачётные; none — без фото (только текст).
    min_weight_kg: 0 — присылать всех, иначе фильтр по весу.
    commands: принимать ли команды /pause /resume /status /last.
    """
    tg = load_license(base).get("telegram") or {}
    try:
        mw = float(tg.get("min_weight_kg", 0) or 0)
    except (TypeError, ValueError):
        mw = 0.0
    photos = tg.get("photos")
    if photos not in ("all", "marks", "none"):
        photos = "all"
    return {"enabled": bool(tg.get("enabled")),
            "token": str(tg.get("token", "") or "").strip(),
            "chat_id": str(tg.get("chat_id", "") or "").strip(),
            "photos": photos,
            "min_weight_kg": max(0.0, mw),
            "commands": bool(tg.get("commands", True)),
            "proxy": str(tg.get("proxy", "") or "").strip(),
            "proxy_backup": [str(x).strip() for x in
                             (tg.get("proxy_backup") or [])
                             if str(x).strip()]}


def set_telegram_config(token="", chat_id="", enabled=False,
                        photos="all", min_weight_kg=0.0, commands=True,
                        proxy="", proxy_backup=None, base=None):
    lic = load_license(base)
    try:
        mw = max(0.0, float(min_weight_kg))
    except (TypeError, ValueError):
        mw = 0.0
    if photos not in ("all", "marks", "none"):
        photos = "all"
    if proxy_backup is None:                     # не затираем резерв
        proxy_backup = ((lic.get("telegram") or {})
                        .get("proxy_backup") or [])
    new = {"enabled": bool(enabled), "token": token.strip(),
           "chat_id": chat_id.strip(), "photos": photos,
           "min_weight_kg": mw, "commands": bool(commands),
           "proxy": proxy.strip(),
           "proxy_backup": [str(x).strip() for x in proxy_backup
                            if str(x).strip()]}
    # №77: служебные ключи секции (как kb_v — отметка о закрепе
    # кнопки «🎣 Меню») НЕ затираем: сохранение карточки в Менеджере
    # раньше сносило бы их — и кнопка шла заново.
    for k, v in ((lic.get("telegram") or {}).items()):
        if k not in new:
            new[k] = v
    lic["telegram"] = new
    return save_license(lic, base)


# ----------------------------------------------- магазин подписки
# №77: витрина бота-кассы. Реквизиты и цены живут ТОЛЬКО в локальном
# license.json (секция shop) — в коде и архиве их нет, в публичный
# репозиторий личная карта не попадает.
_SHOP_PLANS = ("1", "7", "M", "F")


def shop_config(base=None):
    """Витрина для Менеджера и бота: карта, СБП, примечание, цены.
    Пустая цена = тариф скрыт от покупателей."""
    sh = load_license(base).get("shop") or {}
    prices = {}
    for plan in _SHOP_PLANS:
        try:
            v = float(str((sh.get("prices") or {})
                          .get(plan, "") or "").replace(",", "."))
        except (TypeError, ValueError):
            v = 0.0
        if v > 0:
            prices[plan] = v
    return {"card": str(sh.get("card", "") or "").strip(),
            "sbp": str(sh.get("sbp", "") or "").strip(),
            "note": str(sh.get("note", "") or "").strip(),
            "prices": prices}


def set_shop_config(card="", sbp="", note="", prices=None, base=None):
    lic = load_license(base)
    clean = {}
    for plan in _SHOP_PLANS:
        try:
            v = float(str((prices or {}).get(plan, "") or "")
                      .replace(",", "."))
        except (TypeError, ValueError):
            v = 0.0
        if v > 0:
            clean[plan] = v
    lic["shop"] = {"card": str(card or "").strip(),
                   "sbp": str(sbp or "").strip(),
                   "note": str(note or "").strip(),
                   "prices": clean}
    return save_license(lic, base)


def telegram_promote_backup(idx, base=None):
    """№67: резервный прокси idx (=1 — первый из backup) становится
    основным; умерший основной выбрасываем. Публичные так живут."""
    lic = load_license(base)
    tg = lic.get("telegram") or {}
    bk = [x for x in (tg.get("proxy_backup") or []) if x]
    if 1 <= idx <= len(bk):
        tg["proxy"] = bk.pop(idx - 1)
        tg["proxy_backup"] = bk
        lic["telegram"] = tg
        save_license(lic, base)
        return tg["proxy"]
    return tg.get("proxy", "")


def _tg_api(token, method, payload=None, photo=None, timeout=25,
            proxy=""):
    """Один вызов Bot API — вся сеть живёт в tg_net.py (№62).

    Там прямое соединение, системный прокси Windows и явный
    socks5/http-прокси из настроек. Пусто-пусто, но зато в одном
    месте и без внешних пакетов.
    """
    try:
        import tg_net
    except ImportError:
        return False, ("нет файла tg_net.py рядом с программой — "
                       "обновись из свежего обновление.zip")
    return tg_net.api_call(token, method, payload=payload,
                           photo_path=photo, proxy=proxy, timeout=timeout)


def telegram_send(text, photo=None, base=None, keyboard=None,
                  media=None):
    """Сообщение в нашего бота. (ok, ошибка). Выключен — молча False.

    text > 1000 символов к фото режется: лимит подписи у Telegram 1024.
    keyboard — inline-кнопки под сообщением (№70, меню). В multipart
    (фото) она уходит JSON-СТРОКОЙ, в JSON-запросе — объектом.
    """
    tg = telegram_config(base)
    if not tg["enabled"]:
        return False, "Telegram выключен в настройках"
    if not tg["token"] or not tg["chat_id"]:
        return False, "не заполнены токен или Chat ID"
    cid = tg["chat_id"].strip()
    # №67: цепочка прокси (основной + запасные) — публичные умирают
    # за минуты, поэтому при отказе перескакиваем сами и запоминаем
    # новый рабочий как основной.
    eps = [tg["proxy"]] + tg["proxy_backup"]
    try:
        import tg_net
    except ImportError:
        return False, ("нет файла tg_net.py рядом с программой — "
                       "обновись из свежего обновление.zip")
    if photo and os.path.isfile(photo):
        method = ("sendAnimation" if (media and media[0] == "animation")
                  else "sendPhoto")
        payload = {"chat_id": cid, "caption": text[:1000]}
        if keyboard:
            payload["reply_markup"] = json.dumps(keyboard,
                                                 ensure_ascii=False)
        ok, out, idx = tg_net.api_call_multi(
            eps, tg["token"], method, payload=payload,
            photo_path=photo, timeout=16, media=media)
    else:
        payload = {"chat_id": cid, "text": text[:4090]}
        if keyboard:
            payload["reply_markup"] = keyboard
        ok, out, idx = tg_net.api_call_multi(
            eps, tg["token"], "sendMessage", payload=payload, timeout=16)
    if ok and idx:
        telegram_promote_backup(idx, base)
    if not ok and len(eps) > 1 and "прокси" in str(out).lower():
        out = ("%s (пробовал всю цепочку из %d прокси — пересканируй "
               "кнопкой, публичные недолговечны)" % (out, len(eps)))
    return ok, out


# Синяя пилюля «Меню» в строке ввода (как у больших ботов, №79).
_TG_COMMANDS = [
    {"command": "start",  "description": "🏠 Главное меню"},
    {"command": "menu",   "description": "🎣 Кнопки управления"},
    {"command": "shop",   "description": "🛒 Купить подписку"},
    {"command": "pause",  "description": "⏸ Пауза ловли"},
    {"command": "resume", "description": "▶ Продолжить ловлю"},
    {"command": "status", "description": "📊 Статус помощника"},
    {"command": "last",   "description": "🐟 Последний улов"},
    {"command": "help",   "description": "🆘 Помощь"},
]


def telegram_pin_menu_button(base=None):
    """Синяя кнопка «Меню» В СТРОКЕ ВВОДА (профи-вариант №79):
    setMyCommands + setChatMenuButton. Отметка kb_v=2, общая с
    OCR-помощником, дублей не будет; версия 1 (reply-клавиатура)
    снимается аккуратно."""
    try:
        lic = load_license(base)
        tg = lic.get("telegram") or {}
        v = tg.get("kb_v")
        if v == 2 or not tg.get("token") or not tg.get("chat_id"):
            return False
        try:
            import tg_net
        except ImportError:
            return False
        eps = ([str(tg.get("proxy", "") or "")] +
               [str(x) for x in (tg.get("proxy_backup") or [])])

        def call(method, payload):
            ok, out, idx = tg_net.api_call_multi(
                eps, tg["token"], method, payload=payload, timeout=16)
            if ok and idx:
                telegram_promote_backup(idx, base)
            return ok

        ok1 = call("setMyCommands", {"commands": _TG_COMMANDS})
        ok2 = call("setChatMenuButton",
                   {"menu_button": {"type": "commands"}})
        if v == 1:
            call("sendMessage",
                 {"chat_id": tg["chat_id"],
                  "text": "Кнопка «Меню» переехала в строку ввода "
                          "(синяя пилюля слева) 👇",
                  "reply_markup": {"remove_keyboard": True}})
        if ok1 and ok2:
            tg["kb_v"] = 2
            lic["telegram"] = tg
            save_license(lic, base)
        return ok1 and ok2
    except Exception:
        return False


def telegram_notify(text, base=None):
    """Короткая обёртка для простых текстовых уведомлений."""
    return telegram_send(text, base=base)


_TG_PHOTO_LABELS = {"all": "все", "marks": "трофеи и зачётные",
                    "none": "без фото"}


def tg_menu_markup(photos="all", min_weight_kg=0.0, mode="running"):
    """Главный экран кнопок меню бота (№70).

    СИНХРОННО с ocr_watch._tg_menu_markup (там же живут подэкраны
    выбора фото/веса и обработка самих нажатий).
    """
    def btn(text, data):
        return {"text": text, "callback_data": data}
    if photos not in _TG_PHOTO_LABELS:
        photos = "all"
    try:
        mw = float(min_weight_kg)
    except (TypeError, ValueError):
        mw = 0.0
    wl = "все" if mw <= 0 else ("от %s кг" % ("%g" % mw))
    if mode == "paused":
        row1 = [btn("▶ Включить (снять с паузы)", "tp:resume")]
    elif mode == "stopped":
        row1 = [btn("🚀 Запустить бота", "tp:start")]
    else:
        row1 = [btn("⏸ Пауза (выключить)", "tp:pause")]
    return {"inline_keyboard": [
        row1,
        [btn("📊 Статус", "tp:status"),
         btn("🐟 Последний улов", "tp:last")],
        [btn("📷 Фото: " + _TG_PHOTO_LABELS[photos], "tp:photos"),
         btn("⚖ Вес: " + wl, "tp:weight")],
        # №78: магазин — В ТЕЛЕГРАМЕ (управление кнопками хозяина)
        [btn("🛒 Магазин подписки", "tp:shop")],
    ]}


def telegram_test(base=None):
    """Кнопка «Проверить связь» (№68 — подбирает Chat ID САМА).

    Пойманная ситуация: связь до Telegram есть, прокси живой, а в
    Chat ID вписан ник самого бота (@TrofPridiBot) — Telegram
    вежливо отказывает, человек решает, что «ничего не работает».
    Теперь тест честно разделяет три этапа и чинит третий сам:
      1) getMe — дошли до Telegram? бот жив?
      2) sendMessage на записанный Chat ID — дошло? зелёное;
      3) не дошло — смотрим getUpdates, КТО писал боту, подставляем
         ЕГО chat id и шлём повторно. Про «числовой ID» человеку
         знать вообще не нужно: написал боту /start — и всё.
    Проверка работает независимо от выключателя уведомлений —
    это же проверка.
    """
    tg = telegram_config(base)
    if not tg["token"]:
        return False, "сначала впиши токен бота и нажми «Сохранить»"
    try:
        import tg_net
    except ImportError:
        return False, ("нет файла tg_net.py рядом с программой — "
                       "обновись из свежего обновление.zip")

    def call(method, payload=None, photo=None, media=None):
        cfg = telegram_config(base)   # прокси могли переставить — свежие
        eps = [cfg["proxy"]] + cfg["proxy_backup"]
        ok, out, idx = tg_net.api_call_multi(eps, cfg["token"], method,
                                             payload=payload,
                                             photo_path=photo, timeout=16,
                                             media=media)
        if ok and idx:
            telegram_promote_backup(idx, base)
        return ok, out

    ok, out = call("getMe")
    if not ok:
        return False, out
    me = ""
    try:
        un = (out.get("result") or {}).get("username")
        if un:
            me = " @" + un
    except Exception:
        pass

    # №70: успешная проверка = в чат САМО вылетает МЕНЮ с картинкой
    # и кнопками — человек сразу видит, что бот живой и «с кнопками».
    # №71: обложка меню — живой ГИФ; старый всплеск — запасной вариант
    splash = media = None
    for cand, mk in (("tg_menu.gif", ("animation", "image/gif",
                                      "menu.gif")),
                     ("splash_fish.png", None)):
        _p = os.path.join(base or script_dir(), "assets", cand)
        if os.path.isfile(_p):
            splash, media = _p, mk
            break

    def send_menu(cid):
        cfg = telegram_config(base)
        mode, _lbl = bot_status(base)
        kb = tg_menu_markup(cfg["photos"], cfg["min_weight_kg"], mode)
        mtxt = {"running": "🎣 ловит", "paused": "⏸ на паузе",
                "stopped": "⭕ не запущен"}.get(mode)
        caption = ("🎣 TrofPridi на связи! %sЖми кнопки снизу ↓"
                   % (("Помощник: %s. " % mtxt) if mtxt else ""))
        if splash:
            return call("sendAnimation" if media else "sendPhoto",
                        {"chat_id": cid, "caption": caption,
                         "reply_markup": json.dumps(kb,
                                                    ensure_ascii=False)},
                        photo=splash, media=media)
        return call("sendMessage",
                    {"chat_id": cid, "text": caption,
                     "reply_markup": kb})

    cid = tg["chat_id"].strip()
    err = "поле Chat ID пустое"
    if cid:
        ok, err = send_menu(cid)
        if ok:
            telegram_pin_menu_button(base)      # №78: «🎣 Меню» снизу
            return True, ("✔ Бот%s на связи! В чат улетело МЕНЮ "
                          "с кнопками — проверь Telegram!" % me)
    # лечим сами: кто написал боту — тот чат и нужен
    ok, chats, _ = telegram_find_chat(base)
    if ok and chats:
        want, label = chats[-1]           # самое свежее сообщение боту
        if want != cid:
            # ВАЖНО: все поля существующие — один chat_id меняем,
            # а без их передачи токен и выключатель сбросились бы.
            cfg = telegram_config(base)
            set_telegram_config(token=cfg["token"], chat_id=want,
                                enabled=cfg["enabled"],
                                photos=cfg["photos"],
                                min_weight_kg=cfg["min_weight_kg"],
                                commands=cfg["commands"],
                                proxy=cfg["proxy"], base=base)
            ok2, _err2 = send_menu(want)
            if ok2:
                telegram_pin_menu_button(base)  # №78: «🎣 Меню» снизу
                return True, ("✔ Бот%s на связи! Chat ID был неверный — "
                              "подставил сам чат «%s». В чат улетело меню "
                              "с кнопками — проверь Telegram!"
                              % (me, label))
    return False, ("Бот%s живой и до Telegram дорога есть! Осталось "
                   "одно: %s" % (me, err))


def telegram_find_chat(base=None):
    """Chat ID из входящих сообщений бота — кнопка «Определить».

    Люди пишут нашему боту /start, мы читаем последние апдейты и
    достаём их chat id. Возвращает (ok, [(chat_id, подпись)], err).
    Отрицательный offset у getUpdates НЕ подтверждает апдейты —
    поллеру OCR-компаньона ничего не ломаем.
    """
    tg = telegram_config(base)
    if not tg["token"]:
        return False, [], "сначала впиши токен бота"
    try:
        import tg_net
    except ImportError:
        return False, [], ("нет файла tg_net.py рядом с программой — "
                           "обновись из свежего обновление.zip")
    # №68: тоже по цепочке прокси (раньше — только через основной:
    # умрёт он — и «Определить Chat ID» не работало, хотя резерв жив)
    eps = [tg["proxy"]] + tg["proxy_backup"]
    ok, out, idx = tg_net.api_call_multi(
        eps, tg["token"], "getUpdates",
        payload={"offset": -10, "limit": 10, "timeout": 0}, timeout=16)
    if not ok:
        return False, [], out
    if idx:
        telegram_promote_backup(idx, base)
    found, seen = [], set()
    for upd in out.get("result") or []:
        msg = upd.get("message") or upd.get("channel_post") or {}
        chat = msg.get("chat") or {}
        cid = chat.get("id")
        if cid is None or cid in seen:
            continue
        seen.add(cid)
        nm = " ".join(x for x in (chat.get("first_name"),
                                  chat.get("last_name")) if x)
        un = chat.get("username")
        label = ("%s · @%s" % (nm, un) if un else nm) \
            or chat.get("title") or str(cid)
        found.append((str(cid), label))
    if found:
        return True, found, ""
    return True, [], ("пока пусто: напиши своему боту /start "
                      "и нажми кнопку ещё раз")


def telegram_scan_proxies(base=None):
    """Кнопка «Найти рабочий прокси» (№63).

    Перебирает локальные прокси (TgWsProxy, Tor, Clash, v2rayN…) и
    через каждый делает настоящий HTTPS-запрос до Bot API.
    Возвращает ((url, подпись) | None, сколько портов было открыто).
    """
    try:
        import tg_net
    except ImportError:
        return None, 0
    tg = telegram_config(base)
    found, tried = tg_net.scan_local_proxies(token=tg["token"])
    if not found:
        return None, tried
    kind, host, port, label = found
    return ("%s://%s:%d" % (kind, host, port), label), tried


def telegram_scan_public(on_progress=None, base=None):
    """Кнопка «Найти публичный прокси» (№66) — совсем без скачиваний.

    Качает свежие списки с GitHub и проверяет каждый настоящим
    HTTPS-запросом до Bot API. Чужой прокси читать трафик не может:
    он шифрован HTTPS до самого Telegram. Возвращает
    ((url, подпись) | None, сколько скачано, сколько откликнулось).
    """
    try:
        import tg_net
    except ImportError:
        return None, None, 0, 0
    tg = telegram_config(base)
    found, total, alive = tg_net.scan_public_proxies(
        token=tg["token"], on_progress=on_progress)
    if not found:
        return None, None, total, alive
    urls = ["%s://%s:%d" % (k, h, p) for k, h, p, _l in found]
    # №67: первый — основной, остальные спасают, когда он умрёт.
    set_telegram_config(tg["token"], tg["chat_id"], tg["enabled"],
                        photos=tg["photos"],
                        min_weight_kg=tg["min_weight_kg"],
                        commands=tg["commands"],
                        proxy=urls[0], proxy_backup=urls[1:], base=base)
    return urls, found[0][3], total, alive


if __name__ == "__main__":
    # ручной прогон: создать недостающие INI и показать сводку
    made = ensure_default_inis()
    print("configs:", configs_dir(create=True))
    print("создано:", made or "ничего (всё на месте)")
    print("статус бота:", bot_status())
    print("статистика жива:", stats_alive())
    print("HWID:", hwid())
    print("лицензия:", activation_status())

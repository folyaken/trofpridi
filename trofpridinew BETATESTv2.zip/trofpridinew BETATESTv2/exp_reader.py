# -*- coding: utf-8 -*-
"""
Чтение итогового опыта из панели улова — по расположению плашек.

Зачем отдельный движок
----------------------
Windows OCR отдаёт панель одной плоской строкой. Порядок слов в ней
непредсказуем: то «3 348 ВСЕГО ОЧКОВ ОПЫТА», то сначала все числа, а
подписи следом. Приходится угадывать, какое число к какой подписи
относится, — и на этом мы уже дважды ошибались:

  * «3   348» разрывалось на два числа, в журнал уходило 348;
  * «216     648» склеивалось в 216648;
  * у первой колонки подпись тоже «ОЧКОВ ОПЫТА», и метка цеплялась
    к базовому опыту вместо итога.

RapidOCR возвращает КАЖДЫЙ блок текста с координатами. Тогда гадать не
нужно: находим подпись «ВСЕГО» и берём число, которое стоит прямо над
ней. Как OCR исказил буквы и в каком порядке выдал блоки — неважно.

Почему именно RapidOCR
----------------------
Это модели PaddleOCR, запущенные через ONNX Runtime от Microsoft.
Обычная библиотека распознавания изображений: 382 МБ против 5.1 ГБ у
EasyOCR, и без PyTorch. Она не знает и не может знать, что за картинку
ей передали, — никакого взаимодействия с игрой здесь нет, мы работаем
с готовым снимком экрана.

Кириллицу базовая модель читает плохо («ОЧКОВ ОПЫТА» превращается в
«OHKOB ONbITA»), поэтому НАЗВАНИЕ РЫБЫ ей не доверяем — его по-прежнему
читает Windows OCR. А вот цифры она распознаёт уверенно, и для чисел
опыта этого достаточно.
"""

import re

# Подпись «ВСЕГО» с поправкой на подмену кириллицы латиницей.
# RapidOCR выдаёт «BCEFOO4KOB» (ВСЕГО ОЧКОВ слитно: Г читает как F,
# Ч как 4), Windows OCR — «ВСЕГО». Ищем начало слова в обоих
# алфавитах и не требуем точного попадания в середину.
_VSEGO = re.compile(r"[ВB][СCc][ЕE][ГГlrTtFf]{0,2}[ОO0]", re.I)

# Блок целиком из цифр (возможно с разделителем разрядов).
# Плюс в начале — это бонусная плашка, её отбрасываем: нужен итог.
_PLAIN_NUM = re.compile(r"^\d[\d\s\u00a0\u2009\u202f]*$")
_BONUS_NUM = re.compile(r"^\+")


def _digits(s):
    d = re.sub(r"\D", "", s or "")
    return int(d) if d else None


def _center(box):
    """Середина рамки блока. RapidOCR отдаёт четыре угла."""
    xs = [p[0] for p in box]
    ys = [p[1] for p in box]
    return sum(xs) / len(xs), sum(ys) / len(ys)


def _repair_total(v, want):
    """Чинит итог по сумме слагаемых, если разница объяснима.

    Панель устроена так, что итог всегда равен сумме остальных плашек:
    1116 + 1116 + 1116 = 3348. Это бесплатная проверка, и она ловит
    две устойчивые ошибки распознавания:

      * «348» вместо «3348» — потерянная ведущая цифра (сумма 3348
        оканчивается на прочитанное «348»);
      * «216648» вместо «648» — слева прилипла соседняя плашка
        (прочитанное оканчивается на настоящую сумму).

    Если ничего не сошлось — возвращаем как есть: позиция числа над
    подписью «ВСЕГО» сама по себе надёжный признак.
    """
    if v == want or want < 10:
        return v
    sv, sw_ = str(v), str(want)
    if len(sw_) > len(sv) and sw_.endswith(sv):
        return want
    if len(sv) > len(sw_) and sv.endswith(sw_):
        return want
    return v


def _rescue_total(value, parts):
    """Ищет среди чисел панели ПОДМНОЖЕСТВО слагаемых, чья сумма
    объясняет прочитанный итог, и чинит его.

    Общая сумма всех чисел разом ломается о «лишнее» число в кадре
    (рядом стоит бонус за отпуск рыбы «+1 028»): «086 ВСЕГО» чинить
    было не на что, и в журнал уезжало 86 вместо 3086. Подмножество
    {1543, 1543} даёт ровно 3086 — и объясняет обрывок.

    Два узнаваемых искажения (см. такой же чинильщик в ocr_watch):
      A. потеряны ведущие цифры — сумма длиннее и оканчивается на
         прочитанное («86» -> «3086»), берём наименьшую сумму;
      Б. слева прилипло чужое число — прочитанное оканчивается на
         сумму («216648» -> «648»), берём наибольшую.

    Разница в длине — не больше трёх цифр, иначе созвучие случайно.
    """
    cand = [n for n in parts if n and n >= 10 and n != value]
    if not cand:
        return value
    if len(cand) > 14:
        cand = cand[:14]
    sv = str(value)
    best_a, best_b = None, None
    from itertools import combinations
    for r in range(1, len(cand) + 1):
        for combo in combinations(cand, r):
            s = sum(combo)
            if s == value or s < 10:
                continue
            ss = str(s)
            if (s > value and len(ss) - len(sv) <= 3
                    and ss.endswith(sv)):
                if best_a is None or s < best_a:
                    best_a = s
            elif (s < value and len(sv) - len(ss) <= 3
                    and sv.endswith(ss)):
                if best_b is None or s > best_b:
                    best_b = s
    if best_a is not None:
        return best_a
    if best_b is not None:
        return best_b
    return value


def total_from_blocks(blocks, min_value=10, max_value=9999999,
                      img_w=None):
    """Итоговый опыт из распознанных блоков.

    blocks — список (рамка, текст, уверенность) от RapidOCR.

    Ищем подпись «ВСЕГО» и берём ближайшее к ней ЧИСЛО СВЕРХУ: в панели
    цифра всегда над подписью. Если подписи нет (узкая панель без
    бонусов), возвращаем None — пусть решает обычный разбор текста.

    Потолок 9 999 999: семизначные миллионы у морских гигантов реальны,
    а восьмизначной дичи не бывает вообще.
    """
    v = _total_core(blocks, min_value, max_value, img_w)
    if v is not None:
        return v
    return _fused_total(blocks, min_value, max_value)


def _total_core(blocks, min_value, max_value, img_w):
    labels, numbers, bonuses = [], [], []
    for item in blocks or ():
        try:
            box, text = item[0], str(item[1]).strip()
        except Exception:
            continue
        if not text:
            continue
        cx, cy = _center(box)
        # Пробелы внутри подписи убираем: «ВСЕГО ОЧКОВ» приходит слитно
        # и с пробелами в разных кадрах по-разному.
        packed = text.replace(" ", "")
        if _VSEGO.search(packed):
            labels.append((cx, cy, packed))
        # Число может приехать слитно с круглым бейджем «XP» над ним.
        cand = re.sub(r"^[XХх][PРр]\s*", "", text)
        cand = re.sub(r"\s*[XХх][PРр]$", "", cand)
        if _BONUS_NUM.match(cand):
            # Бонусная плашка: не итог, но пригодится для суммы.
            bv = _digits(cand)
            if bv is not None:
                bonuses.append((cx, cy, bv))
            continue                      # «+1 116» — бонус, не итог
        if _PLAIN_NUM.match(cand):
            v = _digits(cand)
            if v is not None:
                numbers.append((cx, cy, v))

    if not labels:
        return None

    # Подписей может быть несколько («ВСЕГО ОЧКОВ» и «ОПЫТА» отдельными
    # блоками) — берём самую правую: колонка итога всегда крайняя.
    lx, ly, ltext = max(labels, key=lambda p: p[0])

    # Подпись могла слипнуться с числом в один блок («501 BCEFOO4KOB»).
    dm = re.search(r"\d[\d\s]*\d|\d", ltext)
    if dm:
        v = _digits(dm.group(0))
        if v and min_value <= v <= max_value:
            return v

    if not numbers:
        return None

    # Число должно быть ВЫШЕ подписи и рядом по горизонтали. У своей
    # колонки центры почти совпадают, у соседней — полторы сотни
    # пикселей вбок. Раньше соседнюю плашку могли принять за свою,
    # когда настоящее число не прочиталось: порог был слишком широким.
    # Дистанция — в доле ширины кадра: панель растёт вместе с экраном.
    dx_max = (img_w or 1200) * 0.08
    above = [n for n in numbers
             if n[1] < ly and min_value <= n[2] <= max_value]
    if not above:
        return None
    best = min(above, key=lambda n: (abs(n[0] - lx), ly - n[1]))
    # Слишком далеко вбок — значит это чужая колонка, а не наша.
    if abs(best[0] - lx) > dx_max:
        return None
    v = best[2]

    # Проверка здравого смысла: итог равен сумме остальных плашек.
    # Плюсы бонусов OCR часто отрывает от чисел («+» отдельно, «133»
    # отдельно), поэтому сумму считаем и по бонусным тоже. Ремонт —
    # по ПОДМНОЖЕСТВАМ: рядом с панелью стоит бонус за отпуск рыбы,
    # и общая сумма с ним не сходится.
    parts = [n[2] for n in numbers if abs(n[0] - lx) > dx_max]
    parts += [b[2] for b in bonuses]
    if parts:
        v = _rescue_total(v, parts)
    return v if min_value <= v <= max_value else None


def _fused_total(blocks, min_value, max_value):
    """Достаёт итог из блока, в который склеились ДВЕ соседние плашки.

    Детектор иногда объединяет две цифры одной строки в один блок:
    «+731250 1 462 500» превращается в «+7312501462500». Такой блок
    принимали за «бонус» (начинается с плюса) и отбрасывали целиком —
    и итог терялся. Особенно обидно это у крупной рыбы: чем длиннее
    числа, тем больше шанс склейки.

    Разбираем по инварианту игры: итог == сумме остальных плашек.
    Отрезаем справа длинной цифровой строки кандидата в итог, а левый
    кусок пробуем разбить на 1-3 плашки (в блок могли попасть и
    «база + бонус + итог» разом). Разрез засчитывается, только если
    левые части + остальные числа панели ровно дают правую.
    """
    nums, blobs = [], []
    for item in blocks or ():
        try:
            box, text = item[0], str(item[1]).strip()
        except Exception:
            continue
        if not text:
            continue
        cand = re.sub(r"^[XХх][PРр]\s*", "", text)
        cand = re.sub(r"\s*[XХх][PРр]$", "", cand)
        d = re.sub(r"\D", "", cand)
        if not d:
            continue
        if len(d) >= 8:
            blobs.append(d)         # 8+ цифр — это склейка, не число
            continue
        v = int(d)
        if min_value <= v <= max_value:
            nums.append(v)
    for d in blobs:
        for cut in range(1, len(d)):
            right = int(d[cut:])
            if not min_value <= right <= max_value:
                continue
            if _split_sum(d[:cut], nums, right, min_value):
                return right
    return None


def _split_sum(left, nums, target, min_value):
    """Можно ли разбить строку цифр так, что вместе с nums выйдет target.

    left — цифры ЛЕВЕЕ кандидата в итог: там одна-три плашки.
    Перебираем разбивки на 1-3 числа, каждое правдоподобное.
    """
    from itertools import combinations
    L = len(left)
    for k in range(0, min(3, L - 1)):
        for cuts in combinations(range(1, L), k):
            parts, prev, ok = [], 0, True
            for cp in list(cuts) + [L]:
                piece = int(left[prev:cp])
                prev = cp
                if piece < min_value:
                    ok = False
                    break
                parts.append(piece)
            if ok and parts and sum(nums) + sum(parts) == target:
                return True
    return False


# Как RapidOCR пишет кириллицу латиницей.
#
# Его модели обучены на китайском и английском, русской модели в пакете
# нет. Но буквы он различает верно — просто подбирает похожие латинские
# начертания: «Ж» видит как «XK», «ы» как «bI», «п» как «n». Это
# устойчивое соответствие, и по нему слово восстанавливается.
_RAPID_TO_CYR = str.maketrans({
    "X": "ж", "K": "к", "e": "е", "p": "р", "x": "х", "o": "о", "O": "о",
    "a": "а", "A": "а", "B": "в", "b": "ь", "H": "н", "M": "м", "T": "т",
    "C": "с", "P": "р", "y": "у", "n": "п", "N": "п", "6": "б", "I": "ы",
    "「": "г", "u": "и", "3": "з", "4": "ч", "0": "о", "l": "ь", "i": "и",
    "c": "с", "m": "м", "t": "т", "h": "н", "r": "г", "g": "д", "s": "ѕ",
})


def rapid_to_fish(raw, known):
    """Восстанавливает русское название по «латинице» от RapidOCR.

    Возвращает имя из справочника или пустую строку, если ничего
    похожего нет. Порог сходства намеренно мягкий: транслитерация
    приблизительная, зато выбор ограничен готовым списком видов, и
    случайный текст в него всё равно не попадёт.
    """
    import difflib
    if not raw or not known:
        return ""
    words = []
    for w in str(raw).split():
        w = "".join(ch for ch in w.translate(_RAPID_TO_CYR) if ch.isalpha())
        if w:
            words.append(w.lower())
    g = " ".join(words)
    if len(g) < 3:
        return ""
    low = [f.lower() for f in known]
    # Сравниваем со ВСЕМИ названиями и берём лучшее. get_close_matches
    # останавливается на первом подходящем, из-за чего короткое имя
    # выигрывало у более точного длинного.
    best = max(range(len(low)),
               key=lambda i: difflib.SequenceMatcher(None, g, low[i]).ratio())
    if difflib.SequenceMatcher(None, g, low[best]).ratio() >= 0.5:
        return known[best]
    # Составные названия: первое слово опознаётся надёжнее прочих.
    first = g.split()[0]
    sc = sorted(((difflib.SequenceMatcher(None, first,
                                          low[i].split()[0]).ratio(), i)
                 for i in range(len(low))), reverse=True)
    return known[sc[0][1]] if sc and sc[0][0] >= 0.6 else ""


def tighten(img, thr=150, pad=8):
    """Обрезает картинку по границам светлого текста.

    Зона имени втрое шире самого слова: у «Жереха» текст занимает 22%
    кадра, у «Язя» и того меньше. Детектор текста на таком фоне часто
    не находит ничего вовсе. После обрезки слово занимает почти весь
    кадр, и распознавание срабатывает — проверено: там, где раньше
    возвращалась пустота, теперь читается «XKepex».
    """
    try:
        import numpy as np
        a = np.asarray(img.convert("L"))
        m = a > thr
        cols = np.where(m.sum(axis=0) > 0)[0]
        rows = np.where(m.sum(axis=1) > 0)[0]
        if not len(cols) or not len(rows):
            return img
        return img.crop((max(0, int(cols.min()) - pad),
                         max(0, int(rows.min()) - pad),
                         min(img.width, int(cols.max()) + pad),
                         min(img.height, int(rows.max()) + pad)))
    except Exception:
        return img


class RapidExpReader:
    """Обёртка над RapidOCR. Молча отключается, если он не установлен.

    Движок тяжёлый (модели ~90 МБ) и грузится около секунды, поэтому
    создаётся один раз и только при первом обращении.
    """

    def __init__(self):
        self.ok = False
        self.error = ""
        self._engine = None

    def enabled(self):
        """Стоит ли вообще обращаться к движку.

        Первая попытка загрузки может занять секунду, а если пакета нет,
        повторять её на каждой рыбе бессмысленно. После неудачи молчим
        навсегда — опыт будет читаться обычным способом.
        """
        return self._engine is not False

    def _ensure(self):
        if self._engine is not None:
            return self.ok
        try:
            from rapidocr_onnxruntime import RapidOCR
            self._engine = RapidOCR()
            self.ok = True
        except ImportError:
            self.error = ("Нет пакета rapidocr-onnxruntime. "
                          "Установи: pip install rapidocr-onnxruntime")
            self._engine = False
        except Exception as e:
            self.error = f"RapidOCR недоступен: {e}"
            self._engine = False
        return self.ok

    def read_name(self, pil_img, known):
        """Название рыбы — запасной путь, когда Windows OCR смолчал.

        Короткие имена («Язь», «Ёрш», «Сом») встроенный движок нередко
        не находит вообще. Здесь картинка сначала обрезается по тексту,
        а результат восстанавливается из «латиницы» по справочнику.
        """
        if not self._ensure():
            return ""
        try:
            import numpy as np
            img = tighten(pil_img.convert("RGB"))
            res = self._engine(np.array(img))
            blocks = res[0] if isinstance(res, tuple) else res
            if not blocks:
                return ""
            raw = " ".join(str(b[1]) for b in blocks)
            return rapid_to_fish(raw, known)
        except Exception:
            return ""

    def read_total(self, pil_img):
        """Итоговый опыт с картинки или None."""
        if not self._ensure():
            return None
        try:
            import numpy as np
            # Картинку НЕ уменьшаем. Замеры: 984x150 и 688x105 читаются
            # за одно и то же время (~1.6 с — оно уходит на поиск текста,
            # а не на его размер), а при уменьшении вдвое цифры плывут и
            # панель перестаёт распознаваться вовсе.
            img = pil_img.convert("RGB")
            res = self._engine(np.array(img))
            blocks = res[0] if isinstance(res, tuple) else res
            v = total_from_blocks(blocks, img_w=img.width)
            if v is not None:
                return v
            # Подпись «ВСЕГО ОЧКОВ ОПЫТА» мелкая — движок мог не найти
            # её вовсе, и тогда опыт пропадал целиком. Пробуем ещё раз
            # на увеличенном кадре: мелкий капс читается заметно лучше.
            # Это дольше, но случается раз в улов, после закрытия окна.
            from PIL import Image as _PIm
            big = img.resize((img.width * 2, img.height * 2),
                             _PIm.LANCZOS)
            res = self._engine(np.array(big))
            blocks = res[0] if isinstance(res, tuple) else res
            return total_from_blocks(blocks, img_w=big.width)
        except Exception:
            return None

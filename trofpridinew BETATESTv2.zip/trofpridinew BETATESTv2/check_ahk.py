#!/usr/bin/env python3
"""
Грубая статическая проверка AHK v1 скрипта.
Не заменяет запуск, но ловит структурные ошибки: несбалансированные
скобки, v2-only синтаксис, вызовы несуществующих функций/меток.
"""
import re
import sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "TrofPridi_v4.0.ahk")
# utf-8-sig: у файла есть BOM — без неё в первую строку влезал \ufeff
raw = path.read_text(encoding="utf-8-sig")
lines = raw.split("\n")


def strip_comment(line: str) -> str:
    """Убирает ; комментарии, уважая строки в кавычках."""
    out, in_str, i = [], False, 0
    while i < len(line):
        ch = line[i]
        if ch == '"':
            # "" внутри строки — экранированная кавычка
            if in_str and i + 1 < len(line) and line[i + 1] == '"':
                out.append('""')
                i += 2
                continue
            in_str = not in_str
        if ch == ";" and not in_str:
            stripped = "".join(out)
            if stripped.strip() == "" or stripped[-1:] in (" ", "\t"):
                break
        out.append(ch)
        i += 1
    return "".join(out)


problems, warnings = [], []

# --- continuation-секции ( ... ) пропускаем целиком -------------------
in_cont = False
clean = []
for n, line in enumerate(lines, 1):
    s = line.strip()
    if not in_cont and re.match(r"^\($", s):
        in_cont = True
        clean.append((n, ""))
        continue
    if in_cont:
        if re.match(r"^\)", s):
            in_cont = False
        clean.append((n, ""))
        continue
    clean.append((n, strip_comment(line)))

# --- 1. баланс фигурных скобок ---------------------------------------
depth = 0
for n, line in clean:
    for ch in line:
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth < 0:
                problems.append(f"строка {n}: лишняя }}")
                depth = 0
if depth != 0:
    problems.append(f"итог: незакрытых {{ = {depth}")

# --- 2. баланс круглых скобок по строкам ------------------------------
# В AHK v1 строка, начинающаяся с ",", "or", "and" (и подобных),
# является продолжением предыдущего выражения. Считать скобки по
# физическим строкам давало ложные «непарные ( )» на перенесённых
# аргументах — склеиваем такие строки в логические.
logical = []
for n, line in clean:
    s = line.strip()
    if logical and re.match(r"^(,|or\b|and\b|&&|\|\|)", s, re.I):
        logical[-1][1] += " " + s
    else:
        logical.append([n, line])
for n, line in logical:
    # {LShift Down} и подобное не мешает; считаем только ( )
    if line.count("(") != line.count(")"):
        s = line.strip()
        if s and not s.endswith(","):
            warnings.append(f"строка {n}: непарные ( ) -> {s[:70]}")

# --- 3. AHK v2-only конструкции ---------------------------------------
v2_patterns = [
    (r"CoordMode,\s*ImageSearch", "CoordMode ImageSearch — только в v2"),
    (r"^\s*MsgBox\s*\(", "MsgBox() как функция — v2"),
    (r"^\s*Sleep\s*\(", "Sleep() как функция — v2"),
    (r":=\s*Map\(", "Map() — v2"),
    (r"^\s*try\s*$", "try без скобок — v2 стиль"),
]
for n, line in clean:
    for pat, msg in v2_patterns:
        if re.search(pat, line, re.I):
            problems.append(f"строка {n}: {msg}")

# --- 4. функции и метки ------------------------------------------------
defined_funcs, defined_labels = set(), set()
for n, line in clean:
    m = re.match(r"^([A-Za-z_]\w*)\s*\([^)]*\)\s*\{?\s*$", line)
    if m and m.group(1).lower() not in ("if", "while", "for", "return", "loop"):
        defined_funcs.add(m.group(1).lower())
    m = re.match(r"^([A-Za-z_]\w*):\s*$", line)
    if m:
        defined_labels.add(m.group(1).lower())

builtin = {
    "strsplit", "instr", "round", "ceil", "floor", "abs", "mod", "format",
    "format time", "regexmatch", "regexreplace", "strreplace", "substr",
    "fileexist", "strlen", "trim", "ltrim", "rtrim", "sleep", "onmessage",
    "postmessage", "soundbeep", "func", "isobject", "dllcall", "wingetpos",
    "settimer", "guicontrol", "objhaskey", "strget", "numget", "min", "max",
    # Встроенные функции v1, которых раньше не хватало — линтер
    # помечал их как «вызов не найденной функции».
    "loadpicture", "varsetcapacity", "chr", "comobjget", "comobjcreate",
    "loadimage", "objaddref", "objrelease", "numput",
}

called = {}
for n, line in clean:
    for m in re.finditer(r"\b([A-Za-z_]\w*)\s*\(", line):
        # Вызов метода (объект.метод(...)) проверять по списку своих
        # функций нельзя — иначе ImgCache.HasKey() и wmi.ExecQuery()
        # отмечались как несуществующие.
        if m.start() > 0 and line[m.start() - 1] == ".":
            continue
        name = m.group(1).lower()
        if name in ("if", "while", "for", "return", "and", "or", "not", "loop"):
            continue
        called.setdefault(name, n)

for name, n in called.items():
    if name not in defined_funcs and name not in builtin:
        warnings.append(f"строка {n}: вызов не найденной функции {name}()")

# --- 4b. режим области видимости функций (частая ошибка загрузки) ------
# Правило AHK v1:
#   первая строка "global" (голое слово)  -> assume-global, local ОБЯЗАТЕЛЕН
#   первая строка "global A, B" (список)  -> assume-local,  local = ОШИБКА
#   нет объявлений вообще                 -> assume-local,  local избыточен
i = 0
while i < len(clean):
    n, line = clean[i]
    m = re.match(r"^([A-Za-z_]\w*)\s*\([^)]*\)\s*\{\s*$", line)
    if not m or m.group(1).lower() in ("if", "while", "for", "loop"):
        i += 1
        continue
    fname = m.group(1)
    depth, j = 1, i + 1
    first_decl, locals_in_body = None, []
    while j < len(clean) and depth > 0:
        _, cur = clean[j]
        depth += cur.count("{") - cur.count("}")
        if depth <= 0:
            break
        s = cur.strip()
        if s and not s.startswith(";"):
            if first_decl is None and re.match(r"^(global|local|static)\b", s):
                first_decl = s
            elif first_decl is None:
                first_decl = ""      # тело началось не с объявления
            if re.match(r"^local\s+", s):
                locals_in_body.append((clean[j][0], s))
        j += 1

    bare_global = (first_decl == "global")
    listed_global = bool(first_decl and re.match(r"^global\s+\S", first_decl))

    for ln, s in locals_in_body:
        if listed_global:
            problems.append(
                f"строка {ln}: в {fname}() объявлен '{s}', но функция начинается "
                f"с '{first_decl}' -> assume-local. AHK: "
                f"'Local variables must not be declared in this function'")
        elif not bare_global and not listed_global:
            warnings.append(
                f"строка {ln}: в {fname}() '{s}' избыточен "
                f"(функция и так assume-local)")
    i = j

# --- 5. SetTimer на несуществующие метки -------------------------------
for n, line in clean:
    m = re.search(r"SetTimer,\s*([A-Za-z_]\w*)", line)
    if m and m.group(1).lower() not in defined_labels:
        problems.append(f"строка {n}: SetTimer на метку {m.group(1)}, которой нет")

# --- 6. GuiControl на несуществующие vName -----------------------------
gui_vars = set()
for n, line in clean:
    for m in re.finditer(r"\bv([A-Z]\w+)", line):
        if "Gui," in line and "Add," in line:
            gui_vars.add(m.group(1).lower())
for n, line in clean:
    m = re.search(r"GuiControl,\s*OSD:\s*(?:Font)?\s*,\s*([A-Za-z_]\w*)", line)
    if m:
        v = m.group(1).lower()
        # Динамическое имя (Line%A_Index%, Ctl%i%) — не проверяем.
        rest = line[m.end():].lstrip()
        if v and v not in gui_vars and not v.startswith("%") \
                and not rest.startswith("%"):
            warnings.append(f"строка {n}: GuiControl на {m.group(1)} — контрол не найден")
for n, line in clean:
    m = re.search(r'SetCtlFont\(\s*"(\w+)"', line)
    if m and m.group(1).lower() not in gui_vars:
        warnings.append(f"строка {n}: SetCtlFont на {m.group(1)} — контрол не найден")


# --- метка обрывает автозапуск ----------------------------------------
# AutoHotkey выполняет код сверху вниз только до первой метки, горячей
# клавиши или return верхнего уровня. Всё, что объявлено ниже, при
# старте НЕ выполняется. Однажды из-за этого перестали вычисляться зоны
# поиска: трофей искался в области 0,0-0,0, и любая рыба, включая
# трофейную, считалась мелочью и уходила в отпуск.
_stop = None
for _i, _raw in enumerate(lines, 1):
    _t = _raw.strip()
    if not _t or _t.startswith(";"):
        continue
    if re.match(r"^[A-Za-z_]\w*:\s*$", _t) or re.match(r"^[*~$]*\w+::", _t):
        _stop = _i
        break
if _stop:
    for _i, _raw in enumerate(lines, 1):
        if _i <= _stop:
            continue
        _m = re.match(r"^([A-Z]\w*(?:StartX|StartY|EndX|EndY))\s*:=",
                      _raw.strip())
        if _m:
            problems.append(
                f"строка {_i}: {_m.group(1)} присваивается после обрыва "
                f"автозапуска (строка {_stop}) — не выполнится при старте")

# --- вывод -------------------------------------------------------------
print(f"Файл: {path.name}  ({len(lines)} строк)")
print(f"Функций: {len(defined_funcs)}   Меток: {len(defined_labels)}   "
      f"Gui-контролов: {len(gui_vars)}")
print("-" * 62)
if problems:
    print("ОШИБКИ:")
    for p in problems:
        print("  ! " + p)
else:
    print("Структурных ошибок не найдено.")
if warnings:
    print("\nПредупреждения:")
    for w in warnings:
        print("  ~ " + w)
print("-" * 62)
print("Метки:  " + ", ".join(sorted(defined_labels)))

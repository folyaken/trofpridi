# -*- coding: utf-8 -*-
"""Сглаженная отрисовка для окна статистики.

Зачем это нужно
---------------
Tkinter Canvas рисует без сглаживания: в его API просто нет такой
опции. Сколько сегментов ни клади в дугу, растеризатор красит пиксель
целиком — отсюда «лесенка» на скруглениях, кольцах и диагоналях.

Здесь холст подменяется на совместимый по вызовам объект, который
рисует всё в Pillow при увеличении SS раз, а потом уменьшает картинку
до нужного размера. Усреднение соседних пикселей и даёт сглаживание.

Главное свойство: набор методов повторяет Canvas (create_text,
create_line, create_oval, create_polygon, create_arc, create_image,
create_rectangle, delete). Поэтому существующий код вёрстки менять
не пришлось — он не знает, куда именно рисует.

Если Pillow недоступен, приложение работает на обычном Canvas: вид
хуже, но окно открывается.
"""

import os
import sys

# Во сколько раз рисуем крупнее. Двойного увеличения достаточно:
# сравнение с тройным дало среднее отличие 0.5 из 255 — глазом не
# видно, — а кадр считается почти вдвое быстрее (55 мс против 92).
# Окно висит поверх игры, поэтому лишние миллисекунды тут дороже.
SS = 2
# Урезанная копия Font Awesome 6 Free Solid: оставлены только
# используемые значки, поэтому 15 КБ вместо мегабайта.
_FA_FILE = "fa-icons.otf"

try:
    from PIL import (Image, ImageChops, ImageDraw, ImageFilter,
                     ImageFont, ImageTk)
    try:
        # BILINEAR, а не BOX. BOX — это простое усреднение блоком: на
        # скруглениях он даёт всего пять полутонов, и края выглядят
        # ступенчатыми. BILINEAR даёт двенадцать — столько же, сколько
        # дорогой LANCZOS, — но стоит втрое дешевле: на полном кадре
        # 1320x840 замер показал 26 мс против 61 мс у LANCZOS и 19 мс
        # у BOX. Семь миллисекунд за исчезнувшие лесенки по всему окну.
        _RESAMPLE = Image.Resampling.BILINEAR
    except AttributeError:          # Pillow старее 9.1
        _RESAMPLE = Image.BILINEAR
    HAVE_PIL = True
except Exception:
    HAVE_PIL = False
    _RESAMPLE = None


def _asset_dir():
    base = (os.path.dirname(sys.executable) if getattr(sys, "frozen", False)
            else os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, "assets")


# ------------------------------------------------------------ иконки
# Font Awesome 6 Free Solid. Рисовать значки глифами надёжнее, чем
# собирать их из отрезков и дуг: шрифт уже нарисован дизайнерами и
# масштабируется без потерь.
FA = {
    "fish": "\uf578", "trophy": "\uf091", "star": "\uf005",
    "chart": "\uf201", "images": "\uf302", "book": "\uf02d",
    "clock": "\uf017", "fire": "\uf06d", "weight": "\uf5cd",
    "ruler": "\uf545", "bolt": "\uf0e7", "mug": "\uf7b6",
    "shield": "\uf3ed", "rotate": "\uf2f9", "plus": "\uf067",
    "xmark": "\uf00d", "check": "\uf00c", "anchor": "\uf13d",
    "sun": "\uf185", "utensils": "\uf2e7", "gauge": "\uf625",
    "medal": "\uf5a2", "crown": "\uf521", "water": "\uf773",
    "minus": "\uf068", "hook": "\uf13d", "grid": "\uf00a",
    # для журнала: поиск, удаление, сортировка, флажки
    "magnifier": "\uf002", "trash": "\uf1f8", "sort": "\uf0dc",
    "sort-up": "\uf0de", "sort-down": "\uf0dd",
    "square": "\uf0c8", "square-check": "\uf14a",
    "filter": "\uf0b0", "eraser": "\uf12d", "list": "\uf03a",
    "circle-check": "\uf058", "ban": "\uf05e",
    "angle-down": "\uf107", "angle-up": "\uf106",
    "gear": "\uf013", "shield-check": "\uf3ed", "camera": "\uf030",
    # ВНИМАНИЕ: assets/fa-icons.otf — это урезанный набор из 42 глифов.
    # Перед добавлением значка сюда проверяй, что его код есть в файле
    # шрифта, иначе вместо иконки нарисуется пустая рамка «.notdef».
    # («pen» \uf304 однажды добавили вслепую — кнопка переименования
    # рисовала «тофу», пока её не вернули на векторный карандаш.)
}


def _hex(color, default=None):
    """Цвет Tk -> кортеж RGBA. Пустая строка = прозрачно."""
    if color is None or color == "":
        return default
    if isinstance(color, tuple):
        return color
    c = str(color).strip()
    if not c:
        return default
    if c.startswith("#"):
        c = c[1:]
        if len(c) == 3:
            c = "".join(ch * 2 for ch in c)
        if len(c) == 6:
            try:
                return (int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16), 255)
            except ValueError:
                return default
    named = {
        "white": (255, 255, 255, 255), "black": (0, 0, 0, 255),
        "red": (255, 0, 0, 255), "gray": (128, 128, 128, 255),
        "grey": (128, 128, 128, 255),
    }
    return named.get(c.lower(), default)


class _FontCache:
    """Шрифты грузим один раз: открытие TTF заметно дороже отрисовки."""

    def __init__(self):
        self._cache = {}
        self._families = None

    def _candidates(self, family, bold):
        f = (family or "").lower()
        win = r"C:\Windows\Fonts"
        out = []
        # Встроенный шрифт программы (assets/font_ui*.ttf) — ходит с
        # дистрибутивом, поэтому идёт первым кандидатом: вид одинаковый
        # на любом компьютере, даже без шрифтов в системе.
        if ("roboto" in f and "slab" in f) or ("noto" in f and "serif" in f):
            ad = _asset_dir()
            if bold or "semibold" in f:
                out += [os.path.join(ad, "font_ui_bold.ttf")]
            out += [os.path.join(ad, "font_ui.ttf")]
        if "segoe" in f:
            if "semibold" in f or bold:
                out += [os.path.join(win, "seguisb.ttf"),
                        os.path.join(win, "segoeuib.ttf")]
            out += [os.path.join(win, "segoeui.ttf")]
        if bold:
            out += [
                "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
                "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
            ]
        out += [
            os.path.join(win, "segoeui.ttf"),
            os.path.join(win, "arial.ttf"),
            "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        ]
        return out

    def get(self, family, size, bold=False, scale=None):
        if scale is None:
            scale = SS
        key = (family, size, bold, scale)
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        px = max(1, int(round(size * 1.34 * scale)))   # пункты -> пиксели
        font = None
        for path in self._candidates(family, bold):
            try:
                font = ImageFont.truetype(path, px)
                break
            except Exception:
                continue
        if font is None:
            try:
                font = ImageFont.load_default(px)
            except Exception:
                font = ImageFont.load_default()
        self._cache[key] = font
        return font

    def icon(self, px, scale=None):
        if scale is None:
            scale = SS
        key = ("__fa__", px, scale)
        hit = self._cache.get(key)
        if hit is not None:
            return hit
        path = os.path.join(_asset_dir(), _FA_FILE)
        try:
            font = ImageFont.truetype(path, max(1, int(px * scale)))
        except Exception:
            font = None
        self._cache[key] = font
        return font


_FONTS = _FontCache() if HAVE_PIL else None


def has_icons():
    """Есть ли шрифт значков — чтобы код мог откатиться на рисованные."""
    return HAVE_PIL and _FONTS is not None and _FONTS.icon(12) is not None


class SmoothCanvas:
    """Приёмник команд рисования с тем же набором методов, что у Canvas.

    Команды копятся в списке и выполняются при flush(): сначала в
    крупный буфер Pillow, затем результат уменьшается и попадает в
    настоящий Canvas одной картинкой.
    """

    def __init__(self, tk_canvas, bg="#11151A"):
        self.cv = tk_canvas
        self.bg = bg
        self._ops = []
        self._images = []       # держим ссылки: иначе сборщик съест
        self._photo = None
        self._ovl_imgs = []
        self._w = self._h = 0

    # ------------------------------------------------ приём команд
    def delete(self, *a):
        self._ops = []
        self._images = []

    def _add(self, kind, args, kw):
        self._ops.append((kind, args, kw))

    def create_rectangle(self, *a, **k):
        self._add("rect", a, k)

    def create_oval(self, *a, **k):
        self._add("oval", a, k)

    def create_line(self, *a, **k):
        self._add("line", a, k)

    def create_polygon(self, *a, **k):
        self._add("poly", a, k)

    def create_arc(self, *a, **k):
        self._add("arc", a, k)

    def create_text(self, *a, **k):
        self._add("text", a, k)

    def create_image(self, *a, **k):
        self._add("image", a, k)

    def create_icon(self, x, y, name, size, color, anchor="mm"):
        """Значок шрифтом Font Awesome."""
        self._add("icon", (x, y), {"name": name, "size": size,
                                   "fill": color, "anchor": anchor})

    def measure(self, text, font_spec):
        """Ширина строки в пикселях.

        Раньше ширину прикидывали как «символов × 6», и подписи в шапке
        наезжали друг на друга. Здесь меряем настоящим шрифтом.
        """
        if not text:
            return 0
        fam, size, bold = _parse_font(font_spec)
        f = _FONTS.get(fam, size, bold, scale=1)
        try:
            return f.getbbox(str(text))[2]
        except Exception:
            return len(str(text)) * size * 0.6

    # Часть кода зовёт эти методы у настоящего холста.
    def winfo_width(self):
        return self.cv.winfo_width()

    def winfo_height(self):
        return self.cv.winfo_height()

    def config(self, **k):
        return self.cv.config(**k)

    def bind(self, *a, **k):
        return self.cv.bind(*a, **k)

    def tag_bind(self, *a, **k):
        return None             # попадания считаются по координатам

    # ------------------------------------------------ отрисовка
    @staticmethod
    def _flat(args):
        """(x1,y1,x2,y2) или [(x,y),...] -> плоский список чисел."""
        if len(args) == 1 and isinstance(args[0], (list, tuple)):
            seq = args[0]
        else:
            seq = args
        out = []
        for v in seq:
            if isinstance(v, (list, tuple)):
                out.extend(v)
            else:
                out.append(v)
        return [float(x) for x in out]

    def snapshot(self):
        """Готовый кадр — чтобы переиспользовать его как фон."""
        return getattr(self, "_last_small", None)

    # ---------------------------------------------- быстрый слой поверх
    # Полная перерисовка через Pillow стоит десятки миллисекунд: буфер
    # 2640x1680 нужно создать и уменьшить. Для подсветки под курсором
    # это непозволительно — реакция должна быть мгновенной.
    # Поэтому рамки и подложки наведения рисуем НАТИВНЫМИ фигурами Tk
    # поверх уже готовой картинки: они рисуются на C и появляются сразу.
    # ---------------------------------------------------- эффекты карточек
    #
    # Тень, градиент и свечение — вещи дорогие: гауссово размытие одной
    # карточки стоит около 0.6 мс, а на странице их пятнадцать. Но форма
    # у всех одна, поэтому каждый эффект считается ОДИН раз и потом
    # берётся из кэша. Замер: 15 карточек с тенью и градиентом — 0.01 мс
    # вместо 51 мс без кэша.
    _FX = {}

    @classmethod
    def _fx_shadow(cls, w, h, r, blur, spread, alpha):
        """Мягкая тень под карточкой. Возвращает маску прозрачности."""
        key = ("sh", w, h, r, blur, spread, alpha)
        got = cls._FX.get(key)
        if got is None:
            lay = Image.new("L", (w + spread * 2, h + spread * 2), 0)
            ImageDraw.Draw(lay).rounded_rectangle(
                [spread, spread + 2, w + spread, h + spread + 2],
                radius=r, fill=alpha)
            got = lay.filter(ImageFilter.GaussianBlur(blur))
            cls._FX[key] = got
        return got

    _NOISE = None                     # статичное зерно (против мерцания)

    @classmethod
    def _noise_for(cls, size):
        """Зерно-«поле», не меньше нужного; кэшируется один раз.

        Шум ОБЯЗАН быть одним и тем же на всех кадрах: генерировать
        его заново на каждую отрисовку — фон «дрожит» как киноплёнка.
        Режем куски из одного большого поля: зерно стоит на месте,
        а полосы градиента разбивает исправно.
        """
        w, h = size
        n = cls._NOISE
        if n is None or n.size[0] < w or n.size[1] < h:
            cls._NOISE = Image.effect_noise((max(w, 1920),
                                             max(h, 1200)), 22)
            n = cls._NOISE
        return n.crop((0, 0, w, h))

    @classmethod
    def _dither(cls, im, amp=1.2):
        """Лёгкий дизеринг против «полосатости» тёмных градиентов.

        Восемь бит на канал — это всего 256 ступеней яркости. На почти
        чёрном фоне перепад градиента в десяток значений размазан на
        сотни пикселей, и каждая ступенька читается отдельной полосой
        (бэндинг). Классическое лечение с эпохи GIF — микрошум около
        ОДНОГО уровня яркости: ступени размываются, глаз собирает их
        в гладкость. Больше не нужно — зерно ±2 было видно само по
        себе, как «плёночный шум». Зерно статичное (см. _noise_for).

        Важно: дизерим и сам ФИНАЛЬНЫЙ кадр (в flush). Уменьшение
        LANCZOS сглаживало зерно слоёв и заново квантовало градиент —
        полосы возвращались, несмотря на дизеринг исходников.
        """
        try:
            noise = cls._noise_for(im.size).point(
                lambda p: 128 + round((p - 128) * amp / 24.0))
            rgb = Image.merge("RGB", (noise, noise, noise))
            # Одна операция: add со сдвигом -128 насыщается ОДИН раз
            # в самом конце. Пара add+subtract насыщалась ДВАЖДЫ:
            # im+noise резалось о 255, и всякий пиксел ярче ~127
            # проваливался к ~127 — фото уловов «грязнели», цвета
            # тускнели. Поймали на скриншоте галереи.
            return ImageChops.add(im.convert("RGB"), rgb, 1.0, -128)
        except Exception:
            return im

    @classmethod
    def _fx_gradient(cls, w, h, top, bottom, r):
        """Вертикальный градиент со скруглёнными углами."""
        key = ("gr", w, h, top, bottom, r)
        got = cls._FX.get(key)
        if got is None:
            c1 = _hex(top, (26, 32, 39, 255))
            c2 = _hex(bottom, (22, 28, 35, 255))
            # Строим построчно: одна строка на каждый пиксель высоты,
            # затем растягиваем по ширине. Это быстрее, чем рисовать
            # градиент линиями (0.18 мс против нескольких миллисекунд).
            rows = []
            for i in range(h):
                t = i / max(1, h - 1)
                rows.append(tuple(int(c1[k] + (c2[k] - c1[k]) * t)
                                  for k in range(3)))
            im = Image.new("RGB", (1, h))
            im.putdata(rows)
            got = im.resize((w, h), Image.BILINEAR)
            # Дизеринг тут бессмысленен: картинка ляжет в кадр до
            # финального уменьшения, и зерно размоется. Полосы лечит
            # финальный дизеринг в flush.
            cls._FX[key] = got
        return got

    @classmethod
    def _fx_glow(cls, w, h, r, blur, spread, alpha):
        """Ореол вокруг карточки — для трофеев.

        Складывается из НЕСКОЛЬКИХ размытий, а не одного. Одно размытие
        выдаёт себя формой: вдоль прямых сторон света много, а в углах
        мало (замер: 99 против 33), и глаз читает не сияние, а
        подсвеченный прямоугольник. Вдобавок при тесном запасе ореол
        упирался в край картинки и обрывался ровной линией — тот самый
        «ящик».

        Здесь три слоя: узкий и яркий даёт чёткую кромку у самого края
        карточки, средний — основное тело свечения, широкий и слабый —
        длинный шлейф, который растворяется в фоне. Вместе получается
        плавное затухание без видимой границы.
        """
        key = ("gl", w, h, r, blur, spread, alpha)
        got = cls._FX.get(key)
        if got is None:
            size = (w + spread * 2, h + spread * 2)
            box = [spread, spread, w + spread, h + spread]
            acc = Image.new("L", size, 0)
            # (доля от базового размытия, доля от базовой яркости)
            for b_k, a_k in ((0.25, 0.70), (0.75, 0.47), (1.7, 0.32)):
                lay = Image.new("L", size, 0)
                ImageDraw.Draw(lay).rounded_rectangle(
                    box, radius=r, fill=int(alpha * a_k))
                acc = ImageChops.add(
                    acc, lay.filter(
                        ImageFilter.GaussianBlur(max(1, blur * b_k))))
            got = acc
            cls._FX[key] = got
        return got

    def card(self, x1, y1, x2, y2, r=14, top="#1F2730", bottom="#161C23",
             shadow=True, glow=None, glow_k=1.0):
        """Карточка с тенью, градиентной заливкой и опциональным свечением.

        Рисуется как единая картинка, а не набор фигур: только так
        получаются мягкие края и плавные переходы. Всё, что можно
        посчитать заранее, лежит в кэше (см. _FX).

        glow — цвет ореола (для трофеев золотой), glow_k — его сила.
        """
        x1i, y1i = int(x1), int(y1)
        w, h = max(2, int(x2 - x1)), max(2, int(y2 - y1))
        self._ops.append(("_card", (x1i, y1i, w, h, r, top, bottom,
                                    shadow, glow, glow_k), {}))

    @classmethod
    def _fx_card(cls, w, h, r, top, bottom, shadow, glow, glow_k, bg):
        """Готовая карточка вместе с тенью и свечением — целиком в кэше.

        Собирать её из трёх наложений на каждый вызов дорого: одно
        наложение с маской стоит около 0.75 мс, а карточек пятнадцать.
        Поэтому склеиваем всё заранее в одну непрозрачную картинку и
        потом просто вставляем — вставка без маски стоит 0.05 мс.

        Возвращает (картинка, отступ), где отступ — насколько она шире
        самой карточки за счёт тени и ореола.
        """
        key = ("card", w, h, r, top, bottom, shadow, glow, glow_k, bg)
        got = cls._FX.get(key)
        if got is not None:
            return got

        # Запас вокруг карточки должен вмещать ВСЁ размытие. Гауссово
        # ядро затухает примерно за три радиуса: если дать меньше,
        # ореол упрётся в край картинки и оборвётся ровной линией —
        # именно так и получался видимый прямоугольник вокруг трофея.
        # Раньше здесь стояло глухое «16», да ещё и без учёта SS.
        blur_g = max(2, int(6 * SS)) if glow else 0
        blur_s = max(2, int(4 * SS)) if shadow else 0
        # Запас должен вмещать САМЫЙ ШИРОКИЙ слой ореола (1.7 от
        # базового размытия) и его затухание — иначе свечение упрётся
        # в край картинки и оборвётся прямой линией. Для тени хватает
        # втрое меньше: она короткая и плотная.
        need = max(blur_g * 1.7 * 2.6, blur_s * 2.2)
        pad = int(need) + 2 if (shadow or glow) else 0

        # Собираем в RGBA: карточку нужно класть на кадр С ПРОЗРАЧНОСТЬЮ.
        # Непрозрачный прямоугольник затирал ореол соседа — в ряду
        # трофеев свечение обрезалось вертикальными швами.
        out = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
        if glow:
            g = cls._fx_glow(w, h, r, blur_g, pad, int(170 * glow_k))
            layer = Image.new("RGBA", out.size, _hex(glow, (255, 179, 0, 255))[:3] + (0,))
            layer.putalpha(g)
            out = Image.alpha_composite(out, layer)
        if shadow:
            sh = cls._fx_shadow(w, h, r, blur_s, pad, 120)
            layer = Image.new("RGBA", out.size, (0, 0, 0, 0))
            layer.putalpha(sh)
            out = Image.alpha_composite(out, layer)
        grad = cls._fx_gradient(w, h, top, bottom, r).convert("RGBA")
        grad.putalpha(cls._fx_mask(w, h, r))
        out.alpha_composite(grad, (pad, pad))

        # Заранее нарезаем то, что понадобится при вставке: середину
        # без прозрачности и четыре полосы каймы. Готовить их на каждой
        # отрисовке — лишние 0.3 мс на карточку, а карточек пятнадцать.
        cw, ch = out.size
        if pad:
            # Ядро вырезаем С ОТСТУПОМ от углов на радиус скругления.
            #
            # Раньше сюда попадал весь прямоугольник от pad до pad+w, а
            # в его углах лежат полупрозрачные пиксели самого скругления.
            # Вставка без маски делала их непрозрачными, и у каждой
            # карточки вылезал острый угол — ровно то, что было видно
            # на панелях по всему окну.
            #
            # Теперь ядро — только гарантированно сплошная середина, а
            # углы вместе с каймой кладутся с прозрачностью.
            # Середина без углов — один сплошной кусок, кладётся без
            # маски. Всё остальное (кайма с тенью и ореолом плюс полосы
            # со скруглениями) — с прозрачностью.
            k = int(r) + 1
            parts = (out.crop((pad, pad + k, cw - pad, ch - pad - k)
                              ).convert("RGB"),            # середина
                     out.crop((0, 0, cw, pad + k)),        # верх с углами
                     out.crop((0, ch - pad - k, cw, ch)),  # низ с углами
                     out.crop((0, pad + k, pad, ch - pad - k)),   # слева
                     out.crop((cw - pad, pad + k, cw, ch - pad - k)),
                     k)
        else:
            parts = None
        cls._FX[key] = (out, pad, parts)
        return cls._FX[key]

    def _draw_fximg(self, im, X, Y, fx):
        """Вставляет готовый эффект (картинка, pad, части) в кадр."""
        card, pad, parts = fx
        if not pad or parts is None:
            # Мелкая форма (части не нарезались) или эффект без каймы —
            # кладём целиком с маской: прозрачность сохранится.
            im.paste(card, (X, Y), card)
            return
        # Вставляем по частям.
        #
        # Сплошную середину кладём без маски — это дёшево (0.04 мс
        # против 0.7 мс). Всё, где есть прозрачность — кайма с тенью,
        # ореолом и скруглённые углы, — только с маской: иначе соседняя
        # карточка затрёт свечение предыдущей, а углы станут острыми.
        mid, top_s, bot_s, left_s, right_s, k = parts
        cw, ch = card.size
        # с прозрачностью: верх и низ целиком (в них скруглённые углы)
        im.paste(top_s, (X, Y), top_s)
        im.paste(bot_s, (X, Y + ch - pad - k), bot_s)
        im.paste(left_s, (X, Y + pad + k), left_s)
        im.paste(right_s, (X + cw - pad, Y + pad + k), right_s)
        # сплошная середина — одним куском, без маски
        im.paste(mid, (X + pad, Y + pad + k))

    @classmethod
    def _fx_parts(cls, out, pad, r):
        """Нарезка эффекта на середину и кайму (как у карточки).

        Для мелких элементов (кнопки) кайма съела бы форму целиком —
        там возвращаем None, и вызывающий код кладёт картинку одним
        куском с маской. Медленнее на копейки, но углы остаются живы.
        """
        cw, ch = out.size
        # Ядро должно быть дальше радиуса от угла: иначе в сплошную
        # середину попадут полупрозрачные пиксели скругления.
        k = int(r) + 1
        if cw <= 2 * (pad + k) + 8 or ch <= 2 * (pad + k) + 8:
            return None
        return (out.crop((pad, pad + k, cw - pad, ch - pad - k)
                          ).convert("RGB"),            # середина
                 out.crop((0, 0, cw, pad + k)),        # верх с углами
                 out.crop((0, ch - pad - k, cw, ch)),  # низ с углами
                 out.crop((0, pad + k, pad, ch - pad - k)),   # слева
                 out.crop((cw - pad, pad + k, cw, ch - pad - k)),
                 k)

    @classmethod
    def _fx_soft(cls, w, h, r, blur, pad, dx, dy, alpha):
        """Размытый силуэт скруглённого прямоугольника со сдвигом.

        Это тень (сдвиг вниз-вправо) или блик (вверх-влево) для
        неоморфных панелей: мягкий след произвольного цвета.
        """
        key = ("so", w, h, r, blur, pad, dx, dy, alpha)
        got = cls._FX.get(key)
        if got is None:
            lay = Image.new("L", (w + pad * 2, h + pad * 2), 0)
            ImageDraw.Draw(lay).rounded_rectangle(
                [pad + dx, pad + dy, pad + dx + w, pad + dy + h],
                radius=r, fill=alpha)
            got = lay.filter(ImageFilter.GaussianBlur(blur))
            cls._FX[key] = got
        return got

    def _draw_card(self, im, x, y, w, h, r, top, bottom, shadow, glow,
                   glow_k):
        """Вставляет готовую карточку в кадр (координаты в масштабе SS)."""
        ss = SS
        fx = self._fx_card(
            w * ss, h * ss, int(r * ss), top, bottom,
            shadow, glow, glow_k, self.bg)
        self._draw_fximg(im, x * ss - fx[1], y * ss - fx[1], fx)

    # -------------------------------------------------- неоморфизм
    def neu(self, x1, y1, x2, y2, r=14, top=None, bottom=None,
            dark=None, light=None, dk=150, hi=110, dist=3, blur=5):
        """Приподнятая панель одного «материала» с фоном.

        Классический неоморфизм: объём читается не сменой цвета
        панели, а парой мягких следов — тёмный вниз-вправо, светлый
        вверх-влево (свет будто падает из левого верхнего угла).
        Цвета берутся из темы; прозрачность dk/hi — 0..255.
        """
        x1i, y1i = int(x1), int(y1)
        w, h = max(2, int(x2 - x1)), max(2, int(y2 - y1))
        self._ops.append(("_neu", (x1i, y1i, w, h, r, top, bottom,
                                   dark, light, dk, hi, dist, blur), {}))

    @classmethod
    def _fx_neu(cls, w, h, r, top, bottom, dark, light, dk_a, hi_a,
                dist, blur):
        """Готовая неоморфная панель целиком в кэше — как _fx_card."""
        key = ("neu", w, h, r, top, bottom, dark, light, dk_a, hi_a,
               dist, blur)
        got = cls._FX.get(key)
        if got is not None:
            return got
        pad = int(blur * 2.2 + abs(dist)) + 2
        out = Image.new("RGBA", (w + pad * 2, h + pad * 2), (0, 0, 0, 0))
        # тёмный след: сдвиг вниз-вправо
        sh = cls._fx_soft(w, h, r, blur, pad, dist, dist, dk_a)
        layer = Image.new("RGBA", out.size, _hex(dark)[:3] + (0,))
        layer.putalpha(sh)
        out = Image.alpha_composite(out, layer)
        # светлый блик: сдвиг вверх-влево
        hl = cls._fx_soft(w, h, r, blur, pad, -dist, -dist, hi_a)
        layer = Image.new("RGBA", out.size, _hex(light)[:3] + (0,))
        layer.putalpha(hl)
        out = Image.alpha_composite(out, layer)
        # тело: едва заметный вертикальный градиент «сверху светлее»
        grad = cls._fx_gradient(w, h, top, bottom, r).convert("RGBA")
        grad.putalpha(cls._fx_mask(w, h, r))
        out.alpha_composite(grad, (pad, pad))
        cls._FX[key] = (out, pad, cls._fx_parts(out, pad, r))
        return cls._FX[key]

    def _draw_neu(self, im, x, y, w, h, r, top, bottom, dark, light,
                  dk, hi, dist, blur):
        ss = SS
        fx = self._fx_neu(w * ss, h * ss, int(r * ss), top, bottom,
                          dark, light, dk, hi, int(dist * ss),
                          int(blur * ss))
        self._draw_fximg(im, x * ss - fx[1], y * ss - fx[1], fx)

    def sink(self, x1, y1, x2, y2, r=10, fill=None, dark=None,
             light=None, dk=90, hi=70, dist=2, blur=2):
        """Углубление — вдавленная «ванночка» (поле ввода, дорожка).

        Обратная панели вещь: тень лежит ВНУТРИ у верхнего и левого
        края, блик — у нижнего и правого. Дно чуть темнее фона.
        """
        x1i, y1i = int(x1), int(y1)
        w, h = max(2, int(x2 - x1)), max(2, int(y2 - y1))
        self._ops.append(("_sink", (x1i, y1i, w, h, r, fill, dark,
                                    light, dk, hi, dist, blur), {}))

    @classmethod
    def _fx_crescent(cls, w, h, r, dx, dy, blur, alpha, fill_on=None):
        """Внутренний полумесяц: куда НЕ сдвинулась маска формы.

        m - offset(m) даёт тонкий серп у противоположного сдвигу края;
        после размытия и обрезки формой это внутренняя тень (или блик).
        fill_on — маска «только внутри формы» (сама маска скругления).
        """
        key = ("cr", w, h, r, dx, dy, blur, alpha)
        got = cls._FX.get(key)
        if got is None:
            m = cls._fx_mask(w, h, r)
            cr = ImageChops.subtract(m, ImageChops.offset(m, dx, dy))
            if blur:
                cr = cr.filter(ImageFilter.GaussianBlur(blur))
            cr = ImageChops.darker(cr, m)
            got = cr.point(lambda v: v * alpha // 255)
            cls._FX[key] = got
        return got

    @classmethod
    def _fx_sink(cls, w, h, r, fillc, dark, light, dk_a, hi_a, dist,
                 blur):
        key = ("sk", w, h, r, fillc, dark, light, dk_a, hi_a, dist, blur)
        got = cls._FX.get(key)
        if got is not None:
            return got
        out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        base = Image.new("RGBA", (w, h), _hex(fillc)[:3] + (255,))
        base.putalpha(cls._fx_mask(w, h, r))
        out.alpha_composite(base)
        # внутренняя тень у верхне-левого края
        sh = cls._fx_crescent(w, h, r, dist, dist, blur, dk_a)
        layer = Image.new("RGBA", (w, h), _hex(dark)[:3] + (0,))
        layer.putalpha(sh)
        out = Image.alpha_composite(out, layer)
        # внутренний блик у нижне-правого
        hl = cls._fx_crescent(w, h, r, -dist, -dist, blur, hi_a)
        layer = Image.new("RGBA", (w, h), _hex(light)[:3] + (0,))
        layer.putalpha(hl)
        out = Image.alpha_composite(out, layer)
        cls._FX[key] = (out, 0, None)
        return cls._FX[key]

    def _draw_sink(self, im, x, y, w, h, r, fillc, dark, light, dk, hi,
                   dist, blur):
        ss = SS
        fx = self._fx_sink(w * ss, h * ss, int(r * ss), fillc, dark,
                           light, dk, hi, int(dist * ss), int(blur * ss))
        im.paste(fx[0], (x * ss, y * ss), fx[0])

    @classmethod
    def _fx_mask(cls, w, h, r):
        """Маска скруглённого прямоугольника."""
        key = ("mk", w, h, r)
        got = cls._FX.get(key)
        if got is None:
            got = Image.new("L", (w, h), 0)
            ImageDraw.Draw(got).rounded_rectangle(
                [0, 0, w - 1, h - 1], radius=r, fill=255)
            cls._FX[key] = got
        return got

    def overlay_clear(self):
        self.cv.delete("ovl")
        self._ovl_imgs = []

    def overlay_round_rect(self, x1, y1, x2, y2, r, fill="", outline="",
                           width=1):
        """Рамка со скруглёнными углами — нативными средствами Tk.

        Собирается из четырёх дуг и четырёх отрезков. Раньше сюда
        подмешивались ещё и залитые круги «для формы», и на светлом
        контуре они торчали лишними кольцами по углам.
        """
        r = max(2, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
        c = self.cv
        d = r * 2
        if fill:
            c.create_rectangle(x1 + r, y1, x2 - r, y2, fill=fill,
                               outline="", tags="ovl")
            c.create_rectangle(x1, y1 + r, x2, y2 - r, fill=fill,
                               outline="", tags="ovl")
            for cx, cy in ((x1, y1), (x2 - d, y1),
                           (x1, y2 - d), (x2 - d, y2 - d)):
                c.create_oval(cx, cy, cx + d, cy + d, fill=fill,
                              outline="", tags="ovl")
        if not outline:
            return
        w = max(1, int(width))
        for bx, by, start in ((x1, y1, 90), (x2 - d, y1, 0),
                              (x1, y2 - d, 180), (x2 - d, y2 - d, 270)):
            c.create_arc(bx, by, bx + d, by + d, start=start, extent=90,
                         style="arc", outline=outline, width=w, tags="ovl")
        for ax, ay, bx2, by2 in ((x1 + r, y1, x2 - r, y1),
                                 (x1 + r, y2, x2 - r, y2),
                                 (x1, y1 + r, x1, y2 - r),
                                 (x2, y1 + r, x2, y2 - r)):
            c.create_line(ax, ay, bx2, by2, fill=outline, width=w,
                          tags="ovl")

    def overlay_line(self, x1, y1, x2, y2, color, width=1):
        """Отрезок в быстром слое — например, подчёркивание ссылки."""
        self.cv.create_line(x1, y1, x2, y2, fill=color,
                            width=width, tags="ovl")

    def overlay_text(self, x, y, text, fill="#FFFFFF", font=None,
                     anchor="center"):
        self.cv.create_text(x, y, text=text, fill=fill,
                            font=font or ("Segoe UI", 9),
                            anchor=anchor, tags="ovl")

    def overlay_patch(self, x1, y1, x2, y2, r=0, tint=None, alpha=0.0,
                      edge=None, edge_w=1.0):
        """Кусок готового кадра, подкрашенный и вставленный обратно.

        Так подсветка не стирает то, что под ней: иконка, подпись и
        всё остальное остаются на месте, просто становятся светлее.
        Раньше кнопка перерисовывалась сплошной заливкой, и значок
        ведёрка под ней пропадал.

        edge — цвет обводки. Её РИСУЕМ ЗДЕСЬ, а не средствами Tk.
        Причина простая: холст Tk не умеет сглаживание вообще, и
        create_arc давал на скруглениях грубую лесенку — по замеру
        два оттенка на кромке против сорока трёх у картинки. Здесь
        рамка рисуется вчетверо крупнее и уменьшается фильтром
        LANCZOS, то есть ровно так же, как весь остальной интерфейс.
        Стоит это 0.34 мс на кадр.
        """
        base = getattr(self, "_last_small", None)
        if base is None:
            return
        x1i, y1i = max(0, int(x1)), max(0, int(y1))
        x2i, y2i = min(base.width, int(x2)), min(base.height, int(y2))
        if x2i - x1i < 2 or y2i - y1i < 2:
            return
        crop = base.crop((x1i, y1i, x2i, y2i)).convert("RGB")
        if tint and alpha > 0:
            # Не смешиваем «в лоб»: обычный blend тянул бы к цвету и
            # тёмный фон, и светлый текст — надписи мутнели. Здесь фон
            # подкрашивается сильно, а всё, что ярче него (буквы,
            # значки), почти не трогается.
            layer = Image.new("RGB", crop.size, tint)
            mixed = Image.blend(crop, layer, min(1.0, alpha))
            # Текст и значки не притапливаем краской, а наоборот
            # осветляем: иначе подпись сливалась с заливкой.
            bright = Image.blend(crop, Image.new("RGB", crop.size,
                                                 "#FFFFFF"), 0.45)
            # Маска: 0 — фон, 255 — буквы и значки. Порог 58 и крутой
            # наклон подобраны по замеру: у серой подписи чипа яркость
            # 104, и при мягкой маске она осветлялась лишь на треть —
            # текст тонул в заливке.
            lum = crop.convert("L").point(
                lambda v: 0 if v < 58 else min(255, (v - 58) * 7))
            crop = Image.composite(bright, mixed, lum)
        if r > 0:
            # Скруглённые углы: за пределами формы возвращаем исходник.
            # Маску строим в четырёхкратном размере и уменьшаем — иначе
            # её край получается ступенчатым (значения строго 0 или 255),
            # и вся подсветка обрастает лесенкой по контуру.
            ss = 4
            big = Image.new("L", (crop.size[0] * ss, crop.size[1] * ss), 0)
            ImageDraw.Draw(big).rounded_rectangle(
                [0, 0, crop.size[0] * ss - 1, crop.size[1] * ss - 1],
                radius=int(r * ss), fill=255)
            mask = big.resize(crop.size, Image.LANCZOS)
            orig = base.crop((x1i, y1i, x2i, y2i)).convert("RGB")
            crop = Image.composite(crop, orig, mask)

        # Обводка — тем же способом: крупно и с уменьшением.
        if edge and edge_w > 0:
            ss = 4
            line = Image.new("L", (crop.size[0] * ss, crop.size[1] * ss), 0)
            ImageDraw.Draw(line).rounded_rectangle(
                [0, 0, crop.size[0] * ss - 1, crop.size[1] * ss - 1],
                radius=int(max(r, 1) * ss), outline=255,
                width=max(1, int(edge_w * ss)))
            lmask = line.resize(crop.size, Image.LANCZOS)
            crop = Image.composite(
                Image.new("RGB", crop.size, edge), crop, lmask)

        ph = ImageTk.PhotoImage(crop)
        self._ovl_imgs.append(ph)          # держим ссылку, иначе исчезнет
        self.cv.create_image(x1i, y1i, anchor="nw", image=ph, tags="ovl")

    def flush(self, size=None):
        """Выполняет накопленные команды и показывает результат.

        Рисуем в два прохода. Фигуры — крупно, с последующим
        уменьшением: только так получается сглаживание. Текст и значки —
        уже поверх готовой картинки, в обычном масштабе: шрифтовой
        растеризатор Pillow сглаживает буквы сам, и рисовать их втрое
        крупнее означало бы просто утроить работу. Замер показал
        разницу 96 мс против 32 мс при том же качестве.
        """
        # Размер можно задать явно. Это важно для окон, которые ещё
        # не показаны: у скрытого виджета winfo_width() возвращает 1,
        # и картинка получалась размером в один пиксель — окно просмотра
        # фото открывалось пустым прямоугольником.
        w = int(size[0]) if size else max(1, self.cv.winfo_width())
        h = int(size[1]) if size else max(1, self.cv.winfo_height())
        if w < 2 or h < 2:                  # холст ещё не разложен
            return
        # Фон: раньше всегда сплошной цвет. Теперь, если окно положило
        # в bg_grad готовую PIL-картинку (лёгкий диагональный градиент
        # тёмной темы), кладём её под фигуры вместо заливки.
        bg_grad = getattr(self, "bg_grad", None)
        if bg_grad is not None:
            if bg_grad.size != (w * SS, h * SS):
                img = bg_grad.resize((w * SS, h * SS), _RESAMPLE)
            else:
                img = bg_grad.copy()
        else:
            img = Image.new("RGB", (w * SS, h * SS), _hex(self.bg)[:3])
        d = ImageDraw.Draw(img, "RGBA")

        text_ops = []
        for kind, args, kw in self._ops:
            if kind in ("text", "icon"):
                text_ops.append((kind, args, kw))
                continue
            try:
                self._render(img, d, kind, args, kw)
            except Exception:
                continue        # один кривой элемент не должен гасить окно

        small = img.resize((w, h), _RESAMPLE)
        self._last_small = small
        if text_ops:
            dt = ImageDraw.Draw(small, "RGBA")
            for kind, args, kw in text_ops:
                try:
                    self._render_text(dt, kind, args, kw)
                except Exception:
                    continue
        self._photo = ImageTk.PhotoImage(small)
        # Ссылку кладём ещё и на сам виджет Tk. create_image запоминает
        # только имя картинки, а не объект: если единственная ссылка
        # лежала в SmoothCanvas и тот оказался локальной переменной
        # (как в окне просмотра фото), сборщик мусора освобождал
        # картинку сразу после выхода из функции — и окно открывалось
        # пустым. Виджет живёт столько же, сколько окно, и держит её.
        try:
            self.cv._smooth_photo = self._photo
        except Exception:
            pass
        self.cv.delete("all")
        self.cv.create_image(0, 0, anchor="nw", image=self._photo)
        self._w, self._h = w, h

    def _render_text(self, d, kind, args, kw):
        """Текст и значки — поверх уменьшенной картинки, в масштабе 1:1."""
        if kind == "text":
            x, y = self._flat(args)[:2]
            fam, size, bold = _parse_font(kw.get("font"))
            font = _FONTS.get(fam, size, bold, scale=1)
            d.text((x, y), str(kw.get("text", "")), font=font,
                   fill=_hex(kw.get("fill")) or _hex("#FFFFFF"),
                   anchor=_pil_anchor(kw.get("anchor", "center")))
        else:
            x, y = args
            font = _FONTS.icon(kw.get("size", 12), scale=1)
            if font is None:
                return
            d.text((x, y), FA.get(kw.get("name"), "?"), font=font,
                   fill=_hex(kw.get("fill")) or _hex("#FFFFFF"),
                   anchor=_pil_anchor(kw.get("anchor", "center")))

    def _render(self, img, d, kind, args, kw):
        S = SS
        fill = _hex(kw.get("fill"))
        outline = _hex(kw.get("outline"))
        width = float(kw.get("width", 1) or 0)

        if kind == "_card":
            # Карточка со всеми эффектами. Рисуется прямо в кадр
            # картинкой — тень и свечение иначе не сделать, у обычных
            # фигур нет мягких краёв.
            self._draw_card(img, *args)
            return

        if kind == "_neu":
            # Приподнятая неоморфная панель: тёмный след и светлый
            # блик уже запечены в картинку, берём её из кэша.
            self._draw_neu(img, *args)
            return

        if kind == "_sink":
            # Вдавленная «ванночка»: внутренние тень и блик.
            self._draw_sink(img, *args)
            return

        if kind == "rect":
            x1, y1, x2, y2 = self._flat(args)[:4]
            d.rectangle([x1 * S, y1 * S, x2 * S, y2 * S], fill=fill,
                        outline=outline,
                        width=max(1, int(width * S)) if outline else 0)

        elif kind == "oval":
            x1, y1, x2, y2 = self._flat(args)[:4]
            d.ellipse([x1 * S, y1 * S, x2 * S, y2 * S], fill=fill,
                      outline=outline,
                      width=max(1, int(width * S)) if outline else 0)

        elif kind == "line":
            pts = self._flat(args)
            xy = [(pts[i] * S, pts[i + 1] * S) for i in range(0, len(pts) - 1, 2)]
            if len(xy) < 2:
                return
            if kw.get("smooth"):
                xy = _spline(xy, int(kw.get("splinesteps", 12)))
            col = fill or _hex("#FFFFFF")
            lw = max(1, int(round(width * S)))
            d.line(xy, fill=col, width=lw, joint="curve")
            # PIL не умеет скруглять концы — дорисовываем кружками
            if kw.get("capstyle") == "round" and lw > S:
                r = lw / 2.0
                for px, py in (xy[0], xy[-1]):
                    d.ellipse([px - r, py - r, px + r, py + r], fill=col)

        elif kind == "poly":
            pts = self._flat(args)
            xy = [(pts[i] * S, pts[i + 1] * S) for i in range(0, len(pts) - 1, 2)]
            if len(xy) < 3:
                return
            if kw.get("smooth"):
                xy = _spline(xy, int(kw.get("splinesteps", 12)), closed=True)
            d.polygon(xy, fill=fill,
                      outline=outline if outline else None)

        elif kind == "arc":
            x1, y1, x2, y2 = self._flat(args)[:4]
            start = float(kw.get("start", 0))
            extent = float(kw.get("extent", 90))
            style = str(kw.get("style", "pieslice"))
            box = [x1 * S, y1 * S, x2 * S, y2 * S]
            # В Tk угол растёт против часовой стрелки, в PIL — по часовой.
            a0, a1 = -(start + extent), -start
            if style == "arc":
                col = outline or fill or _hex("#FFFFFF")
                d.arc(box, a0, a1, fill=col, width=max(1, int(width * S)))
            elif style == "chord":
                d.chord(box, a0, a1, fill=fill, outline=outline,
                        width=max(1, int(width * S)) if outline else 0)
            else:
                d.pieslice(box, a0, a1, fill=fill, outline=outline,
                           width=max(1, int(width * S)) if outline else 0)

        elif kind == "text":
            x, y = self._flat(args)[:2]
            fam, size, bold = _parse_font(kw.get("font"))
            font = _FONTS.get(fam, size, bold)
            anchor = _pil_anchor(kw.get("anchor", "center"))
            d.text((x * S, y * S), str(kw.get("text", "")), font=font,
                   fill=fill or _hex("#FFFFFF"), anchor=anchor)

        elif kind == "icon":
            x, y = args
            font = _FONTS.icon(kw.get("size", 12))
            ch = FA.get(kw.get("name"), "?")
            if font is None:
                return
            d.text((x * S, y * S), ch, font=font,
                   fill=_hex(kw.get("fill")) or _hex("#FFFFFF"),
                   anchor=_pil_anchor(kw.get("anchor", "center")))

        elif kind == "image":
            x, y = self._flat(args)[:2]
            src = kw.get("image")
            pil = getattr(src, "_pil_src", None)
            if pil is None:
                return
            # Увеличенную копию держим прямо на картинке и переиспользуем.
            # Раньше она пересчитывалась LANCZOS на КАЖДЫЙ кадр: пятнадцать
            # снимков в галерее съедали 24 мс, и плавное наведение
            # превращалось в слайд-шоу.
            big = getattr(src, "_pil_big", None)
            if big is None or getattr(src, "_pil_big_ss", None) != S:
                if S == 1:
                    big = pil
                else:
                    big = pil.resize((max(1, pil.width * S),
                                      max(1, pil.height * S)),
                                     Image.BILINEAR)
                try:
                    src._pil_big = big
                    src._pil_big_ss = S
                except Exception:
                    pass
            fx, fy = _anchor_frac(kw.get("anchor", "center"))
            px = x * S - big.width * fx
            py = y * S - big.height * fy
            img.paste(big, (int(round(px)), int(round(py))))


def _parse_font(spec):
    """('Segoe UI', 10, 'bold') -> (семейство, размер, жирный)."""
    if not spec:
        return "Segoe UI", 10, False
    if isinstance(spec, str):
        return spec, 10, False
    fam = spec[0] if len(spec) > 0 else "Segoe UI"
    size = spec[1] if len(spec) > 1 else 10
    bold = len(spec) > 2 and "bold" in str(spec[2]).lower()
    if "semibold" in str(fam).lower():
        bold = True
    try:
        size = int(size)
    except Exception:
        size = 10
    return fam, abs(size), bold


def _anchor_frac(a):
    """Привязка Tk -> доли смещения (по X, по Y).

    Разбираем ТОЧНЫМ сравнением, а не поиском буквы в строке. Прошлая
    версия делала `"n" in anchor`, и слово "center" ломало всё: в нём
    есть и "n", и "e", поэтому картинка считалась привязанной к правому
    краю и уезжала влево на свою ширину.
    """
    a = str(a).strip().lower()
    table = {
        "center": (0.5, 0.5), "c": (0.5, 0.5), "": (0.5, 0.5),
        "n": (0.5, 0.0), "s": (0.5, 1.0),
        "w": (0.0, 0.5), "e": (1.0, 0.5),
        "nw": (0.0, 0.0), "wn": (0.0, 0.0),
        "ne": (1.0, 0.0), "en": (1.0, 0.0),
        "sw": (0.0, 1.0), "ws": (0.0, 1.0),
        "se": (1.0, 1.0), "es": (1.0, 1.0),
    }
    return table.get(a, (0.5, 0.5))


def _pil_anchor(a):
    """Привязка Tk -> двухбуквенная привязка PIL.

    Тоже по таблице, а не поиском букв: "center" содержит и "n", и "e",
    и посимвольный разбор давал бы правый верхний угол вместо середины.
    """
    fx, fy = _anchor_frac(a)
    horiz = {0.0: "l", 0.5: "m", 1.0: "r"}[fx]
    # PIL по вертикали: a = верх, m = середина, d = низ
    vert = {0.0: "a", 0.5: "m", 1.0: "d"}[fy]
    return horiz + vert


def _spline(pts, steps=12, closed=False):
    """Гладкая кривая через точки (Catmull-Rom).

    Tk умеет smooth=True сам, у PIL такого нет. Формула даёт кривую,
    которая проходит ровно через заданные точки, — как раз то, что
    нужно спарклайну и плавникам эмблемы.
    """
    if len(pts) < 3:
        return pts
    p = list(pts)
    if closed:
        p = [pts[-1]] + list(pts) + [pts[0], pts[1]]
    else:
        p = [pts[0]] + list(pts) + [pts[-1]]
    out = []
    steps = max(2, min(steps, 24))
    for i in range(len(p) - 3):
        p0, p1, p2, p3 = p[i], p[i + 1], p[i + 2], p[i + 3]
        for j in range(steps):
            t = j / steps
            t2, t3 = t * t, t * t * t
            out.append((
                0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t
                       + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                       + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
                0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t
                       + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                       + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)))
    out.append(pts[-1] if not closed else pts[0])
    return out

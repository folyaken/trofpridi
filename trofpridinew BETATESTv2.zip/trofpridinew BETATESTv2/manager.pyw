# -*- coding: utf-8 -*-
"""
TrofPridi Manager — запуск без консоли (.pyw).

Вся логика разбита на два файла: manager_core.py (логика, читаемая
и тестируемая без графики) и manager.py (окно на Flet). Этот файл —
тонкая запускалка: .pyw ассоциируется в Windows с pythonw.exe,
поэтому окно открывается без чёрной консоли.
"""
import os
import runpy

runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "manager.py"), run_name="__main__")

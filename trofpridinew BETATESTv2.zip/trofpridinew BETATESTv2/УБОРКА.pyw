# -*- coding: utf-8 -*-
"""
TrofPridi — уборка папки.

Показывает, что в папке лишнее, и переносит это в архив. Ничего не
удаляет безвозвратно: всё уезжает в `TrofPridi_data/backup/УБОРКА_дата`,
откуда можно вернуть руками.

Запуск: двойной клик. Сначала показывается список — что уберём и
почему, — и только после подтверждения файлы перемещаются.
"""

import os
import shutil
import sys
import time

APP = "TrofPridi"
DATA_DIR = "TrofPridi_data"

BG = "#11151A"
CARD = "#1A2027"
FG = "#FFFFFF"
DIM = "#6C7B8B"
ACCENT = "#00A2FF"
GREEN = "#00E6B8"
GOLD = "#FFB300"
RED = "#FF5555"
FONT = "Segoe UI"

# Файлы, без которых программа не работает. Трогать нельзя.
NEEDED = {
    # запуск
    "TrofPridiV3.5.ahk", "stats.pyw", "stats_app.py",
    "ocr_watch.py", "ocr_watch.pyw",
    # модули
    "smooth_canvas.py", "fish_names.py", "exp_reader.py", "_bootstrap.py",
    # шаблоны, по которым бот узнаёт игру
    "catch.png", "zachet.png", "trophy.png", "trofpridi.ico",
    "ready_morning.png", "ready_day.png", "ready_night.png",
    "fish_morning.png", "fish_day.png", "fish_night.png",
    # документация и служебное
    "УСТАНОВИТЬ.pyw", "УСТАНОВКА.md", "ПРОВЕРКА_OCR.md", "ИДЕИ.md",
    "README.md", "КАК_ОБНОВИТЬ.md", "check_ahk.py", "УБОРКА.pyw",
    "ИНСТРУКЦИЯ.txt", "ЯРЛЫКИ.pyw",
}

# Что и почему считаем лишним. Ключ — имя файла, значение — пояснение.
JUNK = {
    "_deps_ok.txt": "отметка установки пакетов, её место в TrofPridi_data",
    "ocr_zones.txt": "старые зоны распознавания, теперь в TrofPridi_data",
    "stats_old.csv": "остаток от прежних версий, статистика не отсюда",
    "instruction.txt": "старая инструкция, заменена на УСТАНОВКА.md",
    "zones_check.ahk": "отладочный скрипт проверки зон",
    "zones_check2.ahk": "отладочный скрипт проверки зон",
    "TrofPridi_v3.3_original.ahk": "исходная версия бота до доработок",
    "TrofPridi_v4.0.ahk": "черновик другой версии, не запускается",
    "spining.ahk": "старая копия бота под другим именем",
    "TrofPridi_v3.3_multires.ahk": "прежняя версия бота, заменена на V3.5",
    "trofpridi.ico.old": "старая иконка",
}

# Эти лежат в корне, хотя должны быть в папке данных. Переносим ТУДА,
# а не в архив: программа продолжит их видеть.
MOVE_TO_DATA = {
    "fish_log.csv": "журнал улова",
    "stats.csv": "события бота",
    "settings.txt": "настройки окна",
    "ocr_debug.log": "лог распознавания",
}


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def scan():
    """Разбирает папку на три списка: мусор, переносимое, неизвестное."""
    d = script_dir()
    junk, to_data, unknown = [], [], []
    for name in sorted(os.listdir(d)):
        full = os.path.join(d, name)
        if os.path.isdir(full):
            continue
        if name in NEEDED:
            continue
        size = os.path.getsize(full)
        if name in JUNK:
            junk.append((name, size, JUNK[name]))
        elif name in MOVE_TO_DATA:
            to_data.append((name, size, MOVE_TO_DATA[name]))
        elif name.endswith((".pyc", ".pyo", ".bak", ".old", ".tmp")):
            junk.append((name, size, "временный файл"))
        elif name.endswith(".zip"):
            junk.append((name, size, "архив обновления, после распаковки не нужен"))
        else:
            unknown.append((name, size, "не знаю, что это — оставляю"))
    return junk, to_data, unknown


def human(n):
    return f"{n / 1024:.0f} КБ" if n >= 1024 else f"{n} Б"


def do_clean(junk, to_data):
    """Переносит файлы. Возвращает (сколько убрано, сколько ошибок)."""
    d = script_dir()
    stamp = time.strftime("%Y%m%d_%H%M%S")
    bak = os.path.join(d, DATA_DIR, "backup", f"УБОРКА_{stamp}")
    data = os.path.join(d, DATA_DIR)
    moved, errors = 0, []

    for name, _s, _w in junk:
        try:
            os.makedirs(bak, exist_ok=True)
            shutil.move(os.path.join(d, name), os.path.join(bak, name))
            moved += 1
        except Exception as e:
            errors.append(f"{name}: {e}")

    for name, _s, _w in to_data:
        try:
            os.makedirs(data, exist_ok=True)
            dst = os.path.join(data, name)
            if os.path.exists(dst):
                # В папке данных уже есть свежий файл — старый в архив,
                # чтобы не затереть рабочие записи.
                os.makedirs(bak, exist_ok=True)
                shutil.move(os.path.join(d, name),
                            os.path.join(bak, name))
            else:
                shutil.move(os.path.join(d, name), dst)
            moved += 1
        except Exception as e:
            errors.append(f"{name}: {e}")

    # Пустые папки кэша Python — их создаёт сам интерпретатор.
    for sub in ("__pycache__",):
        p = os.path.join(d, sub)
        if os.path.isdir(p):
            try:
                shutil.rmtree(p)
                moved += 1
            except Exception:
                pass
    return moved, errors, bak


def main():
    import tkinter as tk

    junk, to_data, unknown = scan()

    root = tk.Tk()
    root.title(f"{APP} — уборка папки")
    root.configure(bg=BG)
    root.resizable(False, False)
    rows = len(junk) + len(to_data) + len(unknown)
    W, H = 620, min(700, 250 + rows * 22)
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry(f"{W}x{H}+{(sw - W) // 2}+{max(0, (sh - H) // 3)}")

    tk.Label(root, text="Уборка папки", bg=BG, fg=FG,
             font=(FONT, 18, "bold")).pack(pady=(20, 0))
    tk.Label(root, text="Ничего не удаляется — всё уезжает в резервную копию",
             bg=BG, fg=DIM, font=(FONT, 9)).pack(pady=(2, 14))

    box = tk.Frame(root, bg=CARD)
    box.pack(fill="both", expand=True, padx=20)

    def section(title, items, color):
        if not items:
            return
        tk.Label(box, text=title, bg=CARD, fg=color,
                 font=(FONT, 10, "bold"), anchor="w").pack(
            fill="x", padx=14, pady=(10, 2))
        for name, size, why in items:
            fr = tk.Frame(box, bg=CARD)
            fr.pack(fill="x", padx=26)
            tk.Label(fr, text=name, bg=CARD, fg=FG, font=(FONT, 9),
                     width=30, anchor="w").pack(side="left")
            tk.Label(fr, text=human(size), bg=CARD, fg=DIM,
                     font=(FONT, 8), width=8, anchor="e").pack(side="left")
            tk.Label(fr, text="  " + why, bg=CARD, fg=DIM,
                     font=(FONT, 8), anchor="w").pack(side="left")

    section(f"Лишнее — в архив ({len(junk)})", junk, GOLD)
    section(f"Не на месте — в папку данных ({len(to_data)})", to_data, ACCENT)
    section(f"Незнакомое — не трогаю ({len(unknown)})", unknown, DIM)
    if not junk and not to_data:
        tk.Label(box, text="\nПапка уже чистая — убирать нечего.",
                 bg=CARD, fg=GREEN, font=(FONT, 11)).pack(pady=20)

    tk.Frame(box, bg=CARD, height=8).pack()
    status = tk.Label(root, text="", bg=BG, fg=ACCENT, font=(FONT, 9),
                      wraplength=W - 50, justify="center")
    status.pack(pady=(10, 2))

    btns = tk.Frame(root, bg=BG)
    btns.pack(pady=(4, 16))

    def run():
        moved, errors, bak = do_clean(junk, to_data)
        if errors:
            status.config(text="Частично не вышло: " + "; ".join(errors[:2]),
                          fg=RED)
        else:
            status.config(text=f"Готово. Убрано: {moved}. "
                               f"Копия: {os.path.basename(bak)}", fg=GREEN)
        ok_btn.config(state="disabled")

    ok_btn = tk.Button(btns, text="Убрать", command=run, bg="#17567F",
                       fg=FG, relief="flat", padx=28, pady=6,
                       font=(FONT, 10, "bold"), cursor="hand2",
                       activebackground="#2A8FD0", activeforeground=FG)
    if junk or to_data:
        ok_btn.pack(side="left", padx=6)
    tk.Button(btns, text="Закрыть", command=root.destroy, bg=CARD, fg=FG,
              relief="flat", padx=24, pady=6, font=(FONT, 10),
              cursor="hand2", activebackground="#222A33",
              activeforeground=FG).pack(side="left", padx=6)

    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        try:
            import tkinter as tk
            from tkinter import messagebox
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror(f"{APP} — уборка", str(e))
        except Exception:
            print(e)

# -*- coding: utf-8 -*-
"""
TrofPridi — запуск окна статистики без консоли (.pyw).

Вся логика живёт в stats_app.py — искать и править нужно ТОЛЬКО там.
Этот файл — тонкая запускалка: .pyw ассоциируется в Windows с
pythonw.exe, поэтому окно открывается без чёрной консоли.
"""
import os
import runpy

runpy.run_path(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "stats_app.py"), run_name="__main__")

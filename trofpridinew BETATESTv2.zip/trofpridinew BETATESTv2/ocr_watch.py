#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TrofPridi — распознавание улова (OCR).

Следит за экраном. Когда появляется окно улова, читает название рыбы
и её вес, дописывает строку в fish_log.csv. Окно статистики берёт
данные оттуда.

Запуск:   ocr_watch.pyw            — фоном, без консоли
          python ocr_watch.py      — с выводом, удобно для настройки
          python ocr_watch.py --calibrate   — помощник настройки зон

Движок OCR: встроенный в Windows 10/11 (Windows.Media.Ocr).
Ставить Tesseract не нужно — только пакет winsdk:
    pip install winsdk mss
"""

import argparse
import asyncio
import configparser
import csv
import difflib
import itertools
import hashlib
import json
import os
import re
import sys
import threading
import time
from collections import Counter
from datetime import datetime

# Доустанавливаем недостающие пакеты при первом запуске.
# Список общий с заставкой статистики (ocr_deps из _bootstrap): она
# проверяет всё то же самое уже на старте и сама доустанавливает
# недостающее в своём окне — своё окно подготовки здесь показывается
# только если распознавание запустили вручную в обход статистики.
try:
    from _bootstrap import ensure, ocr_deps
    ensure(ocr_deps())
except Exception:
    pass

CFG_NAME = "ocr_zones.txt"
STOP_NAME = "STOP"          # файл-сигнал от бота: завершаем работу
DEBUG_LOG = True
_MUTEX = None            # писать сырой текст OCR в ocr_debug.log
_RAPID_WARNED = False    # о недоступности точного чтения сообщаем один раз
ZONES_VERSION = 9          # поднимать при правке DEFAULT_ZONES
LOG_NAME = "fish_log.csv"
NAME_MAP_NAME = "names_map.txt"   # переименования рыб от пользователя

# Зоны по умолчанию для 1920x1080 — доли экрана, поэтому подходят
# и для 2К. Уточняются через --calibrate.
# Проверено по снимкам калибровки на 1920x1080.
# Зона веса захватывает и длину, и значок "Зачётная" — это удобно,
# всё читается за один проход.
DEFAULT_ZONES = {
    # x1, y1, x2, y2 в долях ширины/высоты экрана.
    # Значения вымерены по реальному скриншоту окна улова 1919x1079.
    "name":   (0.3400, 0.0550, 0.6600, 0.1050),   # название рыбы
    # Нижняя граница 0.1650, а не 0.1500: у игроков с крупным
    # интерфейсом плашка категории обрезалась на четверть, и «Трофей»
    # не читался ни текстом, ни по цвету — рыба попадала в лог
    # как незачётная.
    "weight": (0.3400, 0.1000, 0.6600, 0.1650),   # вес + длина + категория
    # Панель опыта бывает ДВУХ видов, и это главная причина, по которой
    # у части рыб опыт не записывался. Когда действуют бонусы (премиум,
    # счастливый час), панель широкая: 3-4 плашки и метка «ВСЕГО ОЧКОВ
    # ОПЫТА». Без бонусов она короткая — всего две плашки, слова «ВСЕГО»
    # в ней нет, а сами плашки стоят правее и ниже. Прежняя зона резала
    # такую панель: справа терялось 34 px, снизу 67 px вместе с подписью
    # «ОЧКОВ ОПЫТА». OCR получал обрывок и возвращал пусто.
    # Границы подобраны по реальному кадру: панель занимает X 796..1343,
    # Y 742..981. Снизу намеренно останавливаемся на 0.8750 — ниже идут
    # кнопки «В садок»/«Отпустить» и плашка «+929 XP» за отпуск рыбы,
    # а её число нельзя путать с опытом за улов.
    # Ширина 0.1200..0.8800 — с запасом на СЕМЬ плашек.
    #
    # Панель центрирована по экрану и растёт в обе стороны по мере того,
    # как добавляются бонусы: базовый опыт, снасть, премиум, счастливый
    # час, «ВСЕГО». На кадрах игрока это уже пять плашек, X 359..920 при
    # ширине 1280 (доли 0.28..0.72). Колонка «ВСЕГО ОЧКОВ ОПЫТА» всегда
    # крайняя справа, поэтому каждый новый бонус сдвигает её дальше от
    # центра — и любая тесная зона рано или поздно срежет именно её.
    # Берём заведомо шире, чем панель бывает: лишний фон распознаванию
    # не мешает, а вот потерянный правый столбец стоил нам опыта.
    #
    # По высоте НЕ расширяем: плашки всегда на одной высоте, а ниже идут
    # кнопки «В садок»/«Отпустить» и плашка «+N XP» за отпуск, число из
    # которой нельзя путать с опытом за улов.
    # Нижняя граница 0.9000, а не 0.8580.
    #
    # Панель растёт не только вширь, но и ВВЫСЬ: когда игра добавляет
    # плашки заданий квалификации, подписи в них идут в три строки
    # («выполнено задание / квалификации / ЛАЙТ И УЛЬТРАЛАЙТ»), и вся
    # панель занимает Y 494..647 вместо привычных 494..600. Прежняя
    # граница резала её на 30 px — как раз по строке с числом у крайних
    # колонок, и опыт у таких рыб не читался вовсе.
    #
    # Плашка «+N XP» за отпуск теперь попадает в кадр, но её число
    # вырезается фильтром в parse_exp, а точный чтец берёт колонку
    # строго под подписью «ВСЕГО ОЧКОВ ОПЫТА» — спутать невозможно.
    "exp":    (0.1200, 0.6750, 0.8800, 0.9000),   # панель очков опыта
    "photo":  (0.1251, 0.2456, 0.8859, 0.6487),   # картинка рыбы
    "release": (0.6423, 0.8601, 0.7153, 0.9194),  # "+N XP" за отпуск
}

# Всё, что создаётся во время работы, складываем в отдельные папки,
# чтобы рядом со скриптами не копился мусор.
DATA_DIR = "TrofPridi_data"          # логи и настройки
PHOTO_DIR = "TrofPridi_data/photos"  # снимки пойманной рыбы
DEBUG_DIR = "TrofPridi_data/debug"   # снимки зон при калибровке

POLL_SEC = 0.35         # окно улова висит ~3 с, успеваем 5-6 проходов
COOLDOWN_SEC = 25       # не писать одну рыбу дважды (точный дубль подписи)
# Сколько секунд собирать показания одного улова, прежде чем записать.
# Одного кадра мало: счётчик опыта в игре бежит вверх (первые кадры
# показывают «1»), а короткие названия OCR читает то верно, то нет.
# За это время набирается 4-6 кадров, и решение принимается по ним всем.
COLLECT_SEC = 1.6
COLLECT_MAX = 7         # больше кадров смысла нет — окно всё равно закроется


def single_instance():
    """Не даёт запустить второй экземпляр.

    use_last_error=True обязателен: без него ctypes может затереть код
    ошибки своими внутренними вызовами, GetLastError вернёт мусор,
    и процесс молча закроется, решив что он второй.
    """
    global _MUTEX
    try:
        import ctypes
        from ctypes import wintypes
        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.CreateMutexW.restype = wintypes.HANDLE
        k32.CreateMutexW.argtypes = [wintypes.LPCVOID, wintypes.BOOL,
                                     wintypes.LPCWSTR]
        _MUTEX = k32.CreateMutexW(None, False, "TrofPridi_OCR_Watch_v1")
        err = ctypes.get_last_error()
        if not _MUTEX:
            return True                 # не смогли создать — не мешаем работе
        return err != 183               # ERROR_ALREADY_EXISTS
    except Exception:
        return True                     # не Windows — не мешаем


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def data_path(*parts):
    """Путь внутри папки данных. Папка создаётся при необходимости."""
    d = os.path.join(script_dir(), DATA_DIR, *parts[:-1]) if len(parts) > 1 \
        else os.path.join(script_dir(), DATA_DIR)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, parts[-1]) if parts else d


# ---------------------------------------------------------------- Telegram
# №61: улов летит в Telegram-бота, а из чата можно управлять
# помощником (/pause /resume /status /last). №69: и кнопками
# (меню под сообщением: пауза, статус, вес, режим фото). Всё на стандартной
# библиотеке — новых зависимостей не появилось. Настройки (токен,
# chat id, фильтры) лежат в TrofPridi_data/configs/license.json,
# задаются из Менеджера и перечитываются перед каждым обращением —
# менять их можно на лету, без перезапуска.
TG_API = "https://api.telegram.org"
_TG_STARTED = False
_KIND_RU = {"trophy": "🏆 ТРОФЕЙ", "zachet": "✅ зачётная",
            "small": "▫️ обычная"}
_KIND_TXT = {"trophy": "трофей", "zachet": "зачётная", "small": "обычная"}


def _tg_cfg():
    """Свежие настройки Telegram или None (выключен/не заполнен)."""
    try:
        with open(data_path("configs", "license.json"),
                  encoding="utf-8") as f:
            tg = json.load(f).get("telegram") or {}
    except Exception:
        return None
    if not (tg.get("enabled") and tg.get("token") and tg.get("chat_id")):
        return None
    try:
        mw = float(tg.get("min_weight_kg", 0) or 0)
    except (TypeError, ValueError):
        mw = 0.0
    photos = tg.get("photos")
    return {"token": str(tg["token"]).strip(),
            "chat_id": str(tg["chat_id"]).strip(),
            "photos": photos if photos in ("all", "marks", "none") else "all",
            "min_weight": max(0.0, mw),
            "commands": bool(tg.get("commands", True)),
            "proxy": str(tg.get("proxy", "") or "").strip(),
            "backups": [str(x).strip() for x in
                        (tg.get("proxy_backup") or []) if str(x).strip()]}


def _tg_promote(idx):
    """№67: запасной прокси становится основным (умерший выкидываем).

    Публичные прокси живут минутами — без этого уведомления за ночь
    молча заглохнут, хотя в резерве был живой адрес.
    """
    try:
        path = data_path("configs", "license.json")
        with open(path, encoding="utf-8") as f:
            lic = json.load(f)
        tg = lic.get("telegram") or {}
        bk = [x for x in (tg.get("proxy_backup") or []) if x]
        if 1 <= idx <= len(bk):
            tg["proxy"] = bk.pop(idx - 1)
            tg["proxy_backup"] = bk
            lic["telegram"] = tg
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(lic, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
    except Exception:
        pass


def _tg_call(cfg, method, payload=None, timeout=25, photo=None,
             media=None):
    """Вызов Bot API по ЦЕПОЧКЕ прокси (основной + запасные, №67).

    При отказе перескакиваем сами и запоминаем новый рабочий как
    основной — иначе следующий вызов опять уткнулся бы в мёртвый.
    """
    try:
        import tg_net
    except ImportError:
        return False, "нет файла tg_net.py рядом с программой"
    eps = [cfg.get("proxy", "")] + list(cfg.get("backups") or [])
    ok, out, idx = tg_net.api_call_multi(
        eps, cfg["token"], method, payload=payload, photo_path=photo,
        timeout=timeout, media=media)
    if ok and idx:
        _tg_promote(idx)
    return ok, out


def _tg_send(cfg, text, photo=None, keyboard=None, media=None):
    """Отправка текста или фото/гифки с подписью. media=("animation",
    "image/gif", "menu.gif") — тогда sendAnimation (№71, ГИФ-меню).
    Не поднимает исключений."""
    try:
        if photo and os.path.isfile(photo):
            method = ("sendAnimation" if (media and media[0] == "animation")
                      else "sendPhoto")
            payload = {"chat_id": cfg["chat_id"], "caption": text[:1000]}
            if keyboard:
                # в multipart-форме разметка уходит JSON-СТРОКОЙ
                payload["reply_markup"] = json.dumps(keyboard,
                                                     ensure_ascii=False)
            ok, out = _tg_call(cfg, method, payload,
                               timeout=30, photo=photo, media=media)
        else:
            payload = {"chat_id": cfg["chat_id"], "text": text[:4090]}
            if keyboard:
                payload["reply_markup"] = keyboard
            ok, out = _tg_call(cfg, "sendMessage", payload)
        if not ok:
            _debug_log("telegram: не отправлено: " + str(out))
        return ok
    except Exception as e:
        _debug_log("telegram: исключение при отправке: %r" % e)
        return False


# -------------------------------------------------- кнопки в чате
# №69: бот — не только «прислал статистику», но и пульт. Под
# сообщением живут интерактивные кнопки (пауза, статус, последний
# улов, режим фото, минимальный вес). Нажатие прилетает в тот же
# getUpdates-поток как callback_query (см. _tg_poll_loop ниже).
_PHOTO_LABELS = {"all": "все", "marks": "трофеи и зачётные",
                 "none": "без фото"}


def _tg_weight_label(mw):
    if mw <= 0:
        return "все"
    return "от %s кг" % (("%.1f" % mw).rstrip("0").rstrip("."))


def _tg_menu_markup(cfg, screen="main"):
    """Клавиатура меню под сообщением. screen: main|photos|weight."""
    def btn(text, data):
        return {"text": text, "callback_data": data}
    if screen == "photos":
        rows = [[btn(("✔ " if cfg["photos"] == k else "") + t,
                     "tp:ph:" + k)]
                for k, t in _PHOTO_LABELS.items()]
        rows.append([btn("◀ Назад", "tp:menu")])
        return {"inline_keyboard": rows}
    if screen == "weight":
        cur = cfg["min_weight"]
        rows = [[btn(("✔ " if abs(cur - v) < 1e-9 else "") + t,
                     "tp:mw:%g" % v)]
                for v, t in ((0.0, "все"), (1.0, "1 кг"),
                             (3.0, "3 кг"), (5.0, "5 кг"))]
        rows.append([btn("◀ Назад", "tp:menu")])
        return {"inline_keyboard": rows}
    if screen == "shop":
        return _tg_shop_admin_markup()
    if screen == "pool":
        return _tg_funpay_pool_markup()
    mode = _tg_bot_mode()
    if mode == "paused":
        row1 = [btn("▶ Включить (снять с паузы)", "tp:resume")]
    elif mode == "stopped":
        # №76: бота выключили — из Телеграма можно и ЗАПУСТИТЬ
        row1 = [btn("🚀 Запустить бота", "tp:start")]
    else:
        row1 = [btn("⏸ Пауза (выключить)", "tp:pause")]
    return {"inline_keyboard": [
        row1,
        [btn("📊 Статус", "tp:status"),
         btn("🐟 Последний улов", "tp:last")],
        [btn("📷 Фото: " + _PHOTO_LABELS[cfg["photos"]], "tp:photos"),
         btn("⚖ Вес: " + _tg_weight_label(cfg["min_weight"]),
             "tp:weight")],
        # №78: магазин — В ТЕЛЕГРАМЕ, как просил владелец
        [btn("🛒 Магазин подписки", "tp:shop")],
    ]}


def _fp_load_pool():
    """Реестр плавучих ключей из license.json (журнал выдач)."""
    try:
        with open(data_path("configs", "license.json"),
                  encoding="utf-8") as f:
            pool = json.load(f).get("funpay_pool") or []
        return [x for x in pool if isinstance(x, dict)]
    except Exception:
        return []


def _tg_funpay_pool_markup():
    """«🎟 FunPay-пул» (№83): генерация плавучих ключей пачками
    для авто-лотов FunPay. Ключи — без привязки к машине, площадка
    сама выдаёт покупателю следующий из списка."""
    def b(t, data):
        return {"text": t, "callback_data": data}
    pool = _fp_load_pool()
    cnt = {p: sum(1 for x in pool if x.get("plan") == p)
           for p in ("1", "7", "M", "F")}
    return {"inline_keyboard": [
        [b("🎟 +5: 1 день (40 ₽)", "shf:fp:1"),
         b("🎟 +5: 7 дней (150 ₽)", "shf:fp:7")],
        [b("🎟 +5: 30 дней (400 ₽)", "shf:fp:M"),
         b("🎟 +5: навсегда (800 ₽)", "shf:fp:F")],
        [b("В журнале: 1д×%d 7д×%d 30д×%d ∞×%d"
           % (cnt["1"], cnt["7"], cnt["M"], cnt["F"]), "shf:noop")],
        [b("◀ Назад в магазин", "tp:shopadmin")],
    ]}


def _funpay_generate(plan, count=5):
    """Сгенерить пачку плавучих ключей и записать в журнал."""
    try:
        import manager_core as mc
    except Exception:
        return None
    keys = mc.keygen_float(plan, count)
    if not keys:
        return None
    try:
        mc.funpay_pool_add(keys, plan)
        return keys
    except Exception:
        return keys          # журнал упал — ключи всё равно отдаём


def _tg_shop_owner_view(cfg):
    """№82: ХОЗЯИН смотрит витрину обычным покупателем — жмёт
    «🛒 Купить подписку» и проходит ту же цепочку (тарифы →
    способ оплаты → HWID). Его босс-панель — одна ненавязчивая
    кнопка «🔧» внизу; покупатели её не видят никогда (и нажать
    не смогут — она отвечает только хозяйскому чату)."""
    kb = _shop_kb_root()
    kb["inline_keyboard"] = kb["inline_keyboard"] + [
        [{"text": "🔧 Настройки магазина (хозяину)",
          "callback_data": "tp:shopadmin"}]]
    _tg_send(cfg, "🛒 Магазин подписки — ровно так его видит "
                  "покупатель ↓", keyboard=kb)


def _tg_shop_admin_markup():
    """Экран магазина ДЛЯ ВЛАДЕЛЬЦА, весь в Телеграме (№78): карта,
    СБП, цены и заявки — правятся прямо отсюда кнопками, а значения
    присылаются обычным сообщением в чат."""
    def b(t, data):
        return {"text": t, "callback_data": data}
    sc = _shop_cfg()
    d = _shop_load()
    pend = sum(1 for x in (d.get("orders") or {}).values()
               if x.get("status") == "pending")
    buyers = set(str(x.get("buyer")) for x in
                 (d.get("orders") or {}).values() if x.get("buyer"))

    def pr(plan):
        return (_money(sc["prices"][plan]) if plan in sc["prices"]
                else "скрыт")
    return {"inline_keyboard": [
        [b("💳 Карта: " + (sc["card"] or "не задана"), "shf:card")],
        [b("📱 СБП: " + (sc["sbp"] or "не задан"), "shf:sbp")],
        [b("1 день: " + pr("1"), "shf:p:1"),
         b("7 дней: " + pr("7"), "shf:p:7")],
        [b("30 дней: " + pr("M"), "shf:p:M"),
         b("Навсегда: " + pr("F"), "shf:p:F")],
        [b("🤖 Выдача: " + _AUTO_RU.get(sc["auto"], sc["auto"]),
           "sha:auto")],
        [b("📦 Заявки" + (" (%d)" % pend if pend else ""),
           "shp:list")],
        # №85: база клиентов — блок/разблок и отзыв ключей
        [b("👥 Клиенты" + (" (%d)" % len(buyers) if buyers else ""),
           "shc:list")],
        [b("🎟 FunPay-пул (ключи без ПК)", "shf:pool")],
        [b("◀ Назад", "tp:menu")],
    ]}


def _shop_set_field(field, value, plan=None):
    """Запись реквизита/цены витрины (license.json[shop]) — атомарно,
    прочие ключи (телеграм и прочее) не страдают."""
    try:
        path = data_path("configs", "license.json")
        with open(path, encoding="utf-8") as f:
            lic = json.load(f)
        sh = lic.get("shop") or {}
        if field == "auto":
            if value in _SHOP_AUTOS:
                sh["auto"] = value
            else:
                sh["auto"] = "all" if value else "manual"
        elif field == "price":
            try:
                v = float(str(value or "").strip().replace(",", "."))
            except (TypeError, ValueError):
                return None
            # №80: первая правка стартует от ЗАВОДСКИХ цен — иначе
            # остальные тарифы «схлопывались» из витрины.
            if "prices" in sh:
                pr = {}
                for k, vv in (sh.get("prices") or {}).items():
                    try:
                        pr[k] = float(vv)
                    except (TypeError, ValueError):
                        pass
            else:
                pr = dict(_SHOP_DEFAULT_PRICES)
            if v > 0:
                pr[plan] = v
            else:
                pr.pop(plan, None)
            sh["prices"] = pr
        else:
            sh[field] = str(value or "").strip()
        lic["shop"] = sh
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(lic, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        return True
    except Exception:
        return None


def _shop_reset_prices():
    """Вернуть заводские цены (40/150/400/800) одной кнопкой (№81).
    Наследие тестовых заполений («1 день 349» и пр.) перекрывало
    заводские — и юзер не понимал, «почему не поменялось»."""
    try:
        path = data_path("configs", "license.json")
        with open(path, encoding="utf-8") as f:
            lic = json.load(f)
        sh = lic.get("shop") or {}
        sh["prices"] = dict(_SHOP_DEFAULT_PRICES)
        lic["shop"] = sh
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(lic, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        return True
    except Exception:
        return None


def _shop_admin_text(cfg, text):
    """Ответ владельца на запрос магазина («пришли карту/цену…»).
    True = сообщение съедено магазином, дальше его гнать нельзя."""
    try:
        d = _shop_load()
        adm = d.get("admin") or {}
        fld = adm.get("field")
        if not fld:
            return False
        # №80: КОМАНДЫ (/start, /shop…) и кнопка «🎣 Меню» НЕ считаются
        # ответом — раньше /start попадал в номер КАРТЫ (скрин юзера).
        # Сессию снимаем и отдаём текст обычному обработчику.
        low = text.strip().lower()
        if low.startswith("/") or low in ("🎣 меню", "меню", "menu"):
            d["admin"] = {}
            _shop_save(d)
            return False
        d["admin"] = {}
        _shop_save(d)
        if fld in ("card", "sbp"):
            val = "" if low in ("нет", "-", "0", "удали") else text.strip()
            ok = _shop_set_field(fld, val)
            if not ok:
                _tg_send(cfg, "Не получилось сохранить 😕 — жми «🛒 "
                              "Магазин» и попробуй ещё.")
                return True
            _tg_send(cfg, ("💳 Карта: %s" % (val or "убрана"))
                     if fld == "card"
                     else ("📱 СБП: %s" % (val or "убран")))
            return True
        if fld == "price":
            plan = str(adm.get("plan") or "M")
            if low in ("нет", "-"):
                value = "0"
            else:
                value = text
            ok = _shop_set_field("price", value, plan=plan)
            if not ok:
                _tg_send(cfg, "Это не число — тариф «%s» не тронут. "
                              "Открой «🛒 Магазин» и попробуй ещё."
                         % _PLAN_RU.get(plan, plan))
                return True
            sc = _shop_cfg()
            _tg_send(cfg, "Тариф «%s»: %s ✅"
                     % (_PLAN_RU.get(plan, plan),
                        (_money(sc["prices"][plan])
                         if plan in sc["prices"] else "скрыт")))
            return True
        return False
    except Exception as e:
        _debug_log("shop: admin-text: %r" % e)
        return True


BOT_SCRIPT = "TrofPridiV3.5.ahk"


def _tg_launch_bot():
    """Запуск главного бота из Телеграма: просто «двойной щелчок»
    по AHK-файлу рядом с программой (как кнопка «Запустить»
    в менеджере, ключ spin-помощника)."""
    try:
        ahk = os.path.join(script_dir(), BOT_SCRIPT)
        if not os.path.isfile(ahk):
            return False
        if os.name == "nt":
            os.startfile(ahk)
        else:
            import subprocess
            subprocess.Popen(["cmd", "/c", "start", "", ahk])
        return True
    except Exception:
        return False


# Что подтверждаем и сколько ждём ответа бота
_TG_CONFIRM = {
    "pause":  (("paused",),          10,
               "⏸ Принял: бот на паузе, ничего не нажимает. "
               "«Продолжить» — и ловит дальше."),
    "resume": (("running",),         10,
               "▶️ Принял: бот снова ловит 🎣"),
    "start":  (("running", "paused"), 20,
               "🚀 Бот запущен! Если он на паузе — жми "
               "«Продолжить», и поехали 🎣"),
}


def _tg_confirm_mode(cfg, want, mid=None):
    """После команды ЧЕСТНО доложить человеку, что бот реально
    сменил состояние (бот пишет bot_state.ini раз в секунду).
    Без этого было «часики покрутились — а сделал ли?..» (№76)."""
    modes, wait_s, ok_text = _TG_CONFIRM[want]

    def _wait():
        deadline = time.time() + wait_s
        while time.time() < deadline:
            if _tg_bot_mode() in modes:
                _tg_send(cfg, ok_text)
                if mid:          # и кнопку под сообщением перевернуть
                    fresh = _tg_cfg() or cfg
                    _tg_call(cfg, "editMessageReplyMarkup",
                             {"chat_id": cfg["chat_id"], "message_id": mid,
                              "reply_markup": _tg_menu_markup(fresh)},
                             timeout=10)
                return
            time.sleep(1.0)
        _tg_send(cfg, "🤔 Бот не ответил за %d сек. — похоже, его "
                      "меню не запущено." % wait_s)

    threading.Thread(target=_wait, daemon=True).start()


_MENU_BTN_TEXT = "🎣 Меню"


# Синяя кнопка «Меню» В СТРОКЕ ВВОДА (как у больших ботов, №79) —
# это встроенный setChatMenuButton Телеграма, список команд из
# setMyCommands. Старая reply-клавиатура снята: другая картинка,
# и юзер просил именно такую.
_TG_COMMANDS = [
    {"command": "start",  "description": "🏠 Главное меню"},
    {"command": "menu",   "description": "🎣 Кнопки управления"},
    {"command": "shop",   "description": "🛒 Купить подписку"},
    {"command": "pause",  "description": "⏸ Пауза ловли"},
    {"command": "resume", "description": "▶ Продолжить ловлю"},
    {"command": "status", "description": "📊 Статус помощника"},
    {"command": "last",   "description": "🐟 Последний улов"},
    {"command": "help",   "description": "🆘 Помощь"},
]


def _tg_pin_menu_button(cfg):
    """Синяя кнопка «Меню» слева в строке ввода (как на скрине
    юзера, №79): setMyCommands заполняет список, setChatMenuButton
    включает саму пилюлю. Отметка kb_v=2: версия 1 — старая
    reply-клавиатура, её мы аккуратно снимаем."""
    try:
        path = data_path("configs", "license.json")
        with open(path, encoding="utf-8") as f:
            lic = json.load(f)
        tg = lic.get("telegram") or {}
        v = tg.get("kb_v")
        if v == 2:
            return
        ok1, _o1 = _tg_call(cfg, "setMyCommands",
                            {"commands": _TG_COMMANDS}, timeout=15)
        ok2, _o2 = _tg_call(cfg, "setChatMenuButton",
                            {"menu_button": {"type": "commands"}},
                            timeout=15)
        if v == 1:                      # снимаем старую клавиатуру
            _tg_call(cfg, "sendMessage",
                     {"chat_id": cfg["chat_id"],
                      "text": "Кнопка «Меню» переехала в строку ввода "
                              "(синяя пилюля слева) 👇",
                      "reply_markup": {"remove_keyboard": True}},
                     timeout=15)
        if ok1 and ok2:
            tg["kb_v"] = 2
            lic["telegram"] = tg
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(lic, f, ensure_ascii=False, indent=2)
            os.replace(tmp, path)
    except Exception:
        pass


# ---------------------------------------------------- магазин (№77)
# Покупка подписки прямо в боте. Покупатель: /start → «🛒 Купить
# подписку» → тариф → реквизиты → «✅ Я оплатил» → присылает свой
# HWID (виден в его Менеджере на вкладке «Активация»). Заявка
# прилетает владельцу с кнопкой «🔑 Выдать ключ» — бот САМ
# подписывает ключ под чужой HWID и шлёт покупателю. Деньги идут
# картой/СБП напрямую владельцу, бот — витрина и автовыдача.
_SHOP_FILE = "shop.json"
_PLAN_RU = {"1": "1 день", "7": "7 дней", "M": "30 дней",
            "F": "навсегда"}
# №80: цены забиты СРАЗУ (попросил владелец) — забивать руками
# не нужно. Своя правка в магазине (кнопка тарифа) перекрывает,
# «нет» — скрывает тариф.
_SHOP_DEFAULT_PRICES = {"1": 40.0, "7": 150.0, "M": 400.0,
                        "F": 800.0}


def _shop_cfg():
    """Витрина из настроек владельца (Менеджер → Активация): карта,
    СБП, цены по тарифам. Пустой тариф = скрыт."""
    try:
        with open(data_path("configs", "license.json"),
                  encoding="utf-8") as f:
            sh = json.load(f).get("shop") or {}
    except Exception:
        sh = {}
    prices = {}
    if "prices" in sh:                      # витрину уже правили
        for plan in ("1", "7", "M", "F"):
            try:
                v = float(str((sh.get("prices") or {})
                              .get(plan, "") or "").replace(",", "."))
            except (TypeError, ValueError):
                v = 0.0
            if v > 0:
                prices[plan] = v
    else:                                   # свежая — заводские цены
        prices = dict(_SHOP_DEFAULT_PRICES)
    # №81: автоочистка мусора в реквизитах. Раньше баг глотал
    # команды — и /start записался КАРТОЙ (скрин юзера). Баг
    # убит в №80, а наследие вот так вот сметаем сами.
    card = str(sh.get("card", "") or "").strip()
    sbp = str(sh.get("sbp", "") or "").strip()
    if card.startswith("/") or card.strip().lower() in ("меню",):
        card = ""
    if sbp.startswith("/") or sbp.strip().lower() in ("меню",):
        sbp = ""
    return {"card": card,
            "sbp": sbp,
            "note": str(sh.get("note", "") or "").strip(),
            "auto": _shop_auto_mode(sh),
            "prices": prices}


# №85: три режима выдачи ключа. Дыра старого «автомата для всех»:
# человек жмёт «Я оплатил» БЕЗ оплаты и получает ключ бесплатно.
# Теперь по умолчанию автомат работает ТОЛЬКО для уже проверенных
# клиентов (тех, кому владелец однажды выдал ключ), а новичок всегда
# ждёт хозяйской кнопки. Миграция старого флага: True → «trusted»
# (закрываем дыру у всех обновившихся), False → «manual», строки —
# как есть.
_SHOP_AUTOS = ("trusted", "all", "manual")
_AUTO_RU = {"all": "АВТОМАТ ВСЕМ (риск: «Я оплатил» без денег!)",
            "trusted": "АВТОМАТ проверенным, новым — моя кнопка",
            "manual": "только после моей кнопки"}


def _shop_auto_mode(sh):
    au = sh.get("auto")
    if au is True:
        return "trusted"
    if au is False:
        return "manual"
    if au in _SHOP_AUTOS:
        return au
    return "trusted"


def _shop_is_blocked(d, chat):
    """Заблокированный клиент: магазин для него закрыт (№85)."""
    return str(chat) in [str(x) for x in (d.get("blocked") or [])]


def _shop_trust(d, chat):
    """Проверенный клиент: есть хоть одна УДЕРЖАННАЯ выдача (granted).
    Отозванные (revoked) и отклонённые (denied) доверия не дают:
    ключ отозвали — следующая покупка снова ждёт хозяйской кнопки."""
    c = str(chat)
    for o in (d.get("orders") or {}).values():
        if str(o.get("buyer")) == c and o.get("status") == "granted":
            return True
    return False


def _money(v):
    return ("%g ₽" % v)


def _shop_load():
    try:
        with open(data_path("configs", _SHOP_FILE),
                  encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            d.setdefault("sessions", {})
            d.setdefault("orders", {})
            d.setdefault("blocked", [])
            return d
    except Exception:
        pass
    return {"sessions": {}, "orders": {}, "blocked": []}


def _shop_save(d):
    try:
        path = data_path("configs", _SHOP_FILE)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def _shop_send(cfg, chat, text, kb=None):
    payload = {"chat_id": str(chat), "text": text[:4090]}
    if kb:
        payload["reply_markup"] = kb
    ok, _out = _tg_call(cfg, "sendMessage", payload, timeout=15)
    return ok


def _shop_name(frm, chat):
    nm = " ".join(x for x in (str(frm.get("first_name") or ""),
                              str(frm.get("last_name") or "")) if x)
    un = str(frm.get("username") or "").strip()
    if un:
        nm = (nm + " @" + un).strip()
    return nm.strip() or ("id " + str(chat))


def _shop_kb_root():
    return {"inline_keyboard": [
        [{"text": "🛒 Купить подписку", "callback_data": "sh:plans"}]]}


def _shop_kb_plans(sc):
    rows = []
    for plan in ("1", "7", "M", "F"):
        if plan in sc["prices"]:
            rows.append([{"text": "%s — %s" % (_PLAN_RU[plan],
                                               _money(sc["prices"][plan])),
                          "callback_data": "sh:plan:" + plan}])
    return rows


def _shop_pay_methods(cfg, chat, sc, plan):
    """№82: после тарифа — ВЫБОР СПОСОБА ОПЛАТЫ, как в VPN-ботах.
    Способ настроен один → идём сразу на его экран (лишний тап
    никому не нужен). Ни одного — честный экран «объявит владелец».
    """
    money = _money(sc["prices"][plan])
    methods = []
    if sc["card"]:
        methods.append(("card", "💳 Оплата на карту"))
    if sc["sbp"]:
        methods.append(("sbp", "📱 Оплата по СБП"))
    if len(methods) == 1:
        _shop_pay_screen(cfg, chat, sc, plan, methods[0][0])
        return
    rows = [[{"text": label,
              "callback_data": "sh:pay:%s:%s" % (plan, key)}]
            for key, label in methods]
    rows.append([{"text": "◀ Назад к тарифам",
                  "callback_data": "sh:plans"}])
    if not methods:
        rows.insert(0, [{"text": "💳 Реквизиты объявит владелец",
                         "callback_data": "sh:pay:%s:any" % plan}])
    _shop_send(cfg, chat,
               "Тариф: %s — %s\n\nВыбери способ оплаты ↓"
               % (_PLAN_RU[plan], money),
               {"inline_keyboard": rows})


def _shop_pay_screen(cfg, chat, sc, plan, method):
    """Экран оплаты конкретным способом: сумма крупно, реквизит —
    только этого способа и большая кнопка «✅ Я оплатил N ₽»."""
    money = _money(sc["prices"][plan])
    head = ["💳 ОПЛАТА ПОДПИСКИ",
            "%s — %s" % (_PLAN_RU[plan], money),
            "─────────────────"]
    if method == "card" and sc["card"]:
        head.append("💳 Номер карты: " + sc["card"])
    elif method == "sbp" and sc["sbp"]:
        head.append("📱 СБП, телефон: " + sc["sbp"])
    else:
        head.append("Реквизиты объявит владелец — он уже настраивает.")
    if sc["note"]:
        head.append(sc["note"])
    head += ["─────────────────",
             "Переведи сумму, жми «✅ Я оплатил %s» и пришли свой "
             "HWID (Менеджер → «Активация», поле «Этот компьютер»). "
             "Скрин перевода сюда же — проверка пройдёт быстрее. "
             "Ключ прилетит прямо в этот чат." % money]
    _shop_send(cfg, chat, "\n".join(head),
               {"inline_keyboard": [
                   [{"text": "✅ Я оплатил %s" % money,
                     "callback_data": "sh:paid:" + plan}],
                   [{"text": "◀ Назад к способам",
                     "callback_data": "sh:plan:" + plan}]]})


def _shop_make_key(hw, plan):
    try:
        import manager_core as mc
        return mc.keygen_make(hw, plan)
    except Exception:
        return None


def _shop_forward_proof(cfg, chat, msg):
    """№85: покупатель прислал ФОТО (скрин перевода) — раньше бот
    его молча терял. Пересылаем владельцу сказать «кто и по какой
    заявке», а если заявка висит — прямо с кнопками выдачи."""
    d = _shop_load()
    if _shop_is_blocked(d, chat):
        _shop_send(cfg, chat, "⛔ Доступ к магазину закрыт владельцем.")
        return
    name = _shop_name(msg.get("from") or {}, chat)
    oid = None
    best = 0.0
    for k, o in (d.get("orders") or {}).items():
        if (str(o.get("buyer")) == str(chat)
                and o.get("status") == "pending"
                and float(o.get("ts") or 0) > best):
            best = float(o.get("ts") or 0)
            oid = k
    sess = (d.get("sessions") or {}).get(str(chat))
    cap = "🧾 %s (id %s) прислал фото — возможно, чек оплаты." % (name,
                                                                  chat)
    kb = None
    if oid:
        cap += "\nОткрытая заявка №%s — кнопки ↓" % oid
        kb = {"inline_keyboard": [
            [{"text": "🔑 Выдать ключ", "callback_data": "shg:" + oid}],
            [{"text": "❌ Нет оплаты", "callback_data": "shd:" + oid}]]}
    elif sess:
        cap += "\nHWID от него ещё ждём — ключ уйдёт по заявке."
    ok, _out = _tg_call(cfg, "copyMessage",
                        {"chat_id": cfg["chat_id"],
                         "from_chat_id": str(chat),
                         "message_id": msg.get("message_id")}, timeout=15)
    _shop_send(cfg, cfg["chat_id"], cap, kb)
    if ok:
        _shop_send(cfg, chat, "🧾 Скрин улетел владельцу — он проверит "
                              "и ответит. Если ещё не прислал HWID — "
                              "пришли и его.")


def _shop_clients_markup(cfg):
    """№85: БАЗА КЛИЕНТОВ — все, кто когда-либо оформлял подписку.
    По каждому: имя, сколько покупал, активные ключи, и кнопки:
    🚫 блок (магазин для него закрывается) / ✅ разблок /
    ♻ отозвать ключи (выдачи аннулируются, доверие пропадает)."""
    d = _shop_load()
    blocked = set(str(x) for x in (d.get("blocked") or []))
    buyers = {}
    for o in (d.get("orders") or {}).values():
        b = str(o.get("buyer") or "")
        if not b:
            continue
        c = buyers.setdefault(b, {"name": o.get("name") or ("id " + b),
                                  "n": 0, "g": 0, "plans": [], "ts": 0})
        c["n"] += 1
        c["ts"] = max(c["ts"], float(o.get("ts") or 0))
        if o.get("status") == "granted":
            c["g"] += 1
        pl = _PLAN_RU.get(o.get("plan"), o.get("plan") or "?")
        c["plans"].append(pl + (" ✅" if o.get("status") == "granted"
                                else ""))
    for b in list(blocked):
        buyers.setdefault(b, {"name": "id " + b, "n": 0, "g": 0,
                              "plans": [], "ts": 0})
    if not buyers:
        _tg_send(cfg, "👥 Клиентов пока нет — сюда попадают все, кто "
                      "оформлял подписку. Что тут можно: 🚫 — закрыть "
                      "человеку магазин; ♻ — отозвать его ключи "
                      "(записи аннулируются, новых выдач ему не "
                      "будет; уже введённый ключ доработает свой "
                      "срок — поэтому первую выдачу человеку всегда "
                      "смотри глазами).")
        return
    lines = ["👥 КЛИЕНТЫ (%d):" % len(buyers), ""]
    rows = []
    shown = 0
    for b, c in sorted(buyers.items(),
                       key=lambda kv: -kv[1]["ts"]):
        shown += 1
        if shown > 12:
            lines.append("…и ещё %d (жми 🚫/✅ сообщениями ниже "
                         "не нужно — скажи, добавим страницы)"
                         % (len(buyers) - 12))
            break
        mark = " 🚫" if b in blocked else ""
        lines.append("%d. %s%s" % (shown, c["name"], mark))
        lines.append("   id %s · покупок %d, активных ключей %d"
                     % (b, c["n"], c["g"]))
        if c["plans"]:
            lines.append("   " + ", ".join(c["plans"][:4]))
        nm = c["name"].split(" @")[0][:14] or ("id " + b)
        if b in blocked:
            rows.append([{"text": "✅ Разблок: " + nm,
                          "callback_data": "shc:u:" + b}])
        elif c["g"]:
            rows.append([
                {"text": "🚫 Блок: " + nm,
                 "callback_data": "shc:b:" + b},
                {"text": "♻ Отозвать",
                 "callback_data": "shc:r:" + b}])
        else:
            rows.append([{"text": "🚫 Блок: " + nm,
                          "callback_data": "shc:b:" + b}])
    lines += ["", "🚫 — закрыть человеку магазин. ♻ — аннулировать "
              "его выданные ключи (записи сгорают, доверия больше "
              "нет; уже введённый ключ доработает оплаченный срок)."]
    rows.append([{"text": "◀ Назад в настройки",
                  "callback_data": "tp:shopadmin"}])
    _tg_send(cfg, "\n".join(lines), keyboard={"inline_keyboard": rows})


def _shop_done_mark(cfg, mid):
    """Кнопки под обработанной заявкой убрать — второй раз не выдать."""
    if mid:
        _tg_call(cfg, "editMessageReplyMarkup",
                 {"chat_id": cfg["chat_id"], "message_id": mid,
                  "reply_markup": {"inline_keyboard": []}}, timeout=10)


def _shop_handle_text(cfg, chat, text, frm):
    """Текст от ЧУЖОГО чата: это покупатель (или будущий)."""
    low = text.strip().lower()
    d = _shop_load()
    if _shop_is_blocked(d, chat):
        _shop_send(cfg, chat,
                   "⛔ Доступ к магазину закрыт владельцем. Если это "
                   "ошибка — напиши ему лично.")
        return
    sess = (d.get("sessions") or {}).get(str(chat))
    if sess and sess.get("stage") == "await_hwid":
        hw = re.sub(r"[^0-9A-Za-z]", "", text).upper()
        if len(hw) == 8 and all(c in "0123456789ABCDEF" for c in hw):
            hw_txt = hw[:4] + "-" + hw[4:]
            plan = str(sess.get("plan") or "M")
            sc = _shop_cfg()
            oid = hashlib.sha256(("%s:%s" % (chat, time.time()))
                                 .encode()).hexdigest()[:6].upper()
            money = (_money(sc["prices"][plan])
                     if plan in sc["prices"] else "—")
            trusted = _shop_trust(d, chat)
            # №85: дыра «Я оплатил без денег» закрыта. Автомат —
            # всех (режим "all") или только ПРОВЕРЕННЫХ (режим
            # "trusted", по умолчанию). Первый ключ человеку без
            # хозяйской кнопки не уходит никогда (кроме "all").
            if sc["auto"] == "all" or (sc["auto"] == "trusted"
                                       and trusted):
                # №79: АВТОМАТ — ключ вылетает сразу, владелец просто
                # ставится в известность сообщением (проверяет карту,
                # когда удобно). Ручной режим — кнопка в магазине.
                key = _shop_make_key(hw_txt, plan)
                if key:
                    d["orders"][oid] = {
                        "buyer": str(chat), "name": _shop_name(frm,
                                                               chat),
                        "plan": plan, "hwid": hw_txt,
                        "ts": time.time(), "status": "granted",
                        "key": key}
                    d["sessions"].pop(str(chat), None)
                    _shop_save(d)
                    _shop_send(cfg, chat,
                               "🎉 Вот твой ключ!\n\n%s\n\n"
                               "Активация: Менеджер → вкладка "
                               "«Активация» → вставь ключ → "
                               "«Активировать». Приятной ловли 🎣"
                               % key)
                    kb = {"inline_keyboard": [
                        [{"text": "♻ Отменить выдачу (нет оплаты)",
                          "callback_data": "shx:" + oid}]]}
                    _shop_send(cfg, cfg["chat_id"],
                               "🛒 ПРОДАЖА (авто%s)\n%s\nТариф: %s — "
                               "%s\nHWID: %s\nКлюч: %s\n\nПроверь "
                               "поступление. Не пришло — жми кнопку:"
                               % (", клиент проверенный" if trusted
                                  else " ВСЕМ — включи «проверенным» "
                                  "в настройках, безопаснее!",
                                  _shop_name(frm, chat),
                                  _PLAN_RU.get(plan, plan), money,
                                  hw_txt, key), kb)
                else:
                    _shop_send(cfg, chat,
                               "HWID принят, но ключ не собрался — "
                               "владелец выпишет вручную, подожди 🙏")
                    _shop_send(cfg, cfg["chat_id"],
                               "⚠️ Оплата + HWID %s (%s), а ключ НЕ "
                               "собрался — проверь ключ-панель!"
                               % (hw_txt, _shop_name(frm, chat)))
                return
            d["orders"][oid] = {"buyer": str(chat),
                                "name": _shop_name(frm, chat),
                                "plan": plan, "hwid": hw_txt,
                                "ts": time.time(), "status": "pending"}
            d["sessions"].pop(str(chat), None)
            _shop_save(d)
            kb = {"inline_keyboard": [
                [{"text": "🔑 Выдать ключ",
                  "callback_data": "shg:" + oid}],
                [{"text": "❌ Нет оплаты",
                  "callback_data": "shd:" + oid}]]}
            _shop_send(cfg, cfg["chat_id"],
                       "🛒 ЗАЯВКА НА ПОДПИСКУ\n%s\nТариф: %s — %s\n"
                       "HWID: %s\n\nПроверь поступление — и жми "
                       "кнопку. Без твоего нажатия ключ не уйдёт%s."
                       % (_shop_name(frm, chat),
                          _PLAN_RU.get(plan, plan), money, hw_txt,
                          "" if trusted else " (новый клиент!)"), kb)
            _shop_send(cfg, chat,
                       "Заявка ушла владельцу! Как проверит оплату — "
                       "ключ прилетит прямо сюда 🎣")
            return
        # №86: КОМАНДА вместо HWID (/start, /help…) — это не
        # «кривой HWID», а просьба «хочу в меню». Раньше бот
        # честно ругался «это не HWID» (скрин юзера) и человек
        # недоумевал. Отменяем ожидание и показываем витрину.
        if low.startswith("/") or low in ("меню", "menu", "🎣 меню",
                                          "отмена"):
            d["sessions"].pop(str(chat), None)
            _shop_save(d)
            _shop_send(cfg, chat,
                       "Хорошо, покупку отложил 👌 Как будешь готов "
                       "— жми кнопку ↓ и повторим: тариф → оплата → "
                       "HWID.",
                       _shop_kb_root())
            return
        _shop_send(cfg, chat,
                   "Похоже, это не HWID. Он вида XXXX-XXXX — скопируй "
                   "из Менеджера: вкладка «Активация», поле «Этот "
                   "компьютер». Пришли его одним сообщением. Передумал "
                   "покупать — напиши «отмена» или жми кнопку «✖ "
                   "Отмена» выше.")
        return
    # приветствие покупателю (сюда же падает и любой его текст)
    _shop_send(cfg, chat,
               "🎣 Это касса бота-помощника TrofPridi (Русская "
               "Рыбалка 4). Здесь покупают подписку: выбрал тариф, "
               "оплатил, прислал свой HWID — и ключ прилетает прямо "
               "в этот чат. Жми кнопку ↓",
               _shop_kb_root())


def _shop_handle_callback(cfg, cq, chat):
    """Кнопки магазина: sh: — витрина покупателя; shg:/shd: — выдача
    (только в чате владельца!)."""
    data = str(cq.get("data") or "")
    cqid = cq.get("id")
    mid = (cq.get("message") or {}).get("message_id")

    def toast(t):
        if cqid:
            _tg_call(cfg, "answerCallbackQuery",
                     {"callback_query_id": cqid, "text": t[:190]},
                     timeout=10)

    # №85: заблокированному клиенту витрина закрыта даже на нажатия
    if data.startswith("sh:") and not data.startswith(("shg:", "shd:",
                                                       "shx:")):
        try:
            if _shop_is_blocked(_shop_load(), chat):
                toast("⛔ Доступ к магазину закрыт владельцем")
                return
        except Exception:
            pass
    if data.startswith(("shg:", "shd:", "shx:")):
        if chat != cfg["chat_id"]:
            toast("Эта кнопка — только владельцу 🙂")
            return
        oid = data[4:]
        d = _shop_load()
        o = (d.get("orders") or {}).get(oid)
        if data.startswith("shx:"):
            # №79: авто-выдали, а оплаты нет — говорим покупателю
            if not o or o.get("status") != "granted":
                toast("Продажи нет — или уже отменена")
                return
            o["status"] = "revoked"
            _shop_save(d)
            toast("Выдача отменена")
            _shop_send(cfg, o["buyer"],
                       "😕 Оплата так и не подтвердилась — ключ "
                       "аннулирован. Если перевод точно был, "
                       "напиши владельцу бота.")
            _shop_done_mark(cfg, mid)
            return
        if not o or o.get("status") != "pending":
            toast("Заявки нет — или она уже закрыта")
            return
        if data.startswith("shd:"):
            o["status"] = "denied"
            _shop_save(d)
            toast("Отклонено")
            _shop_send(cfg, o["buyer"],
                       "😕 Оплата не подтвердилась — заявка отклонена. "
                       "Если деньги точно ушли, напиши владельцу бота.")
            _shop_done_mark(cfg, mid)
            return
        key = _shop_make_key(o.get("hwid", ""), o.get("plan", ""))
        if not key:
            toast("Не вышло подписать ключ — HWID кривой?")
            return
        o["status"] = "granted"
        o["key"] = key
        _shop_save(d)
        _shop_send(cfg, o["buyer"],
                   "🎉 Оплата подтверждена! Твой ключ:\n\n%s\n\n"
                   "Активация: Менеджер → вкладка «Активация» → вставь "
                   "ключ → «Активировать». Приятной ловли 🎣" % key)
        toast("Ключ улетел покупателю ✅")
        _shop_done_mark(cfg, mid)
        _shop_send(cfg, chat, "✅ Выдан ключ %s (%s) — %s"
                   % (key, _PLAN_RU.get(o.get("plan"), o.get("plan")),
                      o.get("name", "")))
        return

    sc = _shop_cfg()
    if data == "sh:cancel":
        d = _shop_load()
        was = d["sessions"].pop(str(chat), None)
        _shop_save(d)
        toast("Покупка отменена" if was else "Отменять нечего 🙂")
        _shop_send(cfg, chat,
                   "Покупку отменил 👌 Передумаешь — всё начинается "
                   "с кнопки ↓",
                   _shop_kb_root())
    elif data == "sh:plans":
        rows = _shop_kb_plans(sc)
        if not rows:
            toast("Витрина пока пустая — владелец скоро выставит цены")
            return
        toast("Тарифы ↓")
        _shop_send(cfg, chat, "Тарифы подписки TrofPridi — выбирай:",
                   {"inline_keyboard": rows})
    elif data.startswith("sh:plan:"):
        plan = data[8:]
        if plan not in sc["prices"]:
            toast("Такого тарифа больше нет")
            return
        _shop_pay_methods(cfg, chat, sc, plan)
        toast("Выбери способ оплаты ↓")
    elif data.startswith("sh:pay:"):
        # экран конкретного способа (карта | сбп) с суммой в кнопке
        parts = data.split(":")
        plan = parts[2] if len(parts) > 2 else ""
        method = parts[3] if len(parts) > 3 else ""
        if plan not in sc["prices"]:
            toast("Такого тарифа больше нет")
            return
        _shop_pay_screen(cfg, chat, sc, plan, method)
        toast("Реквизиты ниже ↓")
    elif data.startswith("sh:paid:"):
        plan = data[8:]
        d = _shop_load()
        d["sessions"][str(chat)] = {"plan": plan,
                                    "stage": "await_hwid",
                                    "ts": time.time()}
        _shop_save(d)
        toast("Жду твой HWID")
        _shop_send(cfg, chat,
                   "Последний шаг! Пришли СЮДА свой ID компьютера "
                   "(HWID) одним сообщением: он вида XXXX-XXXX и "
                   "висит в Менеджере на вкладке «Активация». Ключ "
                   "выпишется ровно на него. Можешь и скрин перевода "
                   "прислать — владельцу проще проверить.",
                   {"inline_keyboard": [[
                       {"text": "✖ Отменить покупку",
                        "callback_data": "sh:cancel"}]]})
    else:
        toast("Кнопка устарела — жми /start")


def _tg_set_field(field, value):
    """Одно поле секции telegram в license.json (атомарно, остальное
    не трогаем: токен, прокси, цепочка и пр. — всё на месте)."""
    try:
        path = data_path("configs", "license.json")
        with open(path, encoding="utf-8") as f:
            lic = json.load(f)
        tg = lic.get("telegram") or {}
        tg[field] = value
        lic["telegram"] = tg
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(lic, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        return True
    except Exception:
        return False


def _tg_handle_callback(cfg, cq):
    """Нажатие кнопки меню. На ЛЮБОЕ нажатие отвечаем
    answerCallbackQuery — иначе у человека на кнопке вечно крутятся
    часики, как будто бот завис."""
    data = str(cq.get("data") or "")
    cqid = cq.get("id")
    mid = (cq.get("message") or {}).get("message_id")

    def toast(text):
        if cqid:
            _tg_call(cfg, "answerCallbackQuery",
                     {"callback_query_id": cqid, "text": text[:190]},
                     timeout=10)

    def refresh(screen="main"):
        if mid:
            fresh = _tg_cfg() or cfg   # после записи — уже новые ценности
            _tg_call(cfg, "editMessageReplyMarkup",
                     {"chat_id": cfg["chat_id"], "message_id": mid,
                      "reply_markup": _tg_menu_markup(fresh, screen)},
                     timeout=10)

    if data == "tp:pause":
        mode_now = _tg_bot_mode()
        if mode_now == "stopped":
            toast("Бот выключен — сначала запусти его 🚀")
            refresh()
        elif mode_now == "paused":
            toast("Он уже на паузе 🙂")
            refresh()
        elif _tg_write_cmd("pause"):
            toast("⏸ Ставлю на паузу…")
            _tg_confirm_mode(cfg, "pause", mid)
        else:
            toast("Не получилось передать команду 😕")
    elif data == "tp:resume":
        mode_now = _tg_bot_mode()
        if mode_now == "stopped":
            toast("Бот выключен — жми «🚀 Запустить бота»")
            refresh()
        elif mode_now == "running":
            toast("Он и так уже ловит 🎣")
            refresh()
        elif _tg_write_cmd("resume"):
            toast("▶ Снимаю с паузы…")
            _tg_confirm_mode(cfg, "resume", mid)
        else:
            toast("Не получилось передать команду 😕")
    elif data == "tp:start":
        if _tg_bot_mode() != "stopped":
            toast("Он уже запущен 🙂")
            refresh()
        elif _tg_launch_bot():
            toast("🚀 Запускаю…")
            _tg_confirm_mode(cfg, "start", mid)
        else:
            toast("Не получилось запустить 😕 файл " + BOT_SCRIPT
                  + " рядом с программой не найден")
    elif data == "tp:status":
        toast("📊")
        _tg_send(cfg, _tg_status_text())
    elif data == "tp:last":
        toast("🐟")
        _tg_handle_command(cfg, "/last")
    elif data == "tp:photos":
        toast("Что присылаем с фото?")
        refresh("photos")
    elif data == "tp:weight":
        toast("Меньше этого веса — не присылаем")
        refresh("weight")
    elif data.startswith("tp:ph:"):
        mode = data[6:]
        if mode in _PHOTO_LABELS and _tg_set_field("photos", mode):
            toast("📷 Теперь присылаем: " + _PHOTO_LABELS[mode])
        else:
            toast("Не получилось сохранить 😕")
        refresh()
    elif data.startswith("tp:mw:"):
        try:
            mw = float(data[6:])
        except ValueError:
            mw = -1.0
        if mw >= 0 and _tg_set_field("min_weight_kg", mw):
            toast("⚖ Присылаем всё подряд, хоть мелочь" if mw == 0
                  else "⚖ Присылаем от %s кг" % ("%g" % mw))
        else:
            toast("Не получилось сохранить 😕")
        refresh()
    elif data == "tp:shop":
        # №82: хозяину шлём ГЛАЗА ПОКУПАТЕЛЯ — так он видит всю
        # цепочку как клиент, босс-панель прячется за «🔧».
        _tg_shop_owner_view(cfg)
        toast("Это магазин глазами покупателя ↓")
    elif data == "tp:shopadmin":
        toast("Настройки магазина ↓")
        refresh("shop")
    elif data in ("shf:card", "shf:sbp"):
        d = _shop_load()
        d["admin"] = {"field": "card" if data == "shf:card" else "sbp"}
        _shop_save(d)
        _tg_send(cfg, "Пришли %s одним сообщением. «нет» — убрать."
                 % ("новый номер КАРТЫ" if data == "shf:card"
                    else "новый телефон СБП"))
        toast("Жду текст сообщением…")
    elif data.startswith("shf:p:"):
        plan = data[6:]
        d = _shop_load()
        d["admin"] = {"field": "price", "plan": plan}
        _shop_save(d)
        _tg_send(cfg, "Тариф «%s»: пришли новую цену одним числом "
                      "(например 349 или 349.90). 0 или «нет» — "
                      "скрыть тариф." % _PLAN_RU.get(plan, plan))
        toast("Жду цену сообщением…")
    elif data == "sha:auto":
        # №85: круг режимов trusted → all → manual → trusted.
        sc = _shop_cfg()
        order = _SHOP_AUTOS     # trusted, all, manual
        nxt = order[(order.index(sc["auto"]) + 1) % len(order)] \
            if sc["auto"] in order else "trusted"
        _shop_set_field("auto", nxt)
        toast({"trusted": "Автомат только ПРОВЕРЕННЫМ клиентам — "
                          "новых пропускаешь ты 👷",
               "all": "⚠️ Автомат ВСЕМ: «Я оплатил» без денег даст "
                      "ключ!",
               "manual": "Ключ только после твоей кнопки 👷"}[nxt])
        refresh("shop")
    elif data == "shf:pool":
        toast("Плавучие ключи для FunPay ↓")
        refresh("pool")
    elif data == "shf:noop":
        toast("Это просто счётчик журнала 🙂")
    elif data.startswith("shf:fp:"):
        plan = data[7:]
        keys = _funpay_generate(plan, 5)
        if not keys:
            toast("Не удалось сгенерить — что-то с keygen'ом 😕")
        else:
            toast("Свежие ключи ниже — вставь их в лот FunPay ⬇")
            _tg_send(cfg,
                     "🎟 %s | тариф %s\n\n%s\n\nВставь этим списком в "
                     "авто-выдачу лота (каждая строка = один товар). "
                     "Ключи без привязки к ПК, бережём от репостов 🙂"
                     % (len(keys), _PLAN_RU.get(plan, plan),
                        "\n".join(keys)))
            refresh("pool")
    elif data == "shp:list":
        d = _shop_load()
        pend = [(oid, x) for oid, x in
                sorted((d.get("orders") or {}).items())
                if x.get("status") == "pending"]
        if not pend:
            toast("Заявок пока нет 🎣")
        else:
            toast("Открытые заявки ↓")
            for oid, x in pend:
                kb = {"inline_keyboard": [
                    [{"text": "🔑 Выдать ключ",
                      "callback_data": "shg:" + oid}],
                    [{"text": "❌ Нет оплаты",
                      "callback_data": "shd:" + oid}]]}
                # №85: kb стоял ТРЕТЬИМ позиционным = фото —
                # отправка молча падала (исключение гасилось) и экран
                # заявок распечатывал пустоту. Чинится keyboard=.
                _tg_send(cfg, "🛒 Заявка №%s\n%s\nТариф: %s\nHWID: %s"
                         % (oid, x.get("name", ""),
                            _PLAN_RU.get(x.get("plan"),
                                         x.get("plan", "")),
                            x.get("hwid", "")), keyboard=kb)
    elif data == "shc:list":
        toast("База клиентов ↓")
        _shop_clients_markup(cfg)
    elif data.startswith(("shc:b:", "shc:u:", "shc:r:")):
        # сюда попадаем ИСКЛЮЧИТЕЛЬНО из хозяйского чата (маршрут
        # опроса чужим сюда дороги не даёт) — так что смело правим.
        cid = data[6:]
        d = _shop_load()
        blocked = [str(x) for x in (d.get("blocked") or [])]
        if data.startswith("shc:b:"):
            if cid not in blocked:
                blocked.append(cid)
            d["blocked"] = blocked
            _shop_save(d)
            toast("🚫 Заблокирован: магазин для него закрыт")
            _shop_send(cfg, cid,
                       "⛔ Доступ к магазину закрыт владельцем. Если "
                       "это ошибка — напиши ему лично.")
        elif data.startswith("shc:u:"):
            d["blocked"] = [x for x in blocked if x != cid]
            _shop_save(d)
            toast("✅ Разблокирован — магазин снова открыт")
            _shop_send(cfg, cid,
                       "✅ Доступ к магазину снова открыт — жми "
                       "«🛒 Купить подписку».")
        else:
            n = 0
            for o in (d.get("orders") or {}).values():
                if (str(o.get("buyer")) == cid
                        and o.get("status") == "granted"):
                    o["status"] = "revoked"
                    n += 1
            _shop_save(d)
            if not n:
                toast("Активных ключей у него нет")
            else:
                toast("♻ Отозвано ключей: %d" % n)
                _shop_send(cfg, cid,
                           "😕 Владелец аннулировал выданные ключи "
                           "(%d шт.). Если оплата была — свяжись с "
                           "ним, разберётесь." % n)
        _shop_clients_markup(cfg)
    elif data == "tp:menu":
        toast("Меню")
        refresh("main")
    else:
        toast("Такой кнопки больше нет")


def tg_notify_catch(name, weight, exp, photo, kind, length, rel_exp):
    """Улов в Telegram. Фильтры: минимальный вес и режим фото.

    Отправка всегда в фоне: сеть способна тормозить секундами, а
    слежение за окном улова ждать не должно ни миллисекунды.
    """
    cfg = _tg_cfg()
    if not cfg:
        return
    try:
        if cfg["min_weight"] > 0 and (weight is None
                                      or weight < cfg["min_weight"]):
            return                     # мелковата для уведомления
        marked = kind in ("trophy", "zachet")
        head = "🎣 %s" % (name or "Рыба")
        if weight:
            head += " — %.3f кг" % weight
        if length:
            head += " (%s см)" % length
        tail = []
        if exp:
            tail.append("+%s опыта" % exp)
        tail.append(_KIND_RU.get(kind, "обычная"))
        if rel_exp:
            tail.append("за отпускание +%s" % rel_exp)
        caption = "\n".join([head, " · ".join(tail),
                             datetime.now().strftime("%H:%M:%S")])
        path = None
        if photo and (cfg["photos"] == "all"
                      or (cfg["photos"] == "marks" and marked)):
            p = os.path.join(script_dir(), PHOTO_DIR, photo)
            if os.path.isfile(p):
                path = p
        threading.Thread(target=_tg_send, args=(cfg, caption, path),
                         daemon=True).start()
    except Exception as e:
        _debug_log("telegram: ошибка уведомления об улове: %r" % e)


def _tg_last_catch():
    """(последняя строка журнала, всего уловов) для /status и /last."""
    try:
        with open(data_path(LOG_NAME), encoding="utf-8-sig") as f:
            rows = [r for r in csv.reader(f, delimiter=";") if r]
        if len(rows) < 2:
            return None, 0
        return rows[-1], len(rows) - 1
    except Exception:
        return None, 0


def _read_ini_loose(path):
    """INI с маяком ТЕРПИМО к кодировке: AHK-IniWrite создаёт файл
    в UTF-16 с BOM, а читали мы его всегда как utf-8 → маяк «не
    виделся» вовсе, режим падал в unknown и в ТГ ВЕЧНО горела
    кнопка «⏸ Пауза» без подписи состояния (№78, скрин юзера).
    Пробуем utf-8 → utf-16 → cp1251."""
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception:
        return None
    for enc in ("utf-8-sig", "utf-16", "cp1251"):
        try:
            cp = configparser.ConfigParser()
            cp.read_string(raw.decode(enc))
            return cp
        except Exception:
            continue
    return None


def _tg_bot_mode():
    """running/paused/stopped по маяку бота (bot_state.ini)."""
    try:
        cp = _read_ini_loose(data_path("bot_state.ini"))
        if cp is None:
            return "stopped"          # маяка нет = бот не работает
        ts = datetime.strptime(cp.get("state", "tick").strip(),
                               "%Y%m%d%H%M%S")
        if (datetime.now() - ts).total_seconds() > 6:
            return "stopped"
        mode = cp.get("state", "mode", fallback="running").strip()
        return mode if mode in ("running", "paused") else "running"
    except Exception:
        return "stopped"


def _tg_write_cmd(cmd):
    """Команда помощнику: AHK подхватывает файл раз в секунду.

    Пишем атомарно (tmp + переименование), чтобы АHK не прочитал
    половину строки.
    """
    try:
        tmp = data_path("tg_cmd.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(cmd)
        os.replace(tmp, data_path("tg_cmd.txt"))
        return True
    except Exception:
        return False


def _tg_format_catch(row):
    """Строка журнала -> 'Язь — 1.245 кг (37 см), +12 опыта, зачётная'."""
    try:
        r = (list(row) + [""] * 8)[:8]
        ts, name, w, exp, _ph, kind, ln, _rel = r
        s = ("🏆 " if kind == "trophy" else "") + (name or "Рыба")
        if w:
            s += " — %s кг" % w
        if ln:
            s += " (%s см)" % ln
        extra = []
        if exp:
            extra.append("+%s опыта" % exp)
        extra.append(_KIND_TXT.get(kind, "обычная"))
        s += " · " + ", ".join(extra)
        if " " in ts:
            s += " · " + ts.split(" ", 1)[1]
        return s
    except Exception:
        return "не читается"


def _tg_status_text():
    mode = _tg_bot_mode()
    mtxt = {"running": "🎣 ловит", "paused": "⏸ на паузе",
            "stopped": "⭕ не запущен"}.get(mode, "❓ неизвестно")
    lines = ["🤖 Помощник: " + mtxt]
    row, total = _tg_last_catch()
    if row:
        lines.append("🐟 Последний: " + _tg_format_catch(row))
        lines.append("📊 Уловов в журнале: %d" % total)
    else:
        lines.append("Журнал пока пуст.")
    return "\n".join(lines)


def _tg_banner():
    """Обложка меню: ЖИВАЯ ГИФКА (№71), иначе старый всплеск PNG,
    иначе честный None — меню уйдёт просто текстом."""
    p = os.path.join(script_dir(), "assets", "tg_menu.gif")
    if os.path.isfile(p):
        return p, ("animation", "image/gif", "menu.gif")
    p = os.path.join(script_dir(), "assets", "splash_fish.png")
    if os.path.isfile(p):
        return p, None
    return None, None


def _tg_send_menu(cfg):
    """№70: меню = фотка сверху, кнопочки снизу; №71: теперь это
    анимированная ГИФКА (пузырьки живут, лучи дышат) — Telegram
    крутит её сам (sendAnimation). Кнопки виснут под ней же.
    Файла нет (удалён?) — падем обратно на PNG, нет и его —
    просто текст с кнопками: меню не теряется никогда.
    """
    kb = _tg_menu_markup(cfg)
    banner, media = _tg_banner()
    mtxt = {"running": "🎣 ловит", "paused": "⏸ на паузе",
            "stopped": "⭕ не запущен"}.get(_tg_bot_mode())
    tail = ("Помощник: %s. " % mtxt) if mtxt else ""
    _tg_send(cfg, "🎣 TrofPridi на связи! %sЖми кнопки снизу ↓" % tail,
             photo=banner, keyboard=kb, media=media)


def _tg_handle_command(cfg, cmd):
    mode = _tg_bot_mode()
    if cmd in ("/start", "/help", "/menu"):
        _tg_send_menu(cfg)
    elif cmd == "/shop":
        # №82: синяя пилюля кормит покупательским видом и хозяина
        _tg_shop_owner_view(cfg)
    elif cmd == "/pause":
        if mode == "running":
            if _tg_write_cmd("pause"):
                _tg_send(cfg, "⏸ Ставлю помощника на паузу…")
            else:
                _tg_send(cfg, "Не получилось передать команду 😕")
        elif mode == "paused":
            _tg_send(cfg, "Он уже на паузе.")
        elif mode == "stopped":
            _tg_send(cfg, "Помощник не запущен — паузить некого.")
        else:
            _tg_write_cmd("pause")
            _tg_send(cfg, "Команда отправлена (состояние не читается).")
    elif cmd == "/resume":
        if mode == "paused":
            if _tg_write_cmd("resume"):
                _tg_send(cfg, "▶️ Снимаю с паузы — продолжаем ловить!")
            else:
                _tg_send(cfg, "Не получилось передать команду 😕")
        elif mode == "running":
            _tg_send(cfg, "Он и так ловит.")
        elif mode == "stopped":
            _tg_send(cfg, "Помощник не запущен. Запусти из меню: "
                          "/menu — кнопка «🚀 Запустить бота».")
        else:
            _tg_write_cmd("resume")
            _tg_send(cfg, "Команда отправлена (состояние не читается).")
    elif cmd == "/status":
        _tg_send(cfg, _tg_status_text())
    elif cmd in ("/last", "/catch"):
        row, _total = _tg_last_catch()
        if not row:
            _tg_send(cfg, "Пока никто не пойман 🎣")
        else:
            ph = None
            try:
                fn = (list(row) + [""] * 8)[4]
                if fn:
                    p = os.path.join(script_dir(), PHOTO_DIR, fn)
                    if os.path.isfile(p):
                        ph = p
            except Exception:
                pass
            _tg_send(cfg, "🐟 " + _tg_format_catch(row), ph)
    else:
        _tg_send(cfg, "Такой команды нет. Список: /help")


def _tg_poll_loop():
    """Приём команд из чата: длинные опросы getUpdates."""
    offset = None
    while True:
        try:
            cfg = _tg_cfg()
            if not cfg or not cfg["commands"]:
                time.sleep(5)
                continue
            if offset is None:
                # Старое выкидываем: иначе после перезапуска внезапно
                # выполнились бы вчерашние /pause накапливаясь.
                ok, out = _tg_call(cfg, "getUpdates",
                                   {"offset": -1, "timeout": 0}, timeout=15)
                if not ok:
                    err = str(out)
                    _debug_log("telegram: getUpdates: " + err)
                    time.sleep(120 if ("401" in err or
                                       "Unauthorized" in err) else 10)
                    continue
                res = out.get("result") or []
                offset = (res[-1]["update_id"] + 1) if res else 0
                # №70: приветственное МЕНЮ — выскакивает само, как
                # только связь завелась. Один раз за запуск.
                try:
                    _tg_send_menu(cfg)
                    _tg_pin_menu_button(cfg)     # №77: «🎣 Меню» снизу
                except Exception:
                    pass
            ok, out = _tg_call(cfg, "getUpdates",
                               {"offset": offset, "timeout": 20},
                               timeout=35)
            if not ok:
                err = str(out)
                _debug_log("telegram: getUpdates: " + err)
                time.sleep(120 if ("401" in err or
                                   "Unauthorized" in err) else 10)
                continue
            for upd in out.get("result") or []:
                offset = upd.get("update_id", offset - 1) + 1
                cq = upd.get("callback_query")  # №69: нажатие кнопки
                if cq:
                    chat = str(((cq.get("message") or {}).get("chat")
                                or {}).get("id", ""))
                    data = str(cq.get("data") or "")
                    if data.startswith(("sh:", "shg:", "shd:", "shx:")):
                        # №77-78: витрина (покупателю) и выдача
                        # ключей (владельцу). shf:/shp: — его кнопки
                        # управления, они идут ниже в его ветку.
                        _shop_handle_callback(cfg, cq, chat)
                    elif chat == cfg["chat_id"]:
                        _tg_handle_callback(cfg, cq)
                    else:
                        _tg_call(cfg, "answerCallbackQuery",
                                 {"callback_query_id": cq.get("id"),
                                  "text": "Эта кнопка не для тебя 🙂"},
                                 timeout=10)
                    continue
                msg = upd.get("message") or {}
                text = (msg.get("text") or "").strip()
                chat = str((msg.get("chat") or {}).get("id", ""))
                if not text:
                    # №85: чек оплаты приходит ФОТОГРАФИЕЙ, а мы её
                    # молча выкидывали. Чужое фото — пересылаем
                    # владельцу (с кнопками выдачи, если заявка ждёт).
                    if ((msg.get("photo") or msg.get("document"))
                            and chat and chat != cfg["chat_id"]):
                        try:
                            _shop_forward_proof(cfg, chat, msg)
                        except Exception as e:
                            _debug_log("shop: чек: %r" % e)
                    continue
                if chat != cfg["chat_id"]:
                    # №77: чужой чат — это покупатель, ему витрина
                    try:
                        _shop_handle_text(cfg, chat, text,
                                          msg.get("from") or {})
                    except Exception as e:
                        _debug_log("shop: текст: %r" % e)
                    continue
                if _shop_admin_text(cfg, text):
                    # №78: владелец ответил магазину (карта/цена и пр.)
                    continue
                # №82: хозяин МОЖЕТ сыграть покупателя: если у его
                # чата висит ожидание HWID (нажал «Я оплатил») —
                # его текст идёт в тот же покупательский поток.
                try:
                    _d = _shop_load()
                    if (_d.get("sessions") or {}).get(chat):
                        _shop_handle_text(cfg, chat, text,
                                          msg.get("from") or {})
                        continue
                except Exception as e:
                    _debug_log("shop: хоз-цепочка: %r" % e)
                low = text.strip().lower()
                if low in ("🎣 меню", "меню", "menu"):
                    # №77: закреплённая кнопка над строкой ввода
                    _tg_send_menu(cfg)
                    continue
                cmd = text.split()[0].lower().split("@")[0]
                _tg_handle_command(cfg, cmd)
        except Exception as e:
            _debug_log("telegram: ошибка цикла команд: %r" % e)
            time.sleep(10)


def tg_commands_start():
    """Фоновый приём команд из Telegram (один раз за процесс)."""
    global _TG_STARTED
    if _TG_STARTED:
        return
    _TG_STARTED = True
    threading.Thread(target=_tg_poll_loop, daemon=True,
                     name="tg-poll").start()


# ------------------------------------------------------------------ OCR
# Какой пакет привязки к Windows Runtime использовать.
#
# Их два, и оба community-версии одного проекта PyWinRT:
#
#   winsdk  — старый, одним большим пакетом. Последняя сборка вышла в
#             августе 2023 года и содержит колёса только для Python
#             3.8-3.12. На 3.13 и 3.14 pip пытается собрать его из
#             исходников, для чего нужен Visual Studio с компилятором,
#             и падает с «Failed building wheel for winsdk».
#
#   winrt-* — новый, разбитый по namespace. Обновляется, колёса есть
#             для Python 3.9-3.14.
#
# Имена модулей внутри совпадают: winsdk.windows.media.ocr и
# winrt.windows.media.ocr — это одно и то же. Поэтому достаточно
# выбрать корень пакета и дальше работать одинаково.
WINRT_ROOT = None
for _root in ("winsdk", "winrt"):
    try:
        __import__(_root + ".windows.media.ocr")
        WINRT_ROOT = _root
        break
    except Exception:
        continue


def _winrt(path):
    """Импортирует модуль привязки независимо от того, какой пакет стоит."""
    import importlib
    return importlib.import_module(f"{WINRT_ROOT}.{path}")


class WinOCR:
    """Обёртка над встроенным OCR Windows."""

    def __init__(self, lang="ru"):
        self.ok = False
        self.error = ""
        if WINRT_ROOT is None:
            self.error = (
                "Нет привязки к Windows Runtime.\n"
                "Для Python 3.13 и новее:  pip install winrt-Windows.Media.Ocr "
                "winrt-Windows.Globalization winrt-Windows.Graphics.Imaging "
                "winrt-Windows.Storage.Streams\n"
                "Для Python 3.8-3.12 подойдёт и старый:  pip install winsdk")
            return
        try:
            OcrEngine = _winrt("windows.media.ocr").OcrEngine
            Language = _winrt("windows.globalization").Language
            self._OcrEngine = OcrEngine
            try:
                self.engine = OcrEngine.try_create_from_language(Language(lang))
            except Exception:
                self.engine = None
            if self.engine is None:
                self.engine = OcrEngine.try_create_from_user_profile_languages()
            self.ok = self.engine is not None
            if not self.ok:
                self.error = ("Windows OCR не нашёл языковой пакет.\n"
                              "Параметры → Время и язык → Язык → Русский →\n"
                              "Параметры → Распознавание текста → Установить")
        except ImportError as e:
            self.error = f"Не хватает части привязки к Windows Runtime: {e}"
        except Exception as e:
            self.error = f"OCR недоступен: {e}"

    async def _run(self, pil_img):
        _imaging = _winrt("windows.graphics.imaging")
        BitmapDecoder = _imaging.BitmapDecoder
        BitmapPixelFormat = _imaging.BitmapPixelFormat
        _streams = _winrt("windows.storage.streams")
        DataWriter = _streams.DataWriter
        InMemoryRandomAccessStream = _streams.InMemoryRandomAccessStream
        import io

        buf = io.BytesIO()
        pil_img.convert("RGB").save(buf, format="BMP")
        data = buf.getvalue()

        stream = InMemoryRandomAccessStream()
        w = DataWriter(stream.get_output_stream_at(0))
        w.write_bytes(data)
        await w.store_async()
        await w.flush_async()
        stream.seek(0)

        dec = await BitmapDecoder.create_async(stream)
        bmp = await dec.get_software_bitmap_async(
            BitmapPixelFormat.BGRA8, 0)  # 0 = premultiplied ignore
        res = await self.engine.recognize_async(bmp)
        return res.text or ""

    def read(self, pil_img):
        if not self.ok:
            return ""
        try:
            return asyncio.run(self._run(pil_img))
        except Exception:
            return ""


# ------------------------------------------------------------ подготовка
def prep(img, scale=3, thr=140):
    """Мелкий текст на пёстром фоне OCR читает плохо.

    Увеличиваем, переводим в серое и бинаризуем — точность заметно выше.

    thr — порог бинаризации. По умолчанию 140, но для коротких названий
    его приходится перебирать: на трёхбуквенном слове детектор текста
    иногда не находит ничего при 140 и уверенно читает то же самое при
    110 или 175. Из-за этого «Язь» пропадал целиком.
    """
    from PIL import Image, ImageOps, ImageFilter
    img = img.convert("L")
    img = img.resize((img.width * scale, img.height * scale),
                     Image.LANCZOS)
    img = ImageOps.autocontrast(img)
    img = img.filter(ImageFilter.SHARPEN)
    # светлый текст на тёмном фоне -> инвертируем, OCR любит тёмное на белом
    if sum(img.getdata()) / (img.width * img.height) < 128:
        img = ImageOps.invert(img)
    return img.point(lambda v: 0 if v < thr else 255)


# Точный чтец опыта — по координатам плашек (см. exp_reader.py).
# Если модуля или пакета нет, подставляем заглушку: тогда опыт читается
# старым способом, и обновление всё равно работает.
try:
    from exp_reader import RapidExpReader
    _EXP_READER = RapidExpReader()
except Exception:
    class _NoReader:
        ok = False
        error = "exp_reader недоступен"

        def enabled(self):
            return False

        def read_total(self, img):
            return None

        def read_name(self, img, known=None):
            return ""

    _EXP_READER = _NoReader()


def read_exp(ocr, ebox):
    """Быстрое чтение опыта — для кадров, снимаемых в цикле.

    Здесь работает только Windows OCR: он отвечает за 30-40 мс, и его
    можно звать хоть каждые 200 мс, пока открыто окно улова.

    Точный разбор по координатам делается ОДИН раз в конце сбора, из
    сохранённого снимка (см. refine_exp). Звать тяжёлый движок в цикле
    нельзя: он думает около двух секунд, а окно улова висит всего три —
    сбор кадров просто не успел бы пройти.
    """
    return parse_exp(ocr.read(prep(grab(ebox))))


def refine_exp(shot, ebox, current):
    """Уточняет опыт по снимку всего экрана, сделанному в начале сбора.

    RapidOCR возвращает каждый блок текста со своими координатами,
    поэтому число берётся из колонки, под которой стоит подпись «ВСЕГО
    ОЧКОВ ОПЫТА». Это снимает целый класс ошибок: не нужно угадывать по
    плоской строке, какое число к какой подписи относится, и не важно,
    как OCR исказил буквы.

    Вызывается один раз за улов и уже ПОСЛЕ того, как окно закрылось, —
    на скорость записи это не влияет. Если движок не установлен или
    ничего не нашёл, остаётся значение, добытое обычным способом.
    """
    if shot is None:
        return current
    if not _EXP_READER.enabled():
        # Пакет не установлен — точное чтение недоступно. Раньше здесь
        # был молчаливый выход, и пользователь не мог понять, почему
        # у части рыб опыт пустой: со стороны это выглядело как
        # случайный сбой. Пишем один раз, чтобы не засорять лог.
        global _RAPID_WARNED
        if not _RAPID_WARNED:
            _RAPID_WARNED = True
            _debug_log("точное чтение опыта НЕДОСТУПНО: "
                       + (_EXP_READER.error or "нет rapidocr-onnxruntime")
                       + ". Опыт читается только встроенным движком, "
                       "у сложных панелей он ошибается. Поставь: "
                       "pip install rapidocr-onnxruntime")
        return current
    try:
        crop = shot.crop((ebox["left"], ebox["top"],
                          ebox["left"] + ebox["width"],
                          ebox["top"] + ebox["height"]))
    except Exception:
        return current
    v = _EXP_READER.read_total(crop)
    if not v:
        return current
    # Раньше принималось только значение НЕ МЕНЬШЕ уже найденного:
    # панель анимирована, и ранний кадр мог «понизить» итог. Но у этого
    # правила оказалась лютая обратная сторона: если обычный разбор
    # склеил числа («334»+«501» -> «334501»), то настоящие «501» с
    # табличного чтения отвергались как «понижение», и заоблачная цифра
    # оставалась в журнале навсегда. Чтец по координатам берёт число
    # СТРОГО из колонки «ВСЕГО ОЧКОВ ОПЫТА» — он и есть первоисточник:
    # принимаем его всегда, даже если он меньше добычки по тексту.
    if v != current and DEBUG_LOG:
        _debug_log(f"опыт уточнён по плашкам: {current} -> {v}")
    return v


def exp_probe(ocr, ebox):
    """Быстрая проверка: видна ли панель опыта.

    Нужна как второй признак настоящего улова, когда вес не прочитался.
    """
    try:
        return parse_exp(ocr.read(prep(grab(ebox)))) is not None
    except Exception:
        return False


# Слова из НАШЕГО окна статистики и прочего интерфейса. Если такое
# попало в зону названия — это не улов. Реальный случай: окно
# статистики оказалось поверх игры, OCR прочитал вкладку «Сессии»,
# принял её за рыбу и записал улов «Се ии» весом 12.400 кг —
# это был общий вес из той же панели.
UI_WORDS = {
    "сессии", "сессия", "обзор", "галерея", "журнал", "статистика",
    "рекорды", "рекорд", "виды", "рыбы", "улов", "уловы", "последний",
    "трофеи", "зачётные", "зачетные", "мелочь", "опыт", "опыта",
    "всего", "поймано", "темп", "вес", "длина", "время", "игре",
    "новый", "период", "обновить", "данные", "поймана", "средний",
    "количество", "максимальный", "активная", "текущий", "лучший",
    "распознанные", "автоматически", "сохраняются", "снимок",
    "сохранён", "сохранен", "нет", "фото", "общий", "начало",
    "длительность", "название", "категория", "чат", "подсказка",
}


def stats_overlaps(zones_px):
    """Перекрывает ли окно статистики зоны, откуда читаем улов.

    Окно раз в секунду обновляет файл-отметку: строка 1 — время,
    строка 2 — границы окна, строка 3 — работает ли защита от снимков.

    ГЛАВНОЕ: если защита от снимков включилась (WDA_EXCLUDEFROMCAPTURE),
    окна В КАДРЕ ПРОСТО НЕТ — Windows вырезает его из любого снимка.
    Читать оно ничему не мешает, даже вися прямо поверх зон улова.
    Тогда блокировать нечего, и мы всегда отвечаем «не мешает».

    Почему это важно. Окно статистики по умолчанию занимает
    X 180..1500, Y 80..920, а название и вес читаются в Y 59..178 —
    прямоугольники пересекаются ВСЕГДА. Пока проверка не знала про
    защиту от снимков, она честно возвращала True на каждом проходе:
    распознавание молчало всё время, пока открыта статистика, и в
    журнал не попадали ни рыба, ни фотографии. Категории при этом
    писал бот, поэтому со стороны выглядело как «OCR сломался».

    Прямоугольники сверяем только когда защита выключена — вот тогда
    окно действительно попадает в кадр и может быть прочитано вместо
    игры.
    """
    try:
        path = os.path.join(script_dir(), DATA_DIR, "ui_visible")
        if not os.path.exists(path):
            return False
        if (time.time() - os.path.getmtime(path)) >= 3.0:
            return False        # отметка протухла — окно закрылось
        with open(path, encoding="utf-8") as f:
            lines = f.read().split("\n")
        # Строка 3: "1" — окно исключено из снимков экрана.
        if len(lines) >= 3 and lines[2].strip() == "1":
            return False        # в кадре нас нет — мешать не можем
        if len(lines) < 2 or not lines[1].strip():
            return False        # формат без границ — работаем как обычно
        wx1, wy1, wx2, wy2 = (int(v) for v in lines[1].split())
    except Exception:
        return False

    for b in zones_px:
        zx1, zy1 = b["left"], b["top"]
        zx2, zy2 = zx1 + b["width"], zy1 + b["height"]
        if not (zx2 < wx1 or zx1 > wx2 or zy2 < wy1 or zy1 > wy2):
            return True
    return False


def looks_like_ui(name_text):
    """Похоже ли прочитанное на надпись из интерфейса, а не на рыбу?"""
    low = name_text.lower().strip()
    if not low:
        return False
    words = [w for w in re.split(r"[\s\-]+", low) if w]
    if not words:
        return False
    # Совпало хотя бы одно слово — и это не название рыбы из справочника
    if name_text in KNOWN_FISH:
        return False
    return any(w in UI_WORDS for w in words)


def catch_window_open(name_text, wtext):
    """Окно улова открыто?

    Проверяем два признака сразу: в зоне названия — правдоподобное имя
    рыбы, в зоне веса — цифры. Одних цифр мало: игровые подсказки и чат
    тоже попадают в кадр и раньше принимались за улов.
    """
    # Порог 3 символа: короткие названия — Язь, Ёрш, Сом, Лещ —
    # раньше отсекались вместе с мусором и терялись целиком.
    # Исключение для известных рыб: «Язь» после потери мягкого знака
    # превращается в «Яз», и порог длины съедал бы его целиком.
    # А если имя НЕ прочиталось совсем (пёстрый фон, рябь): окно улова
    # всё равно настоящее, если рядом читается длина в сантиметрах —
    # такую рыбу записываем без имени, но записываем обязательно.
    nameless_ok = False
    if len(name_text) < 3 and name_text not in KNOWN_FISH:
        if parse_len(wtext) is None:
            return False
        nameless_ok = True
    if not nameless_ok and not any(ch.isalpha() for ch in name_text):
        return False
    if not any(ch.isdigit() for ch in wtext):
        return False
    # Наше собственное окно поверх игры — не улов.
    if looks_like_ui(name_text):
        return False

    # Имя должно быть похоже на рыбу из справочника. Порог 0.62 взят
    # по замерам: настоящие названия дают 1.00, посторонний текст
    # («Подсказка», «Ачк», «Чат») — не выше 0.57.
    # Проверку «похоже ли имя на рыбу» здесь не делаем: она отсекала
    # бы виды, которых нет в справочнике. Посторонний текст отсеивается
    # надёжнее по наличию веса или длины (см. основной цикл) — там для
    # записи требуются реальные показатели улова.
    return True


# OCR часто путает кириллические единицы: "г" -> "r"/"g", "кг" -> "kg"/"хг".
# Поэтому единицу измерения ищем свободно, а не строгим списком.
WEIGHT_KG_RE = re.compile(r"(\d{1,3})[.,](\d{1,3})\s*[кkхx]?[гgr]", re.I)
WEIGHT_G_RE = re.compile(r"(?<![.,\d])(\d{2,4})\s*[гgr](?![a-zа-я])", re.I)
WEIGHT_BARE_RE = re.compile(r"(?<![.,\d])(\d{1,3})[.,](\d{1,3})(?![.,\d])")


def parse_weight(text):
    """Вес в килограммах.

    Понимает '1,897 кг', '888 г', а также случаи, когда OCR исказил
    единицу измерения ('888 r', '1.2 kg') или потерял её вовсе.
    """
    t = " ".join(text.split())

    m = WEIGHT_KG_RE.search(t)
    if m:
        v = float(f"{m.group(1)}.{m.group(2)}")
        if 0 < v < 200:
            return round(v, 3)

    m = WEIGHT_G_RE.search(t)
    if m:
        v = int(m.group(1)) / 1000.0
        if 0 < v < 200:
            return round(v, 3)

    # единица не распозналась: дробное число — почти наверняка кг
    m = WEIGHT_BARE_RE.search(t)
    if m:
        v = float(f"{m.group(1)}.{m.group(2)}")
        if 0 < v < 200:
            return round(v, 3)

    # целое в диапазоне граммов, рядом нет "см" — считаем граммами
    for m in re.finditer(r"(?<![.,\d])(\d{2,4})(?![.,\d])", t):
        tail = t[m.end():m.end() + 4].lower()
        if "см" in tail or "cm" in tail:
            continue
        v = int(m.group(1))
        if 20 <= v <= 99999:
            return round(v / 1000.0, 3)
    return None


# Длина рядом с весом: "37 см". OCR иногда отдаёт латинское "cm".
LEN_RE = re.compile(r"(\d{1,3})\s*(?:см|cm|cм|см\.)", re.I)


def parse_len(text):
    """Длина в сантиметрах — она в той же строке, что и вес."""
    m = LEN_RE.search(text.replace("\n", " "))
    if m:
        v = int(m.group(1))
        return v if 0 < v < 400 else None
    return None


def parse_kind(text):
    """Категория улова по подписи рядом с весом."""
    t = text.lower()
    if "троф" in t or "тpoф" in t:
        return "trophy"
    # "незачётная" проверяем ДО "зачётной": иначе подстрока "зач"
    # найдётся внутри слова "незачёт" и категория определится неверно.
    if "незач" in t or "не зач" in t or "нeзaч" in t:
        return "small"
    if "зач" in t or "3ач" in t:
        return "zachet"
    return ""


def kind_by_color(img):
    """Категория по цвету плашки рядом с весом.

    Мелкий текст на пёстром фоне читается плохо, а цвет плашки в игре
    всегда один и тот же — по нему и определяем.

    Раньше цвета искались широкими диапазонами («красный — это когда R
    заметно больше G и B»). На фотографии рыбы такие условия задевали
    и чешую, и блики, поэтому пороги пришлось задрать до 6% площади.
    В итоге настоящий трофей набрал 5.8% — три точки до срабатывания —
    и записался как незачёт.

    Теперь сверяем с ТОЧНЫМ цветом плашки. Совпадений меньше, зато они
    настоящие: у проверенного скриншота 6.7% золота против 0.006%
    зелени. Порог 1.5% отделяет плашку уверенно.
    """
    try:
        from PIL import Image
        im = img.convert("RGB")
        # Уменьшаем до разумного размера: попиксельный обход полной
        # зоны заметно медленнее, а доля цвета от этого не меняется.
        if im.width > 240:
            im = im.resize((240, max(1, int(im.height * 240 / im.width))))
        px = list(im.getdata())
        n = len(px)
        if not n:
            return ""

        def share(cr, cg, cb, tol=40):
            k = 0
            for r, g, b in px:
                if abs(r - cr) <= tol and abs(g - cg) <= tol \
                        and abs(b - cb) <= tol:
                    k += 1
            return k / n

        gold = share(252, 195, 0)      # Трофей
        if gold >= 0.015:
            return "trophy"
        green = share(155, 200, 63)    # Зачётная
        if green >= 0.015:
            return "zachet"
        # У незачётной плашки нет вовсе — её определяем не по цвету,
        # а по отсутствию остальных (см. основной цикл).
    except Exception:
        pass
    return ""


# В панели улова четыре числа: базовый опыт, два бонуса и ИТОГ.
# Нужен именно итог — он подписан "ВСЕГО ОЧКОВ ОПЫТА".
#
# Число ищем как ЦЕЛУЮ группу цифр: «216 648» — это «216648», а вот
# «216   648» с большим разрывом — два разных числа из соседних плашек.
# Внутри одного числа игра ставит тонкий пробел-разделитель разрядов
# («5 706»), поэтому один-два пробела допускаем, а больше — нет.
# Раньше стояло [\d\s]{0,8}: регулярка перепрыгивала любые пробелы и
# склеивала числа из РАЗНЫХ плашек — «216» и «648» превращались в
# «2166», а в журнал уезжало 216648 вместо 648.
# ВАЖНО про \d{1,3}: писать так нельзя. Слитное «1116» разбивалось
# на «111» и «6», и сумма плашек считалась по мусору. Первая группа
# должна съедать ЛЮБОЕ число цифр, а разделитель разрядов допускаем
# только перед ровно тремя.
_NUMBER = r"\d+(?:[  \u00a0\u2009\u202f]\d{3})*"

# Слово «ВСЕГО» — обязательный ориентир: именно под ним стоит итог.
# Допускаем латинские двойники букв (OCR часто читает «ВСЕГО» как
# «BCEГO») и любой порядок «число-подпись» / «подпись-число».
#
# Буквы перечислены парами кириллица/латиница, потому что в коротком
# слове движок регулярно подменяет В->B, С->C, Е->E, О->O, Г->l/r/T.
_VSEGO = r"[ВBв][СCсc][ЕEе][ГГгlrTt]?[ОO0о]"

# Между меткой и числом может стоять «ОЧКОВ ОПЫТА» — с любыми
# опечатками. Описываем это как «немного не-цифр», а не точным текстом:
# на «ОЧКОB ОПbITA» строгий шаблон не сработал бы.
EXP_TOTAL_RE = re.compile(
    rf"({_NUMBER})\s*(?:[^\d;]{{0,16}}?)?(?:{_VSEGO})", re.I)
EXP_AFTER_RE = re.compile(
    rf"(?:{_VSEGO})\D{{0,14}}({_NUMBER})", re.I)
EXP_SIMPLE_RE = re.compile(
    rf"(?:опыт\w*|exp|xp)\D{{0,6}}({_NUMBER})|"
    rf"\+\s?({_NUMBER})\s*(?:опыт\w*|exp|xp)", re.I)


def _num(s):
    d = re.sub(r"\D", "", s or "")
    return int(d) if d else None


def _cap(v):
    """Потолок здравого смысла для опыта за одну рыбу.

    Восемь и более значных цифр игра не рисует никогда: это OCR,
    склеивший ТРИ соседних числа. Семизначные миллионы у морских
    гигантов бывают — их пропускаем.
    """
    return v if v is not None and 0 < v < 10000000 else None


def _unglue(v, raw):
    """Расклеивает число, слепленное из двух соседних плашек.

    Плоский текст неотличим: «216 648» — это и 216648 с разделителем
    разрядов, и плашки «216» + «648». Различаем по форме: тысячный
    разряд в игре короткий («5 706», «18 030» — 4-5 цифр), миллионы
    гигантов — семизначные («1 462 500»), а СКЛЕЙКА двух трёхзначных
    плашек даёт ровно ШЕСТЬ цифр. Шестизнач с пробелом подозрителен:
    если правая группа правдоподобна — берём её (она стоит вплотную
    к подписи, это и есть итог), нет — оставляем как прочитано.
    """
    if v is None or " " not in (raw or "").strip():
        return v
    if not 100000 <= v <= 999999:
        return v
    right = _cap(_num(raw.split()[-1]))
    return right if right is not None and right >= 10 else v


def _repair_total(value, raw, all_nums):
    """Сверяет итог с суммой слагаемых и чинит очевидные искажения.

    Панель устроена так, что итог всегда равен сумме остальных плашек:
    1116 + 1116 + 1116 = 3348. Это бесплатная проверка, и она ловит две
    противоположные ошибки распознавания.

    1. ЧИСЛО РАЗОРВАНО. Игра рисует разделитель разрядов широким
       пробелом, и OCR иногда отдаёт «3   348». Тогда в итог попадает
       только «348» — правдоподобное число, которое молча уезжает в
       журнал. Если сумма слагаемых оканчивается на прочитанное, берём
       её: «348» -> «3348».
    2. ЧИСЛА СКЛЕИЛИСЬ. Обратный случай: «216     648» из двух соседних
       колонок читается как одно «216648». Если сумма слагаемых
       совпадает с ХВОСТОМ прочитанного, значит слева прилипло чужое
       число, и берём сумму: «216648» -> «648».

    Когда сумму посчитать не из чего (узкая панель без бонусов) или
    ничего не сходится, возвращаем как прочитали: лучше живое число,
    чем пустая клетка.
    """
    parts = [n for n in all_nums if n != value]
    if not parts:
        return value
    return _rescue_total(value, parts)


def _rescue_total(value, parts):
    """Ищет среди чисел панели ПОДМНОЖЕСТВО слагаемых, чья сумма
    объясняет прочитанный итог, и чинит его.

    Раньше проверялась только сумма ВСЕХ чисел разом. Это ломалось,
    как только в кадре появлялось «лишнее» число: рядом с панелью
    опыта стоит бонус за отпуск рыбы («+1 028»), и он попадал в общую
    сумму. Тогда «086 ВСЕГО» (OCR откусил тройку от «3 086») чинить
    было не на что: 1543+1543+1028=4114 на «86» не оканчивается, и в
    журнал уезжало 86 вместо 3086. Подмножество {1543, 1543} даёт
    ровно 3086 — и объясняет обрывок.

    Два узнаваемых искажения:
      A. потеряны ведущие цифры: сумма длиннее прочитанного и
         оканчивается на него («86» -> «3086»), берём наименьшую
         подходящую сумму — ближайшее правдоподобное значение;
      Б. слева прилипло чужое число: прочитанное оканчивается на
         сумму («216648» -> «648»), берём наибольшую — самый длинный
         правдоподобный хвост.

    Разница в длине — не больше трёх цифр: больший скачок значит,
    что числа просто случайно созвучны, и чинить нечего. Чисел в
    панели мало, поэтому перебор подмножеств мгновенный; на всякий
    случай ограничиваем их 14 — больше в окне не бывает.
    """
    cand = [n for n in parts if n and n >= 10]
    if not cand:
        return value
    if len(cand) > 14:
        cand = cand[:14]
    sv = str(value)
    best_a, best_b = None, None
    for r in range(1, len(cand) + 1):
        for combo in itertools.combinations(cand, r):
            s = sum(combo)
            if s == value or s < 10:
                continue
            ss = str(s)
            if (s > value and len(ss) - len(sv) <= 3
                    and ss.endswith(sv)):
                if best_a is None or s < best_a:
                    best_a = s
            elif (s < value and len(sv) - len(ss) <= 3
                    and sv.endswith(ss)):
                if best_b is None or s > best_b:
                    best_b = s
    if best_a is not None:
        return best_a
    if best_b is not None:
        return best_b
    return value


def parse_exp(text):
    """Возвращает ИТОГОВЫЙ опыт за рыбу.

    В окне улова видно: "1 902 ОЧКА ОПЫТА", два бонуса "+1 902 XP" и
    "5 706 ВСЕГО ОЧКОВ ОПЫТА". Брать нужно последнее, поэтому сначала
    ищем метку "ВСЕГО", и лишь потом — запасные варианты.

    Порог 10 действует и для метки «ВСЕГО»: панель опыта в игре
    анимированная, числа набегают с нуля, и в первые кадры под меткой
    честно написана «1». Раньше такое значение принималось как итог,
    и в статистику попадала рыба с одним очком опыта.
    """
    # Ширину пробела как признак границы плашек использовать НЕЛЬЗЯ.
    # Казалось логичным: «216     648» — это два числа из соседних
    # колонок, а «5 706» — одно число с разделителем разрядов. Но игра
    # рисует разделитель разрядов широким пробелом, и OCR отдаёт его
    # то одним, то тремя символами. На «3   348 ВСЕГО» такое правило
    # отрезало первую цифру, и в журнал уходило 348 вместо 3348.
    #
    # Поэтому пробелы просто нормализуем, а склейку разных чисел ловим
    # ниже проверкой суммы: итог обязан равняться сумме слагаемых.
    t = " ".join(str(text).split())

    # Плашка «+929 XP» за отпуск рыбы стоит рядом с панелью опыта и при
    # широком кадре попадает в неё. Её число к улову отношения не имеет:
    # у мелкой рыбы опыт за отпуск бывает больше опыта за поимку, и в
    # журнал уехала бы чужая цифра.
    #
    # Режем ТОЛЬКО хвост строки: плашка отпуска стоит правее и ниже всей
    # панели, поэтому в тексте оказывается последней. Бонусы «+216 XP»
    # внутри самой панели трогать нельзя — по ним проверяется сумма,
    # когда подпись «ВСЕГО» не прочиталась.
    t = re.sub(rf"\+\s*{_NUMBER}\s*XP\s*$", " ", t, flags=re.I)
    # Во второй плашке узкой панели стоит прогресс уровня: «+0,2 = 58,8%».
    # Это проценты, а не очки. Если панель прочиталась плохо и настоящее
    # число потерялось, «58» могло уехать в журнал как опыт.
    t = re.sub(r"[+\-]?\s*\d+(?:[.,]\d+)?\s*%", " ", t)
    t = re.sub(r"[+\-]\s*\d+[.,]\d+\s*=", " ", t)

    # ---- ГЛАВНОЕ ПРАВИЛО: колонка «ВСЕГО ОЧКОВ ОПЫТА» ----------------
    # Она есть у рыбы всегда и всегда содержит итог. Если метка нашлась,
    # берём число ТОЛЬКО из неё и никуда дальше не идём.
    #
    # Берём ПОСЛЕДНЕЕ совпадение, а не первое: «ВСЕГО» — крайняя правая
    # плашка, и левее могут оказаться числа с похожими подписями
    # («ОЧКОВ ОПЫТА» у базовой колонки). Первое совпадение указывало бы
    # на базовый опыт вместо итога.
    # Все числа панели: нужны для проверки итога на сумму.
    all_nums = [n for n in (_num(x) for x in re.findall(_NUMBER, t))
                if n and n < 10000000]

    for rx in (EXP_TOTAL_RE, EXP_AFTER_RE):
        hits = [m for m in rx.finditer(t) if _num(m.group(1))]
        if not hits:
            continue
        raw_v = hits[-1].group(1)
        v = _num(raw_v)
        if not v or v < 10:
            # Метка есть, но число под ней ещё не набежало (анимация).
            # Молчим: брать соседние плашки нельзя — там не итог.
            return None
        # Число у метки может оказаться склейкой двух плашек:
        # «334 501 ВСЕГО» -> 334501. Склейку от тысячного разряда
        # отличает форма (см. _unglue): расклеиваем и берём ПРАВУЮ
        # группу — она вплотную к подписи. Проверку суммы после такой
        # поправки не гоним: остальные числа строки собраны из того же
        # склеенного мусора и «чинить» итог обратно будут именно они.
        unglued = _unglue(v, raw_v)
        if unglued != v:
            return _cap(unglued)
        return _cap(_repair_total(v, raw_v, all_nums))

    # Все числа строки. Порог 10 отсекает мусор вроде одиночной «1»,
    # которая появляется, когда кадр снят до отрисовки панели.
    nums = [_num(x) for x in re.findall(_NUMBER, t)]
    nums = [n for n in nums if n and 10 <= n < 10000000]

    # Метки «ВСЕГО» в тексте нет. Дальше — только догадки, а догадываться
    # ЗАПРЕЩЕНО: раньше здесь из чисел панели выбирался «правдоподобный»
    # итог (сумма сошлась / максимум заметно больше остальных), и в журнал
    # регулярно уезжали чужие цифры — базовый опыт, бонус «за отпуск»
    # (у мелкой рыбы он больше опыта за поимку!) или склеенная пара
    # чисел («334»+«501» -> 334501).
    #
    # Если подпись не прочиталась, итог возьмёт точный чтец по координатам
    # (refine_exp — он ищет именно колонку «ВСЕГО ОЧКОВ ОПЫТА»), либо
    # клетка останется пустой. Пусто лучше, чем неверно.
    if len(nums) >= 3:
        return None

    # EXP_SIMPLE_RE возвращает ПЕРВОЕ число, поэтому применяем её только
    # к коротким строкам («Опыт: 340»). В полной панели улова чисел
    # несколько, и первое — это базовый опыт, а не итог.
    if len(nums) <= 1:
        m = EXP_SIMPLE_RE.search(t)
        if m:
            v = _num(m.group(1) or m.group(2))
            if v and v >= 10:
                return _cap(v)
        # Узкая панель без бонусов: единственное число и есть итог.
        # На всякий случай расклеиваем, если это склейка двух плашек.
        if nums:
            raw0 = re.findall(_NUMBER, t)[0]
            return _cap(_unglue(nums[0], raw0))
        return None

    # Осталось ровно два числа. Понять, где итог, а где база, нельзя:
    # у узкой панели без бонусов число всего одно, и второе — мусор.
    # Молчим, чтобы не записать заведомо неверную цифру.
    return None


def vote_name(samples):
    """Выбирает название по нескольким кадрам одного улова.

    Короткие имена (Язь, Ёрш, Сом, Лещ) OCR читает нестабильно: в одном
    кадре «Язь», в соседнем «Rзb» или обрывок. Раньше решение принималось
    по первому же кадру — если не повезло, рыба уходила в лог под чужим
    именем или не проходила проверку вовсе.

    Голосуем: имя, найденное в справочнике, весит больше незнакомого,
    при равенстве побеждает то, что встретилось чаще.
    """
    names = [s for s in samples if s]
    if not names:
        return ""
    known = set(KNOWN_FISH)
    cnt = Counter(names)
    return max(cnt, key=lambda n: (n in known, cnt[n], len(n)))


def vote_exp(samples):
    """Опыт за улов по нескольким кадрам.

    Числа в панели анимированы и растут до итогового значения, поэтому
    берём максимум — промежуточные кадры всегда меньше настоящего итога.
    """
    vals = [v for v in samples if v and v >= 10]
    return max(vals) if vals else None


def clean_name(text):
    """Оставляет только название рыбы, без единиц и служебных слов.

    Регистр приводим сами: у половины кириллических букв заглавная
    и строчная различаются лишь высотой (Ж/ж, С/с, О/о, Я/я...), и OCR
    на коротких строках регулярно ошибается — отсюда «жерех» вместо
    «Жерех». Названия рыб всегда пишутся с большой буквы, так что
    полагаться на распознанный регистр смысла нет.
    """
    t = " ".join(text.split())
    # Смесь латиницы, кириллицы и цифр чиним ДО того, как вырезать
    # лишние знаки. Порядок здесь принципиален: «Язь» движок нередко
    # читает целиком латиницей — «R3b», «Rz6», «N3b». Если сначала
    # срезать цифры, останется огрызок «Rb», и рыба потеряется совсем:
    # ни записи в журнале, ни фотографии. Сейчас слово сперва
    # переводится в кириллицу («R3b» -> «Язь») и только потом чистится.
    t = normalize_ocr_letters(t)
    # Короткое название могло приехать разорванным по буквам: «R 3 b»,
    # «Я з ь». По отдельности куски не переводятся, поэтому пробуем
    # склеить их и перевести целиком.
    parts = t.split()
    if len(parts) > 1 and sum(len(p) for p in parts) <= 6 \
            and any(len(p) == 1 for p in parts):
        glued = normalize_ocr_letters("".join(parts))
        if re.search(r"[А-Яа-яЁё]", glued):
            t = glued
    # Похожие на буквы цифры возвращаем на место: OCR путает их
    # в коротких названиях, и «Я3ь» после вырезания цифр распадалось
    # на одиночные буквы, а рыба терялась целиком.
    for digit, letter in (("3", "з"), ("0", "о"), ("6", "б"), ("4", "ч")):
        t = re.sub(rf"(?<=[А-Яа-яЁё]){digit}(?=[А-Яа-яЁё])", letter, t)
    t = re.sub(r"[^А-Яа-яЁёA-Za-z \-]", " ", t)          # прочие знаки прочь
    for junk in ("Улов", "Поймана", "Поймано", "Поймал", "Вес",
                 "Трофей", "Трофейная", "Зачётная", "Зачетная",
                 "Незачётная", "Незачетная",
                 "В садок", "Садок", "Отпустить", "Выпустить",
                 "Опыт", "кг", "гр", "kg"):
        t = re.sub(rf"\b{junk}\b", " ", t, flags=re.I)
    # Короткое название OCR иногда рвёт на части: «Я зь», «Ле щ».
    # Если всё вместе укладывается в одно короткое слово (<= 6 букв),
    # склеиваем — иначе рыба вроде Язя терялась целиком.
    raw_words = t.split()
    if raw_words and sum(len(w) for w in raw_words) <= 6 \
            and any(len(w) == 1 for w in raw_words):
        words = ["".join(raw_words)]
    else:
        # обычный случай: одиночные буквы — мусор вроде "(Т)"
        words = [w for w in raw_words if len(w) > 1]
    if not words:
        return ""

    # Первое слово — с заглавной, остальные строчными:
    # «Форель Ручьевая» -> «Форель ручьевая», «жерех» -> «Жерех».
    out = [words[0][:1].upper() + words[0][1:].lower()]
    for w in words[1:]:
        out.append(w if w.isupper() and len(w) <= 3 else w.lower())
    result = " ".join(out)[:40].strip(" -")

    # Сверяем со справочником: «Окуну» -> «Окунь», «Голавпь» -> «Голавль».
    return match_known_fish(result, _EXTRA_NAMES)


# ------------------------------------------------------- справочник рыб
# Список вынесен в fish_names.py, чтобы статистика могла его читать,
# не импортируя весь этот модуль (при импорте тут запускается
# автоустановка пакетов — лишнее для окна статистики).
try:
    from fish_names import (KNOWN_FISH, match_known_fish,
                            normalize_ocr_letters,
                            load_name_map, apply_name_map)
except Exception:
    KNOWN_FISH = []

    def match_known_fish(name, extra=None):
        return name

    def normalize_ocr_letters(text):
        return text

    def load_name_map(path):
        return {}

    def apply_name_map(name, mapping):
        return name

_EXTRA_NAMES = []


def _load_extra_names():
    """Подхватывает пользовательский список рыб, если он есть."""
    global _EXTRA_NAMES
    try:
        path = data_path("fish_names.txt")
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                _EXTRA_NAMES = [ln.strip() for ln in f
                                if ln.strip() and not ln.startswith("#")]
    except Exception:
        _EXTRA_NAMES = []


# ------------------------------------------------------------------ зоны# ------------------------------------------------------------------ зоны
def load_zones():
    """Читает ocr_zones.txt, но только если он не устарел.

    Иначе правки зон в коде молча перекрывались бы старым файлом —
    именно на это легко потратить час, гадая, почему зона не сдвинулась.
    """
    path = data_path(CFG_NAME)
    zones = dict(DEFAULT_ZONES)
    if not os.path.exists(path):
        return zones

    file_ver = 0
    parsed = {}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.split("#")[0].strip()
                if not line or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip()
                if k == "version":
                    try:
                        file_ver = int(float(v.strip()))
                    except ValueError:
                        file_ver = 0
                    continue
                nums = [float(x) for x in v.replace(";", ",").split(",")]
                if len(nums) == 4:
                    parsed[k] = tuple(nums)
    except Exception as e:
        print("Ошибка чтения зон:", e)
        return zones

    if file_ver < ZONES_VERSION:
        bak = path + ".old"
        try:
            if os.path.exists(bak):
                os.remove(bak)
            os.rename(path, bak)
            print(f"Файл зон устарел (v{file_ver} < v{ZONES_VERSION}), "
                  f"беру новые значения. Старый сохранён как {os.path.basename(bak)}")
        except OSError:
            pass
        return zones

    zones.update(parsed)
    return zones


def save_zones(zones):
    path = data_path(CFG_NAME)
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"version = {ZONES_VERSION}\n")
        f.write("# Зоны распознавания в долях экрана: x1,y1,x2,y2\n")
        f.write("# 0,0 — левый верх; 1,1 — правый низ.\n")
        f.write("# Работает на любом разрешении, включая 2К.\n\n")
        for k, v in zones.items():
            f.write(f"{k} = {v[0]:.4f}, {v[1]:.4f}, {v[2]:.4f}, {v[3]:.4f}\n")
    return path


def grab(box=None):
    import mss
    from PIL import Image
    with mss.mss() as sct:
        mon = sct.monitors[1]
        shot = sct.grab(mon if box is None else box)
        return Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")


def zone_box(zone, sw, sh):
    x1, y1, x2, y2 = zone
    return {"left": int(x1 * sw), "top": int(y1 * sh),
            "width": max(1, int((x2 - x1) * sw)),
            "height": max(1, int((y2 - y1) * sh))}


# ------------------------------------------------------------------ лог
def save_photo(img, name, weight):
    """Сохраняет снимок экрана. Возвращает имя файла.

    Полный кадр 1920x1080 в PNG весит около 2 МБ — за сотню рыб это
    четверть гигабайта. Уменьшаем до 1280 по ширине и пишем JPEG:
    качество для галереи достаточное, размер меньше в разы.
    """
    d = os.path.join(script_dir(), PHOTO_DIR)
    os.makedirs(d, exist_ok=True)
    safe = re.sub(r"[^\w\-А-Яа-яЁё ]", "", name).strip().replace(" ", "_")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    wpart = f"_{weight:.3f}kg" if weight else ""
    fn = f"{stamp}_{safe}{wpart}.jpg"
    try:
        im = img.convert("RGB")
        if im.width > 1280:
            h = int(im.height * 1280 / im.width)
            im = im.resize((1280, h))
        im.save(os.path.join(d, fn), "JPEG", quality=82, optimize=True)
        return fn
    except Exception:
        return ""


def _reset_requested():
    """Нажата ли кнопка «Новый период» с прошлой проверки.

    Окно статистики кладёт файл-отметку, мы его сразу убираем — иначе
    память сбрасывалась бы на каждом проходе цикла.
    """
    try:
        p = os.path.join(script_dir(), DATA_DIR, "RESET")
        if os.path.exists(p):
            os.remove(p)
            return True
    except Exception:
        pass
    return False


def _debug_log(msg):
    """Сырой результат OCR — чтобы было видно, что именно прочиталось."""
    try:
        with open(data_path("ocr_debug.log"), "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}\n")
    except Exception:
        pass


def _fmt_w(weight):
    return f"{weight:.3f}" if weight else ""


def recent_dup(name, weight, length):
    """Эта рыба уже записана секунды назад? Защита от повторов цикла.

    Повтор рождается так: флаг «уже записали» снимается мгновенным
    «провалом» окна (OCR моргнул на одном кадре) или сменой прочитанного
    имени при голосовании — и та же самая рыба собирается ещё раз.
    Подпись при повторном сборе могла чуть отличаться, короткий
    8-секундный заслон её не ловил, и в журнал с галереей ехал дубль.

    Считаем дублем:
      * имя+вес+длина совпали за последние 25 с (вес с точностью
        до грамма и длина до сантиметра у двух разных рыб подряд
        не повторяются);
      * имя+длина совпали за последние 10 с — на случай, если вес
        при повторе прочитался иначе.
    """
    path = data_path(LOG_NAME)
    try:
        if not os.path.exists(path):
            return False
        with open(path, "r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.reader(f, delimiter=";"))[-5:]
        now = datetime.now()
        w_cur = _fmt_w(weight)
        l_cur = f"{length}" if length else ""
        for r in rows:
            if len(r) < 3 or r[0] == "timestamp":
                continue
            try:
                prev = datetime.strptime(r[0], "%Y-%m-%d %H:%M:%S")
            except ValueError:
                continue
            dt = (now - prev).total_seconds()
            if dt < 0 or dt > 25:
                continue
            same_w = bool(r[2]) and r[2] == w_cur
            r_len = r[6] if len(r) > 6 else ""
            same_l = bool(r_len) and r_len == l_cur
            if r[1] == name and ((same_w and same_l)
                                 or (same_l and dt <= 10)):
                return True
    except Exception:
        pass
    return False


# Карта переименований перечитывается, только если файл изменился:
# стат через os.path.getmtime на каждую запись — существенно дешевле,
# чем разбор файла, а правки из окна статистики подхватываются сами.
_NAME_MAP = {"mtime": None, "data": {}}


def name_map():
    """Переименования рыб из окна статистики (кэш по mtime)."""
    path = data_path(NAME_MAP_NAME)
    try:
        mt = os.path.getmtime(path)
    except OSError:
        mt = None
    if mt != _NAME_MAP["mtime"]:
        _NAME_MAP["data"] = load_name_map(path)
        _NAME_MAP["mtime"] = mt
    return _NAME_MAP["data"]


def append_fish(name, weight, exp, photo, kind="", length=None,
                release_exp=None):
    path = data_path(LOG_NAME)
    # Подстраховка от дублей: одна и та же рыба, записанная дважды
    # подряд за несколько секунд, — это повтор от быстрого цикла.
    if recent_dup(name, weight, length):
        _debug_log(f"дубль пропущен: {name} {weight}")
        return

    new = not os.path.exists(path)
    with open(path, "a", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=";")
        if new:
            w.writerow(["timestamp", "name", "weight_kg", "exp",
                        "photo", "kind", "length_cm", "release_exp"])
        w.writerow([datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    name, f"{weight:.3f}" if weight else "",
                    exp if exp else "", photo, kind,
                    length if length else "",
                    release_exp if release_exp else ""])


# ------------------------------------------------------------ калибровка
def calibrate():
    """Показывает, что видит OCR в текущих зонах, и сохраняет снимки."""
    from PIL import Image
    ocr = WinOCR()
    print("=" * 62)
    print("КАЛИБРОВКА ЗОН OCR")
    print("=" * 62)
    if not ocr.ok:
        print("!! " + ocr.error)
        print("\nСнимки зон всё равно сохраню — посмотри, попадают ли они.")
    dbg = os.path.join(script_dir(), DEBUG_DIR)
    os.makedirs(dbg, exist_ok=True)
    zones = load_zones()
    full = grab()
    sw, sh = full.size
    print(f"Экран: {sw}x{sh}\n")
    for key, z in zones.items():
        b = zone_box(z, sw, sh)
        if key == "photo":
            crop = full.crop((b["left"], b["top"], b["left"] + b["width"],
                              b["top"] + b["height"]))
            crop.save(os.path.join(dbg, "photo.png"))
            print(f"[photo]  область {b['left']},{b['top']} "
                  f"{b['width']}x{b['height']}")
            print(f"   снимок: {DEBUG_DIR}/photo.png — проверь, что рыба в кадре\n")
            continue
        crop = full.crop((b["left"], b["top"],
                          b["left"] + b["width"], b["top"] + b["height"]))
        fn = os.path.join(dbg, f"{key}.png")
        crop.save(fn)
        prepped = prep(crop)
        prepped.save(os.path.join(dbg, f"{key}_prep.png"))
        text = ocr.read(prepped) if ocr.ok else ""
        print(f"[{key}]  область {b['left']},{b['top']} "
              f"{b['width']}x{b['height']}")
        print(f"   снимок: {DEBUG_DIR}/{key}.png")
        print(f"   распознано: {text.strip()!r}")
        if key == "weight":
            print(f"   вес -> {parse_weight(text)}")
        if key == "weight":
            print(f"   длина -> {parse_len(text)}   "
                  f"категория -> {parse_kind(text)!r}")
        if key == "exp":
            print(f"   опыт -> {parse_exp(text)}")
        if key == "name":
            print(f"   название -> {clean_name(text)!r}")
        print()
    p = save_zones(zones)
    print(f"Файл зон: {p}")
    print(f"Открой снимки в папке {DEBUG_DIR}. Если текст не попал —")
    print("поправь доли в ocr_zones.txt и запусти калибровку снова.")


# ------------------------------------------------------------------ цикл
def watch(verbose=True):
    if not single_instance():
        print("OCR уже запущен — второй экземпляр не нужен.")
        _debug_log("выход: уже запущен другой экземпляр")
        return

    ocr = WinOCR()
    if not ocr.ok:
        print("!! " + ocr.error)
        return
    zones = load_zones()
    full = grab()
    sw, sh = full.size
    nbox = zone_box(zones["name"], sw, sh)
    wbox = zone_box(zones["weight"], sw, sh)
    ebox = zone_box(zones["exp"], sw, sh)
    pbox = zone_box(zones["photo"], sw, sh)
    rbox = zone_box(zones["release"], sw, sh) if "release" in zones else None

    if verbose:
        print(f"Слежу за экраном {sw}x{sh}. Ctrl+C — стоп.")
    # В лог пишем всегда: если OCR молчит, отсюда видно, дошёл ли он
    # до рабочего цикла и какие зоны использует.
    _load_extra_names()
    _debug_log(f"=== СТАРТ === экран {sw}x{sh}, зоны: "
               f"name={nbox} weight={wbox} exp={ebox}")

    # Самопроверка разборщиков: ловит опечатки в коде до того, как они
    # тихо сломают запись в рабочем цикле.
    try:
        probe = "888 г 37 см Зачётная"
        assert parse_weight(probe) == 0.888, "parse_weight"
        assert parse_len(probe) == 37, "parse_len"
        assert parse_kind(probe) == "zachet", "parse_kind"
        assert parse_exp("XP 5 706 ВСЕГО ОЧКОВ ОПЫТА") == 5706, "parse_exp"
        # Анимация счётчика: в первых кадрах под меткой «ВСЕГО» стоит «1».
        # Такое значение обязано отбрасываться, иначе в лог попадёт
        # рыба с одним очком опыта.
        assert parse_exp("XP 1 ВСЕГО ОЧКОВ ОПЫТА") is None, "parse_exp anim"
        # Панель без бонусов: слова «ВСЕГО» в ней нет, число одно.
        # Из-за узкой зоны она обрезалась, и опыт у части рыб не
        # записывался вовсе — в галерее оставался прочерк.
        assert parse_exp("XP 1 858 ОЧКОВ ОПЫТА +0,2 = 58,8% "
                         "ПОПЛАВОЧНАЯ ЛОВЛЯ") == 1858, "parse_exp узкая"
        # Главное правило: при наличии колонки «ВСЕГО ОЧКОВ ОПЫТА»
        # берём именно её, а не базовый опыт и не бонусы.
        assert parse_exp("216 ОЧКОВ ОПЫТА +216 XP UL СНАСТЬ +216 XP "
                         "ПРЕМИУМ 648 ВСЕГО ОЧКОВ ОПЫТА") == 648, \
            "parse_exp ВСЕГО"
        # То же, но OCR выдал числа отдельно от подписей (построчно).
        # Метка оказалась далеко от своего числа — надёжно определить
        # итог нельзя. Догадки запрещены: молчим, а разберёт
        # координатный чтец (refine_exp), ему видно колонки.
        assert parse_exp("216 +216 XP +216 XP 648 ОЧКОВ ОПЫТА UL СНАСТЬ "
                         "ПРЕМИУМ ВСЕГО ОЧКОВ ОПЫТА") is None, \
            "parse_exp ВСЕГО построчно — молчим, не угадываем"
        # Числа соседних плашек без промежуточного текста между ними —
        # склейка. Потолок реализма её гасит, а правую группу у подписи
        # ещё можно спасти: она вплотную к «ВСЕГО», это и есть итог.
        assert parse_exp("216     648 ВСЕГО ОЧКОВ ОПЫТА") == 648, \
            "parse_exp склейка у метки"
        # Склейка двух плашек и пропавшая метка: шестизнач с пробелом
        # разрядом не бывает (разряд 4-5 цифр, миллионы — 7), значит
        # это «база»+«итог». Правая группа — плашка итога, берём её.
        assert parse_exp("334 501") == 501, "parse_exp расклейка без метки"
        # Метка не прочиталась — НЕ угадываем (раньше тут брали
        # «максимум, если он заметно больше», и уезжал бонус за отпуск).
        assert parse_exp("334 +167 XP 501") is None, \
            "parse_exp без метки — не угадываем"
        # Пять плашек (база + три бонуса + итог) — реальный кадр игрока.
        # «ВСЕГО» стоит крайней справа, поэтому берём ПОСЛЕДНЕЕ
        # совпадение метки: у первого числа подпись тоже «ОЧКОВ ОПЫТА».
        assert parse_exp(
            "3 606 ОЧКОВ ОПЫТА +3 606 XP UL СНАСТЬ +3 606 XP ПРЕМИУМ "
            "+7 212 XP СЧАСТЛИВЫЙ ЧАС 18 030 ВСЕГО ОЧКОВ ОПЫТА"
        ) == 18030, "parse_exp 5 плашек"
        # Семизначные миллионы гигантов — честные цифры, пропускаем.
        assert parse_exp("38 250 ОЧКА ОПЫТА +38 250 XP ПРЕМИУМ "
                         "1 462 500 ВСЕГО ОЧКОВ ОПЫТА") == 1462500, \
            "parse_exp миллионы гиганта"
        # Шестизнач тоже бывает честным («150 000» — белуга с бонусами):
        # правая группа здесь «000», неправдоподобна — оставляем целое.
        assert parse_exp("150 000 ВСЕГО ОЧКОВ ОПЫТА") == 150000, \
            "parse_exp честный шестизнач"
        # Плашка «+929 XP» за отпуск не должна подменять опыт за улов.
        assert parse_exp("XP 858 ОЧКОВ ОПЫТА + 929 XP") == 858, \
            "parse_exp отпуск"
        # Проценты прогресса уровня — не очки опыта.
        assert parse_exp("+0,2 = 58,8% ПОПЛАВОЧНАЯ ЛОВЛЯ") is None, \
            "parse_exp проценты"
        assert vote_exp([1, None, 340, 5706]) == 5706, "vote_exp"
        assert clean_name("Форель ручьевая") == "Форель ручьевая", "clean_name"
        # Латиница вместо кириллицы — из-за неё пропадал Язь.
        assert clean_name("Rзb") == "Язь", "clean_name latin"
        assert clean_name("Я3ь") == "Язь", "clean_name digit"
        # «Язь» движок часто читает ЦЕЛИКОМ латиницей с цифрами.
        # Кириллицы внутри нет, поэтому старая правка смеси букв такое
        # слово пропускала, цифра срезалась, оставался огрызок «Rb» —
        # и рыба не попадала ни в журнал, ни в галерею.
        for _v in ("R3b", "Rz6", "N3b", "r3b", "R 3 b", "n3b", "nз6"):
            assert clean_name(_v) == "Язь", f"clean_name {_v}"
        # Обратная сторона: настоящие рыбы не должны искажаться.
        for _v in ("Окунь", "Лещ", "Плотва обыкновенная", "Форель ручьевая"):
            assert clean_name(_v) == _v, f"clean_name искажает {_v}"
        assert vote_name(["Rзb", "Язь", "Яз"]) == "Язь", "vote_name"
        # Надписи нашего окна не должны приниматься за рыбу.
        assert looks_like_ui("Сессии"), "looks_like_ui"
        assert looks_like_ui("Рекорды по весу"), "looks_like_ui 2"
        assert not looks_like_ui("Окунь"), "looks_like_ui рыба"
        assert not catch_window_open("Сессии", "12.400 кг"), "UI как улов"
        # Окно статистики висит поверх зон улова ВСЕГДА (его границы
        # 180..1500 x 80..920, зоны — 59..178). Пока оно скрыто от
        # снимков, мешать не может. Если эта проверка once сломается,
        # распознавание замолчит при открытой статистике и в журнал
        # не попадут ни рыба, ни фото — ровно как было раньше.
        _t = data_path("ui_visible")
        _bak = None
        if os.path.exists(_t):
            with open(_t, encoding="utf-8") as f:
                _bak = f.read()
        try:
            with open(_t, "w", encoding="utf-8") as f:
                f.write(f"{int(time.time())}\n0 0 {sw} {sh}\n1\n")
            assert not stats_overlaps((nbox, wbox)), "скрытое окно блокирует"
            with open(_t, "w", encoding="utf-8") as f:
                f.write(f"{int(time.time())}\n0 0 {sw} {sh}\n0\n")
            assert stats_overlaps((nbox, wbox)), "видимое окно не блокирует"
        finally:
            if _bak is None:
                try:
                    os.remove(_t)
                except Exception:
                    pass
            else:
                with open(_t, "w", encoding="utf-8") as f:
                    f.write(_bak)
        _debug_log("самопроверка разборщиков: OK")
    except Exception as e:
        msg = f"САМОПРОВЕРКА ПРОВАЛЕНА: {e}"
        print("!! " + msg)
        _debug_log(msg)
    last_sig, last_time = "", 0.0
    last_name = ""        # имя последней записанной рыбы
    armed = True          # готовы записать следующий улов
    closed_hits = 0       # сколько кадров подряд окно улова не видно
    skip_logged = False   # чтобы не сыпать в лог одно и то же

    # №61: фоновый приём команд из Telegram (/pause и компания) —
    # пока сам молчит, и ни на что не влияет.
    tg_commands_start()

    while True:
        try:
            time.sleep(POLL_SEC)

            # бот закрылся -> выходим вместе с ним
            if os.path.exists(os.path.join(script_dir(), DATA_DIR,
                                           STOP_NAME)):
                if verbose:
                    print("Получен сигнал остановки.")
                return

            # Нажали «Новый период»: журнал и снимки уехали в backup.
            #
            # Забываем последний улов, иначе первая же рыба после
            # сброса может совпасть с ним по имени и весу — и защита
            # от дублей молча её проглотит. Заодно проверяем, что папка
            # для снимков на месте: её перемещают при сбросе, и если
            # создать заново не удалось, save_photo писал бы в пустоту.
            if _reset_requested():
                last_sig, last_time = "", 0.0
                last_name = ""
                armed = True
                try:
                    os.makedirs(os.path.join(script_dir(), PHOTO_DIR),
                                exist_ok=True)
                except Exception:
                    pass
                _debug_log("новый период: журнал очищен, "
                           "память о прошлом улове сброшена")

            # Окно статистики перекрыло зоны улова — читать нечего.
            if stats_overlaps((nbox, wbox)):
                if DEBUG_LOG and not skip_logged:
                    _debug_log(
                        "пропуск: окно статистики закрывает зоны улова "
                        "и НЕ скрыто от снимков экрана. Включи "
                        "«Защита от скриншотов» в настройках окна — "
                        "тогда оно перестанет мешать, даже вися поверх "
                        "игры. Либо сверни его.")
                    skip_logged = True
                armed = True
                continue
            skip_logged = False

            raw_name = ocr.read(prep(grab(nbox)))
            name = clean_name(raw_name)
            wraw = grab(wbox)
            wtext = ocr.read(prep(wraw))

            # Короткие названия («Язь», «Ёрш», «Сом») движок нередко не
            # находит ВООБЩЕ: три буквы на пёстром фоне — слишком мало
            # для детектора текста, и зона возвращается пустой. Рыба при
            # этом на экране есть, вес и длина читаются прекрасно.
            #
            # Пробуем ещё раз с другой подготовкой картинки. Разный
            # порог бинаризации сильно меняет результат на тонком шрифте:
            # то, что пропало при 140, часто проявляется при 110 или 175.
            if len(name) < 3 and parse_len(wtext) is not None:
                for _thr in (110, 175, 95):
                    try:
                        alt = clean_name(ocr.read(prep(grab(nbox),
                                                       thr=_thr)))
                    except Exception:
                        break
                    if len(alt) >= 3:
                        _debug_log(f"имя добыто со второй попытки "
                                   f"(порог {_thr}): {alt!r}")
                        name, raw_name = alt, alt
                        break
                else:
                    # Пороги не помогли — спрашиваем второй движок.
                    # Он обрезает картинку по тексту, и там, где
                    # встроенный OCR возвращал пустоту, находит слово.
                    # Кириллицу он пишет латиницей («XKepex»), поэтому
                    # результат сверяется со справочником видов.
                    try:
                        alt = _EXP_READER.read_name(grab(nbox), KNOWN_FISH)
                    except Exception:
                        alt = ""
                    if alt:
                        _debug_log(f"имя добыто вторым движком: {alt!r}")
                        name, raw_name = alt, alt

            # Что-то видно на экране? Логируем ЛЮБУЮ попытку, иначе
            # непонятно, почему улов не записался: раньше в лог попадали
            # только успешные записи, а пропуски исчезали бесследно.
            seen_any = bool(raw_name.strip() or wtext.strip())

            if not catch_window_open(name, wtext):
                if seen_any and DEBUG_LOG:
                    _debug_log(f"пропуск (не окно улова): "
                               f"name={name!r} raw={raw_name.strip()!r} "
                               f"wtext={wtext.strip()!r}")
                # Готовность возвращаем только после ДВУХ «закрытых»
                # кадров подряд. Раньше хватало одного: OCR моргнул на
                # кадре, флаг сбрасывался, и та же самая рыба собиралась
                # и снималась повторно — отсюда дубли в журнале и двойные
                # фото в галерее.
                closed_hits += 1
                if closed_hits >= 2:
                    armed = True        # окно закрылось — ждём следующий улов
                continue
            closed_hits = 0             # окно на экране — серия закрытия сброшена

            # Готовность возвращаем не только по закрытию окна, но и по
            # смене названия: если в зонах мелькнёт посторонний текст,
            # флаг armed мог залипнуть и следующая рыба терялась молча.
            if not armed:
                if name and name != last_name:
                    armed = True
                    _debug_log(f"новая рыба при залипшем флаге: {name!r}")
                else:
                    continue            # эту рыбу уже записали

            # ---- собираем несколько кадров одного улова -------------
            # По одному снимку решать нельзя: опыт в панели анимирован
            # (первые кадры показывают «1»), а короткие названия OCR
            # читает через раз. Пара секунд наблюдения решает и то, и то.
            # Снимок делаем сразу: пока идёт сбор, окно улова может
            # закрыться, и в галерею попал бы пустой берег вместо рыбы.
            shot = grab()
            # Снимок ДЛЯ ОПЫТА — отдельный, и делается он в конце сбора.
            #
            # Здесь, в самом начале, панель опыта ещё анимирована: числа
            # набегают с нуля, и на первом кадре под меткой «ВСЕГО»
            # честно стоит «0» или промежуточное значение. Точный чтец
            # разбирал именно этот кадр и возвращал недобежавшую цифру
            # либо не находил ничего — в журнале оставался прочерк.
            # Заводим переменную сразу, чтобы она существовала даже
            # если сбор прервётся на первом же проходе.
            exp_shot = shot

            n_votes = [name]
            e_votes = [read_exp(ocr, ebox)]
            weight = parse_weight(wtext)
            length = parse_len(wtext)
            kind = parse_kind(wtext) or kind_by_color(wraw)

            t_end = time.time() + COLLECT_SEC
            for _ in range(COLLECT_MAX):
                if time.time() >= t_end:
                    break
                time.sleep(0.22)
                try:
                    nm2 = clean_name(ocr.read(prep(grab(nbox))))
                    wraw2 = grab(wbox)
                    wt2 = ocr.read(prep(wraw2))
                except Exception:
                    break
                # окно закрылось раньше времени — работаем с тем, что есть
                if not catch_window_open(nm2, wt2):
                    break
                n_votes.append(nm2)
                e_votes.append(read_exp(ocr, ebox))
                # Обновляем снимок для точного чтения опыта: каждый
                # следующий кадр ближе к моменту, когда счётчик
                # досчитал. Берём зону целиком, а не весь экран —
                # это дешевле и памяти, и времени.
                try:
                    exp_shot = grab()
                except Exception:
                    pass
                if weight is None:
                    weight = parse_weight(wt2)
                if length is None:
                    length = parse_len(wt2)
                if not kind:
                    kind = parse_kind(wt2) or kind_by_color(wraw2)
                wtext = wt2 if len(wt2.strip()) > len(wtext.strip()) else wtext

            name = vote_name(n_votes) or name
            # Ручные переименования из окна статистики — в самом конце:
            # какое бы имя ни собралось из кадров и справочника, если
            # пользователь однажды исправил такую запись, применяем его
            # вариант. Одна и та же опечатка OCR воспроизводится
            # стабильно, поэтому обучение срабатывает наверняка.
            fixed = apply_name_map(name, name_map())
            if fixed != name:
                _debug_log(f"переименовано пользователем: {name!r} -> "
                           f"{fixed!r}")
                name = fixed
            exp = vote_exp(e_votes)
            # Окно улова уже закрылось, торопиться некуда — уточняем
            # опыт по снимку точным способом (число под подписью
            # «ВСЕГО ОЧКОВ ОПЫТА»). Он ловит случаи, где разбор текста
            # ошибался: разорванные и склеенные числа, метку у чужой
            # колонки.
            exp = refine_exp(exp_shot, ebox, exp)
            if DEBUG_LOG and len(n_votes) > 1:
                _debug_log(f"кадров: {len(n_votes)} | имена={n_votes} -> "
                           f"{name!r} | опыт={e_votes} -> {exp}")

            # В игре у рыбы всего три состояния: трофей, зачётная и
            # незачётная. У незачётной бейджа просто нет, поэтому
            # «ничего не нашли» = незачёт. Ставим это только когда зона
            # реально прочиталась (есть вес или длина) — иначе можно
            # ошибочно записать незачёт при сбое распознавания.
            if not kind and (weight is not None or length is not None):
                kind = "small"

            # Для записи ОБЯЗАТЕЛЬНА длина в сантиметрах. У любой рыбы
            # в окне улова она есть, а в постороннем тексте — почти
            # никогда.
            #
            # Раньше принимался и «вес в кг без длины». Эта поблажка
            # вышла боком: окно статистики оказалось поверх игры, OCR
            # прочитал в зоне веса строку «12.400 кг» из панели рекордов
            # и записал несуществующий улов. Убрано: одного веса мало.
            if length is None:
                if DEBUG_LOG:
                    _debug_log(f"пропуск (нет длины в см): name={name!r} "
                               f"wtext={wtext.strip()!r}")
                continue

            rel_exp = parse_exp(ocr.read(prep(grab(rbox)))) if rbox else None

            sig = f"{name}|{weight}|{length}"
            now = time.time()
            if sig == last_sig and now - last_time < COOLDOWN_SEC:
                continue
            last_sig, last_time = sig, now
            last_name = name
            armed = False               # до закрытия окна больше не пишем

            # Эта рыба уже в журнале (повторный сбор того же окна после
            # моргания OCR)? Проверяем ДО снимка: иначе строку дубля
            # append_fish ещё отсекал, а фото-дубль в галерее оставался.
            if recent_dup(name, weight, length):
                _debug_log(f"дубль улова пропущен до снимка: {name} "
                           f"{weight} кг {length} см")
                continue

            photo = save_photo(shot, name, weight)
            append_fish(name, weight, exp, photo, kind, length, rel_exp)
            # №61: улов сразу улетает в Telegram-бота (фоном, с
            # фильтрами из настроек — молчит, если он выключен).
            tg_notify_catch(name, weight, exp, photo, kind, length,
                            rel_exp)
            _debug_log(f"ЗАПИСАНО: {name} | {weight} кг | {length} см | "
                       f"{exp} опыта | {kind or 'без категории'}")

            if verbose:
                parts = [name]
                parts.append(f"{weight} кг" if weight else "вес —")
                if length:
                    parts.append(f"{length} см")
                parts.append(f"+{exp} опыта" if exp else "опыт —")
                if kind:
                    parts.append(kind)
                print(f"  {datetime.now():%H:%M:%S}  " + "  |  ".join(parts))
        except KeyboardInterrupt:
            print("\nОстановлено.")
            return
        except Exception as e:
            if verbose:
                print("  ошибка:", e)
            if DEBUG_LOG:
                _debug_log(f"ОШИБКА ЦИКЛА: {e}")
            time.sleep(2)


def _license_gate():
    """№72: без подписки наблюдатель молча уходит («блок всего»)."""
    try:
        import manager_core as mc
    except ImportError:
        return True                         # нет ядра — не наш суд
    try:
        mc.sync_license_state()
        if mc.license_state()[0] == "expired":
            print("Подписка закончилась: введи ключ в Менеджере "
                  "(вкладка «Активация»), HWID — там же.")
            return False
    except Exception:
        pass                                # сбой проверки — не наказываем
    return True


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="OCR-наблюдатель TrofPridi")
    ap.add_argument("--calibrate", action="store_true",
                    help="проверить зоны и сохранить снимки")
    a = ap.parse_args()
    if a.calibrate:
        calibrate()
    elif _license_gate():
        watch()

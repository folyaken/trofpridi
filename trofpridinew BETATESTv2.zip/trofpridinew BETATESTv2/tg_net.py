#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""TrofPridi — транспорт до Telegram Bot API (№62).

В стране у пользователя Telegram может быть перекрыт: голый HTTPS до
api.telegram.org умирает по тайм-ауту даже с «включённым VPN», если
тот работает только для браузера. Этот модуль умеет ходить:

  • напрямую (как раньше);
  • через СИСТЕМНЫЙ прокси Windows — подхватывается сам из настроек
    («Параметры → Сеть → Прокси»), ничего вписывать не нужно;
  • через ЯВНЫЙ прокси из настроек Менеджера: http:// или socks5://,
    с логином-паролем или без (socks5://user:pass@host:port).

MTProto-прокси из Telegram Desktop НЕ подходят: они умеют только
внутренний протокол мессенджера, а бот ходит обычным HTTPS. Нужен
SOCKS5 или HTTP(S)-прокси.

Зависимостей ноль — только стандартная библиотека. Используется и
Менеджером (кнопка «Проверить связь»), и OCR-наблюдателем (уловы и
команды) — код сети один на всех, здесь.
"""

import http.client
import json
import socket
import ssl
import struct
import threading

TG_HOST = "api.telegram.org"
# Известные IPv4 Bot API (официальный AS62041 Telegram). Нужны, когда
# прокси принимает только IP-цели (так делают узкие прокси вроде
# tg-ws-proxy — он рассчитан на приложение Telegram, которое ходит
# по IP), а местный DNS отравлен или молчит.
TG_IPV4_FALLBACK = ("149.154.167.220", "149.154.166.110")


def _tg_ipv4s():
    """IPv4 api.telegram.org: сначала честный DNS, потом известные."""
    ips = []
    try:
        for info in socket.getaddrinfo(TG_HOST, 443, socket.AF_INET):
            ip = info[4][0]
            if ip not in ips:
                ips.append(ip)
    except Exception:
        pass
    for ip in TG_IPV4_FALLBACK:
        if ip not in ips:
            ips.append(ip)
    return ips


def _err_text(e):
    """Понятное пояснение вместо молчаливого traceback."""
    s = str(e)
    low = s.lower()
    if "timed out" in low or "timeout" in low:
        return ("тайм-аут: сервер молчит. Похоже, Telegram заблокирован "
                "и без прокси не достучаться — впиши SOCKS5/HTTP-прокси "
                "в настройках (MTProto-прокси не подходит)")
    if "getaddrinfo" in low or "11001" in low or "name or service" in low:
        return "DNS не отвечает: проверь интернет или адрес прокси"
    if "10061" in low or "refused" in low:
        return "прокси отверг соединение — проверь адрес и порт"
    if "10013" in low:
        return "сокет запрещён: посмотри фаервол и антивирус"
    if "forbidden" in low and "url" in low:
        return "запрос запрещён системой: проверь прокси"
    if "certificate" in low:
        return "ошибка сертификата HTTPS: %s" % s
    return s


def _api_desc_ru(desc):
    """Ответ самого Telegram (ok:false) — понятными словами (№68).

    Сетевые ошибки переводит _err_text, а это — ВЕЖЛИВЫЕ отказы
    Bot API с HTTP 200/403: сырой английский «Forbidden: the bot
    can't send messages to the bot» пугал («ничего не работает»),
    хотя значил простое: в Chat ID стоит сам бот.
    """
    s = str(desc)
    low = s.lower()
    if "send messages to the bot" in low:
        return ("в Chat ID стоит САМ БОТ, а бот сам себе писать не "
                "может! Напиши боту /start со СВОЕГО аккаунта "
                "(с телефона/компа, где ТЫ сидишь в Telegram) и нажми "
                "«Определить Chat ID» — или просто «Проверить связь», "
                "она подберёт чат сама")
    if "chat not found" in low or "user not found" in low \
            or "initiate conversation" in low or "peer_id_invalid" in low:
        return ("бот не знает такого чата: напиши ему /start в "
                "Telegram со своего аккаунта — и повтори")
    if "bot was blocked" in low:
        return ("бот заблокирован тобой в Telegram: разблокируй "
                "его и напиши /start")
    if "user is deactivated" in low:
        return "этот аккаунт Telegram удалён — нужен другой Chat ID"
    if "not enough rights" in low or "have no rights" in low \
            or "need administrator" in low or "administrator rights" in low:
        return "нет прав: в группе бот должен быть АДМИНОМ с правом писать"
    if "too many requests" in low or "retry after" in low:
        return "Telegram просит помедленнее: подожди минуту и повтори"
    if "unauthorized" in low:
        return ("токен отозван @BotFather: напиши ему /revoke, возьми "
                "НОВЫЙ токен и впиши в настройки")
    return s


def parse_proxy(url):
    """'socks5://user:pass@host:port' -> ('socks5', host, port, user, pwd).

    Пустая строка -> None. Схемы: http:// (CONNECT-туннель, этот же
    формат у https-прокси) и socks5:// (socks5h/socks тоже сюда).
    """
    u = (url or "").strip()
    if not u:
        return None
    scheme = "http"
    if "://" in u:
        scheme, u = u.split("://", 1)
    scheme = scheme.lower()
    if scheme in ("socks5h", "socks"):
        scheme = "socks5"
    if scheme not in ("http", "socks5"):
        raise OSError("прокси бывает http:// или socks5:// — "
                      "MTProto-прокси из Telegram не подходит")
    user = pwd = None
    if "@" in u:
        auth, u = u.rsplit("@", 1)
        user, _, pwd = auth.partition(":")
        user = user or None
        pwd = pwd or None
    u = u.strip("/ ")
    host, sep, port = u.rpartition(":")
    if sep:
        try:
            port = int(port)
        except ValueError:
            raise OSError("в адресе прокси порт должен быть числом")
    else:
        host = u
        port = 1080 if scheme == "socks5" else 8080
    host = host.strip("[] ")
    if not host:
        raise OSError("пустой адрес прокси")
    return (scheme, host, port, user, pwd)


def _system_proxy():
    """Прокси из настроек самой системы (на Windows — из реестра)."""
    try:
        from urllib.request import getproxies
        pr = getproxies() or {}
        for k in ("https", "http"):
            v = pr.get(k)
            if v:
                try:
                    return parse_proxy(v)
                except OSError:
                    return None
    except Exception:
        pass
    return None


def _recvn(sock, n):
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise OSError("прокси оборвал соединение")
        buf += chunk
    return buf


def _socks5_handshake(sock, user, pwd, host, port):
    """Минимальный SOCKS5 (RFC 1928): greeting, вход, CONNECT.

    Домен Telegram отдаём прокси как есть (тип адреса 3) — DNS
    резолвит сам прокси, местные подмены DNS нам не страшны.
    """
    if user:
        sock.sendall(b"\x05\x02\x00\x02")      # без пароля и с паролем
    else:
        sock.sendall(b"\x05\x01\x00")          # только без пароля
    resp = _recvn(sock, 2)
    if resp[0] != 5:
        raise OSError("это не SOCKS5-прокси")
    if resp[1] == 0xFF:
        raise OSError("прокси не принимает наши способы входа")
    if resp[1] == 0x02:
        ub = (user or "").encode("utf-8")
        wb = (pwd or "").encode("utf-8")
        if len(ub) > 255 or len(wb) > 255:
            raise OSError("слишком длинный логин/пароль прокси")
        sock.sendall(b"\x01" + bytes([len(ub)]) + ub
                     + bytes([len(wb)]) + wb)
        if _recvn(sock, 2) != b"\x01\x00":
            raise OSError("прокси: неверный логин или пароль")
    hb = host.encode("idna")
    sock.sendall(b"\x05\x01\x00\x03" + bytes([len(hb)]) + hb
                 + struct.pack(">H", port))
    head = _recvn(sock, 4)
    if head[1] != 0:
        codes = {1: "общий сбой прокси", 2: "запрещено правилами прокси",
                 3: "сеть недоступна", 4: "хост недоступен",
                 5: "прокси отказал в соединении", 6: "TTL истёк",
                 7: "команда не поддерживается",
                 8: "тип адреса не поддерживается"}
        raise OSError("SOCKS5 CONNECT: %s"
                      % codes.get(head[1], "код %d" % head[1]))
    atyp = head[3]
    if atyp == 1:
        _recvn(sock, 6)                # IPv4 + порт
    elif atyp == 4:
        _recvn(sock, 18)               # IPv6 + порт
    else:
        ln = _recvn(sock, 1)[0]        # домен + порт
        _recvn(sock, ln + 2)


class _TunneledHTTPS(http.client.HTTPSConnection):
    """HTTPS до api.telegram.org: напрямую, через HTTP или SOCKS5."""

    def __init__(self, proxy, timeout):
        if proxy and len(proxy) < 5:
            proxy = tuple(proxy) + (None, None)
        self._proxy = proxy            # кортеж из parse_proxy или None
        self._ctx = ssl.create_default_context()
        if proxy and proxy[0] == "http":
            super().__init__(proxy[1], proxy[2], timeout=timeout)
            headers = {}
            if proxy[3]:
                import base64
                tok = base64.b64encode(
                    ("%s:%s" % (proxy[3], proxy[4] or ""))
                    .encode("utf-8")).decode("ascii")
                headers["Proxy-Authorization"] = "Basic " + tok
            self.set_tunnel(TG_HOST, 443, headers=headers)
        else:
            super().__init__(TG_HOST, 443, timeout=timeout)

    def connect(self):
        p = self._proxy
        if p and p[0] == "socks5":
            # Сначала домен: DNS резолвит сам прокси, местные подмены
            # не страшны. Но некоторые прокси умеют ТОЛЬКО IPv4-цели
            # (tg-ws-proxy заточен под приложение Telegram, которое
            # ходит по IP) — им отдаём адрес Bot API напрямую.
            last = None
            for tgt in [TG_HOST] + _tg_ipv4s():
                try:
                    raw = socket.create_connection((p[1], p[2]),
                                                   timeout=self.timeout)
                except OSError:
                    raise           # сам прокси недоступен: ретрай не оживит
                try:
                    _socks5_handshake(raw, p[3], p[4], tgt, 443)
                except OSError as e:
                    last = e
                    raw.close()
                    continue
                self.sock = self._ctx.wrap_socket(raw,
                                                  server_hostname=TG_HOST)
                return
            raise last
        else:
            super().connect()


def api_call(token, method, payload=None, photo_path=None, proxy="",
             timeout=25, media=None):
    """Один вызов Bot API. Возвращает (ok, dict-ответ | строка ошибки).

    proxy: строка настроек ('socks5://…' / 'http://…'). Пусто — прямое
    соединение; если в самой Windows прописан прокси — идём через него.
    photo_path: файл — тогда медиа уходит multipart/form-data, собранным
    вручную. media=(поле, content-type, имя-файла): по умолчанию
    ("photo", "image/jpeg", "catch.jpg") для sendPhoto; №71 добавил
    ("animation", "image/gif", "menu.gif") — ГИФ-меню (sendAnimation).
    """
    try:
        prx = parse_proxy(proxy) if (proxy or "").strip() else _system_proxy()
    except OSError as e:
        return False, str(e)

    if photo_path:
        boundary = "TrofPridi%012x" % (abs(hash((token, method))) % 10**12)
        parts = bytearray()
        for k, v in (payload or {}).items():
            parts += (("--%s\r\nContent-Disposition: form-data; "
                       "name=\"%s\"\r\n\r\n%s\r\n")
                      % (boundary, k, v)).encode("utf-8")
        try:
            with open(photo_path, "rb") as f:
                img = f.read()
        except OSError as e:
            return False, "фото не читается: %s" % e
        mname, mtype, mfname = media or ("photo", "image/jpeg",
                                         "catch.jpg")
        parts += (("--%s\r\nContent-Disposition: form-data; "
                   "name=\"%s\"; filename=\"%s\"\r\n"
                   "Content-Type: %s\r\n\r\n")
                  % (boundary, mname, mfname, mtype)).encode("utf-8")
        parts += img
        parts += ("\r\n--%s--\r\n" % boundary).encode("utf-8")
        body = bytes(parts)
        c_type = "multipart/form-data; boundary=" + boundary
    else:
        body = json.dumps(payload or {}).encode("utf-8")
        c_type = "application/json"

    try:
        conn = _TunneledHTTPS(prx, timeout)
        try:
            conn.request("POST", "/bot%s/%s" % (token, method),
                         body=body, headers={"Content-Type": c_type})
            resp = conn.getresponse()
            data = resp.read()
        finally:
            conn.close()
        try:
            out = json.loads(data.decode("utf-8", "replace"))
        except json.JSONDecodeError:
            return False, "странный ответ сервера (не JSON)"
        if out.get("ok"):
            return True, out
        return False, _api_desc_ru(out.get("description")
                                   or "Telegram отклонил запрос")
    except (OSError, ssl.SSLError, http.client.HTTPException) as e:
        msg = _err_text(e)
        # №65: отказ на ЛОКАЛЬНОМ порту = прокси-программа просто не
        # запущена. Говорим это прямо, а не «проверь адрес и порт».
        low = str(e).lower()
        if (prx and prx[1] in ("127.0.0.1", "localhost", "::1")
                and ("refused" in low or "10061" in low)):
            names = {1080: "TgWsProxy", 9150: "Tor Browser",
                     9050: "Tor", 7890: "Clash", 10808: "v2rayN"}
            who = names.get(prx[2])
            if who:
                msg = ("на 127.0.0.1:%d никого нет — %s не запущен? "
                       "Открой его и повтори: порт живёт, только пока "
                       "программа открыта" % (prx[2], who))
            else:
                msg = ("на 127.0.0.1:%d никого нет — прокси-программа "
                       "не запущена или слушает другой порт" % prx[2])
        return False, msg
    except Exception as e:
        return False, str(e)


# ------------------------------------------------- поиск прокси на ПК
# №63: «у меня нет рабочего прокси, Telegram живёт только через
# TgWsProxy». TgWsProxy и подобные программы поднимают обычный
# локальный SOCKS5/HTTP-порт — перебираем известные и через каждый
# делаем ЧЕСТНЫЙ запрос до Bot API. Ответил Telegram — прокси годится.
LOCAL_PROXIES = [
    ("socks5", 1080, "TgWsProxy / локальный SOCKS5"),
    ("socks5", 1081, "локальный SOCKS5"),
    ("socks5", 2080, "Nekoray / Shadowsocks"),
    ("socks5", 2081, "локальный SOCKS5"),
    ("socks5", 7890, "Clash"),
    ("http",   7890, "Clash (HTTP)"),
    ("socks5", 7891, "Clash"),
    ("socks5", 7893, "Clash Verge"),
    ("socks5", 4780, "Mihomo / Clash Meta"),
    ("http",   8080, "HTTP-прокси"),
    ("http",   8118, "Privoxy"),
    ("http",   8888, "Fiddler"),
    ("socks5", 9050, "Tor"),
    ("socks5", 9150, "Tor Browser"),
    ("socks5", 10808, "v2rayN / NekoBox"),
    ("http",   10809, "v2rayN (HTTP)"),
    ("socks5", 10800, "локальный SOCKS5"),
]


def _probe(kind, host, port, token, timeout):
    """True, если через прокси реально отвечает Bot API.

    Критерий строгий (№67): JSON-ответ Telegram, у которого есть
    ключ "ok". Отказ по токену (401) тоже засчитываем — нам важно
    ДОСТУЧАТЬСЯ, а не валидность токена (проверка текста «ok» в
    строке была дырявой: проходил и отрицательный ответ).
    """
    prx = (kind, host, port, None, None)
    try:
        conn = _TunneledHTTPS(prx, timeout)
        try:
            path = "/bot%s/getMe" % (token or "0:x")
            conn.request("POST", path, body=b"{}",
                         headers={"Content-Type": "application/json"})
            data = conn.getresponse().read()
        finally:
            conn.close()
        out = json.loads(data.decode("utf-8", "replace"))
        return isinstance(out, dict) and "ok" in out
    except Exception:
        return False


def api_call_multi(endpoints, token, method, payload=None,
                   photo_path=None, timeout=14, media=None):
    """Цепочка прокси: первый живой выигрывает (№67).

    endpoints: список proxy-url (первый — основной, дальше резерв).
    Публичные прокси живут минутами — резерв обязателен.
    Возвращает (ok, ответ-или-ошибка, индекс сработавшего | None).
    """
    last = "нет прокси в цепочке"
    for i, prx in enumerate(endpoints):
        ok, out = api_call(token, method, payload=payload,
                           photo_path=photo_path, proxy=prx,
                           timeout=timeout, media=media)
        if ok:
            return True, out, i
        last = out
    return False, last, None


def scan_local_proxies(token="", ports=None, timeout=4):
    """((kind, host, port, label) | None, сколько портов проверено).

    Сначала дешёвый TCP-стук (закрытые порты отваливаются мгновенно),
    потом HTTPS-проба только по открытым — параллельно, чтобы кнопка
    в Менеджере не висела.
    """
    if ports is not None:              # свой список портов (автотесты)
        cands = [(k, "127.0.0.1", p, "порт из списка")
                 for p in ports for k in ("socks5", "http")]
    else:
        cands = [(k, "127.0.0.1", p, lbl) for k, p, lbl in LOCAL_PROXIES]
    import concurrent.futures as cf

    def knock(i):
        try:
            s = socket.create_connection((cands[i][1], cands[i][2]),
                                         timeout=1.2)
            s.close()
            return i
        except OSError:
            return None

    with cf.ThreadPoolExecutor(max_workers=16) as ex:
        open_idx = [i for i in ex.map(knock, range(len(cands)))
                    if i is not None]
    results = []

    def work(i):
        k, h, p, lbl = cands[i]
        if _probe(k, h, p, token, timeout):
            results.append((k, h, p, lbl))

    if open_idx:
        with cf.ThreadPoolExecutor(max_workers=8) as ex:
            list(ex.map(work, open_idx))
    # стабильно выбираем самый ранний кандидат из списка
    for k, h, p, lbl in cands:
        for r in results:
            if r[:3] == (k, h, p):
                return r, len(open_idx)
    return None, len(open_idx)


# ------------------------------------------ публичные прокси (без скачиваний)
# №66: «не могу скачать даже Tor». Выход — публичные прокси: свежие
# списки лежат на GitHub (у пользователя он открыт — вон архивы
# качаются), качаем и проверяем КАЖДЫЙ настоящим запросом до
# Bot API. Чужой прокси не страшен: весь трафик идёт шифрованным
# HTTPS прямо до api.telegram.org, прочитать ни токен, ни тексты
# он не может — только видит, что мы стучимся в Telegram.
PROXY_LIST_URLS = [
    ("socks5", "https://raw.githubusercontent.com/TheSpeedX/"
               "PROXY-List/master/socks5.txt"),
    ("http",   "https://raw.githubusercontent.com/TheSpeedX/"
               "PROXY-List/master/http.txt"),
    ("socks5", "https://raw.githubusercontent.com/monosans/"
               "proxy-list/main/proxies/socks5.txt"),
    ("http",   "https://raw.githubusercontent.com/monosans/"
               "proxy-list/main/proxies/http.txt"),
]


def fetch_public_proxies(limit=120, timeout=10):
    """Свежие публичные прокси из GitHub-списков: [(kind, host, port)].

    Только строки вида ip:port (списки большие — читаем разумно и
    перемешиваем, чтобы не долбить первым старым хвостом).
    """
    from urllib.request import Request, urlopen
    pools = {"socks5": [], "http": []}
    for kind, url in PROXY_LIST_URLS:
        try:
            req = Request(url, headers={"User-Agent": "TrofPridi"})
            with urlopen(req, timeout=timeout) as r:
                txt = r.read(3_000_000).decode("utf-8", "replace")
        except Exception:
            continue
        for line in txt.splitlines():
            line = line.strip()
            host, sep, port = line.partition(":")
            if not sep or "." not in host:
                continue
            try:
                socket.inet_aton(host)
                port = int(port)
            except (OSError, ValueError):
                continue
            # приватные/кривые адреса отбрасываем сразу
            if host.startswith(("0.", "127.", "10.", "192.168.", "169.254.")):
                continue
            if not (1 <= port <= 65535):
                continue
            rec = (kind, host, port)
            if rec not in pools[kind]:
                pools[kind].append(rec)
    import random
    out = []
    for kind in ("socks5", "http"):
        random.shuffle(pools[kind])
        out += pools[kind][:limit]
    return out


def scan_public_proxies(token="", on_progress=None, timeout=4,
                        limit=120, want=3):
    """Рабочие публичные прокси до Bot API — НЕСКОЛЬКО сразу (№67).

    Один публичный прокси умрёт через минуту, поэтому собираем до
    `want` живых: основной + резервная цепочка. Этап 1 — TCP-стук,
    этап 2 — HTTPS-проба только по откликнувшимся.
    Возвращает (список (kind, host, port, label) — может быть пустым,
    скачано, откликнулось).
    """
    cands = fetch_public_proxies(limit=limit)
    total = len(cands)
    if not total:
        return [], 0, 0
    import concurrent.futures as cf

    def knock(c):
        try:
            s = socket.create_connection((c[1], c[2]), timeout=2.2)
            s.close()
            return c
        except OSError:
            return None

    alive = []
    done = 0
    with cf.ThreadPoolExecutor(max_workers=32) as ex:
        futs = [ex.submit(knock, c) for c in cands]
        for f in cf.as_completed(futs):
            r = f.result()
            done += 1
            if on_progress and done % 16 == 0:
                on_progress("стук %d/%d…" % (done, total))
            if r:
                alive.append(r)
    stop = threading.Event()

    def probe(c):
        if stop.is_set():
            return False
        return _probe(c[0], c[1], c[2], token, timeout)

    found = []
    done = 0
    with cf.ThreadPoolExecutor(max_workers=12) as ex:
        futs = {ex.submit(probe, c): c for c in alive}
        for f in cf.as_completed(futs):
            done += 1
            if on_progress and done % 4 == 0:
                on_progress("проба Telegram %d/%d…" % (done, len(alive)))
            if f.result():
                c = futs[f]
                found.append((c + ("публичный %s-прокси" % c[0],)))
                if len(found) >= want:
                    stop.set()
    return found, total, len(alive)


if __name__ == "__main__":
    # ручная проверка: python tg_net.py <токен> [прокси]
    import sys
    if len(sys.argv) < 2:
        print("использование: python tg_net.py <токен> [proxy-url]")
        sys.exit(1)
    ok, out = api_call(sys.argv[1], "getMe",
                       proxy=sys.argv[2] if len(sys.argv) > 2 else "")
    print("OK" if ok else "FAIL", out)

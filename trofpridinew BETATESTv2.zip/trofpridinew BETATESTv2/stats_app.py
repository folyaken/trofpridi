#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TrofPridi — окно статистики.

Читает stats.csv, который пишет AHK-бот, и показывает сводку.
Запуск:  stats.pyw (без консоли)  либо  python stats_app.py

Всё рисуется на Canvas вручную — tkinter не умеет скруглённые углы
у обычных виджетов, а именно они дают нужный вид.
"""

import csv
import ctypes
import shutil
import time
import math
import os
import random
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta

try:
    # Доустановка недостающих пакетов. ВАЖНО: здесь только импортируем,
    # а проверку вызываем позже — из App.__init__, когда на экране УЖЕ
    # есть заставка. Раньше установка шла прямо тут, при импорте, и
    # показывала СВОЁ окно — выходило два окна загрузки подряд.
    from _bootstrap import ensure, ocr_deps
except Exception:
    ensure = None
    ocr_deps = None

import tkinter as tk
from tkinter import filedialog, messagebox

# Сглаживающий слой отрисовки. Tkinter Canvas рисует без антиалиасинга,
# поэтому скругления, кольца и диагонали выходят ступеньками. Слой
# перерисовывает то же самое через Pillow в увеличенном масштабе.
try:
    from smooth_canvas import (SmoothCanvas, has_icons, HAVE_PIL,
                               FA as FA_ICONS)
    SMOOTH = HAVE_PIL
except Exception:
    SmoothCanvas = None
    SMOOTH = False
    FA_ICONS = {}

    def has_icons():
        return False

DATA_DIR = "TrofPridi_data"
CSV_NAME = "stats.csv"
STOP_NAME = "STOP"          # файл-сигнал: бот закрылся, закрываемся тоже
REFRESH_MS = 3000
# Версия — ОДНА на всё приложение: подзаголовок заставки и подпись
# внизу окна берут её отсюда, чтобы нигде не залежался старый номер
# (на заставке так и висел v3.5, когда внизу уже был v3.17).
VERSION = "v3.30.1"
# Автоочистка снимков: за длинную сессию папка photos разрастается
# до сотен мегабайт. Держим только последние KEEP_PHOTOS штук.
KEEP_PHOTOS = 300
AUTO_PURGE = True
# №51: единый settings.txt распилили на INI по компонентам —
# всё лежит в TrofPridi_data\configs\. Статистике — stats.ini
# ([ui]: тема и защита, [photos]: уборка снимков). Помощникам —
# свои bot_*.ini, их пишет TrofPridi Manager.
CONFIGS_NAME = "configs"
STATS_INI = "stats.ini"
LEGACY_SETTINGS_NAME = "settings.txt"   # старый файл: только читаем, мигрируем

# Значения по умолчанию. Файл настроек читается поверх них, поэтому
# новые пункты можно добавлять без правки уже созданного файла.
DEFAULT_SETTINGS = {
    "capture_guard": True,     # прятать окно от снимков экрана
    "theme": "dark",           # оформление: dark / light (меню AHK тоже)
    # --- внутренние (в окне не показываем; их правит Менеджер) ---
    "auto_purge": True,        # сама удалять старые снимки
    "keep_photos": 300,        # сколько снимков хранить
}

# ---- палитры тем: тёмная и светлая ----
# Цвета живут словарём и подменяются целиком функцией apply_theme():
# вся отрисовка читает эти имена как глобальные В МОМЕНТ вызова, поэтому
# смена темы — это rebind + перерисовка, без перезапуска окна.
#
# Неоморфизм: панель — «тот же материал», что и фон (CARD почти = BG),
# объём даётся парой мягких следов: тёмный вниз-вправо (NEU_DARK) и
# светлый вверх-влево (NEU_LIGHT). Углубления (поля, дорожки) — SINK.
THEMES = {
    "dark": {
        "BG": "#0D1017",        # фон окна
        # Длинные градиенты убраны ПО ПРОСЬБЕ: на 8-битном канале
        # перепад в несколько уровней на сотни пикселей раскладывался
        # на видимые полосы (бэндинг), а маскирующее зерно глазу мешало
        # сильнее самих полос. Ровная заливка — ни полос, ни шума.
        "GRAD_TL": "#0D1017",
        "GRAD_BR": "#0D1017",
        "CARD": "#131923",      # «материал» панели
        "CARD_TOP": "#151C26",  # тело панели — практически ровное:
        "CARD_BOT": "#141A24",  # перепад 1 уровень — полос не даст
        "HOVER": "#1C2530",
        "FG": "#FFFFFF",        # крупные цифры
        "SOFT": "#9AA9B8",      # текст-полутон светлее
        "DIM": "#758598",       # подписи
        "DIMDEEP": "#616F7D",   # подписи послабее
        "MUTE": "#667687",
        "MID": "#8A97A5",
        "PALE": "#C3CEDA",      # почти белый текст
        "FAINT": "#161D27",     # едва видимое (текст-призрак)
        "FAINT2": "#3D4753",    # приглушённые номера/уголки
        "ACCENT": "#00A2FF",
        "GOLD": "#FFB300",
        "GREEN": "#00E6B8",
        "RED": "#FF5555",
        "REDSOFT": "#FF8A8A",
        "EXP": "#7BE04A",       # опыт — всегда этим цветом
        "LINE": "#232B36",
        "DIVLINE": "#1A2230",   # тонкие разделители в панелях
        "SINK": "#090D13",      # дно углублений
        "BGDEEP": "#070A0F",    # глухие глубокие подложки
        "CHIP": "#171E29",      # лицо кнопки/чипа (нейтральной)
        "CHIP2": "#1B2330",     # лицо чипа посветлее
        "CHIP_EDGE": "#2C3A4C",
        "CHIPS_ON": "#13202F",  # лицо выбранного чипа
        "HANDLE": "#0A0D13",    # ручка ползунка
        "HOTFILL": "#313D4A",   # подсветка наведения
        "HOTEDGE": "#5A6B7C",
        "GHOSTEDGE": "#2B3644", # рамки кнопок-призраков
        "CHECKLINE": "#46525F", # рамка чекбокса
        "ACTFACE": "#17567F",   # главная кнопка (акцентная)
        "ACTHOT": "#2E9BE0",
        "NEUHOT": "#3C4C5E",    # hover нейтральной кнопки диалога
        "OVLEDGE": "#151C26",   # незаметная основа рамки наведения
        "OVLEDGE2": "#16202C",
        "LINKTINT": "#24333F",  # подкраска ссылки-названия рыбы
        "NEU_DARK": "#04070C",  # тёмный след панели
        "NEU_LIGHT": "#3A4A5C", # светлый блик панели
        "NEU_DK": 185, "NEU_HI": 180,
        "SINK_DK": 120, "SINK_HI": 100,
        "SPARK_FILL": "#0E2233",   # заливка под графиком темпа
        "EMBLEM_BG": "#0E2233",    # круг под рыбой-эмблемой
        "EMBLEM_FISH": "#4FB3E8",  # рисованная эмблема (запасной вид)
        "PH_FISH": "#27333F",      # рыба на этой заглушке
        "SCROLL": "#3B4653",       # ползунок прокрутки
        "DIALOG_BG": "#11161E",    # панель окон вопроса
        "DIALOG_EDGE": "#273242",
        "splash": {
            "bg": "#0D1119",        # фон заставки
            "edge": "#232E3C",      # мягкая рамка окна
            "edge_hi": "#324052",   # блик верхней кромки
            "sink": "#080C12",      # тёмное «углубление»
            "track": "#0D1218",     # дно дорожки прогресса
            "track_sh": "#05080C",  # внутренняя тень дорожки
            "track_hi": "#29394A",  # нижний блик дорожки
            "accent_hi": "#33B4FF", # стеклянный блик бегунка
            "dim": "#5A6773",       # совет внизу
            "by": "#46525F",        # подпись автора
            "sink_deep": "#070A0E", # глубокая тень
        },
    },
    "light": {
        "BG": "#E4E7ED",
        "CARD": "#E7EAF0",
        "CARD_TOP": "#EBEEF4",
        "CARD_BOT": "#E1E5EC",
        "HOVER": "#DCE1E9",
        "FG": "#1B2430",
        "SOFT": "#46525F",
        "DIM": "#67727F",
        "DIMDEEP": "#8490A0",
        "MUTE": "#7C8896",
        "MID": "#5B6875",
        "PALE": "#3E4A58",
        "FAINT": "#9AA4B1",
        "FAINT2": "#AEB6C2",
        "ACCENT": "#0078D2",
        "GOLD": "#C98A00",
        "GREEN": "#00A87E",
        "RED": "#E04848",
        "REDSOFT": "#DE5555",
        "EXP": "#4FA821",
        "LINE": "#C9CFDA",
        "DIVLINE": "#CBD1DB",
        "SINK": "#D4D9E2",
        "BGDEEP": "#C6CCD6",
        "CHIP": "#EFF1F6",
        "CHIP2": "#E9ECF2",
        "CHIP_EDGE": "#C2C9D5",
        "CHIPS_ON": "#CFDEF0",
        "HANDLE": "#F5F7FA",
        "HOTFILL": "#D6DCE6",
        "HOTEDGE": "#9AA6B8",
        "GHOSTEDGE": "#BEC6D2",
        "CHECKLINE": "#9DA7B4",
        "ACTFACE": "#2B7BC0",
        "ACTHOT": "#5AABE8",
        "NEUHOT": "#C4CCDA",
        "OVLEDGE": "#D8DDE6",
        "OVLEDGE2": "#D2D8E2",
        "LINKTINT": "#BFD9F2",
        "NEU_DARK": "#B9C0CF",
        "NEU_LIGHT": "#FFFFFF",
        "NEU_DK": 168, "NEU_HI": 215,
        "SINK_DK": 100, "SINK_HI": 125,
        "SPARK_FILL": "#C7DFF3",
        "EMBLEM_BG": "#D3E2F0",
        "EMBLEM_FISH": "#2E7FA8",
        "PH_FISH": "#A7B3C1",
        "SCROLL": "#AEB7C4",
        "DIALOG_BG": "#EEF1F6",
        "DIALOG_EDGE": "#C2CAD6",
        "splash": {
            "bg": "#E9ECF2",
            "edge": "#C0C7D2",
            "edge_hi": "#FFFFFF",
            "sink": "#D4D9E2",
            "track": "#D2D7E0",
            "track_sh": "#B4BBC7",
            "track_hi": "#FFFFFF",
            "accent_hi": "#3BA0FF",
            "dim": "#7A8593",
            "by": "#9AA3AE",
            "sink_deep": "#C3C9D4",
        },
    },
}

# Текущая тема подставляется ниже один раз; дальше меняет apply_theme().
THEME = "dark"
_globals = globals()
for _k, _v in THEMES[THEME].items():
    if _k != "splash":
        _globals[_k] = _v
del _globals, _k, _v

# Шрифты. Segoe UI Variable Display мягче на крупных цифрах;
# если системе он неизвестен, tkinter молча падает на Segoe UI.
# Шрифты подбираем среди реально установленных: tkinter при неизвестном
# имени молча подставляет системный (часто с засечками), и вид ломается.
FONT = "Segoe UI"
FONT_NUM = "Segoe UI Semibold"

# --- ЦВЕТА ЗАСТАВКИ ---
# Живут внутри тем (THEMES[*]["splash"]): достаточно подставить другой
# словарь, ничего в отрисовке не меняя. Мутируем сам dict, потому что
# движок заставки держит ссылку на него.
SPLASH_THEME = dict(THEMES[THEME]["splash"])


def apply_palette(name):
    """Подменяет ВСЕ цвета модуля на палитру темы name.

    Рисующие функции смотрят эти имена как глобальные в момент вызова,
    поэтому достаточно перепривязать их здесь и перерисовать окно —
    никакие call site'ы править не нужно. SPLASH_THEME меняем на месте:
    движок заставки держит на него готовую ссылку.
    Возвращает имя реально применённой темы.
    """
    global THEME
    if name not in THEMES:
        name = "dark"
    THEME = name
    pal = THEMES[name]
    g = globals()
    for k, v in pal.items():
        if k != "splash":
            g[k] = v
    SPLASH_THEME.clear()
    SPLASH_THEME.update(pal["splash"])
    return name


def _rgb(c):
    """'#00A2FF' -> (0, 162, 255)."""
    return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5))


def _pil_vgrad(w, h, stops):
    """Вертикальный градиент (список (позиция0..1, RGBA))."""
    from PIL import Image
    img = Image.new("RGBA", (1, h))
    px = img.load()
    for y in range(h):
        t = y / max(1, h - 1)
        col = stops[-1][1]
        for i in range(len(stops) - 1):
            p0, c0 = stops[i]
            p1, c1 = stops[i + 1]
            if p0 <= t <= p1:
                k = 0 if p1 == p0 else (t - p0) / (p1 - p0)
                col = tuple(int(round(c0[j] + (c1[j] - c0[j]) * k))
                            for j in range(4))
                break
        px[0, y] = col
    return img.resize((w, h))


def splash_compose(w, h, p, status, tip, t, th, art, note=""):
    """Полный кадр заставки одной PIL-картинкой (гладко, без «лесенок»).

    Рисуется в двойном размере и уменьшается LANCZOS'ом — капсулы,
    кольца и градиенты иногда круглее, чем умеет холст Tk. art —
    словарь с картинками и шрифтами (см. _splash_load_art).
    note — золотая строка под подзаголовком (показывается, только
    когда идёт установка компонентов).
    """
    from PIL import Image, ImageDraw, ImageFilter

    SS = 2
    W, H = w * SS, h * SS
    p = max(0.0, min(1.0, p))
    img = Image.new("RGB", (W, H), _rgb(th["bg"]))
    d = ImageDraw.Draw(img, "RGBA")

    # мягкая рамка-карточка без кричащей полосы
    d.rectangle([SS, SS, W - 2 * SS, H - 2 * SS], outline=_rgb(th["edge"]),
                width=SS)
    d.line([2 * SS, 2 * SS, W - 2 * SS, 2 * SS], fill=_rgb(th["edge_hi"]),
           width=SS)

    cx, cy = W // 2, 118 * SS
    # кольца: тёмное «углубление» + мягко пульсирующее к синему
    d.ellipse([cx - 64 * SS, cy - 64 * SS, cx + 64 * SS, cy + 64 * SS],
              outline=_rgb(th["sink"]), width=2 * SS)
    pulse = (math.sin(t * 2.1) + 1) / 2
    a, b = _rgb(th["sink"]), _rgb(ACCENT)
    ring = tuple(int(a[i] + (b[i] - a[i]) * (0.25 + 0.45 * pulse))
                 for i in range(3))
    d.ellipse([cx - 53 * SS, cy - 53 * SS, cx + 53 * SS, cy + 53 * SS],
              outline=ring, width=2 * SS)

    # рыба парит (арт заранее гладкий, апскейл не портит края)
    bob = math.sin(t * 2.4) * 5 * SS
    fish = art.get("fish")
    if fish is not None:
        fs = fish.resize((fish.width * SS, fish.height * SS),
                         Image.LANCZOS)
        img.paste(fs, (cx - fs.width // 2, int(cy + bob - fs.height // 2)),
                  fs)
    bub = art.get("bub")
    if bub is not None:
        bs = bub.resize((bub.width * SS, bub.height * SS), Image.LANCZOS)
        for bx, ph in ((-58, 0.0), (50, 1.6)):
            yy = (cy // SS + 42 - ((t * 30 + ph * 66) % 128)) * SS
            if (cy // SS - 86) * SS < yy < (cy // SS + 38) * SS:
                img.paste(bs, (int(cx + bx * SS - bs.width // 2),
                               int(yy + bob * 0.3 - bs.height // 2)), bs)

    # градиентный заголовок с бегущим бликом (4 готовых кадра)
    titles = art.get("titles") or []
    titles = [x for x in titles if x is not None]
    if titles:
        fr = titles[int(t * 3.2) % len(titles)]
        ts = fr.resize((fr.width * SS, fr.height * SS), Image.LANCZOS)
        img.paste(ts, (cx - ts.width // 2, 202 * SS - ts.height // 2), ts)
        d.text((cx, 231 * SS), f"УСАДЬБА РЫБАКА  •  {VERSION}",
               font=art["fonts"].get("sm"), fill=_rgb(DIM), anchor="mm")
    else:
        d.text((cx, 202 * SS), "TROFPRIDI", font=art["fonts"].get("big"),
               fill=_rgb(ACCENT), anchor="mm")
        d.text((cx, 229 * SS), f"УСАДЬБА РЫБАКА  •  {VERSION}",
               font=art["fonts"].get("sm"), fill=_rgb(DIM), anchor="mm")
    if note:
        d.text((cx, 250 * SS), note, font=art["fonts"].get("sm"),
               fill=_rgb(GOLD), anchor="mm")

    # прогресс-капсула: «вдавленная» дорожка и переливающийся бегунок
    x1, x2, y = 90 * SS, W - 90 * SS, 266 * SS
    bh = 8 * SS
    d.rounded_rectangle([x1, y, x2, y + bh], radius=bh // 2,
                        fill=_rgb(th["track"]))
    d.line([x1 + 3 * SS, y + SS, x2 - 3 * SS, y + SS],
           fill=_rgb(th["track_sh"]), width=SS)
    d.line([x1 + 3 * SS, y + bh - SS, x2 - 3 * SS, y + bh - SS],
           fill=_rgb(th["track_hi"]), width=SS)
    bar_w = x2 - x1
    fw = int(bar_w * p)
    if fw > 2 * SS:
        # основа — спокойный горизонтальный градиент акцента
        strip = _pil_vgrad(bar_w, bh, [(0.0, _rgb(ACCENT) + (255,)),
                                       (1.0, _rgb(ACCENT) + (255,))])
        hi, lo = _rgb("#4FCBFF"), _rgb("#0077DE")
        grad = Image.new("RGBA", (bar_w, bh))
        gp = grad.load()
        for xx in range(bar_w):
            k = xx / max(1, bar_w - 1)
            col = tuple(int(hi[i] + (lo[i] - hi[i]) * k) for i in range(3))
            for yy2 in range(bh):
                gp[xx, yy2] = col + (255,)
        # бегущий блик: диагональная светлая полоса поверх градиента
        bright = Image.blend(grad, Image.new("RGBA", (bar_w, bh),
                                             (255, 255, 255, 255)), 0.45)
        band = Image.new("L", (bar_w, bh), 0)
        bd = ImageDraw.Draw(band)
        bx = int(((t * 130) % (bar_w + 240 * SS)) - 120 * SS)
        bd.polygon([(bx, -8), (bx + 46 * SS, -8),
                    (bx - 10 * SS, bh + 8), (bx - 56 * SS, bh + 8)],
                   fill=200)
        band = band.filter(ImageFilter.GaussianBlur(6 * SS))
        strip = Image.composite(bright, grad, band)
        strip = strip.crop((0, 0, fw, bh))
        # капсульная маска на концах
        m = Image.new("L", (fw, bh), 0)
        ImageDraw.Draw(m).rounded_rectangle([0, 0, fw - 1, bh - 1],
                                            radius=bh // 2, fill=255)
        img.paste(strip, (x1, y), m)
    d.text((x2, y - 10 * SS), f"{int(p * 100)}%",
           font=art["fonts"].get("sm"), fill=_rgb(DIM), anchor="rs")
    d.text((cx, y + 28 * SS), status, font=art["fonts"].get("md"),
           fill=_rgb(FG), anchor="mm")
    d.text((cx, H - 20 * SS), tip, font=art["fonts"].get("sm"),
           fill=_rgb(th["dim"]), anchor="mm")
    d.text((W - 12 * SS, H - 9 * SS), "by tg/flkn69",
           font=art["fonts"].get("sm"), fill=_rgb(th["by"]), anchor="rs")

    return img.resize((w, h), Image.LANCZOS)


class _SplashDepUI:
    """Мост между _bootstrap.ensure и заставкой статистики.

    _bootstrap ставит пакеты в фоновом потоке, а мы по его звонкам
    из ГЛАВНОГО потока крутим ту же самую заставку: рыба продолжает
    качаться, полоса ползёт. Отдельного окна установки больше нет —
    и загрузка, и доустановка идут в одном окне.
    """

    def __init__(self, app):
        self.app = app

    def busy(self, names):
        self.app._splash_note = ("Первый запуск — ставим компоненты, "
                                 "это делается один раз")

    def tick(self, step):
        app = self.app
        # Честного процента у pip нет — ползём к отметке 0.30 всё
        # медленнее: видно, что работа идёт, и ничего не обещаем.
        p = app.__dict__.get("_splash_p", 0.1)
        p = min(0.30, p + max(0.0005, (0.30 - p) * 0.01))
        app._splash_p = p
        app._splash_draw(p, "Ставим компоненты распознавания улова…")
        try:
            app.update()
        except Exception:
            pass
        time.sleep(0.033)

    def done(self, ok, names, log):
        app = self.app
        app._splash_note = ""
        p = app.__dict__.get("_splash_p", 0.3)
        if ok:
            app._splash_draw(p, "Компоненты на месте")
            pause = 0.35
        else:
            # Не поставилось (нет интернета?) — честно скажем и идём
            # дальше: окно работает и с неполным набором.
            app._splash_draw(p, "Не всё установилось — проверь интернет")
            pause = 1.6
        try:
            app.update()
        except Exception:
            pass
        time.sleep(pause)


def bar_gradient(w, h):
    """Капсульная полоска прогресса WxH с градиентом акцента.

    Для баров «Видов рыбы» и подобных: округлые концы и горизонтальный
    градиент. Без верхней светлой линии-«блика»: на тонкой полоске
    она читалась как вторая, отдельная полоса и только путала.
    Рисуем в 4x.
    """
    from PIL import Image, ImageDraw

    SS = 4
    w, h = max(8, int(w)), max(3, int(h))
    W, H = w * SS, h * SS
    hi, lo = _rgb("#46C7FF"), _rgb("#0073D8")
    grad = Image.new("RGBA", (W, H))
    gp = grad.load()
    for xx in range(W):
        k = xx / max(1, W - 1)
        col = tuple(int(hi[i] + (lo[i] - hi[i]) * k) for i in range(3))
        for yy in range(H):
            gp[xx, yy] = col + (255,)
    m = Image.new("L", (W, H), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, W - 1, H - 1],
                                        radius=H // 2 + 1, fill=255)
    out = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    out.paste(grad, (0, 0), m)
    return out.resize((w, h), Image.LANCZOS)


_FONT_REGISTERED = None


def _register_bundled_font():
    """Подключает свой шрифт из assets (Roboto Slab) к процессу.

    На Windows регистрируем файлы через AddFontResourceExW с флагом
    FR_PRIVATE: семейство становится видно окну без установки шрифта
    в систему — на абсолютно чистом компьютере вид тот же. PIL читает
    TTF напрямую по пути (см. smooth_canvas._candidates), поэтому там
    регистрация не нужна.
    """
    global _FONT_REGISTERED
    if _FONT_REGISTERED is not None:
        return _FONT_REGISTERED
    ok = False
    try:
        ad = os.path.join(script_dir(), "assets")
        p1 = os.path.join(ad, "font_ui.ttf")
        p2 = os.path.join(ad, "font_ui_bold.ttf")
        if os.path.isfile(p1):
            ok = True
            if os.name == "nt":
                import ctypes
                FR_PRIVATE = 0x10
                r1 = ctypes.windll.gdi32.AddFontResourceExW(p1, FR_PRIVATE, 0)
                r2 = (ctypes.windll.gdi32.AddFontResourceExW(p2, FR_PRIVATE, 0)
                      if os.path.isfile(p2) else 0)
                ok = bool(r1 or r2)
                if ok:
                    # broadcast WM_FONTCHANGE: перечитываем списки шрифтов
                    try:
                        ctypes.windll.user32.SendMessageW(0xFFFF, 0x001D,
                                                          0, 0)
                    except Exception:
                        pass
    except Exception:
        ok = False
    _FONT_REGISTERED = ok
    return ok


def _pick_fonts(root):
    """Выбирает лучший доступный шрифт. Вызывать после создания окна."""
    global FONT, FONT_NUM
    # Свой встроенный шрифт — в приоритете: одинаковый вид на любом ПК.
    if _register_bundled_font():
        FONT = "Roboto Slab"
        FONT_NUM = "Roboto Slab"
        return
    try:
        from tkinter import font as tkfont
        have = {f.lower() for f in tkfont.families(root)}
    except Exception:
        return
    for name in ("Segoe UI Variable Text", "Segoe UI", "Inter",
                 "Noto Sans", "DejaVu Sans", "Helvetica"):
        if name.lower() in have:
            FONT = name
            break
    for name in ("Segoe UI Variable Display Semib", "Segoe UI Semibold",
                 "Segoe UI Variable Display", "Inter SemiBold",
                 FONT):
        if name.lower() in have:
            FONT_NUM = name
            break
    else:
        FONT_NUM = FONT
R_CARD = 14      # радиус карточек
R_TAB  = 16      # радиус вкладок-пилюль
R_BTN  = 9

CAT_RU = {
    "trophy": "Трофей", "zachet": "Зачётная", "small": "Мелочь",
    "coffee": "Кофе / чай", "food": "Еда", "sun": "Солнцезащита",
    "full": "Садок полон", "ok": "Заброс",
    "start": "Старт", "stop": "Стоп",
}


def launch_ocr():
    """Поднимает ocr_watch.pyw фоном.

    Повторный запуск не страшен: сам ocr_watch держит мьютекс и второй
    экземпляр закрывается сразу. Раньше здесь была проверка через wmic,
    но в новых Windows 11 его нет — она молча пропускалась, и в итоге
    работали два процесса, записывая каждую рыбу дважды.
    """
    import subprocess
    exe = os.path.join(script_dir(), "ocr_watch.pyw")
    if not os.path.exists(exe):
        return
    for runner in ("pythonw.exe", "python.exe", sys.executable):
        try:
            subprocess.Popen([runner, exe], cwd=script_dir(),
                             creationflags=getattr(subprocess,
                                                   "CREATE_NO_WINDOW", 0))
            return
        except Exception:
            continue


def script_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- helpers
def round_rect(cv, x1, y1, x2, y2, r, steps=None, **kw):
    """Прямоугольник со скруглёнными углами.

    Число сегментов на угол считаем от радиуса: на восьми отрезках
    крупные скругления выглядели гранёными. Теперь шаг примерно
    полтора пикселя по дуге — грани не различимы.
    """
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    if steps is None:
        steps = max(8, min(28, int(r * 1.6)))
    pts = []
    for cx, cy, a0 in ((x2 - r, y1 + r, -90), (x2 - r, y2 - r, 0),
                       (x1 + r, y2 - r, 90), (x1 + r, y1 + r, 180)):
        for i in range(steps + 1):
            a = math.radians(a0 + 90 * i / steps)
            pts.extend([cx + r * math.cos(a), cy + r * math.sin(a)])
    return cv.create_polygon(pts, smooth=False, **kw)


def round_outline(cv, x1, y1, x2, y2, r, color, width=1, steps=None):
    """Скруглённая рамка без заливки.

    create_rectangle рисует острые углы, и рамка вокруг скруглённой
    плашки выглядела как коробка поверх неё.
    """
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    if steps is None:
        steps = max(8, min(28, int(r * 1.6)))
    pts = []
    for cx, cy, a0 in ((x2 - r, y1 + r, -90), (x2 - r, y2 - r, 0),
                       (x1 + r, y2 - r, 90), (x1 + r, y1 + r, 180)):
        for i in range(steps + 1):
            a = math.radians(a0 + 90 * i / steps)
            pts.extend([cx + r * math.cos(a), cy + r * math.sin(a)])
    pts.extend(pts[:2])          # замыкаем контур
    return cv.create_line(pts, fill=color, width=width, capstyle="round")


def fmt_dur(td):
    """Длительность в виде '3ч 42м', '2ч 05м', '47м'."""
    s = int(td.total_seconds())
    h, m = s // 3600, (s % 3600) // 60
    if h and m:
        return f"{h}ч {m:02d}м"
    if h:
        return f"{h}ч"
    return f"{m}м"


# ---------------------------------------------------------------- иконки
# Рисуем векторно на Canvas: Tk 8.6 не умеет цветные эмодзи в create_text
# (вместо ☕ выводится пустой квадрат — это было видно на скриншотах).
#
# Если рядом лежит шрифт Font Awesome, значки берутся из него: готовая
# профессиональная графика вместо самодельных отрезков и дуг. Ручные
# версии остаются запасным вариантом — окно должно работать и без шрифта.

def _fa(cv, cx, cy, name, s, color):
    """Пробует нарисовать значок шрифтом. True — получилось."""
    if not (SMOOTH and has_icons() and hasattr(cv, "create_icon")):
        return False
    if name not in FA_ICONS:
        return False
    cv.create_icon(cx, cy, name, 15.0 * s, color)
    return True


def icon_anchor(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Якорь — эмблема приложения."""
    if _fa(cv, cx, cy, "anchor", s, color):
        return
    w = max(1.4, 1.9 * s)
    cv.create_oval(cx - 2.6 * s, cy - 10 * s, cx + 2.6 * s, cy - 4.8 * s,
                   outline=color, width=w)
    cv.create_line(cx, cy - 5 * s, cx, cy + 9 * s,
                   fill=color, width=w, capstyle="round")
    cv.create_line(cx - 5.5 * s, cy - 2.5 * s, cx + 5.5 * s, cy - 2.5 * s,
                   fill=color, width=w, capstyle="round")
    cv.create_arc(cx - 8 * s, cy - 1 * s, cx + 8 * s, cy + 11 * s,
                  start=200, extent=140, style="arc",
                  outline=color, width=w)


def icon_grid(cv, cx, cy, s=1.0, color=None):
    color = DIM if color is None else color
    """Четыре квадрата — вкладка «Обзор»."""
    if _fa(cv, cx, cy, "gauge", s, color):
        return
    d = 3.4 * s
    g = 1.1 * s
    for dx in (-1, 1):
        for dy in (-1, 1):
            x = cx + dx * (d / 2 + g / 2)
            y = cy + dy * (d / 2 + g / 2)
            cv.create_rectangle(x - d / 2, y - d / 2, x + d / 2, y + d / 2,
                                fill=color, outline="")


def icon_gallery(cv, cx, cy, s=1.0, color=None):
    color = DIM if color is None else color
    """Рамка с горами — вкладка «Галерея»."""
    if _fa(cv, cx, cy, "images", s, color):
        return
    w = max(1.1, 1.4 * s)
    cv.create_rectangle(cx - 7 * s, cy - 5.5 * s, cx + 7 * s, cy + 5.5 * s,
                        outline=color, width=w)
    cv.create_polygon(cx - 4.5 * s, cy + 3.5 * s, cx - 1 * s, cy - 1.5 * s,
                      cx + 2.5 * s, cy + 3.5 * s,
                      fill=color, outline="")
    cv.create_oval(cx + 2.6 * s, cy - 3.6 * s, cx + 5 * s, cy - 1.2 * s,
                   fill=color, outline="")


def icon_book(cv, cx, cy, s=1.0, color=None):
    color = DIM if color is None else color
    """Раскрытая книга — вкладка «Журнал»."""
    if _fa(cv, cx, cy, "book", s, color):
        return
    w = max(1.1, 1.4 * s)
    cv.create_line(cx, cy - 4.5 * s, cx, cy + 5 * s, fill=color, width=w)
    for sign in (-1, 1):
        cv.create_line(cx, cy - 4.5 * s, cx + sign * 6.5 * s, cy - 3 * s,
                       fill=color, width=w)
        cv.create_line(cx + sign * 6.5 * s, cy - 3 * s,
                       cx + sign * 6.5 * s, cy + 4 * s, fill=color, width=w)
        cv.create_line(cx, cy + 5 * s, cx + sign * 6.5 * s, cy + 4 * s,
                       fill=color, width=w)


def icon_chart(cv, cx, cy, s=1.0, color=None):
    color = DIM if color is None else color
    """Столбчатая диаграмма — вкладка «Сессии»."""
    if _fa(cv, cx, cy, "chart", s, color):
        return
    for i, h in enumerate((3.5, 7, 5)):
        x = cx - 5 * s + i * 5 * s
        cv.create_rectangle(x - 1.6 * s, cy + 5 * s - h * s,
                            x + 1.6 * s, cy + 5 * s,
                            fill=color, outline="")


def icon_refresh(cv, cx, cy, s=1.0, color=None):
    color = SOFT if color is None else color
    """Круговая стрелка — кнопка «Обновить»."""
    if _fa(cv, cx, cy, "rotate", s, color):
        return
    w = max(1.2, 1.5 * s)
    cv.create_arc(cx - 6 * s, cy - 6 * s, cx + 6 * s, cy + 6 * s,
                  start=40, extent=280, style="arc",
                  outline=color, width=w)
    cv.create_polygon(cx + 5.5 * s, cy - 6.5 * s, cx + 8.5 * s, cy - 2.5 * s,
                      cx + 2.8 * s, cy - 3 * s, fill=color, outline="")


def icon_plus(cv, cx, cy, s=1.0, color="#FFFFFF"):
    """Плюс — кнопка «Новый период»."""
    if _fa(cv, cx, cy, "plus", s, color):
        return
    w = max(1.4, 1.8 * s)
    cv.create_line(cx - 4.5 * s, cy, cx + 4.5 * s, cy,
                   fill=color, width=w, capstyle="round")
    cv.create_line(cx, cy - 4.5 * s, cx, cy + 4.5 * s,
                   fill=color, width=w, capstyle="round")


def icon_restart(cv, cx, cy, s=1.0, color="#FFFFFF"):
    """Круговая стрелка — «начать заново».

    Плюс на этой кнопке вводил в заблуждение: он обещает добавление,
    а кнопка уносит накопленное в резервную копию и обнуляет счёт.
    """
    if _fa(cv, cx, cy, "rotate", s, color):
        return
    r = 5.0 * s
    w = max(1.4, 1.7 * s)
    # Дуга с разрывом сверху справа — место для наконечника стрелки.
    cv.create_arc(cx - r, cy - r, cx + r, cy + r, start=50, extent=290,
                  style="arc", outline=color, width=w)
    a = 0.9
    tipx, tipy = cx + r * math.cos(a), cy - r * math.sin(a)
    cv.create_polygon(tipx + 2.6 * s, tipy - 0.4 * s,
                      tipx - 1.6 * s, tipy - 2.4 * s,
                      tipx - 0.6 * s, tipy + 2.2 * s,
                      fill=color, outline="")


def icon_shield(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Щит с галочкой — «данные сохраняются»."""
    if _fa(cv, cx, cy, "shield", s, color):
        return
    cv.create_oval(cx - 6 * s, cy - 6 * s, cx + 6 * s, cy + 6 * s,
                   fill=color, outline="")
    cv.create_line(cx - 2.8 * s, cy + 0.3 * s, cx - 0.8 * s, cy + 2.6 * s,
                   cx + 3 * s, cy - 2.6 * s, fill="#0B1116",
                   width=max(1.2, 1.6 * s), capstyle="round",
                   joinstyle="round")


def emblem_fish(cv, x1, y1, x2, y2, color="#2E7FA8"):
    """Декоративная рыба в круге — заглушка вместо фото.

    Если есть шрифт значков, берём готовый силуэт: он нарисован
    дизайнерами и на любом размере выглядит опрятнее самодельной
    кривой. Иначе строим контур вручную, как раньше.
    """
    if SMOOTH and has_icons() and hasattr(cv, "create_icon"):
        size = min(x2 - x1, y2 - y1) * 0.52
        cv.create_icon((x1 + x2) / 2, (y1 + y2) / 2, "fish", size, color)
        return

    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    R = min(x2 - x1, y2 - y1) * 0.42
    s = R / 10.0
    thin = max(1.0, 1.0 * s)
    line = max(1.2, 1.4 * s)

    cv.create_oval(cx - R, cy - R, cx + R, cy + R,
                   outline=color, width=thin)

    nose = cx - 7.2 * s
    tail = cx + 4.6 * s

    # Тело: опорные точки спины и брюха. Начинаем и заканчиваем в носу,
    # поэтому контур получается замкнутым без лишнего отрезка.
    cv.create_line(
        nose, cy,
        cx - 4.4 * s, cy - 2.9 * s,
        cx - 0.8 * s, cy - 3.8 * s,
        cx + 2.6 * s, cy - 3.0 * s,
        tail, cy - 1.4 * s,
        tail, cy + 1.4 * s,
        cx + 2.6 * s, cy + 3.0 * s,
        cx - 0.8 * s, cy + 3.6 * s,
        cx - 4.4 * s, cy + 2.7 * s,
        nose, cy,
        fill=color, width=line, smooth=True, splinesteps=24,
        capstyle="round", joinstyle="round")

    # Хвост: две дуги от основания
    cv.create_line(
        tail - 0.6 * s, cy - 1.2 * s,
        tail + 3.2 * s, cy - 4.4 * s,
        tail + 4.4 * s, cy - 1.0 * s,
        tail + 4.4 * s, cy + 1.0 * s,
        tail + 3.2 * s, cy + 4.4 * s,
        tail - 0.6 * s, cy + 1.2 * s,
        fill=color, width=line, smooth=True, splinesteps=20,
        capstyle="round", joinstyle="round")

    # Спинной плавник
    cv.create_line(cx - 1.8 * s, cy - 3.6 * s,
                   cx - 0.2 * s, cy - 6.0 * s,
                   cx + 2.2 * s, cy - 3.1 * s,
                   fill=color, width=thin, smooth=True, splinesteps=14,
                   capstyle="round")
    # Брюшной плавник
    cv.create_line(cx - 0.8 * s, cy + 3.5 * s,
                   cx + 0.6 * s, cy + 5.4 * s,
                   cx + 2.4 * s, cy + 2.8 * s,
                   fill=color, width=thin, smooth=True, splinesteps=14,
                   capstyle="round")
    # Жаберная дуга
    cv.create_line(cx - 4.6 * s, cy - 2.2 * s,
                   cx - 3.8 * s, cy,
                   cx - 4.6 * s, cy + 2.1 * s,
                   fill=color, width=thin, smooth=True, splinesteps=12,
                   capstyle="round")
    # Глаз
    cv.create_oval(cx - 5.9 * s, cy - 1.3 * s,
                   cx - 4.5 * s, cy + 0.1 * s,
                   outline=color, width=thin)


def icon_hook(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Рыболовный крючок: ушко, прямое цевьё, J-образный загиб, жало.

    Внимание: в tkinter угол 90 — это ВЕРХ овала, отсчёт против часовой
    стрелки (в PIL наоборот). start=180/extent=180 даёт нижнюю половину.
    """
    if _fa(cv, cx, cy, "anchor", s, color):
        return
    w = max(1.6, 2.3 * s)
    top = cy - 12 * s          # верх ушка
    bend = cy + 3 * s          # где начинается загиб
    r = 5.6 * s                # радиус загиба

    # ушко — незамкнутое колечко
    cv.create_arc(cx - 3 * s, top, cx + 3 * s, top + 6 * s,
                  start=20, extent=300, style="arc",
                  outline=color, width=w * 0.85)
    # цевьё
    cv.create_line(cx, top + 6 * s, cx, bend,
                   fill=color, width=w, capstyle="round")
    # загиб — нижняя половина окружности
    cv.create_arc(cx - r, bend - r, cx + r, bend + r,
                  start=180, extent=180, style="arc",
                  outline=color, width=w)
    # жало вверх с внешней стороны
    cv.create_line(cx + r, bend, cx + r, bend - 5.2 * s,
                   fill=color, width=w, capstyle="round")
    # бородка
    cv.create_line(cx + r, bend - 5.2 * s, cx + r - 3 * s, bend - 1.6 * s,
                   fill=color, width=w * 0.8, capstyle="round")


def icon_coffee(cv, cx, cy, s=1.0):
    """Кружка кофе с паром."""
    if _fa(cv, cx, cy, "mug", s, "#00E6B8"):
        return
    body = "#C98A5B"
    cup = PALE
    for i, dx in enumerate((-3.5, 0, 3.5)):
        cv.create_line(cx + dx * s, cy - 9 * s, cx + dx * s, cy - 6 * s,
                       fill="#5E7183", width=1.6 * s, capstyle="round")
    cv.create_arc(cx + 4 * s, cy - 4 * s, cx + 11 * s, cy + 3 * s,
                  start=270, extent=180, style="arc",
                  outline=cup, width=1.8 * s)
    round_rect(cv, cx - 7 * s, cy - 4.5 * s, cx + 5 * s, cy + 6.5 * s,
               3 * s, fill=cup, outline="")
    round_rect(cv, cx - 5.4 * s, cy - 3 * s, cx + 3.4 * s, cy + 1.6 * s,
               1.6 * s, fill=body, outline="")


def icon_food(cv, cx, cy, s=1.0):
    """Вилка и нож."""
    if _fa(cv, cx, cy, "utensils", s, "#FFB300"):
        return
    col = "#9FE870"
    # вилка
    for dx in (-6.2, -4.4, -2.6):
        cv.create_line(cx + dx * s, cy - 9 * s, cx + dx * s, cy - 4 * s,
                       fill=col, width=1.5 * s, capstyle="round")
    cv.create_line(cx - 6.2 * s, cy - 4 * s, cx - 2.6 * s, cy - 4 * s,
                   fill=col, width=1.5 * s)
    cv.create_line(cx - 4.4 * s, cy - 4 * s, cx - 4.4 * s, cy + 9 * s,
                   fill=col, width=2.0 * s, capstyle="round")
    # нож
    cv.create_line(cx + 4.4 * s, cy - 9 * s, cx + 4.4 * s, cy + 9 * s,
                   fill=col, width=2.0 * s, capstyle="round")
    cv.create_arc(cx + 1.6 * s, cy - 9.5 * s, cx + 7.2 * s, cy + 1 * s,
                  start=0, extent=180, style="arc",
                  outline=col, width=1.5 * s)


def icon_fish(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Силуэт рыбки для заголовка панели."""
    if _fa(cv, cx, cy, "fish", s, color):
        return
    cv.create_oval(cx - 7 * s, cy - 4 * s, cx + 4 * s, cy + 4 * s,
                   fill=color, outline="")
    cv.create_polygon(cx + 3 * s, cy, cx + 8 * s, cy - 4 * s,
                      cx + 8 * s, cy + 4 * s, fill=color, outline="")
    cv.create_oval(cx - 4.6 * s, cy - 1.6 * s, cx - 3 * s, cy,
                   fill="#0B1116", outline="")


def icon_star(cv, cx, cy, s=1.0, color=None):
    color = GOLD if color is None else color
    """Пятиконечная звезда — трофей."""
    if _fa(cv, cx, cy, "star", s, color):
        return
    pts = []
    for i in range(10):
        a = math.radians(-90 + i * 36)
        r = 8.4 * s if i % 2 == 0 else 3.6 * s
        pts.extend([cx + r * math.cos(a), cy + r * math.sin(a)])
    cv.create_polygon(pts, fill=color, outline="")


def icon_check(cv, cx, cy, s=1.0, color=None):
    color = GREEN if color is None else color
    """Галочка в круге — зачётная."""
    if _fa(cv, cx, cy, "check", s, color):
        return
    cv.create_oval(cx - 8 * s, cy - 8 * s, cx + 8 * s, cy + 8 * s,
                   fill=color, outline="")
    cv.create_line(cx - 3.6 * s, cy + 0.4 * s, cx - 1 * s, cy + 3.4 * s,
                   cx + 4 * s, cy - 3.4 * s,
                   fill="#0B1116", width=max(1.6, 2.0 * s),
                   capstyle="round", joinstyle="round")


def icon_trophy(cv, cx, cy, s=1.0, color=None):
    color = GOLD if color is None else color
    """Кубок — трофейные экземпляры."""
    if _fa(cv, cx, cy, "trophy", s, color):
        return
    cv.create_arc(cx - 5.5 * s, cy - 7 * s, cx + 5.5 * s, cy + 3 * s,
                  start=180, extent=180, style="chord",
                  fill=color, outline="")
    cv.create_arc(cx - 9 * s, cy - 6.5 * s, cx - 3 * s, cy - 0.5 * s,
                  start=90, extent=180, style="arc",
                  outline=color, width=max(1.2, 1.5 * s))
    cv.create_arc(cx + 3 * s, cy - 6.5 * s, cx + 9 * s, cy - 0.5 * s,
                  start=270, extent=180, style="arc",
                  outline=color, width=max(1.2, 1.5 * s))
    cv.create_line(cx, cy + 2 * s, cx, cy + 5.5 * s,
                   fill=color, width=max(1.4, 1.8 * s))
    cv.create_line(cx - 4 * s, cy + 6.5 * s, cx + 4 * s, cy + 6.5 * s,
                   fill=color, width=max(1.6, 2.2 * s), capstyle="round")


def icon_speed(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Спидометр — средний темп ловли."""
    if _fa(cv, cx, cy, "gauge", s, color):
        return
    cv.create_arc(cx - 7.5 * s, cy - 7.5 * s, cx + 7.5 * s, cy + 7.5 * s,
                  start=20, extent=140, style="arc",
                  outline=color, width=max(1.3, 1.7 * s))
    cv.create_line(cx, cy + 3 * s, cx + 4.5 * s, cy - 3.5 * s,
                   fill=color, width=max(1.3, 1.7 * s), capstyle="round")
    cv.create_oval(cx - 1.6 * s, cy + 1.6 * s, cx + 1.6 * s, cy + 4.8 * s,
                   fill=color, outline="")


def icon_weight(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Гиря — суммарный вес улова."""
    if _fa(cv, cx, cy, "weight", s, color):
        return
    cv.create_arc(cx - 3 * s, cy - 7 * s, cx + 3 * s, cy - 1 * s,
                  start=0, extent=180, style="arc",
                  outline=color, width=max(1.2, 1.5 * s))
    cv.create_polygon(cx - 6.5 * s, cy + 6.5 * s, cx - 4.5 * s, cy - 3 * s,
                      cx + 4.5 * s, cy - 3 * s, cx + 6.5 * s, cy + 6.5 * s,
                      fill=color, outline="")


def icon_clock(cv, cx, cy, s=1.0, color=None):
    color = ACCENT if color is None else color
    """Часы со стрелкой назад — заголовок «Последний улов»."""
    if _fa(cv, cx, cy, "clock", s, color):
        return
    r = 7 * s
    cv.create_oval(cx - r, cy - r, cx + r, cy + r,
                   outline=color, width=max(1.2, 1.6 * s))
    cv.create_line(cx, cy - 3.4 * s, cx, cy, fill=color,
                   width=max(1.2, 1.5 * s), capstyle="round")
    cv.create_line(cx, cy, cx + 3.2 * s, cy + 1.6 * s, fill=color,
                   width=max(1.2, 1.5 * s), capstyle="round")


def icon_gamepad(cv, cx, cy, s=1.0, color=None):
    """Джойстик — метка игрового времени. В урезанном наборе FA его
    нет (42 значка), поэтому только вектор, как у запасных иконок."""
    color = ACCENT if color is None else color
    # корпус: «пилюля» с двумя рукавами-хватками
    x1, x2 = cx - 6 * s, cx + 6 * s
    y1, y2 = cy - 3.2 * s, cy + 3.2 * s
    cv.create_rectangle(x1 + 1.2 * s, y1, x2 - 1.2 * s, y2,
                        fill=color, outline="")
    cv.create_oval(x1 - 1 * s, y1, x1 + 3.6 * s, y2, fill=color, outline="")
    cv.create_oval(x2 - 3.6 * s, y1, x2 + 1 * s, y2, fill=color, outline="")
    cv.create_oval(x1 + 0.4 * s, y1 - 2 * s, x1 + 3 * s, y1 + 0.6 * s,
                   fill=color, outline="")        # левый борт
    cv.create_oval(x2 - 3 * s, y1 - 2 * s, x2 - 0.4 * s, y1 + 0.6 * s,
                   fill=color, outline="")        # правый борт
    d = "#0B1116"    # детали «выгравированы», как у щита
    # крестовина слева
    cv.create_line(cx - 4 * s, cy, cx - 1.6 * s, cy, fill=d,
                   width=max(1.0, 1.1 * s), capstyle="round")
    cv.create_line(cx - 2.8 * s, cy - 1.2 * s, cx - 2.8 * s, cy + 1.2 * s,
                   fill=d, width=max(1.0, 1.1 * s), capstyle="round")
    # две кнопки справа
    cv.create_oval(cx + 1.8 * s, cy - 1.3 * s, cx + 2.8 * s, cy - 0.3 * s,
                   fill=d, outline="")
    cv.create_oval(cx + 3.1 * s, cy + 0.3 * s, cx + 4.1 * s, cy + 1.3 * s,
                   fill=d, outline="")


def icon_cross(cv, cx, cy, s=1.0, color=None):
    color = RED if color is None else color
    """Крестик в круге — незачётная рыба."""
    if _fa(cv, cx, cy, "xmark", s, color):
        return
    cv.create_oval(cx - 8 * s, cy - 8 * s, cx + 8 * s, cy + 8 * s,
                   fill=color, outline="")
    d = 3.4 * s
    cv.create_line(cx - d, cy - d, cx + d, cy + d, fill="#0B1116",
                   width=max(1.4, 1.9 * s), capstyle="round")
    cv.create_line(cx - d, cy + d, cx + d, cy - d, fill="#0B1116",
                   width=max(1.4, 1.9 * s), capstyle="round")


def icon_search(cv, cx, cy, s=1.0, color=None):
    color = SOFT if color is None else color
    """Лупа — поле поиска."""
    if _fa(cv, cx, cy, "magnifier", s, color):
        return
    r = 5 * s
    cv.create_oval(cx - r - 1.5 * s, cy - r - 1.5 * s,
                   cx + r - 1.5 * s, cy + r - 1.5 * s,
                   outline=color, width=max(1.2, 1.6 * s))
    cv.create_line(cx + 2.4 * s, cy + 2.4 * s, cx + 6.5 * s, cy + 6.5 * s,
                   fill=color, width=max(1.2, 1.8 * s), capstyle="round")


def icon_trash(cv, cx, cy, s=1.0, color=None):
    color = REDSOFT if color is None else color
    """Корзина — удаление записей."""
    if _fa(cv, cx, cy, "trash", s, color):
        return
    w = max(1.2, 1.5 * s)
    cv.create_line(cx - 6 * s, cy - 4 * s, cx + 6 * s, cy - 4 * s,
                   fill=color, width=w, capstyle="round")
    cv.create_line(cx - 2 * s, cy - 6.5 * s, cx + 2 * s, cy - 6.5 * s,
                   fill=color, width=w, capstyle="round")
    for dx in (-3, 0, 3):
        cv.create_line(cx + dx * s, cy - 1.5 * s, cx + dx * s, cy + 5 * s,
                       fill=color, width=w, capstyle="round")
    cv.create_line(cx - 4.6 * s, cy - 3 * s, cx - 3.8 * s, cy + 6.5 * s,
                   fill=color, width=w, capstyle="round")
    cv.create_line(cx + 4.6 * s, cy - 3 * s, cx + 3.8 * s, cy + 6.5 * s,
                   fill=color, width=w, capstyle="round")
    cv.create_line(cx - 3.8 * s, cy + 6.5 * s, cx + 3.8 * s, cy + 6.5 * s,
                   fill=color, width=w, capstyle="round")


def icon_sort(cv, cx, cy, s=1.0, color=None, desc=True, active=True):
    color = ACCENT if color is None else color
    """Указатель сортировки.

    У неактивного столбца рисуем ПАРУ стрелок (вверх и вниз) — так
    сразу видно, что по нему тоже можно сортировать. У активного
    остаётся одна стрелка, показывающая текущее направление.
    """
    if active:
        name = "sort-down" if desc else "sort-up"
        if _fa(cv, cx, cy, name, s, color):
            return
        d = 3.2 * s
        if desc:
            cv.create_polygon(cx - d, cy - d * 0.55, cx + d, cy - d * 0.55,
                              cx, cy + d, fill=color, outline="")
        else:
            cv.create_polygon(cx - d, cy + d * 0.55, cx + d, cy + d * 0.55,
                              cx, cy - d, fill=color, outline="")
        return

    # неактивный столбец: две бледные стрелки друг над другом
    if _fa(cv, cx, cy, "sort", s, color):
        return
    d = 2.7 * s
    gap = 1.4 * s
    cv.create_polygon(cx - d, cy - gap, cx + d, cy - gap,
                      cx, cy - gap - d * 1.15, fill=color, outline="")
    cv.create_polygon(cx - d, cy + gap, cx + d, cy + gap,
                      cx, cy + gap + d * 1.15, fill=color, outline="")


def icon_checkbox(cv, cx, cy, s=1.0, color=None, checked=False):
    color = CHECKLINE if color is None else color
    """Кружок выбора строки: пустой контур или с галочкой внутри.

    Контур сделан толще и крупнее: тонкое кольцо r=7 при s=0.6 даже
    со сглаживанием распадалось на глаз в рваную «лесенку», особенно
    на крупном DPI. Жирное кольцо читается чисто.
    """
    r = 7.5 * s
    if checked:
        cv.create_oval(cx - r, cy - r, cx + r, cy + r,
                       fill=color, outline="")
        cv.create_line(cx - 3.1 * s, cy + 0.1 * s,
                       cx - 0.9 * s, cy + 2.5 * s,
                       cx + 3.4 * s, cy - 2.8 * s, fill="#0B1116",
                       width=max(1.7, 2.2 * s), capstyle="round",
                       joinstyle="round")
    else:
        cv.create_oval(cx - r, cy - r, cx + r, cy + r,
                       outline=color, width=max(1.8, 2.2 * s))


def icon_gear(cv, cx, cy, s=1.0, color=None):
    color = DIM if color is None else color
    """Шестерёнка — вкладка настроек."""
    if _fa(cv, cx, cy, "gear", s, color):
        return
    r_out, r_in = 8.0 * s, 4.6 * s
    pts = []
    teeth = 8
    for i in range(teeth * 2):
        a = math.radians(i * (180.0 / teeth))
        r = r_out if i % 2 == 0 else r_out * 0.74
        pts.extend([cx + r * math.cos(a), cy + r * math.sin(a)])
    cv.create_polygon(pts, fill=color, outline="")
    cv.create_oval(cx - r_in, cy - r_in, cx + r_in, cy + r_in,
                   fill="#0B1116", outline="")


def icon_info(cv, cx, cy, s=1.0, color=None):
    """Буква «i» в круге — вкладка «О программе».

    В урезанном наборе assets/fa-icons.otf глифа info нет,
    поэтому рисуем вектором, как остальные запасные значки."""
    color = DIM if color is None else color
    cv.create_oval(cx - 7 * s, cy - 7 * s, cx + 7 * s, cy + 7 * s,
                   outline=color, width=max(1.3, 1.7 * s))
    cv.create_oval(cx - 1.1 * s, cy - 4.3 * s,
                   cx + 1.1 * s, cy - 2.1 * s, fill=color, outline="")
    cv.create_line(cx, cy - 0.5 * s, cx, cy + 4.1 * s,
                   fill=color, width=max(1.6, 2.1 * s), capstyle="round")


def icon_pen(cv, cx, cy, s=1.0, color=None):
    color = SOFT if color is None else color
    """Карандаш — переименование записи журнала.

    Глифа «pen» нет в урезанном assets/fa-icons.otf (проверено по
    таблице символов шрифта), поэтому значок всегда векторный:
    _fa вернёт False, а шрифтовой путь оставлен на будущее.
    """
    if _fa(cv, cx, cy, "pen", s, color):
        return
    d = s / 1.4142
    # ствол: диагональный штрих с круглыми концами
    cv.create_line(cx - 2.6 * d, cy + 2.6 * d, cx + 2.4 * d, cy - 2.4 * d,
                   fill=color, width=2.6 * s, capstyle="round")
    # заточенный грифель у нижнего конца
    cv.create_line(cx - 6.2 * d, cy + 6.2 * d, cx - 3.4 * d, cy + 3.4 * d,
                   fill=color, width=1.5 * s, capstyle="round")


def icon_toggle(cv, cx, cy, s=1.0, on=False, glow=0.0):
    """Переключатель «включено/выключено».

    glow 0..1 — насколько подсвечен при наведении: рамка светлеет,
    так понятно, что по нему можно щёлкнуть.
    """
    w, h = 42 * s, 22 * s
    x1, y1, x2, y2 = cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2
    track = ACCENT if on else CHECKLINE
    if on and glow:
        track = "#33B4FF"
    round_rect(cv, x1, y1, x2, y2, h / 2, fill=track, outline="")
    if not on and glow:
        round_outline(cv, x1, y1, x2, y2, h / 2, CHECKLINE)
    kr = h / 2 - 3 * s
    kx = (x2 - kr - 3 * s) if on else (x1 + kr + 3 * s)
    cv.create_oval(kx - kr, cy - kr, kx + kr, cy + kr,
                   fill="#F2F6FA" if on else MID, outline="")


def icon_sun(cv, cx, cy, s=1.0, color=None):
    """Солнце с лучами."""
    col = color or "#FFC93C"
    if _fa(cv, cx, cy, "sun", s, col):
        return
    cv.create_oval(cx - 4.2 * s, cy - 4.2 * s, cx + 4.2 * s, cy + 4.2 * s,
                   fill=col, outline="")
    for i in range(8):
        a = math.radians(i * 45)
        x0 = cx + 6.4 * s * math.cos(a)
        y0 = cy + 6.4 * s * math.sin(a)
        x1 = cx + 9.4 * s * math.cos(a)
        y1 = cy + 9.4 * s * math.sin(a)
        cv.create_line(x0, y0, x1, y1, fill=col,
                       width=1.8 * s, capstyle="round")


def icon_angle(cv, cx, cy, s=1.0, color=None, name="left"):
    color = SOFT if color is None else color
    """Стрелки листания: одинарные и двойные (в начало / в конец)."""
    w = max(1.3, 1.7 * s)
    d = 3.2 * s
    if name in ("first", "last"):
        # sign задаёт, куда смотрит ОСТРИЁ: для «в начало» — влево.
        sign = 1 if name == "first" else -1
        for off in (-2.6 * s, 1.4 * s):
            cv.create_line(cx + off + sign * d * 0.7, cy - d,
                           cx + off - sign * d * 0.3, cy,
                           cx + off + sign * d * 0.7, cy + d,
                           fill=color, width=w, capstyle="round",
                           joinstyle="round")
        return
    # sign>0 — остриё смотрит вправо, sign<0 — влево
    sign = -1 if name == "left" else 1
    cv.create_line(cx - sign * d * 0.5, cy - d,
                   cx + sign * d * 0.5, cy,
                   cx - sign * d * 0.5, cy + d,
                   fill=color, width=w, capstyle="round", joinstyle="round")


# Реестр значков — журнал выбирает иконку фильтра по имени.
_ICONS = {
    "angle": icon_angle,
    "list": lambda cv, x, y, s=1.0, col=None: icon_grid(cv, x, y, s, col or SOFT),
    "star": icon_star,
    "check": icon_check,
    "xmark": icon_cross,
    "fish": icon_fish,
}


# --------------------------------------------------- исправление имён
# Справочник берём из ocr_watch, чтобы список был в одном месте.
# Импортируем ТОЛЬКО справочник, а не ocr_watch целиком: тот при
# импорте запускает автоустановку пакетов и может открыть лишнее окно.
try:
    from fish_names import (match_known_fish as _match_fish,
                            load_name_map, save_name_map, apply_name_map)
except Exception:
    def _match_fish(name, extra=None):
        return name

    def load_name_map(path):
        return {}

    def save_name_map(path, mapping):
        pass

    def apply_name_map(name, mapping):
        return name


# Карта переименований перечитывается с диска, только если файл
# поменялся: журнал дергает загрузку часто, а парсить текстовик
# на каждую рыбу — лишняя работа.
_MAP_CACHE = {"path": "", "mtime": -1.0, "data": {}}


def _name_map_for(path):
    """Карта переименований рядом с fish_log.csv, с кэшем по mtime."""
    try:
        mt = os.path.getmtime(path)
    except OSError:
        mt = -1.0
    if _MAP_CACHE["path"] != path or _MAP_CACHE["mtime"] != mt:
        _MAP_CACHE["path"] = path
        _MAP_CACHE["mtime"] = mt
        _MAP_CACHE["data"] = load_name_map(path) if mt >= 0 else {}
    return _MAP_CACHE["data"]


def _fix_fish_name(name):
    """Подбирает ближайшее известное название рыбы."""
    try:
        return _match_fish(name)
    except Exception:
        return name


def _scrub_fish_log(path, kept_rows):
    """Переписывает fish_log.csv без точных дублей.

    Дубли родились у старого процесса OCR запущенного до появления
    заслонов от повторов: одна и та же рыба уходила в журнал дважды
    за пару секунд. Перед перезаписью оригинал уезжает в backup —
    как при удалении сессий, вернуть можно всегда. Не получилось —
    не страшно: дубли мы уже не показываем, а журнал не тронем.
    """
    try:
        import shutil as _sh
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        bak = os.path.join(os.path.dirname(path), "backup", stamp)
        os.makedirs(bak, exist_ok=True)
        _sh.copy2(path, os.path.join(bak, "fish_log.csv"))
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["timestamp", "name", "weight_kg", "exp",
                        "photo", "kind", "length_cm", "release_exp"])
            w.writerows(kept_rows)
    except Exception:
        pass


# ---------------------------------------------------------------- данные
class Stats:
    def __init__(self):
        self.rows = []
        self.fish = []
        self.error = ""

    def load(self, path):
        self.rows, self.error = [], ""
        if not os.path.exists(path):
            self.error = ("Файл stats.csv ещё не создан.\n"
                          "Запусти бота и поймай рыбу.")
            return False
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                for r in csv.reader(f, delimiter=";"):
                    if len(r) < 3 or r[0] == "timestamp":
                        continue
                    try:
                        ts = datetime.strptime(r[0].strip(), "%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        continue
                    self.rows.append((ts, r[1].strip(), r[2].strip()))
        except Exception as e:
            self.error = f"Не удалось прочитать файл:\n{e}"
            return False
        self.rows.sort(key=lambda x: x[0])
        return True

    def load_fish(self, path):
        """fish_log.csv от OCR: время, название, вес, категория."""
        self.fish = []
        if not os.path.exists(path):
            return
        # Карта переименований живёт рядом с журналом улова. Применяем
        # её и здесь: тогда даже старый процесс OCR, запущенный до
        # обновления, не помешает статистике показывать новые имена.
        mapping = _name_map_for(os.path.join(os.path.dirname(path),
                                             "names_map.txt"))
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                raw_rows = list(csv.reader(f, delimiter=";"))
            # Точные дубли: та же рыба (имя+вес до грамма+длина),
            # записанная дважды подряд за секунды, — так писал запущенный
            # давно процесс OCR ещё без заслонов от повторов. Две настоящие
            # рыбы с одинаковым весом до грамма за 45 секунд не ловятся.
            # Дубли не показываем, а сам файл чистим (оригинал — в backup).
            kept_rows = []
            dropped = 0
            last_sig, last_ts = None, None
            for r in raw_rows:
                if len(r) < 3 or r[0] == "timestamp":
                    continue
                try:
                    ts = datetime.strptime(r[0].strip(),
                                           "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    continue
                sig = (r[1].strip().lower(), r[2].strip(),
                       r[6].strip() if len(r) > 6 else "")
                if (sig[0] and (sig[1] or sig[2]) and sig == last_sig
                        and last_ts is not None
                        and 0 <= (ts - last_ts).total_seconds() <= 45):
                    dropped += 1
                    continue
                last_sig, last_ts = sig, ts
                kept_rows.append(r)
            if dropped:
                _scrub_fish_log(path, kept_rows)
            for r in kept_rows:
                ts = datetime.strptime(r[0].strip(), "%Y-%m-%d %H:%M:%S")
                try:
                    w = float(r[2]) if r[2].strip() else None
                except ValueError:
                    w = None
                exp = 0
                if len(r) > 3 and r[3].strip().isdigit():
                    exp = int(r[3].strip())
                # Панель опыта в игре анимирована: числа набегают
                # с нуля, и снимок первых кадров давал «1 опыта».
                # Такие значения в старых записях не показываем —
                # лучше прочерк, чем заведомо неверная цифра.
                if exp < 10:
                    exp = 0
                photo = r[4].strip() if len(r) > 4 else ""
                ln_ok = (len(r) > 6 and r[6].strip().isdigit()
                         and int(r[6].strip()) > 0)
                kind = r[5].strip() if len(r) > 5 else ""
                # Записи старых версий приходили с пустой категорией.
                # Если вес или длина есть, значит окно улова прочиталось
                # нормально, а бейджа не было — это незачётная рыба.
                if not kind and (w is not None or ln_ok):
                    kind = "small"
                ln = 0
                if len(r) > 6 and r[6].strip().isdigit():
                    ln = int(r[6].strip())
                # Регистр правим и при чтении: в старых записях
                # встречается «жерех» рядом с «Жерех», иначе один
                # вид считался бы за два разных.
                nm = r[1].strip()
                if nm:
                    parts = nm.split()
                    nm = " ".join(
                        [parts[0][:1].upper() + parts[0][1:].lower()]
                        + [x.lower() for x in parts[1:]])
                    # Опечатки OCR («Окуну» вместо «Окунь») правим
                    # и для уже записанных уловов, иначе одна рыба
                    # числится в статистике как два разных вида.
                    nm = _fix_fish_name(nm)
                    # А теперь — личные переименования из журнала:
                    # «Карп голый», переименованный в «Карасекарпа»,
                    # должен показываться новым именем везде.
                    nm = apply_name_map(nm, mapping)
                self.fish.append((ts, nm, w, exp, photo, kind, ln))
        except Exception:
            pass

    def top_species(self, n=5):
        c = Counter(f[1] for f in getattr(self, "fish", []) if f[1])
        return c.most_common(n)

    def records(self, n=5):
        """Самые тяжёлые экземпляры."""
        wf = [f for f in getattr(self, "fish", []) if f[2]]
        return sorted(wf, key=lambda x: -x[2])[:n]

    def total_exp(self):
        return sum(f[3] for f in getattr(self, "fish", []) if len(f) > 3)

    def best_exp(self):
        e = [(f[3], f[1]) for f in getattr(self, "fish", [])
             if len(f) > 3 and f[3]]
        return max(e) if e else (0, "")

    def photos(self):
        return [f for f in getattr(self, "fish", [])
                if len(f) > 4 and f[4]]

    def total_weight(self):
        return sum(f[2] for f in getattr(self, "fish", []) if f[2])

    def avg_weight(self):
        w = [f[2] for f in getattr(self, "fish", []) if f[2]]
        return sum(w) / len(w) if w else 0.0

    def catches(self):
        return [r for r in self.rows if r[1] == "catch"]

    def by_category(self):
        """Сколько трофеев, зачётных и мелочи.

        Считаем по журналу улова (fish_log.csv), а не по событиям бота
        (stats.csv). Причина: удаление записи в журнале правит именно
        fish_log, а события бота остаются. Раньше из-за этого удалённый
        трофей продолжал числиться в «Обзоре» — цифра не сходилась с
        тем, что видно в галерее.

        Если распознанных уловов нет вовсе (OCR ещё не настроен), берём
        события бота: лучше показать хоть какие-то категории, чем нули.
        """
        fish = getattr(self, "fish", [])
        if fish:
            return Counter(f[5] for f in fish if len(f) > 5 and f[5])
        return Counter(c[2] for c in self.catches())

    def consumables(self):
        return Counter(r[2] for r in self.rows if r[1] == "consume")

    def casts(self):
        return sum(1 for r in self.rows if r[1] == "cast")

    def keepnet_full(self):
        return sum(1 for r in self.rows if r[1] == "keepnet")

    def sessions(self):
        out, start = [], None
        for ts, ev, cat in self.rows:
            if ev == "session" and cat == "start":
                start = ts
            elif ev == "session" and cat == "stop" and start:
                out.append((start, ts, ts - start))
                start = None
        if start:
            last = self.rows[-1][0] if self.rows else start
            out.append((start, last, last - start))
        return out

    def total_time(self):
        return sum((s[2] for s in self.sessions()), timedelta())

    def longest_session(self):
        return max((x[2] for x in self.sessions()), default=timedelta())

    def per_hour(self):
        t = self.total_time().total_seconds()
        return len(self.catches()) / (t / 3600) if t > 60 else 0.0

    def best_day(self):
        if not self.catches():
            return None, 0
        d = Counter(c[0].date() for c in self.catches())
        return d.most_common(1)[0]

    def activity_by_hour(self):
        h = defaultdict(int)
        for c in self.catches():
            h[c[0].hour] += 1
        return h

    def streak(self):
        best = cur = 0
        for c in self.catches():
            if c[2] in ("trophy", "zachet"):
                cur += 1
                best = max(best, cur)
            else:
                cur = 0
        return best

    def recent(self, n=60):
        return list(reversed(self.catches()))[:n]


# ---------------------------------------------------------------- окно
class App(tk.Tk):
    # Ботами рулит TrofPridi Manager (№52): из статистики убрана
    # вкладка «Бригада» — тут только обзор уловов и про саму программу.
    TABS = ("Обзор", "Галерея", "Журнал", "Сессии", "О программе")

    # Длительность подсветки при наведении и уходе, миллисекунды.
    # Появление чуть медленнее — оно должно читаться как движение;
    # гашение быстрее, иначе подсветка «тянется» за курсором.
    HOVER_IN_MS = 190
    HOVER_OUT_MS = 130
    # Отдача при нажатии: кнопка коротко проседает и возвращается.
    PRESS_MS = 220
    # Вертикальный центр строки часов в шапке (иконки И цифры).
    _CLK_CY = 29.5

    def __init__(self):
        super().__init__()
        self.title("TrofPridi — статистика")
        self.configure(bg=BG)
        self.minsize(820, 640)

        # Убираем системную рамку Windows. После этого окно теряет
        # кнопки закрытия и возможность двигать мышью — и то и другое
        # реализуем сами в шапке (см. _header и _drag_*).
        self.overrideredirect(True)
        # Шире по горизонтали, ниже по вертикали. Смещаем левее, чтобы
        # окно не перекрывало панель бота в правом верхнем углу.
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        # Высота 840 подобрана так, чтобы в галерею помещались ровно
        # три ряда карточек (110 отступ сверху + 3 x 228 + футер).
        w = min(1320, int(sw * 0.80))
        h = min(840, int(sh * 0.88))
        self.geometry(f"{w}x{h}+{max(0, (sw - w) // 2 - 120)}"
                      f"+{max(0, (sh - h) // 3)}")
        # Путь к данным определяем ПЕРВЫМ делом: от него зависит
        # data_dir(), а его спрашивают и настройки, и иконка. Раньше
        # csv_path задавался ниже, и load_settings() падал на попытке
        # прочитать несуществующий атрибут — окно вообще не открывалось.
        p = os.path.join(script_dir(), DATA_DIR, CSV_NAME)
        if not os.path.exists(p):
            legacy = os.path.join(script_dir(), CSV_NAME)
            if os.path.exists(legacy):
                p = legacy
        self.csv_path = p

        # без этого окно не появляется на панели задач
        self._taskbar_ok = False
        # Стоимость кадра: задаём заранее. Читать через getattr с
        # умолчанием нельзя — у окна Tk обращение к несуществующему
        # полю уходит в бесконечную рекурсию.
        self._draw_ms = 16.0
        self._anim_job = None
        self._hov_t = {}
        # Зоны подсветки: заполняются при отрисовке, используются
        # быстрым слоем поверх кадра.
        self._hot_zones = {}
        self._hot_btns = {}
        self._hover_prev = None
        self._ovl_t = 0.0          # фаза подсветки под курсором
        self._ovl_job = None
        # Анимация подсветки идёт по времени, а не по кадрам: так она
        # длится одинаково на быстрой и медленной машине.
        self._ovl_start = None     # когда начали текущий переход, мс
        self._ovl_from = 0.0       # с какого значения стартовали
        self._press = None         # (ключ кнопки, время нажатия)
        self._press_fx_key = None  # кнопка, «продавленная» прямо сейчас
        # Списки кликабельных зон: задаём заранее. getattr с умолчанием
        # на окне Tk опасен — обращение к несозданному полю уходит
        # в бесконечную рекурсию.
        self._set_hit = []
        self._ov_hit = []
        # Зоны плиток категорий в «Обзоре». Задаём заранее:
        # у объекта Tk обращение к несозданному полю уходит
        # в бесконечную рекурсию.
        self._cat_zones = {}
        self._gal_ui = []
        self._gal_hit = []
        self._jr_hit = []
        # флаг «окно уже затухает» — чтобы крестик, Escape, F8 и
        # файл-сигнал STOP не запустили закрытие по второму кругу
        self._closing = False
        # «продавливание» живёт дольше одного кадра: команда по клику
        # тут же собирает новый кадр — эффект дорисуем поверх него
        self._press_rect = None
        self._press_until = 0.0
        self._press_tab = -1
        # фоновое чтение файлов (асинхронное «Обновить»)
        self._loading = False
        self._imrefs = []          # ссылки на PhotoImage, чтобы не съели
        self._content_top = 100
        self._content_bot = 700
        # кэш фонового градиента (пересчитываем только по смене
        # размера или темы: генерировать картинку на каждый кадр
        # было бы лишней работой)
        self._bg_grad_key = None
        self._bg_grad_img = None
        self.load_settings()
        # Тема из настроек — до заставки: она тоже рисуется цветами темы.
        apply_palette(self.cfg.get("theme", "dark"))
        # Прячем основное окно: сначала показываем заставку-загрузку
        # «как у игры». _splash = None означает «заставки нет», поле
        # задаём сразу — чтение несозданного атрибута у окна Tk
        # уходит в бесконечную рекурсию.
        self._splash = None
        self._splash_p = 0.0
        self._splash_tip = ""
        self._splash_art = None
        self._splash_photo = None
        self._splash_note = ""        # золотая строка про установку
        self._splash_rgn_ok = False   # применилось ли скругление окна
        # Капсулы баров рисуем в Pillow один раз и кэшируем —
        # закругления идеально гладкие, без «лесенок».
        self._bar_imgs = {}
        # Рыба-логотип в блоке «Всего поймано» — качается, как на
        # заставке. Живёт отдельным элементом холста поверх кадра.
        self._fish_img = None
        self._fish_item = None
        self._fish_t0 = time.time()
        self._fish_last = None    # время прошлого тика (для dt)
        self._hero_fish_pos = None
        # Пузырьки по клику на рыбку: список живых (координаты, скорость,
        # время рождения, элемент холста) и кадры затухания bubble.png.
        self._bubbles = []
        self._bub_fades = []
        self.withdraw()
        self._splash_start()
        # Сначала компоненты: если чего-то не хватает, доустановка
        # идёт прямо в этой заставке (Pillow и компоненты OCR),
        # а отдельное окно подготовки больше не нужно никому.
        self._splash_step(0.1, "Проверяем компоненты…", 240)
        self._ensure_deps()
        self._reload_smooth()
        self._splash_load_art()      # Pillow точно на месте (если ставился)
        self._load_hero_fish()
        self._splash_step(0.36, "Читаем журнал улова…", 300)
        self._set_icon()
        self.after(10, self._fix_taskbar)
        # Windows иногда применяет стиль не с первого раза (окно ещё
        # не до конца создано) — повторяем, пока кнопка не появится.
        self.after(400, self._fix_taskbar)
        self.after(1500, self._fix_taskbar)
        # Прячем окно от снимков экрана: иначе распознавание улова
        # фотографирует статистику вместо игры.
        self._hidden_from_capture = False
        self.after(60, self._apply_capture_hide)
        self.after(30000, self._auto_purge_tick)   # первая уборка не сразу

        self._drag = None
        self._rs = None
        self._hover_btn = None
        self._maxed = False
        self._geo_backup = None

        self.stats = Stats()
        self._splash_step(0.52, "Считаем уловы…", 240)
        self.tab = 0
        self._tabhit = []
        # Своя прокрутка: содержимое рисуется на Canvas вручную,
        # поэтому стандартный scrollbar тут не работает.
        self._last_error = ""
        self._stamp = None
        self.scroll = {0: 0, 1: 0, 2: 0, 3: 0}
        self.scroll_max = {0: 0, 1: 0, 2: 0, 3: 0}

        # --- состояние вкладки «Журнал» ---
        self.jr_sort = "time"     # по какому столбцу сортируем
        self.jr_desc = True       # по убыванию
        self.jr_filter = "all"    # all / trophy / zachet / small
        self.jr_query = ""        # строка поиска по названию
        self.jr_search_on = False  # курсор стоит в поле поиска
        self.jr_sel = set()        # отмеченные записи (по метке времени)
        self._jr_press = None      # какой чип сейчас «вдавлен»
        # --- состояние вкладки «Галерея» ---
        self.gal_sort = "time"
        self.gal_desc = True
        self.gal_filter = "all"
        self.gal_page = 0
        self._gal_press = None
        self._gal_ui = []
        self._gal_pages = 1
        self.gal_pick = False      # режим выбора снимков для удаления
        self.gal_sel = set()       # отмеченные карточки
        self._gal_shown = []       # что сейчас на странице
        self.jr_page = 0           # текущая страница журнала
        self.ses_page = 0          # текущая страница сессий
        self._ses_pages = 1
        self._ses_sel = None       # None — обычный вид; set — выбор
        self._ses_list_all = []    # все сессии (для «Выбрать всё»)

        self.jr_wmin = None        # нижняя граница веса, кг
        self.jr_wmax = None        # верхняя граница веса
        self._jr_drag = None       # какую ручку ползунка тянем

        _pick_fonts(self)

        self._splash_step(0.68, "Строим интерфейс…", 240)
        self._tkcv = tk.Canvas(self, bg=BG, highlightthickness=0)
        self._tkcv.pack(fill="both", expand=True)
        # Рисуем через сглаживающий слой: Canvas сам не умеет
        # антиалиасинг, из-за чего все скругления выходили ступеньками.
        # Если Pillow нет — работаем прямо на Canvas, окно не падает.
        self.cv = (SmoothCanvas(self._tkcv, BG) if SMOOTH else self._tkcv)
        self.cv.bind("<Configure>", lambda e: self.draw())
        self.cv.bind("<Button-1>", self.on_press)
        self.cv.bind("<B1-Motion>", self.on_drag)
        self.cv.bind("<ButtonRelease-1>", self.on_release)
        self.cv.bind("<Double-Button-1>", self.on_double)
        self.cv.bind("<MouseWheel>", self.on_wheel)          # Windows
        self.cv.bind("<Button-4>", lambda e: self.on_wheel(e, 1))
        self.cv.bind("<Button-5>", lambda e: self.on_wheel(e, -1))
        self.cv.bind("<Motion>", self.on_move)
        self.bind("<F5>", lambda e: self.reload())
        # F8 закрывает окно — та же клавиша, что завершает бота.
        # Когда бот запущен, он сам перехватывает F8 и гасит всё через
        # файл STOP; привязка нужна для работы статистики без AHK.
        self.bind("<F8>", lambda _e: self._close())
        self.bind("<Escape>", self._on_escape)
        # Ввод в поле поиска журнала. Отдельной привязкой, чтобы не
        # мешать остальным клавишам, когда поиск неактивен.
        self.bind("<Key>", self._jr_key)

        self._splash_step(0.84, "Загружаем снимки…", 220)
        self.reload()
        self._splash_step(0.95, "Проверяем трофеи…", 200)
        self._splash_step(1.0, "Готово, понеслась!", 220)
        self._splash_done()
        self.after(REFRESH_MS, self._tick)
        self.after(900, launch_ocr)      # OCR поднимаем следом за окном
        self._watch_stop()               # раз в полсекунды проверяем сигнал
        self._heartbeat()                # отметка «жива» для бота
        self._init_game_clock()          # живые часы «Реал · Игра» в шапке
        self._fish_tick()                # покачивание рыбы в «Обзоре»

    # Советы на заставке — как при загрузке игры.
    SPLASH_TIPS = (
        "Совет: PgDn — пауза и запуск бота",
        "Совет: F6 прячет это окно и возвращает обратно",
        "Совет: F8 закрывает это окно — и бота тоже",
        "Совет: Safe Mode в настройках делает бота живее",
        "Совет: клик по снимку в галерее открывает его крупно",
        "Совет: клик по рыбе в журнале показывает её фото",
        "Совет: F5 — обновить данные вручную",
    )

    @staticmethod
    def _round_region(win, w, h, r=26):
        """Скругляет углы окна конвертом региона.

        Вызывать ТОЛЬКО после update_idletasks: до этого настоящий
        дескриптор окна может ещё не существовать, регион применялся
        «в никуда» — и по углам оставались едва заметные квадратные
        уголки фона. Прозрачностью (-alpha) у такого окна не пользуемся
        вообще: смена прозрачности пересоздаёт дескриптор, и применённый
        регион слетает вместе с ним.
        """
        try:
            if sys.platform.startswith("win"):
                rgn = ctypes.windll.gdi32.CreateRoundRectRgn(
                    0, 0, w + 1, h + 1, r, r)
                return bool(ctypes.windll.user32.SetWindowRgn(
                    win.winfo_id(), rgn, True))
        except Exception:
            pass
        return False

    def _splash_start(self):
        """Отдельное окно-заставка «как у игры» на время запуска."""
        try:
            th = SPLASH_THEME
            w, h = 560, 330
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            sp = tk.Toplevel(self)
            sp.overrideredirect(True)
            sp.configure(bg=th["bg"])
            sp.attributes("-topmost", True)
            sp.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2 - 40}")
            cv = tk.Canvas(sp, width=w, height=h, bg=th["bg"],
                           highlightthickness=0)
            cv.pack(fill="both", expand=True)
            # Теперь окно точно «материализовано» — скругление применится
            # по-настоящему. Запасно повторим и на первом кадре (см.
            # _splash_draw): зависит от того, когда Windows создала hwnd.
            sp.update_idletasks()
            self._splash_rgn_ok = self._round_region(sp, w, h)
            # заставка — не цель для случайного снимка экрана: прячем
            # её из захвата точно так же, как основное окно
            try:
                if (self.cfg.get("capture_guard", True)
                        and sys.platform.startswith("win")):
                    ctypes.windll.user32.SetWindowDisplayAffinity(
                        sp.winfo_id(), 0x11)
            except Exception:
                pass
            self._splash = (sp, cv, w, h)
            self._splash_p = 0.0
            self._splash_t0 = time.time()
            self._splash_tip = random.choice(self.SPLASH_TIPS)
            # Логотип — готовый гладкий PNG (рисуем Tk'ом, Pillow не
            # нужен). Если файла нет — векторный запасной вариант.
            self._splash_fish = None
            self._splash_bub = None
            try:
                base = os.path.join(script_dir(), "assets")
                fp = os.path.join(base, "splash_fish.png")
                if os.path.exists(fp):
                    self._splash_fish = tk.PhotoImage(file=fp)
                bp = os.path.join(base, "bubble.png")
                if os.path.exists(bp):
                    self._splash_bub = tk.PhotoImage(file=bp)
            except Exception:
                pass
            # Арт для кадра-картинки грузим в _splash_load_art() —
            # ОТДЕЛЬНО, после проверки компонентов: Pillow мог быть
            # доустановлен только что, и гладкий вариант заставки
            # подхватится прямо на лету, без перезапуска окна.
            self._splash_art = None
            self._splash_photo = None
            self._splash_load_art()
            self._splash_draw(0.0, "Запускаем…")
            self.update()
        except Exception:
            self._splash = None

    def _splash_load_art(self):
        """Картинки и шрифты для заставки-кадра (нужен Pillow).

        Вызываем заново после проверки компонентов: если Pillow только
        что доустановился, заставка сразу переходит на гладкий вариант.
        """
        self._splash_art = None
        if not SMOOTH:
            return
        try:
            from PIL import Image as _Im, ImageFont as _F

            def _load(n):
                pth = os.path.join(script_dir(), "assets", n)
                return (_Im.open(pth).convert("RGBA")
                        if os.path.exists(pth) else None)

            fonts = {}
            for nm, sz in (("big", 25 * 2), ("md", 12 * 2),
                           ("sm", 9 * 2)):
                fnt = None
                for cand in ("segoeui.ttf", "segoeuib.ttf",
                             "DejaVuSans.ttf"):
                    try:
                        fnt = _F.truetype(cand, sz)
                        break
                    except Exception:
                        continue
                fonts[nm] = fnt
            self._splash_art = {
                "fish": _load("splash_fish.png"),
                "bub": _load("bubble.png"),
                "titles": [_load(f"title_{i}.png") for i in range(4)],
                "fonts": fonts,
            }
        except Exception:
            self._splash_art = None

    def _splash_draw(self, p, status):
        """Один кадр заставки: логотип, полоса прогресса, подпись."""
        sp = self.__dict__.get("_splash")
        if not sp:
            return
        win, cv, w, h = sp
        th = SPLASH_THEME
        cv.delete("all")
        p = max(0.0, min(1.0, p))
        # Страховочное скругление: если при старте hwnd ещё не
        # существовал и регион применился «в никуда».
        if not self.__dict__.get("_splash_rgn_ok"):
            self._splash_rgn_ok = self._round_region(win, w, h)
        # Если есть Pillow — кадр рисуем целиком картинкой
        # (идеальные капсулы и градиенты), иначе — вектором ниже.
        if self.__dict__.get("_splash_art"):
            try:
                from PIL import ImageTk
                t0 = time.time() - self.__dict__.get(
                    "_splash_t0", time.time())
                img = splash_compose(w, h, p, status, self._splash_tip,
                                     t0, th, self._splash_art,
                                     self.__dict__.get("_splash_note", ""))
                ph = ImageTk.PhotoImage(img)
                cv.create_image(0, 0, anchor="nw", image=ph)
                self._splash_photo = ph
                return
            except Exception:
                pass
        # мягкая рамка-карточка, без кричащей полосы сверху
        cv.create_rectangle(1, 1, w - 2, h - 2, outline=th["edge"])
        cv.create_line(2, 2, w - 2, 2, fill=th["edge_hi"])

        cx = w / 2
        cy = 118
        t = time.time() - self.__dict__.get("_splash_t0", time.time())
        # кольца: внешнее — тёмное «углубление», внутреннее мягко
        # пульсирует к фирменному синему
        cv.create_oval(cx - 64, cy - 64, cx + 64, cy + 64,
                       outline=th["sink"], width=2)
        pulse = (math.sin(t * 2.1) + 1) / 2
        ring = self._mix(th["sink"], ACCENT, 0.25 + 0.45 * pulse)
        cv.create_oval(cx - 53, cy - 53, cx + 53, cy + 53,
                       outline=ring, width=2)
        # рыба парит — покачивается по синусу, как в воде
        bob = math.sin(t * 2.4) * 5
        if self.__dict__.get("_splash_fish"):
            cv.create_image(cx, cy + bob, image=self._splash_fish)
        else:
            icon_fish(cv, cx, cy + bob, 5.0, ACCENT)
        # пузырьки поднимаются от рыбы к поверхности
        bub = self.__dict__.get("_splash_bub")
        if bub:
            for bx, ph in ((-58, 0.0), (50, 1.6)):
                yy = cy + 42 - ((t * 30 + ph * 66) % 128)
                if cy - 86 < yy < cy + 38:
                    cv.create_image(cx + bx, yy + bob * 0.3, image=bub)
        # название и бренд
        cv.create_text(cx, 202, anchor="c", fill=ACCENT,
                       font=(FONT, 25, "bold"), text="TROFPRIDI")
        cv.create_text(cx, 230, anchor="c", fill=DIM,
                       font=(FONT, 10), text=f"УСАДЬБА РЫБАКА  •  {VERSION}")
        if self.__dict__.get("_splash_note"):
            cv.create_text(cx, 251, anchor="c", fill=GOLD,
                           font=(FONT, 9), text=self._splash_note)
        # прогресс: «вдавленная» дорожка, стеклянный бегунок сверху
        x1, x2, y = 90, w - 90, 266
        cv.create_rectangle(x1, y, x2, y + 8, fill=th["track"], outline="")
        cv.create_line(x1, y, x2, y, fill=th["track_sh"])
        cv.create_line(x1, y + 8, x2, y + 8, fill=th["track_hi"])
        fw = x1 + (x2 - x1) * p
        if p > 0.01:
            cv.create_rectangle(x1, y + 1, min(x2, fw), y + 7,
                                fill=ACCENT, outline="")
            cv.create_line(x1, y + 1, min(x2, fw), y + 1,
                           fill=th["accent_hi"])
        cv.create_text(x2, y - 13, anchor="e", fill=DIM, font=(FONT, 9),
                       text=f"{int(p * 100)}%")
        cv.create_text(cx, y + 27, anchor="c", fill=FG, font=(FONT, 11),
                       text=status)
        cv.create_text(cx, h - 20, anchor="c", fill=th["dim"],
                       font=(FONT, 9), text=self._splash_tip)
        cv.create_text(w - 12, h - 8, anchor="se", fill=th["by"],
                       font=(FONT, 7), text="by tg/flkn69")

    def _splash_step(self, to, status, ms=260):
        """Плавно доводит полосу до `to` за ms миллисекунд."""
        if not self.__dict__.get("_splash"):
            return
        try:
            t0 = time.time() * 1000
            frm = self._splash_p
            while True:
                k = (time.time() * 1000 - t0) / ms
                if k >= 1:
                    break
                e = 1 - (1 - k) ** 3          # ease-out, как в игре
                self._splash_draw(frm + (to - frm) * e, status)
                self.update()
            self._splash_p = to
            self._splash_draw(to, status)
            self.update()
        except Exception:
            pass

    def _splash_done(self):
        """Убирает заставку и показывает основное окно."""
        sp = self.__dict__.get("_splash")
        if sp:
            try:
                sp[0].destroy()
            except Exception:
                pass
        self._splash = None
        try:
            self.deiconify()
            self.lift()
            # мягкое проявление вместо резкого выскакивания
            self._fade_in()
        except Exception:
            pass

    def _ensure_deps(self):
        """Всё, что нужно программе И распознаванию, — в этой же заставке.

        Раньше проверка и доустановка шли своим окном ещё до заставки:
        пользователь видел окно загрузки за окном загрузки. Теперь окно
        одно — то, что уже на экране: статус и полоса просто продолжаются,
        даже если первый запуск затянется установкой компонентов.
        Проверяем сразу и пакеты OCR — тогда при старте распознавания
        маркер _deps_ok.txt уже записан, и второго окна не будет нигде.
        """
        if ensure is None:
            return
        try:
            pkgs = ocr_deps() if ocr_deps else {"PIL": "pillow"}
        except Exception:
            pkgs = {"PIL": "pillow"}
        try:
            ensure(pkgs, ui=_SplashDepUI(self))
        except Exception:
            pass

    def _reload_smooth(self):
        """Переподключает сглаживание после доустановки Pillow.

        smooth_canvas запоминает наличие Pillow при первом импорте.
        Если пакет только что доустановили, там осталась бы метка
        «Pillow нет», и окно работало бы плоско до перезапуска.
        Перечитываем модуль и подхватываем новые имена.
        """
        global SmoothCanvas, SMOOTH, FA_ICONS, has_icons
        try:
            import importlib
            import smooth_canvas as sc
            importlib.reload(sc)
            SmoothCanvas = sc.SmoothCanvas
            SMOOTH = sc.HAVE_PIL
            FA_ICONS = sc.FA
            has_icons = sc.has_icons
        except Exception:
            pass

    def _card_bg(self, k=0.5):
        """Цвет панели в точке по высоте (k: 0 — верх, 1 — низ).

        Панели рисуются вертикальным градиентом CARD_TOP → CARD_BOT,
        а картинки-спрайты (тумблеры, бары) кладутся поверх БЕЗ
        прозрачности: стоит залить их углы просто CARD — и вокруг
        каждого виден едва заметный КВАДРАТ не того оттенка. Берём
        цвет градиента в самой точке вставки — и шов исчезает.
        """
        k = max(0.0, min(1.0, k))
        return self._mix(CARD_TOP, CARD_BOT, k)

    # ---------------- окно без рамки ----------------
    def _place_center(self, w, h):
        sw = self.winfo_screenwidth()
        sh = self.winfo_screenheight()
        self.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 3}")

    def _apply_capture_hide(self):
        """Включает или снимает защиту согласно настройке."""
        want = bool(self.cfg.get("capture_guard", True))
        self._hidden_from_capture = self._hide_from_capture(want)

    def _hide_from_capture(self, enable=True):
        """Убирает окно из снимков экрана.

        Распознавание улова фотографирует весь экран. Если статистика
        открыта поверх игры, она попадала прямо в кадр — а однажды OCR
        даже прочитал её вкладку «Сессии» и записал несуществующую рыбу.
        Windows умеет исключать окно из захвата штатно.

        0x11 = WDA_EXCLUDEFROMCAPTURE — окно пропадает из снимка целиком
               (Windows 10 2004 и новее);
        0x01 = WDA_MONITOR — запасной путь для старых сборок: в кадре
               останется чёрный прямоугольник, но текст в OCR не попадёт.
        """
        if not sys.platform.startswith("win"):
            return False
        try:
            hwnd = self._hwnd()
            if not hwnd:
                return False
            fn = ctypes.windll.user32.SetWindowDisplayAffinity
            if not enable:
                # 0x00 = WDA_NONE — окно снова попадает в снимки,
                # чтобы можно было заскринить программу для отчёта.
                fn(ctypes.c_void_p(hwnd), ctypes.c_uint(0x00))
                return False
            for flag in (0x11, 0x01):
                if fn(ctypes.c_void_p(hwnd), ctypes.c_uint(flag)):
                    return True
        except Exception:
            pass
        return False

    def _draw_icon(self, px):
        """Рисует эмблему приложения — рыба в круге — заданного размера."""
        from PIL import Image, ImageDraw
        k = px / 64.0
        im = Image.new("RGBA", (px, px), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)

        def S(*v):
            return [x * k for x in v]

        d.ellipse(S(1, 1, 62, 62), fill="#132434",
                  outline=ACCENT, width=max(1, int(3 * k)))
        d.ellipse(S(13, 24, 45, 42), fill=ACCENT)                 # тело
        d.polygon([(44 * k, 33 * k), (57 * k, 22 * k),
                   (53 * k, 33 * k), (57 * k, 44 * k)], fill=ACCENT)
        d.polygon([(26 * k, 24 * k), (33 * k, 17 * k),
                   (35 * k, 25 * k)], fill="#59C8FF")             # плавник
        d.ellipse(S(19, 29, 25, 35), fill="#08111A")              # глаз
        return im

    def _own_taskbar_id(self):
        """Отделяет окно от Python в панели задач.

        Windows группирует кнопки по «идентификатору приложения», и по
        умолчанию у скрипта он общий с python.exe — поэтому на панели
        задач рисовался значок Python, сколько иконку окну ни ставь.
        Задаём собственный идентификатор ДО создания окна: тогда
        система считает нас отдельной программой и берёт нашу иконку.
        """
        if not sys.platform.startswith("win"):
            return
        try:
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "TrofPridi.Statistics.3.5")
        except Exception:
            pass          # не критично: окно всё равно откроется

    def _set_icon(self):
        """Своя иконка окна — вместо стандартного пера Tk.

        В Windows кнопку на панели задач рисует НЕ iconphoto, а иконка
        самого окна. Поэтому кладём настоящий .ico рядом с данными и
        подключаем через iconbitmap: только так значок меняется и на
        панели, и в Alt+Tab. iconphoto оставляем запасным вариантом
        для случаев, когда файл создать не удалось.
        """
        self._own_taskbar_id()
        try:
            # Сначала берём иконку из папки программы: она идёт в
            # комплекте и совпадает со значком бота. Своя рисованная —
            # запасной путь, если файл потеряли.
            path = os.path.join(script_dir(), "trofpridi.ico")
            if not os.path.exists(path):
                path = os.path.join(self.data_dir(), "trofpridi.ico")
            if not os.path.exists(path):
                base = self._draw_icon(256)
                # Несколько размеров в одном файле: Windows сама возьмёт
                # подходящий для панели, заголовка и Alt+Tab.
                base.save(path, format="ICO",
                          sizes=[(16, 16), (24, 24), (32, 32),
                                 (48, 48), (64, 64), (128, 128), (256, 256)])
            self.iconbitmap(default=path)
            self._icon_path = path
        except Exception:
            self._icon_path = None
        try:
            from PIL import ImageTk
            self._icon_img = ImageTk.PhotoImage(self._draw_icon(64),
                                                master=self)
            self.iconphoto(True, self._icon_img)
        except Exception:
            pass          # без иконки окно всё равно работает

    # ------------------------------------------------ настройки
    def _settings_path(self):
        """stats.ini в TrofPridi_data\\configs\\ (№51)."""
        return os.path.join(self.data_dir(), CONFIGS_NAME, STATS_INI)

    def _legacy_settings(self):
        """Старый общий settings.txt — читаем один раз для миграции."""
        out = {}
        try:
            with open(os.path.join(self.data_dir(), LEGACY_SETTINGS_NAME),
                      encoding="utf-8") as f:
                for line in f:
                    line = line.split("#")[0].strip()
                    if "=" not in line:
                        continue
                    k, v = (p.strip() for p in line.split("=", 1))
                    out[k] = v
        except OSError:
            pass
        return out

    def load_settings(self):
        """Читает stats.ini. Нет его — мигрируем со старого settings.txt
        (файл не удаляем: ещё пригодится, если Менеджер старой версии
        снова туда заглянет). Чего нет в файле — берём из умолчаний."""
        import configparser
        self.cfg = dict(DEFAULT_SETTINGS)
        path = self._settings_path()
        vals = {}
        try:
            cp = configparser.ConfigParser()
            cp.read(path, encoding="utf-8")
            if cp.has_option("ui", "theme"):
                vals["theme"] = cp.get("ui", "theme")
            if cp.has_option("ui", "capture_guard"):
                vals["capture_guard"] = cp.get("ui", "capture_guard")
            if cp.has_option("photos", "auto_purge"):
                vals["auto_purge"] = cp.get("photos", "auto_purge")
            if cp.has_option("photos", "keep_photos"):
                vals["keep_photos"] = cp.get("photos", "keep_photos")
        except Exception:
            vals = {}
        if not vals:                                # INI ещё нет
            vals = self._legacy_settings()          # старый файл?
        for k, v in vals.items():
            if k not in self.cfg:
                continue
            if isinstance(self.cfg[k], bool):
                self.cfg[k] = str(v).lower() in ("1", "да", "true", "on")
            elif isinstance(self.cfg[k], int):
                try:
                    self.cfg[k] = int(v)
                except (ValueError, TypeError):
                    pass
            else:
                self.cfg[k] = v
        if not os.path.exists(path):
            self.save_settings()                    # миграция: пишем INI
        return self.cfg

    def save_settings(self):
        try:
            path = self._settings_path()
            os.makedirs(os.path.dirname(path), exist_ok=True)
            cfg = self.cfg
            def b(v):
                return "1" if cfg.get(v) else "0"
            with open(path, "w", encoding="utf-8") as f:
                f.write("# stats.ini — настройки статистики TrofPridi\r\n")
                f.write("# Пишет программа. Можно и в Блокноте:\r\n")
                f.write("# 1 — включено, 0 — выключено.\r\n\r\n")
                f.write("[ui]\r\n")
                f.write("theme = %s\r\n" % cfg.get("theme", "dark"))
                f.write("capture_guard = %s\r\n" % b("capture_guard"))
                f.write("\r\n[photos]\r\n")
                f.write("auto_purge = %s\r\n" % b("auto_purge"))
                f.write("keep_photos = %s\r\n"
                        % cfg.get("keep_photos", KEEP_PHOTOS))
        except OSError:
            pass

    def _really_visible(self):
        """Границы окна на экране или None, если его не видно.

        Сворачиваем мы через WinAPI (iconify на окне без рамки не
        работает), а Tk об этом не знает: winfo_viewable() продолжает
        отвечать «видимо», а state() — «normal». Из-за этого отметка
        «окно на экране» стояла всегда, распознавание считало, что
        статистика перекрывает игру, и не записывало ни рыбу, ни фото.
        Спрашиваем состояние у самой Windows.
        """
        try:
            hwnd = self._hwnd()
            if hwnd and sys.platform.startswith("win"):
                u = ctypes.windll.user32
                if not u.IsWindowVisible(hwnd) or u.IsIconic(hwnd):
                    return None
                rect = ctypes.create_string_buffer(16)
                if u.GetWindowRect(hwnd, rect):
                    import struct
                    box = struct.unpack("iiii", rect.raw)
                    # Окно может быть «видимым» по стилю, но полностью
                    # закрытым игрой. Тогда в снимок экрана оно не
                    # попадает и распознаванию не мешает — сообщать о
                    # своих границах нельзя.
                    if self._occluded(box):
                        return None
                    return box
        except Exception:
            pass
        # не Windows или не получилось — считаем по данным Tk
        try:
            if not self.winfo_viewable() or self.state() == "iconic":
                return None
            return (self.winfo_rootx(), self.winfo_rooty(),
                    self.winfo_rootx() + self.winfo_width(),
                    self.winfo_rooty() + self.winfo_height())
        except Exception:
            return None

    def _occluded(self, box):
        """Закрыто ли наше окно другим окном (обычно — игрой)?

        IsWindowVisible проверяет только флаг стиля WS_VISIBLE: у окна,
        полностью перекрытого полноэкранной игрой, он всё равно стоит.
        Из-за этого статистика сообщала распознаванию свои координаты,
        даже когда её не было ни на экране, ни в снимке, — а её границы
        всегда пересекают зоны улова. Распознавание считало, что обзор
        закрыт, и не записывало ни одной рыбы.

        Спрашиваем у Windows, какое окно находится в центре нашего.
        Если это не мы и не наш потомок — мы под кем-то.
        """
        if not sys.platform.startswith("win"):
            return False

        class POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]

        try:
            u = ctypes.windll.user32
            u.WindowFromPoint.argtypes = [POINT]
            u.WindowFromPoint.restype = ctypes.c_void_p

            # Смотрим несколько точек: одна могла попасть на чужую
            # мелкую панель, и целое окно зря считалось бы закрытым.
            x1, y1, x2, y2 = box
            pts = [((x1 + x2) // 2, (y1 + y2) // 2),
                   (x1 + (x2 - x1) // 4, y1 + (y2 - y1) // 4),
                   (x1 + 3 * (x2 - x1) // 4, y1 + 3 * (y2 - y1) // 4)]

            mine = os.getpid()
            covered = 0
            for px, py in pts:
                top = u.WindowFromPoint(POINT(px, py))
                if not top:
                    continue
                pid = ctypes.c_ulong(0)
                u.GetWindowThreadProcessId(ctypes.c_void_p(top),
                                           ctypes.byref(pid))
                # Своё же окно или свой диалог — это по-прежнему мы.
                if pid.value != mine:
                    covered += 1
            # Закрыто, если чужое окно лежит поверх всех проб.
            return covered == len(pts)
        except Exception:
            return False        # не смогли выяснить — не мешаем работе

    def _hwnd(self):
        """HWND настоящего окна Windows.

        У окна с overrideredirect Tk создаёт скрытое родительское окно,
        и кнопку на панели задач получает именно оно. Но GetParent
        возвращает 0, если родителя нет, — тогда работаем со своим.
        """
        try:
            wid = self.winfo_id()
            parent = ctypes.windll.user32.GetParent(wid)
            return parent or wid
        except Exception:
            return 0

    def _fix_taskbar(self):
        """Возвращает окно на панель задач.

        overrideredirect убирает рамку, а заодно и кнопку на панели —
        Windows считает такое окно служебным. Чиним стилями окна.

        Каждый шаг в своём try: раньше всё было в одном блоке, и если
        первая же строка (wm_attributes) давала осечку, до главного —
        установки WS_EX_APPWINDOW — дело не доходило, а ошибка молча
        глоталась. Отсюда и пропадала кнопка на панели задач.
        """
        if not sys.platform.startswith("win"):
            return
        try:
            self.wm_attributes("-toolwindow", False)
        except Exception:
            pass                      # не во всех версиях Tk работает

        GWL_EXSTYLE = -20
        WS_EX_APPWINDOW = 0x00040000
        WS_EX_TOOLWINDOW = 0x00000080
        try:
            hwnd = self._hwnd()
            if not hwnd:
                return
            u = ctypes.windll.user32
            st = u.GetWindowLongW(hwnd, GWL_EXSTYLE)
            new = (st & ~WS_EX_TOOLWINDOW) | WS_EX_APPWINDOW
            if new != st:
                u.SetWindowLongW(hwnd, GWL_EXSTYLE, new)
                # Стиль применяется только после переоткрытия окна.
                if self.state() != "withdrawn":
                    self.withdraw()
                    self.after(10, self.deiconify)
            self._taskbar_ok = True
        except Exception as ex:
            self._taskbar_ok = False
            self._last_error = f"панель задач: {ex}"

    def _rs_start(self, e):
        self._rs = (e.x_root, e.y_root, self.winfo_width(), self.winfo_height())

    def _rs_move(self, e):
        if not getattr(self, "_rs", None):
            return
        x0, y0, w0, h0 = self._rs
        w = max(720, w0 + e.x_root - x0)
        h = max(600, h0 + e.y_root - y0)
        self.geometry(f"{w}x{h}")

    def _drag_start(self, e):
        self._drag = (e.x_root - self.winfo_x(), e.y_root - self.winfo_y())

    def _drag_move(self, e):
        if self._drag:
            self.geometry(f"+{e.x_root - self._drag[0]}+{e.y_root - self._drag[1]}")

    def _drag_end(self, _e):
        self._drag = None

    def toggle_max(self):
        if self._maxed:
            if self._geo_backup:
                self.geometry(self._geo_backup)
            self._maxed = False
        else:
            self._geo_backup = self.geometry()
            self.geometry(f"{self.winfo_screenwidth()}x"
                          f"{self.winfo_screenheight() - 48}+0+0")
            self._maxed = True
        self.draw()

    def minimize(self):
        """Свернуть окно без системной рамки.

        iconify() на overrideredirect-окне в Windows не работает: окно
        просто исчезает и не возвращается с панели задач. Поэтому
        сворачиваем настоящее окно через WinAPI, по его HWND.
        """
        try:
            hwnd = self._hwnd()
            if hwnd:
                ctypes.windll.user32.ShowWindow(hwnd, 6)   # SW_MINIMIZE
                return
        except Exception:
            pass
        # запасной путь для не-Windows
        self.overrideredirect(False)
        self.iconify()
        self.bind("<Map>", self._on_restore)

    def _present(self):
        """Развернуть окно и показать поверх остальных.

        Обратное к minimize(). Через WinAPI по той же причине: окно без
        системной рамки свёрнуто вызовом ShowWindow, и Tk об этом не
        знает — deiconify() на него не действует.
        """
        try:
            hwnd = self._hwnd()
            if hwnd and sys.platform.startswith("win"):
                u = ctypes.windll.user32
                if u.IsIconic(hwnd):
                    u.ShowWindow(hwnd, 9)          # SW_RESTORE
                else:
                    u.ShowWindow(hwnd, 5)          # SW_SHOW
                u.SetForegroundWindow(hwnd)
                return
        except Exception:
            pass
        try:
            self.deiconify()
            self.lift()
            self.focus_force()
        except Exception:
            pass

    def _on_restore(self, _e=None):
        self.unbind("<Map>")
        self.overrideredirect(True)
        self.after(10, self._fix_taskbar)

    def destroy(self):
        for name in ("alive.txt", "ui_visible"):
            try:
                os.remove(os.path.join(self.data_dir(), name))
            except Exception:
                pass
        super().destroy()

    # ---- плавные появление и закрытие: маленькие затухания ----
    # Вместо резкого «щёлкнул — пропало» окно мягко тает и мягко
    # проступает. Через прозрачность окна WinAPI: на нашей
    # безрамочной форме работает чисто.

    def _fade_in(self, steps=11):
        """Мягкое проявление окна после заставки."""
        if self._closing:
            return
        try:
            self.attributes("-alpha", 0.0)
        except Exception:
            return
        ms = 14

        def _step(i):
            if self._closing:
                return
            try:
                self.attributes("-alpha", i / steps)
            except Exception:
                return
            if i < steps:
                self.after(ms, lambda: _step(i + 1))

        _step(1)

    def _close(self):
        """Плавное закрытие окна: быстрое затухание, потом destroy.

        Вызывают крестик, Escape, F8 и сигнал STOP от бота. Страж
        _closing нужен, чтобы повторный сигнал (скажем, F8 почти
        одновременно с уходом бота) не повторил затухание.
        """
        if self._closing:
            return
        self._closing = True
        steps, ms = 10, 14

        def _step(i):
            if i <= 0:
                self.destroy()
                return
            try:
                self.attributes("-alpha", i / steps)
            except Exception:
                # окна уже нет — просто выходим
                self.destroy()
                return
            self.after(ms, lambda: _step(i - 1))

        # стартуем от текущей прозрачности: если закрыли прямо посреди
        # проявления, яркость не должна прыгать обратно к 100%
        try:
            cur = float(self.attributes("-alpha"))
        except Exception:
            cur = 1.0
        _step(max(1, min(steps - 1, round(cur * steps))))

    def _stop_requested(self):
        """Бот при выходе создаёт файл STOP — значит пора закрываться."""
        return os.path.exists(
            os.path.join(script_dir(), DATA_DIR, STOP_NAME))

    def _tick(self):
        """Периодическое обновление.

        Перезапуск таймера — в finally: если reload() или draw() бросят
        исключение, цепочка не должна оборваться. Раньше одна битая
        строка в CSV навсегда «замораживала» окно: оно выглядело живым,
        но данные больше не обновлялись.
        """
        try:
            if self._stop_requested():
                self._close()
                return
            self.reload()
        except Exception as e:
            self._last_error = str(e)
        finally:
            try:
                self.after(REFRESH_MS, self._tick)
            except Exception:
                pass

    def _heartbeat(self):
        """Пишет отметку «я жива» для индикатора в меню бота.

        Первая строка — состояние (ok/err), вторая — время. Файл
        обновляется раз в секунду; если он «протух», бот покажет,
        что статистика не работает.
        """
        try:
            state = "err" if getattr(self, "_last_error", "") else "ok"
            ocr = "1" if self._ocr_alive() else "0"
            with open(os.path.join(self.data_dir(), "alive.txt"), "w",
                      encoding="utf-8") as f:
                f.write(f"{state}\n{int(time.time())}\n{ocr}\n")
        except Exception:
            pass

        # Сообщаем распознаванию, видно ли нас на экране.
        # Иначе OCR читает НАШЕ окно: однажды он принял вкладку
        # «Сессии» за рыбу и записал улов «Се ии» весом 12.400 кг,
        # взяв вес из панели рекордов.
        try:
            flag = os.path.join(self.data_dir(), "ui_visible")
            visible = self._really_visible()
            if visible:
                with open(flag, "w", encoding="utf-8") as f:
                    # Пишем и границы окна: распознаванию важно знать не
                    # только «окно открыто», но и где именно оно висит.
                    f.write(f"{int(time.time())}\n")
                    f.write("%d %d %d %d\n" % visible)
                    # Третья строка — сработала ли защита от снимков.
                    # Если да, нас нет в кадре, и распознавание может
                    # спокойно работать даже когда окно висит поверх
                    # зон улова. Без этой строки OCR считал, что мы
                    # закрываем ему обзор, и не писал ни рыбу, ни фото.
                    f.write("1\n" if self._hidden_from_capture else "0\n")
            elif os.path.exists(flag):
                os.remove(flag)
        except Exception:
            pass
        try:
            self.after(1000, self._heartbeat)
        except Exception:
            pass

    def _ocr_alive(self):
        """OCR считается живым, если его лог обновлялся недавно."""
        try:
            p = os.path.join(self.data_dir(), "ocr_debug.log")
            if not os.path.exists(p):
                return False
            return (time.time() - os.path.getmtime(p)) < 900
        except Exception:
            return False

    def _watch_stop(self):
        try:
            if self._stop_requested():
                self._close()
                return
        except Exception:
            pass
        # Бот просит показаться: F6 при уже открытом окне не запускает
        # второй экземпляр, а создаёт файл-сигнал. Обычно бот
        # разворачивает окно сам через WinAPI, но если не нашёл его по
        # заголовку — просит нас. Файл сразу убираем, иначе окно
        # выскакивало бы снова и снова.
        try:
            flag = os.path.join(self.data_dir(), "SHOW")
            if os.path.exists(flag):
                os.remove(flag)
                self._present()
        except Exception:
            pass
        try:
            self.after(500, self._watch_stop)
        except Exception:
            pass

    def data_dir(self):
        """Папка с данными — считаем от stats.csv, а не угадываем."""
        return os.path.dirname(self.csv_path) or "."

    def _refresh_now(self):
        """Отложенное перечитывание за кнопкой «Обновить» (см. клик).

        Грузим файлы в ФОНОВОМ потоке: парсинг растущих CSV занимает
        заметные доли секунды, и синхронное чтение на месте клика
        выглядело как «кнопка залагала сильно». Пока крутится поток,
        окно свободно, а «продавленная» кнопка спокойно видна.
        """
        self._stamp = None          # заставляем перечитать файлы
        try:
            self.reload(async_load=True)
        except Exception:
            try:
                self.reload()
            except Exception:
                pass

    def _refresh_icon(self, cv, cx, cy, s, col):
        """Стрелка кнопки «Обновить» — всегда статичная."""
        icon_refresh(cv, cx, cy, s, col)

    def reload(self, async_load=False):
        """Перечитывает файлы и перерисовывает окно.

        Обновление отслеживаем по времени изменения файлов: если ничего
        не поменялось, лишний раз не перерисовываем — иначе прокрутка
        дёргается каждые три секунды.

        async_load=True: чтение и разбор CSV уходят в поток, а новые
        данные меняются одной атомарной подменой в главном потоке —
        интерфейс не стоит даже на больших журналах.
        """
        fish_csv = os.path.join(self.data_dir(), "fish_log.csv")
        stamp = []
        for p in (self.csv_path, fish_csv):
            try:
                stamp.append(os.path.getmtime(p))
                stamp.append(os.path.getsize(p))
            except OSError:
                stamp.append(0)
        stamp = tuple(stamp)

        changed = stamp != getattr(self, "_stamp", None)
        if not changed:
            self.draw()
            self._last_error = ""
            return

        if async_load:
            if getattr(self, "_loading", False):
                return            # поток ещё читает: доберёт сам
            self._loading = True
            self._stamp = stamp
            import threading
            threading.Thread(target=self._reload_worker,
                             args=(self.csv_path, fish_csv),
                             daemon=True).start()
            return

        self._stamp = stamp
        self.stats.load(self.csv_path)
        self.stats.load_fish(fish_csv)
        # Убираем отметки на записях, которых больше нет: иначе
        # счётчик «Удалить (N)» показывал бы несуществующие строки.
        if self.jr_sel:
            alive = {f[0] for f in self.stats.fish}
            self.jr_sel &= alive
        self.draw()
        # Успешно дошли до конца — прошлая ошибка больше не актуальна.
        self._last_error = ""

    def _reload_worker(self, csv_path, fish_csv):
        """Фоновая часть reload(): только чтение файлов и разбор.

        Tk трогать из потока нельзя — сюда не смотрит ни один
        виджет. Новая порция данных просто собирается в отдельный
        объект и подменяется в главном потоке одним присваиванием.
        """
        try:
            fresh = Stats()
            fresh.load(csv_path)
            fresh.load_fish(fish_csv)
        except Exception:
            fresh = None

        def apply():
            self._loading = False
            if fresh is not None:
                self.stats = fresh
                if self.jr_sel:
                    alive = {f[0] for f in self.stats.fish}
                    self.jr_sel &= alive
            try:
                self.draw()
            except Exception:
                pass
            self._last_error = ""
        try:
            self.after(0, apply)
        except Exception:
            self._loading = False

    # ------------------------------------------------ отрисовка
    def _text_w(self, text, font_spec):
        """Ширина строки в пикселях.

        Прикидка «число символов × коэффициент» на кириллице врёт:
        буквы шире латинских, и подписи наезжали друг на друга.
        Сглаженный слой умеет мерить настоящим шрифтом.
        """
        m = getattr(self.cv, "measure", None)
        if m:
            try:
                return m(text, font_spec)
            except Exception:
                pass
        size = font_spec[1] if len(font_spec) > 1 else 10
        return len(str(text)) * size * 0.62

    # ------------------------------------------------ анимация наведения
    def _hov(self, key, active, speed=None):
        """Плавное значение 0..1 для элемента под курсором.

        Резкое переключение цвета ощущается как мигание. Здесь значение
        подтягивается к цели по чуть-чуть, а пока идёт движение —
        запрашивается следующий кадр. Возвращает текущую долю.
        """
        st = self._hov_t
        if speed is None:
            # Чем дороже кадр, тем крупнее шаг: переход занимает
            # примерно одно и то же время на любой машине.
            speed = max(0.18, min(0.6, self._draw_ms / 90.0))
        cur = st.get(key, 0.0)
        goal = 1.0 if active else 0.0
        if abs(cur - goal) < 0.02:
            st[key] = goal
            return goal
        cur += (goal - cur) * speed if abs(goal - cur) > 0.04 else (
            0.04 if goal > cur else -0.04)
        st[key] = max(0.0, min(1.0, cur))
        self._anim_soon()
        return st[key]

    def _anim_soon(self):
        """Просит следующий кадр анимации.

        Пауза считается от реальной стоимости последней перерисовки.
        Просить 60 кадров в секунду, когда кадр рисуется 70 мс, —
        значит поставить очередь заданий, которую окно не разгребает:
        именно от этого интерфейс начинал заметно отставать.
        """
        if self._anim_job:
            return
        delay = max(16, min(120, int(self._draw_ms * 1.2)))
        self._anim_job = self.after(delay, self._anim_tick)

    def _anim_tick(self):
        self._anim_job = None
        try:
            self.draw()
        except Exception:
            pass

    @staticmethod
    def _mix(c1, c2, t):
        """Промежуточный цвет между двумя. t: 0 — первый, 1 — второй."""
        t = max(0.0, min(1.0, t))
        a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
        b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
        return "#%02X%02X%02X" % tuple(
            int(a[i] + (b[i] - a[i]) * t) for i in range(3))

    def _paint_hover(self):
        """Рисует подсветку под курсором поверх готового кадра.

        Ключевой момент: полный кадр НЕ пересчитывается. Пересобрать
        картинку в Pillow стоит около 70 мс, и на каждое движение мыши
        это выливалось в секунды задержки. Здесь используются обычные
        фигуры Tk — они рисуются на C и появляются мгновенно.
        """
        cv = self.cv
        if not hasattr(cv, "overlay_clear"):
            return
        cv.overlay_clear()
        key = self._hover_btn
        t = self._ovl_t                    # 0..1 — насколько «разгорелось»
        if not key or t <= 0.01:
            return

        # Подсказка о последнем улове. Тоже в быстром слое: внутри
        # кадра она заставляла перерисовывать всё окно, и всплывала
        # с задержкой в несколько секунд.
        if key == "m_last":
            if t > 0.45:
                self._draw_last_tip()
            return

        # Плитки категорий раскрывают список видов.
        if isinstance(key, str) and key.startswith("m_cat_"):
            if t > 0.45:
                self._draw_cat_tip(key[6:])
            return

        z = self._hot_zones.get(key)
        if z:
            x1, y1, x2, y2 = z
            if str(key).startswith("jr_n_"):
                # Название рыбы — это ссылка на снимок. Рамка вокруг
                # текста смотрелась бы как выделение, поэтому светлим
                # подпись и подчёркиваем её.
                cv.overlay_patch(x1, y1, x2, y2, r=4,
                                 tint=LINKTINT, alpha=0.5 * t)
                cv.overlay_line(x1 + 4, y2 - 1, x2 - 4, y2 - 1,
                                self._mix(HOTFILL, "#FFFFFF", t))
            else:
                # Снимок: рамка проявляется и чуть «раскрывается».
                # Рисуем её заплаткой из кадра (PIL, сглаживание) —
                # нативные дуги Tk давали на скруглениях лесенку.
                g = 1.0 + 2.0 * t
                cv.overlay_patch(x1 - g, y1 - g, x2 + g, y2 + g, r=11,
                                 edge=self._mix(OVLEDGE2, ACCENT, t),
                                 edge_w=1.0 + 0.6 * t)
            return

        # Подсветка кнопки. Не заливаем сплошным цветом — подкрашиваем
        # кусок готового кадра, поэтому иконка и подпись остаются
        # на месте. Прозрачность и рамка нарастают за несколько кадров:
        # мгновенная смена цвета читалась как рывок, а не как анимация.
        b = self._hot_btns.get(key)
        if b:
            x1, y1, x2, y2, col, edge = b[0], b[1], b[2], b[3], b[4], b[5]
            # Рамка теперь ПОВТОРЯЕТ форму кнопки и стоит ровно по её
            # границам. Раньше зона росла на 2 px наружу — читалось
            # как «обводка увеличивается снизу», а радиус 10 у вкладок
            # с их 16 давал углы чужой формы.
            r = b[6] if len(b) > 6 else 10
            # Рамку рисует сам patch — средствами PIL, со сглаживанием.
            # Прежде она шла через create_arc холста Tk, а тот сглаживать
            # не умеет: на скруглениях была видна явная лесенка.
            cv.overlay_patch(x1, y1, x2, y2, r=r,
                             tint=col, alpha=0.34 * t,
                             edge=self._mix(OVLEDGE, edge, t),
                             edge_w=1.0 + 0.6 * t)

    def panel(self, x1, y1, x2, y2, r=None, glow=None, glow_k=1.0):
        """Панель-«материал»: неоморфный объём тенями, не цветом.

        Классический неоморфизм: панель почти не отличается от фона
        оттенком, а читается парой мягких следов — тёмного вниз-вправо
        и светлого вверх-влево. Единая замена round_rect(fill=CARD) по
        всему окну, так что поверхности одинаковы. Если сглаживающий
        слой недоступен, честно рисуем плоскую панель.
        Трофеям по-прежнему положен золотой ореол (glow).
        """
        c = self.cv
        r = R_CARD if r is None else r
        if SMOOTH and isinstance(c, SmoothCanvas):
            if glow:
                c.card(x1, y1, x2, y2, r, top=CARD_TOP, bottom=CARD_BOT,
                       shadow=False, glow=glow, glow_k=glow_k)
            else:
                c.neu(x1, y1, x2, y2, r, top=CARD_TOP, bottom=CARD_BOT,
                      dark=NEU_DARK, light=NEU_LIGHT,
                      dk=NEU_DK, hi=NEU_HI, dist=3, blur=5)
        else:
            round_rect(c, x1, y1, x2, y2, r, fill=CARD, outline="")

    def _face(self, x1, y1, x2, y2, r=10, on=False, style="neutral"):
        """Лицо кнопки: приподнятая площадка, а «включённая» — вдавлена.

        style: neutral — тот же материал, что и окно; primary —
        акцентная заливка (главные действия). on=True — кнопка
        «залипла» (активный чип, выбранное значение): рисуем её
        углублённой, как нажатую клавишу.
        """
        c = self.cv
        if SMOOTH and isinstance(c, SmoothCanvas):
            if on:
                c.sink(x1 + 1, y1 + 1, x2 - 1, y2 - 1, max(2, r - 1),
                       fill=SINK, dark=NEU_DARK, light=NEU_LIGHT,
                       dk=SINK_DK, hi=SINK_HI, dist=2, blur=2)
            elif style == "primary":
                c.neu(x1, y1, x2, y2, r, top=ACTHOT, bottom=ACTFACE,
                      dark=NEU_DARK, light=NEU_LIGHT,
                      dk=NEU_DK, hi=NEU_HI, dist=2, blur=3)
            else:
                c.neu(x1, y1, x2, y2, r, top=CHIP, bottom=CARD_BOT,
                      dark=NEU_DARK, light=NEU_LIGHT,
                      dk=max(60, NEU_DK - 35), hi=NEU_HI, dist=2, blur=3)
        else:
            round_rect(c, x1, y1, x2, y2, r,
                       fill=(SINK if on else
                             ACTFACE if style == "primary" else CHIP),
                       outline="")

    def _well(self, x1, y1, x2, y2, r=8):
        """Углубление в панели: поле ввода, дорожка, место под фото."""
        c = self.cv
        if SMOOTH and isinstance(c, SmoothCanvas):
            c.sink(x1, y1, x2, y2, r, fill=SINK, dark=NEU_DARK,
                   light=NEU_LIGHT, dk=SINK_DK, hi=SINK_HI,
                   dist=2, blur=2)
        else:
            round_rect(c, x1, y1, x2, y2, r, fill=SINK, outline="")

    # ---- симметричная геометрия капсул «иконка + подпись» ----
    # Поля слева и справа равные, иконке — свой фиксированный слот,
    # подпись ЦЕНТРИРУЕТСЯ в оставшемся месте. Раньше текст рисовался
    # от левого края, измеренная ширина слегка расходилась с
    # отрисованной — и справа от надписи места визуально оставалось
    # меньше, чем слева. Центровка гасит эту погрешность пополам.
    CHIP_PAD = 12.0            # поля по бокам капсулы
    CHIP_ISLOT = 16.0          # слот под иконку

    def _chip_w(self, label, font, tail=0.0, icon=True):
        """Ширина капсулы с симметричными полями."""
        return (self.CHIP_PAD * 2 + (self.CHIP_ISLOT if icon else 0.0)
                + tail + self._text_w(label, font))

    def _chip_content(self, x, w, yc, label, font, col,
                      icon_fn=None, icol=None, iscale=0.52,
                      tail_fn=None, tail=0.0):
        """Иконка в левом слоте, подпись — по центру остатка.

        tail_fn — иконка в ПРАВОМ слоте шириной tail (стрелка
        сортировки): тогда подпись центрируется между слотами.
        """
        c = self.cv
        x = float(x)
        if icon_fn is not None:
            icon_fn(c, x + self.CHIP_PAD + self.CHIP_ISLOT / 2, yc,
                    iscale, icol)
        tx1 = (x + self.CHIP_PAD + self.CHIP_ISLOT if icon_fn is not None
               else x + self.CHIP_PAD)
        tx2 = x + w - self.CHIP_PAD - tail
        tw = self._text_w(label, font)
        c.create_text((tx1 + tx2 - tw) / 2, yc, anchor="w", fill=col,
                      font=font, text=label)
        if tail_fn is not None:
            tail_fn(c, x + w - self.CHIP_PAD - tail / 2, yc)

    def _toggle(self, cx, cy, frac=0.0, hot=False):
        """Тумблер настройки — неоморфный, из фигур сглаженного слоя.

        frac 0..1 — анимированная позиция бегунка (0 — слева/ВЫКЛ,
        1 — справа/ВКЛ): при щелчке он плавно ЕДЕТ через дорожку.
        Дорожка меняет вид на середине пути: выключенная вдавлена,
        включённая — акцентная. Раньше тумблер был спрайтом-картинкой:
        мелкий, «пиксельный», с квадратом по углам. Теперь форма живёт
        в общем сглаженном кадре — никаких углов и ступенек.
        """
        c = self.cv
        w, h = 46.0, 26.0
        on = frac >= 0.5
        x1, y1 = cx - w / 2, cy - h / 2
        x2, y2 = cx + w / 2, cy + h / 2
        if SMOOTH and isinstance(c, SmoothCanvas):
            if on:
                # Включённая дорожка — ЧИСТЫЙ акцент. Раньше тут был
                # неоморфный объём из затемнённых ACTHOT/ACTFACE да ещё
                # и с тенями по краям — цвет выходил мутным и бледным.
                top = self._mix(ACCENT, "#FFFFFF", 0.10)
                bottom = self._mix(ACCENT, "#000000", 0.15)
                c.neu(x1, y1, x2, y2, 13, top=top, bottom=bottom,
                      dark=NEU_DARK, light=NEU_LIGHT,
                      dk=38, hi=26, dist=2, blur=3)
                round_outline(c, x1, y1, x2, y2, 13,
                              self._mix(ACCENT, "#FFFFFF", 0.22))
            else:
                c.sink(x1, y1, x2, y2, 13, fill=SINK, dark=NEU_DARK,
                       light=NEU_LIGHT, dk=SINK_DK, hi=SINK_HI,
                       dist=2, blur=2)
            # бегунок — приподнятая белая «таблетка» на анимированной
            # позиции
            kr = 9.0
            kx = x1 + 13.5 + (w - 27.0) * frac
            c.neu(kx - kr, cy - kr, kx + kr, cy + kr, kr,
                  top="#FFFFFF", bottom="#D8E1EA",
                  dark=NEU_DARK, light=NEU_LIGHT,
                  dk=85 if on else 70, hi=60, dist=1, blur=2)
            if hot:
                round_outline(c, x1, y1, x2, y2, 13, HOTEDGE)
        else:
            icon_toggle(c, cx, cy, 1.0, on, 1.0 if hot else 0.0)

    def _toggle_frac(self, key, on):
        """Текущая позиция бегунка с учётом незаконченной анимации."""
        target = 1.0 if on else 0.0
        st = self.__dict__.get("_tg_anim", {}).get(key)
        if not st:
            return target
        t0, frm, to = st
        p = (time.time() - t0) / 0.20
        if p >= 1.0:
            self._tg_anim.pop(key, None)
            return target
        p = 1 - (1 - p) ** 3                 # ease-out cubic
        return frm + (to - frm) * p

    def _tg_sprite(self, frac):
        """Плавный спрайт тумблера в текущей теме (№60).

        Рисуем в Pillow на удвоенном холсте и сжимаем — края круглые,
        без «лесенки», с обводкой. Одна позиция бегунка = один спрайт
        в кэше: повторные кадры ничего не рисуют, ядро окна не
        трогаем — поэтому и не лагает. frac 0..1 — позиция бегунка,
        цвет дорожки плавно плывёт к акцентному."""
        from PIL import Image, ImageDraw, ImageTk
        try:
            RES = Image.Resampling.BILINEAR
        except AttributeError:
            RES = Image.BILINEAR
        key = (round(frac * 8) / 8, ACCENT, SINK)
        cache = self.__dict__.setdefault("_tg_sprites", {})
        spr = cache.get(key)
        if spr is not None:
            return spr
        SS2 = 2
        w, h = 52, 32
        im = Image.new("RGBA", (w * SS2, h * SS2), (0, 0, 0, 0))
        dd = ImageDraw.Draw(im)
        col = self._mix(SINK, ACCENT, frac)
        edge = self._mix(col, "#FFFFFF", 0.18)
        dd.rounded_rectangle((6, 6, 98, 58), radius=26, fill=col,
                             outline=edge, width=2)
        kx = 6 + 27 + (92 - 54) * frac
        kedge = self._mix("#F4F8FC", "#20303F", 0.16)
        dd.ellipse((kx - 18, 32 - 18, kx + 18, 32 + 18), fill="#F4F8FC",
                   outline=kedge, width=2)
        im = im.resize((w, h), RES)
        spr = ImageTk.PhotoImage(im)
        if len(cache) > 24:
            cache.clear()
        cache[key] = spr            # кэш же и хранит ссылки на картинки
        return spr

    def _toggle_overlay(self, key):
        """Рисует ОДИН тумблер поверх готового кадра — без перемонтажа
        всего окна (№59-60).

        Раньше каждый тик анимации пересобирал ПОЛНЫЙ кадр через
        Pillow (30-50 мс на кадр, 6-7 кадров подряд) — вот тумблеры
        и тормозили; наивный оверлей из Tk-фигур был дёрганый и с
        «лесенкой». Теперь кадр лежит нетронутым, а поверх едет
        гладкий PIL-спрайт тумблера. Когда езда закончилась — один
        точный финальный кадр (все неоморфные тени на месте)."""
        c = self.cv
        if not (SMOOTH and isinstance(c, SmoothCanvas)):
            return False
        coord = self.__dict__.get("_tg_pos", {}).get(key)
        if not coord:
            return False
        tx, cy = coord
        on = ((self.cfg.get("theme") == "light") if key == "theme"
              else bool(self.cfg.get(key)))
        frac = self._toggle_frac(key, on)
        try:
            spr = self._tg_sprite(frac)
        except Exception:
            return False
        c.overlay_clear()
        c.cv.create_image(tx, cy, image=spr, tags="ovl")
        return True

    def _start_toggle_anim(self, key, from_on, to_on):
        """Запускает «приезд» бегунка в новое положение (~0.2 c)."""
        anims = self.__dict__.setdefault("_tg_anim", {})
        anims[key] = (time.time(), 1.0 if from_on else 0.0,
                      1.0 if to_on else 0.0)
        self._toggle_tick()

    def _toggle_tick(self):
        """Кадры поездки бегунка. №59: если доступен оверлей — рисуем
        только тумблер поверх кадра (лёгкие Tk-дуги), полный draw()
        нужен один-единственный раз, в самом конце. Без сглаживания —
        как раньше, полная перерисовка раз в 33 мс."""
        if not self.__dict__.get("_tg_anim"):
            return
        if self._toggle_overlay(list(self._tg_anim.keys())[0]):
            if self.__dict__.get("_tg_anim"):       # ещё едет
                self.after(25, self._toggle_tick)
            else:                                   # доехал
                self.draw()                         # точный финал
            return
        self.draw()                                 # откат без оверлея
        if self.__dict__.get("_tg_anim"):
            self.after(33, self._toggle_tick)

    def _press_offset(self, key):
        """На сколько пикселей просела кнопка сразу после нажатия.

        Короткая отдача — то, чем «дорогой» интерфейс отличается от
        обычного: нажатие должно ощущаться. Кнопка уходит вниз на
        пиксель и возвращается по кривой ease-out, за PRESS_MS.
        """
        # Поле читаем через __dict__, а не напрямую: у объекта Tk
        # обращение к несозданному атрибуту уходит в бесконечную
        # рекурсию, и окно падало бы вместо отрисовки.
        st = self.__dict__.get("_press")
        if not st or st[0] != key:
            return 0
        p = (time.time() * 1000.0 - st[1]) / float(self.PRESS_MS)
        if p >= 1.0:
            self._press = None
            return 0
        # Полволны синуса: быстро вниз, плавно обратно.
        return int(round(math.sin(math.pi * p) * 1.6))

    def _press_start(self, key):
        """Запускает отдачу и крутит её до конца."""
        self._press = (key, time.time() * 1000.0)

        def tick():
            if not self._press:
                return
            self.draw()
            if self._press:
                self.after(16, tick)

        tick()

    def _press_colors(self):
        """Цвета «продавливания» под текущую тему.

        В светлой теме чёрная кромка #020508 по белой кнопке давала
        грязный ореол вместо аккуратного нажатия — отсюда «на
        некоторых кнопках ореолы». Возвращает (tint, alpha, edge).
        """
        if THEME == "light":
            return "#0E1C2E", 0.30, "#22344A"
        return "#05080C", 0.45, "#12202E"

    def _press_fx(self, key):
        """Мгновенная отдача нажатия на ЛЮБОЙ кнопке — без пересборки.

        Затемняем кусок готового кадра в форме самой кнопки: фон
        проваливается, а буквы наоборот остаются яркими — читается как
        неоморфное «продавливание». Раньше нажатие визуально никак не
        отзывалось, и было непонятно, сработал ли клик. Через треть
        секунды подсветка возвращается к ховеру.
        """
        b = self._hot_btns.get(key)
        if not b or not hasattr(self.cv, "overlay_patch"):
            return
        x1, y1, x2, y2 = b[0], b[1], b[2], b[3]
        r = b[6] if len(b) > 6 else 10
        try:
            t_col, t_a, t_e = self._press_colors()
            self.cv.overlay_patch(x1, y1, x2, y2, r=r,
                                  tint=t_col, alpha=t_a,
                                  edge=t_e, edge_w=1.2)
        except Exception:
            return
        self._press_fx_key = key
        # запоминаем прямоугольник: команда по клику (та же
        # «Обновить») мгновенно собирает новый кадр и стирала бы
        # эффект — draw() дорисует «продавливание» поверх свежего
        self._press_rect = (x1, y1, x2, y2, r)
        self._press_tab = self.tab
        self._press_until = time.perf_counter() + 0.28
        try:
            self.after(320, self._press_fx_end)
        except Exception:
            pass

    def _press_fx_end(self):
        self._press_fx_key = None
        self._press_rect = None
        self._press_until = 0.0
        try:
            self._paint_hover()       # она же чистит быстрый слой
        except Exception:
            pass

    def _press_fx_any(self, e):
        """Отдача нажатия для зон вне быстрых кнопок.

        Ищет клик по спискам хит-зон текущей вкладки и затемняет
        кусок кадра тем же «неоморфным провалом», что и _press_fx:
        единый язык отклика по всему окну. Через треть секунды
        подсветка собирается обратно ховером.
        """
        lists = []
        if self.tab == 0:
            lists.append(getattr(self, "_ov_hit", []))
        elif self.tab == 1:
            lists.append(getattr(self, "_gal_ui", []))
        elif self.tab == 2:
            lists.append(getattr(self, "_jr_hit", []))
        elif self.tab == 4:
            lists.append(getattr(self, "_set_hit", []))
        hit = None
        for lst in lists:
            for h in lst:
                if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                    hit = h
                    break
            if hit is not None:
                break
        if hit is None or not hasattr(self.cv, "overlay_patch"):
            return
        r = min(9.0, max(2.0, (hit[3] - hit[1]) / 2.0))
        try:
            t_col, t_a, t_e = self._press_colors()
            self.cv.overlay_patch(hit[0], hit[1], hit[2], hit[3], r=r,
                                  tint=t_col, alpha=t_a,
                                  edge=t_e, edge_w=1.2)
        except Exception:
            return
        self._press_rect = (hit[0], hit[1], hit[2], hit[3], r)
        self._press_tab = self.tab
        self._press_until = time.perf_counter() + 0.28
        try:
            self.after(320, self._press_fx_end)
        except Exception:
            pass

    def _set_cursor(self, name):
        """Меняет курсор, только если он реально другой.

        config() на каждое движение мыши — лишняя работа для Tk,
        а движений приходит десятки в секунду.
        """
        if getattr(self, "_cursor", None) != name:
            self._cursor = name
            try:
                self.cv.config(cursor=name)
            except Exception:
                pass

    def _hover_changed(self):
        """Реакция на смену элемента под курсором.

        Если для нового и старого элемента есть быстрая зона подсветки,
        обходимся слоем поверх кадра — это мгновенно. Полную
        перерисовку запускаем только когда меняется что-то ещё
        (вкладки, кнопки окна и прочее, что рисуется в самом кадре).
        """
        cur = self._hover_btn
        prev = self._hover_prev
        self._hover_prev = cur
        fast = self._hot_zones.keys() | self._hot_btns.keys()
        # Быстрый слой существует только у гладкого холста. Без него
        # честно перерисовываем кадр — медленнее, но подсветка будет.
        overlay = hasattr(self.cv, "overlay_clear")
        if overlay and (cur is None or cur in fast) \
                and (prev is None or prev in fast):
            # Ушли с элемента — гасим сразу, чтобы подсветка не тянулась
            # за курсором. Пришли на новый — разгораемся с нуля.
            self._ovl_t = 0.0 if cur else self._ovl_t
            self._ovl_run()
            return
        self._draw_soon()

    def _ovl_run(self):
        """Плавно доводит подсветку до нужной яркости.

        Крутится только лёгкий слой поверх готового кадра: один шаг
        стоит доли миллисекунды, поэтому можно позволить себе честные
        60 кадров в секунду — в отличие от полной перерисовки.
        """
        if self._ovl_job:
            try:
                self.after_cancel(self._ovl_job)
            except Exception:
                pass
            self._ovl_job = None

        goal = 1.0 if self._hover_btn else 0.0
        # Считаем по ВРЕМЕНИ, а не по числу кадров.
        #
        # Раньше значение подтягивалось к цели долей 0.22 за кадр. Это
        # экспонента: резкий рывок в начале, вялый хвост, и длительность
        # зависела от того, успевает ли машина рисовать. Отсюда ощущение
        # дёрганости. Теперь фиксируем длительность и ведём по кривой
        # ease-out-quint — она даёт мгновенный отклик и мягкое
        # торможение, как в дорогих интерфейсах.
        dur = self.HOVER_IN_MS if goal > 0 else self.HOVER_OUT_MS
        now = time.time() * 1000.0
        start = self._ovl_from
        if self._ovl_start is None:
            self._ovl_start = now
            start = self._ovl_t
            self._ovl_from = start

        p = min(1.0, (now - self._ovl_start) / max(1.0, dur))
        eased = 1.0 - (1.0 - p) ** 5          # ease-out-quint
        self._ovl_t = start + (goal - start) * eased

        if p >= 1.0:
            self._ovl_t = goal
            self._ovl_start = None
            self._paint_hover()
            return
        self._paint_hover()
        self._ovl_job = self.after(16, self._ovl_run)

    def _draw_soon(self):
        """Откладывает перерисовку на ближайший тик.

        Движение мыши шлёт события десятками в секунду. Без склейки
        каждое из них перерисовывало бы окно целиком. Пауза считается
        от реальной стоимости кадра: на медленной машине запросы
        копились бы в очередь быстрее, чем окно успевает рисовать.
        """
        if self._draw_job:
            return
        delay = max(16, min(90, int(self._draw_ms * 0.9)))
        self._draw_job = self.after(delay, self._draw_now)

    def _draw_now(self):
        self._draw_job = None
        try:
            self.draw()
        except Exception:
            pass

    def draw(self):
        t0 = time.perf_counter()
        self._draw_body()
        # Запоминаем, сколько стоит кадр: от этого зависит частота
        # анимации и величина шага. Сглаживаем, чтобы случайный
        # долгий кадр не дёргал настройки.
        ms = (time.perf_counter() - t0) * 1000.0
        self._draw_ms = self._draw_ms * 0.7 + ms * 0.3
        # Отдача нажатия ПЕРЕЖИВАЕТ перерисовку: без этого команда
        # («Обновить», смена фильтра) собирала новый кадр раньше,
        # чем глаз успевал увидеть «продавливание», и кнопки
        # ощущались деревянными. Дорисовываем эффект поверх свежего
        # кадра, пока не вышло его время. Чужую вкладку не трогаем:
        # на ней старый прямоугольник осветил бы случайное место.
        try:
            if (self._press_rect is not None
                    and self._press_tab == self.tab
                    and time.perf_counter() < self._press_until
                    and hasattr(self.cv, "overlay_patch")):
                x1, y1, x2, y2, r = self._press_rect
                t_col, t_a, t_e = self._press_colors()
                self.cv.overlay_patch(x1, y1, x2, y2, r=r,
                                      tint=t_col, alpha=t_a,
                                      edge=t_e, edge_w=1.2)
        except Exception:
            pass

    def _apply_bg_gradient(self, W, H):
        """Фон окна — лёгкий диагональный градиент (в тёмной теме).

        Градиент кладётся ПОД фигуры сглаженного слоя (bg_grad), сам
        холст его не рисует. Строится из крошечной картинки 2×2 —
        билинейное растяжение даёт идеально гладкую диагональ бесплатно.
        Если у темы ключей GRAD_TL/GRAD_BR нет (светлая), фон остаётся
        сплошным, как и был.
        """
        if not (SMOOTH and isinstance(self.cv, SmoothCanvas)):
            return
        pal = THEMES.get(THEME, {})
        tl_c, br_c = pal.get("GRAD_TL"), pal.get("GRAD_BR")
        if not (tl_c and br_c):
            if getattr(self.cv, "bg_grad", None) is not None:
                self.cv.bg_grad = None
            return
        key = (W, H, tl_c, br_c)
        if self._bg_grad_key != key:
            from PIL import Image
            a, b = _rgb(tl_c), _rgb(br_c)
            mid = tuple((a[i] + b[i]) // 2 for i in range(3))
            tiny = Image.new("RGB", (2, 2))
            tiny.putpixel((0, 0), a)
            tiny.putpixel((1, 0), mid)
            tiny.putpixel((0, 1), mid)
            tiny.putpixel((1, 1), b)
            self._bg_grad_img = tiny.resize((max(2, W), max(2, H)),
                                            Image.BILINEAR)
            # Дизеринг здесь поздний и ранний одновременно: в flush
            # фон уйдёт под уменьшение (зерно смоется), а реальные
            # полосы лечатся финальным дизерингом кадра.
            self._bg_grad_key = key
        self.cv.bg_grad = self._bg_grad_img

    def _draw_body(self):
        c = self.cv
        c.delete("all")
        self._hot_zones = {}
        self._hot_btns = {}
        W = c.winfo_width() or 880
        H = c.winfo_height() or 700
        self._tabhit = []
        self._ses_hit = []        # действия вкладки «Сессии»
        self._apply_bg_gradient(W, H)

        # тонкая рамка вместо системной
        round_outline(c, 0, 0, W - 1, H - 1, 10, LINE)
        self._header(W)
        y = self._tabs(24, 62, W)
        self._content_top = y
        self._content_bot = H - 42
        # Сообщение «нет данных» — только на вкладках со статистикой.
        # «О программе» должна открываться всегда, даже до первой рыбы.
        if self.stats.error and not self.stats.rows and self.tab != 4:
            self.panel(24, y, W - 24, y + 90, 12)
            c.create_text(44, y + 45, anchor="w", fill=DIM,
                          font=(FONT, 11), text=self.stats.error)
            self._footer(W, H)
            # Тот же сброс буфера, что и в конце draw(): без него при
            # ошибке чтения окно осталось бы пустым.
            if SMOOTH:
                self.cv.flush()
            return

        if self.tab == 0:
            self._overview(24, y, W - 24, H - 46)
        elif self.tab == 1:
            self._gallery(24, y, W - 24, H - 46)
        elif self.tab == 2:
            self._journal(24, y, W - 24, H - 46)
        elif self.tab == 3:
            self._sessions_tab(24, y, W - 24, H - 46)
        else:
            self._about_tab(24, y, W - 24, H - 46)
        self._footer(W, H)

        # Всё, что нарисовали, лежит в буфере — показываем одним кадром.
        if SMOOTH:
            self.cv.flush()
        self._paint_hover()
        # Рыба-логотип «Всего поймано» — поверх кадра, отдельным
        # элементом холста (только на вкладке «Обзор»).
        self._place_hero_fish()

    def _header(self, W):
        c = self.cv
        # эмблема-якорь и название
        icon_anchor(c, 30, 28, 1.15, ACCENT)
        c.create_text(52, 28, anchor="w", fill=FG,
                      font=(FONT, 15, "bold"), text="TrofPridi")
        c.create_text(160, 29, anchor="w", fill=DIM,
                      font=(FONT, 9), text="УСАДЬБА РЫБАКА")

        # --- живые часы справа от подзаголовка ---
        # Иконки (часики, джойстик) — частью кадра: они статичны.
        # Тикающие цифры — два виджета рядом: кадр обновляется раз в
        # 3 секунды, а часы обязаны тикать каждую (_clock_tick).
        # Вся строка ровняется по ОДНОМУ центру (_CLK_CY): и значки,
        # и лейблы ставим так, чтобы их середины совпали — иначе
        # значки «висели» выше цифр. Ширины берём у самих лейблов
        # (reqwidth), а не у прикидочной строки: от этого зависят
        # зазоры, и с «00:00:00» они плавали.
        sw = self._text_w("УСАДЬБА РЫБАКА", (FONT, 9))
        gap1, gap_i, gap_t = 14, 4, 10   # подзаголовок/иконка/текст
        x0 = 160 + sw + gap1
        icx = x0 + 6
        icon_clock(c, icx, self._CLK_CY, 0.72, SOFT)
        rx = icx + 6 + gap_i
        rw = self._clock_size("real")[0]
        pcx = rx + rw + gap_t + 6
        icon_gamepad(c, pcx, self._CLK_CY, 0.75, GREEN)
        gx = pcx + 6 + gap_i
        self._place_clock_labels(rx, gx)

        # --- кнопки окна ---
        # Символы —/□/✕ текстом выглядели разнокалиберно: у шрифта
        # разная ширина и базовая линия. Рисуем линиями — тогда они
        # одного размера и выровнены по центру.
        self._wbtn = []
        bx = W - 16
        for label, cmd in (("close", self._close),
                           ("max", self.toggle_max),
                           ("min", self.minimize)):
            x1, y1, x2, y2 = bx - 30, 12, bx, 42
            # Подсветку рисует быстрый слой поверх кадра: раньше она
            # требовала полной перерисовки, и реакция запаздывала
            # на несколько секунд.
            self._hot_btns[label] = (
                x1, y1, x2, y2,
                "#C42B1C" if label == "close" else HOTFILL,
                "#FF8A7A" if label == "close" else HOTEDGE)
            mx, my = (x1 + x2) / 2, (y1 + y2) / 2
            col = SOFT
            if label == "close":
                c.create_line(mx - 5, my - 5, mx + 5, my + 5,
                              fill=col, width=1.4, capstyle="round")
                c.create_line(mx - 5, my + 5, mx + 5, my - 5,
                              fill=col, width=1.4, capstyle="round")
            elif label == "max":
                if self._maxed:      # значок «вернуть из полного экрана»
                    c.create_rectangle(mx - 6, my - 3, mx + 3, my + 6,
                                       outline=col, width=1.3)
                    c.create_line(mx - 3, my - 3, mx - 3, my - 6,
                                  fill=col, width=1.3)
                    c.create_line(mx - 3, my - 6, mx + 6, my - 6,
                                  fill=col, width=1.3)
                    c.create_line(mx + 6, my - 6, mx + 6, my + 3,
                                  fill=col, width=1.3)
                    c.create_line(mx + 6, my + 3, mx + 3, my + 3,
                                  fill=col, width=1.3)
                else:
                    c.create_rectangle(mx - 5, my - 5, mx + 5, my + 5,
                                       outline=col, width=1.3)
            else:                    # свернуть
                c.create_line(mx - 5, my + 4, mx + 5, my + 4,
                              fill=col, width=1.4, capstyle="round")
            self._wbtn.append((x1, y1, x2, y2, cmd, label))
            bx -= 34

        # --- статус и время обновления ---
        err = getattr(self, "_last_error", "")
        age = None
        try:
            fl = os.path.join(self.data_dir(), "fish_log.csv")
            src = fl if os.path.exists(fl) else self.csv_path
            age = (datetime.now() - datetime.fromtimestamp(
                os.path.getmtime(src))).total_seconds()
        except Exception:
            pass
        dot = RED if err else (GREEN if (age is None or age < 300) else GOLD)

        t_now = datetime.now().strftime("%H:%M:%S")
        upd = f"обновлено {t_now}"
        tx = W - 124
        c.create_text(tx, 29, anchor="e", fill=DIMDEEP,
                      font=(FONT, 9), text=upd)

        # Слева от времени — состояние бота: работает ли он и что делает.
        # Ширину меряем настоящим шрифтом: прикидка «символов × 6»
        # ошибалась на кириллице, и подписи наезжали друг на друга.
        state = self._bot_state()
        stx = tx - self._text_w(upd, (FONT, 9)) - 20
        c.create_text(stx, 29, anchor="e", fill=DIM,
                      font=(FONT, 9), text=state)
        sw_ = self._text_w(state, (FONT, 9))
        c.create_oval(stx - sw_ - 16, 25, stx - sw_ - 8, 33,
                      fill=dot, outline="")

        if err:
            c.create_text(tx, 44, anchor="e", fill=RED, font=(FONT, 8),
                          text=self._fit("ошибка: " + err, 260))

        # Зону перетаскивания НЕ делаем фигурой на Canvas: элемент с
        # fill="" прозрачен для мыши, tag_bind по нему не срабатывает.
        self._drag_limit = W - 118

    def _bot_state(self):
        """Короткая строка о состоянии бота для шапки.

        №61: главный источник — маяк бота bot_state.ini: AHK пишет его
        раз в секунду ВСЕГДА, пока запущен (даже на паузе и даже до
        первого улова). Раньше судили по последнему событию журнала,
        и запущенный, но ещё не ловивший бот честно выглядел
        «не запущен» — хотя как процесс он работал.
        """
        try:
            import configparser
            cp = configparser.ConfigParser()
            if cp.read(os.path.join(self.data_dir(), "bot_state.ini"),
                       encoding="utf-8"):
                ts = datetime.strptime(
                    cp.get("state", "tick").strip(), "%Y%m%d%H%M%S")
                if (datetime.now() - ts).total_seconds() <= 6:
                    mode = cp.get("state", "mode",
                                  fallback="running").strip()
                    if mode == "paused":
                        return "AHK работает · Пауза"
                    return "AHK работает · Ловля"
                return "AHK не запущен"      # маяк есть, но замер
        except Exception:
            pass
        # Маяка нет вовсе (бот старой версии без маяка) — старый
        # способ по последнему событию журнала.
        rows = getattr(self.stats, "rows", [])
        if not rows:
            return "AHK не запущен"
        last = rows[-1]
        age = (datetime.now() - last[0]).total_seconds()
        if age > 600:
            return "AHK не запущен"
        if last[1] == "session" and last[2] == "stop":
            return "AHK работает · Пауза"
        return "AHK работает · Ловля"

    # ------------------------------------------------ часы шапки
    def _init_game_clock(self):
        """Живые часы в шапке: реальное время и игровое (РР4).

        Игровое время РР4 идёт ровно в 24 раза быстрее реального —
        это подтверждается и официальными анонсами («состязание
        48 игровых часов = 2 реальных часа»), и сайтами с игровым
        временем: проверили их формулу на живом скриншоте
        («реал 21:23:27 -> игра 09:22» — сошлось до минуты
        с нулевым сдвигом от местной полуночи). Значит, часы
        показывают точное время ВСЕГДА, даже когда клиент игры
        закрыт, — OCR не нужен вообще.

        Конструкция: иконки (часики + джойстик) рисует кадр шапки в
        _header — они статичны; тикающие ЦИФРЫ — два виджета-тикера
        рядом с ними. Кадр перерисовывается раз в 3 секунды, а часы
        обязаны тикать каждую — виджеты дешевле полного рендера.
        Цвета подхватываем из текущей палитры каждую секунду —
        смена темы перекрашивает их сама."""
        self._clock_lbl_real = tk.Label(self, font=(FONT, 9), bd=0,
                                        highlightthickness=0)
        self._clock_lbl_game = tk.Label(self, font=(FONT, 10, "bold"),
                                        bd=0, highlightthickness=0)
        # Клики и перетаскивание окна пропускаем через часы: иначе
        # кусок шапки под ними «умирал» для мыши (окно без рамки,
        # его таскают за шапку). Координаты переноса корневые,
        # поэтому чужие события обработчики принимают как свои.
        for lbl in (self._clock_lbl_real, self._clock_lbl_game):
            lbl.bind("<Button-1>", self.on_press)
            lbl.bind("<B1-Motion>", self.on_drag)
            lbl.bind("<ButtonRelease-1>", self.on_release)
        self._clock_r = ""
        self._clock_g = ""
        self._clock_tick()

    def _clock_size(self, kind):
        """(ширина, высота) лейбла-циферблата: по виджету, с запасным
        прикидком, если его ещё нет.

        Иконки под часы рисуются в кадре при каждом проходе _header,
        и их координаты считаются от этих размеров. Замеренное у
        виджета значение кэшируем (цифры моноширинные, размер
        стабилен); прикидок не кэшируем — как только лейбл
        ответит размерами, позиции «встанут» на истинные.
        """
        key = "_clock_sz_" + kind
        sz = self.__dict__.get(key)
        if sz:
            return sz
        lbl = (self.__dict__.get("_clock_lbl_real") if kind == "real"
               else self.__dict__.get("_clock_lbl_game"))
        try:
            w, h = lbl.winfo_reqwidth(), lbl.winfo_reqheight()
        except Exception:
            w = h = 0
        if w > 20 and h > 8:
            sz = (w, h)
            self.__dict__[key] = sz          # истинные размеры — навсегда
        elif kind == "real":
            sz = (self._text_w("00:00:00", (FONT, 9)), 17)
        else:
            sz = (self._text_w("00:00", (FONT, 10, "bold")), 18)
        return sz

    def _place_clock_labels(self, rx, gx):
        """Ставит циферблаты точно за иконками кадра (см. _header).

        Вертикаль — не «жёсткие пиксели», а центрирование по _CLK_CY:
        из-за разных размеров шрифтов (9 и 10) фиксированные y=21/19
        давали заметную разнобойность с иконками.
        """
        if self.__dict__.get("_clock_lbl_real") is None:
            return
        try:
            rh = self._clock_size("real")[1]
            gh = self._clock_size("game")[1]
            self._clock_lbl_real.place(x=rx, y=int(self._CLK_CY - rh / 2))
            self._clock_lbl_game.place(x=gx, y=int(self._CLK_CY - gh / 2))
        except Exception:
            pass

    def _clock_tick(self):
        """Раз в секунду: реальные часы и игровые (x24, от полуночи)."""
        try:
            now = datetime.now()
            # игровое: местная полночь — старт игровых суток, х24
            sec = (now.hour * 3600 + now.minute * 60 + now.second
                   + now.microsecond / 1e6)
            gsec = (sec * 24) % 86400
            gh, gm = int(gsec // 3600), int(gsec % 3600 // 60)
            rt = now.strftime("%H:%M:%S")
            gt = f"{gh:02d}:{gm:02d}"
            if rt != self._clock_r:
                self._clock_r = rt
                self._clock_lbl_real.configure(text=rt)
            if gt != self._clock_g:
                self._clock_g = gt
                self._clock_lbl_game.configure(text=gt)
            # цвета — каждый тик из живой палитры (тема может смениться)
            self._clock_lbl_real.configure(bg=BG, fg=SOFT)
            self._clock_lbl_game.configure(bg=BG, fg=GREEN)
        except Exception:
            pass
        try:
            self.after(1000, self._clock_tick)
        except Exception:
            pass

    TAB_ICONS = (icon_grid, icon_gallery, icon_book, icon_chart,
                 icon_info)

    def _tabs(self, x, y, W=None):
        """Вкладки с иконками и кнопка «Обновить» у правого края."""
        for i, name in enumerate(self.TABS):
            active = (i == self.tab)
            # Ширину меряем ТЕМ ЖЕ начертанием, что рисуем: активная
            # вкладка жирная, и замер обычным шрифтом занижал ширину —
            # подпись жала вправо. Плюс лёгкий запас капсуле.
            fnt = (FONT, 10, "bold") if active else (FONT, 10)
            w = self._chip_w(name, fnt) + 6
            x2 = x + w
            if active:
                self._face(x, y, x2, y + 34, R_TAB)
            col = ACCENT if active else DIM
            self._chip_content(x, w, y + 17, name, fnt, col,
                               self.TAB_ICONS[i], col, 0.85)
            # и у вкладок мгновенная подсветка слоем, как у кнопок
            self._hot_btns[i] = (x, y, x2, y + 34,
                                 HOTFILL, HOTEDGE, R_TAB)
            self._tabhit.append((x, y, x2, y + 34, i))
            x = x2 + 6

        # кнопка «Обновить» — справа на одной линии с вкладками
        if W:
            bw = self._chip_w("Обновить", (FONT, 9)) + 6
            bx1, bx2 = W - 24 - bw, W - 24
            self._face(bx1, y, bx2, y + 34, R_TAB)
            self._chip_content(bx1, bw, y + 17, "Обновить", (FONT, 9),
                               SOFT, self._refresh_icon, SOFT, 0.72)
            # Куда слать спрайт вращения (дёшево, без пересборки кадра)
            self._refresh_ic_pos = (bx1 + self.CHIP_PAD
                                    + self.CHIP_ISLOT / 2, y + 17)
            self._hot_btns["refresh"] = (bx1, y, bx2, y + 34,
                                         ACCENT, ACCENT, R_TAB)
            self._tabhit.append((bx1, y, bx2, y + 34, "refresh"))
        return y + 50

    def _card(self, x1, y1, x2, y2, label, value, color=FG, size=19,
              accent=None):
        """Карточка. Текст центрируется по фактической высоте, иначе
        в низких карточках значение прижимается ко дну."""
        c = self.cv
        self.panel(x1, y1, x2, y2)

        # тонкая цветная полоска слева — задаёт иерархию без пестроты
        if accent:
            round_rect(c, x1 + 2, y1 + 16, x1 + 5, y2 - 16, 1.5,
                       fill=accent, outline="")

        pad = 20
        lab = 18
        c.create_text(x1 + pad, y1 + lab, anchor="w", fill=DIM,
                      font=(FONT, 9), text=label)
        # Значение центрируем в остатке карточки: при жёсткой координате
        # в низких карточках текст прижимался ко дну. Множитель 0.5
        # подобран так, что зазоры сверху и снизу совпадают.
        vy = y1 + lab + (y2 - y1 - lab) * 0.5
        if "\n" in str(value):
            # Двухстрочное значение (например «Лучший улов»): первую
            # строку крупнее, вторую мельче и приглушённее.
            head, tail = str(value).split("\n", 1)
            c.create_text(x1 + pad, vy - 8, anchor="w", fill=color,
                          font=(FONT_NUM, size), text=head)
            c.create_text(x1 + pad, vy + 11, anchor="w", fill=SOFT,
                          font=(FONT, 8), text=tail)
        else:
            c.create_text(x1 + pad, vy, anchor="w", fill=color,
                          font=(FONT_NUM, size), text=value)

    def _best_catch_text(self):
        """Самая тяжёлая рыба: название, вес, длина и полученный опыт."""
        recs = self.stats.records(1)
        if not recs:
            return "—"
        rec = recs[0]
        name, w = rec[1], rec[2]
        exp = rec[3] if len(rec) > 3 else 0
        ln = rec[6] if len(rec) > 6 else 0
        bits = []
        if w:
            bits.append(f"{w:.3f} кг")
        if ln:
            bits.append(f"{ln} см")
        if exp:
            bits.append(f"{exp:,}".replace(",", " ") + " опыта")
        return f"{self._fit(name or 'Без названия', 130)}\n{' · '.join(bits)}"

    def _card_consum(self, x1, y1, x2, y2, cons):
        """Расходники: рисованные иконки вместо эмодзи."""
        c = self.cv
        self.panel(x1, y1, x2, y2)
        c.create_text(x1 + 20, y1 + 18, anchor="w", fill=DIM,
                      font=(FONT, 9), text="Расходники")
        vy = y1 + 18 + (y2 - y1 - 18) * 0.5
        step = (x2 - x1 - 34) / 3.0
        items = ((icon_coffee, cons.get("coffee", 0)),
                 (icon_food, cons.get("food", 0)),
                 (icon_sun, cons.get("sun", 0)))
        for i, (draw, n) in enumerate(items):
            ix = x1 + 28 + i * step
            draw(c, ix, vy, 0.78)
            c.create_text(ix + 13, vy + 1, anchor="w", fill=PALE,
                          font=(FONT_NUM, 12), text=str(n))

    def _overview(self, x1, y1, x2, y2):
        """Сводка: герой-блок, полоса показателей, три панели."""
        s = self.stats
        cat = s.by_category()
        total = len(s.catches()) or 1

        gap = 12
        hero_h = 178
        strip_h = 96

        self._hero(x1, y1, x2, y1 + hero_h)

        def pct(n):
            return f"{n / total * 100:.1f}%" if s.catches() else "0.0%"

        # В полосе показателей — ПОСЛЕДНИЙ улов: он меняется каждую
        # рыбу, за ним и следят. Лучший улов ушёл вниз, в панель
        # с фотографией, где для него есть место.
        fish = getattr(s, "fish", [])
        last = max(fish, key=lambda f: f[0]) if fish else None
        last_w = "—"
        if last:
            if last[2]:
                last_w = f"{last[2]:.3f} кг"
            elif len(last) > 6 and last[6]:
                last_w = f"{last[6]} см"
            else:
                last_w = last[1] or "—"

        items = [
            (icon_trophy, GOLD, "Трофеи", str(cat.get("trophy", 0)),
             pct(cat.get("trophy", 0)), GOLD),
            (icon_check, GREEN, "Зачётные", str(cat.get("zachet", 0)),
             pct(cat.get("zachet", 0)), GREEN),
            (icon_cross, RED, "Мелочь", str(cat.get("small", 0)),
             pct(cat.get("small", 0)), RED),
            (icon_clock, ACCENT, "Время в игре", fmt_dur(s.total_time()),
             "Активная сессия", ACCENT),
            (icon_speed, ACCENT, "Рыбы в час", f"{s.per_hour():.1f}",
             "Средний темп", ACCENT),
            (icon_weight, ACCENT, "Общий вес",
             f"{s.total_weight():.1f} кг" if s.total_weight() else "—",
             "Только распознанные", ACCENT),
            (icon_fish, ACCENT, "Последний улов", last_w,
             (last[1] if last else "пока пусто"), ACCENT),
        ]
        sy = y1 + hero_h + gap
        # Запись сохраняем ДО отрисовки: полоса показателей по ней
        # решает, вешать ли зону подсказки на последнюю ячейку.
        self._last_catch = last
        self._tip_zone = None
        self._cat_zones = {}
        # Ключ подсказки регистрируем как быструю зону: иначе
        # _hover_changed не находит его и уходит в полную перерисовку,
        # а это сотни миллисекунд задержки.
        self._hot_btns.pop("m_last", None)
        self._ov_hit = []          # кликабельные области вкладки
        self._metrics_strip(x1, sy, x2, sy + strip_h, items)

        # Три панели снизу. Высоту ограничиваем: на большом окне они
        # растягивались до самого низа и выглядели пустыми колодцами.
        py = sy + strip_h + gap
        avail = y2 - py
        if avail > 120:
            self._panels(x1, py, x2, py + min(avail, 380))

    def _load_hero_fish(self):
        """Готовит рыбу-логотип для блока «Всего поймано».

        Та самая рыба с заставки: гладкий PNG с прозрачным фоном.
        Уменьшаем под размер кольца через Pillow. Без Pillow выигрыша
        в гладкости нет — тогда берём файл как есть и ужимаем вдвое;
        если и он потерялся, остаётся рисованная эмблема: интерфейс
        работает в любом случае.
        """
        self._fish_img = None
        fp = os.path.join(script_dir(), "assets", "splash_fish.png")
        if os.path.exists(fp):
            try:
                from PIL import Image as _Im, ImageTk as _IT
                im = _Im.open(fp).convert("RGBA")
                # Кольцо ~104 px; у PNG есть запас под свечение по краям.
                im.thumbnail((104, 104), _Im.LANCZOS)
                self._fish_img = _IT.PhotoImage(im)
            except Exception:
                try:
                    ph = tk.PhotoImage(file=fp)
                    if ph.width() > 120:
                        ph = ph.subsample(2, 2)
                    self._fish_img = ph
                except Exception:
                    self._fish_img = None
        # Пузырьки грузим отдельно и ВСЕГДА: раньше этот код стоял
        # ниже return при успешной загрузке рыбы — кадры пузырька не
        # загружались никогда, и клики по рыбке молчали.
        self._load_bubble_fades()

    def _load_bubble_fades(self):
        """Кадры пузырька с затуханием для клика по рыбке.

        Tk не умеет менять прозрачность готовой картинки, поэтому
        заготавливаем три степени — пузырёк на взлёте густой, к концу
        почти прозрачный. Без Pillow берём файл как есть одним кадром,
        пузыри просто исчезнут без затухания.
        """
        self._bub_fades = []
        bp = os.path.join(script_dir(), "assets", "bubble.png")
        if not os.path.exists(bp):
            return
        try:
            from PIL import Image as _Im2, ImageTk as _IT2
            im = _Im2.open(bp).convert("RGBA")
            faces = []
            for k_ in (1.0, 0.55, 0.25):
                a = im.copy()
                a.putalpha(a.split()[3].point(lambda v, c=k_: int(v * c)))
                faces.append(_IT2.PhotoImage(a))
            self._bub_fades = faces
        except Exception:
            try:
                self._bub_fades = [tk.PhotoImage(file=bp)]
            except Exception:
                self._bub_fades = []

    def _place_hero_fish(self):
        """Кладёт рыбу поверх готового кадра в блоке «Всего поймано».

        Отдельным элементом холста, ПОСЛЕ сборки картинки кадра:
        благодаря этому покачивание — просто сдвиг координат элемента,
        а не пересборка всего кадра на каждый шаг. Заодно возвращаем
        на место пузырьки: сборка кадра удалила их элементы холста,
        поэтому пересоздаём по сохранённым координатам.
        """
        self._fish_item = None
        for b in self.__dict__.get("_bubbles", []):
            b["item"] = None
        pos = self.__dict__.get("_hero_fish_pos")
        img = self.__dict__.get("_fish_img")
        if img is not None and pos and self.tab == 0:
            try:
                t = time.time() - self._fish_t0
                bob = math.sin(t * 2.4) * 4
                self._fish_item = self._tkcv.create_image(
                    pos[0], pos[1] + bob, image=img)
            except Exception:
                self._fish_item = None
        self._bubbles_draw()

    def _bubbles_draw(self):
        """Создаёт элементы холста для пузырьков, у которых их нет."""
        fades = self.__dict__.get("_bub_fades", [])
        if self.tab != 0 or not fades:
            return
        for b in self.__dict__.get("_bubbles", []):
            if b["item"] is None:
                fi = min(len(fades) - 1, b.get("fi", 0))
                try:
                    b["item"] = self._tkcv.create_image(
                        b["x"], b["y"], image=fades[fi])
                except Exception:
                    pass

    def _bubble_spawn(self, pos):
        """Клик по рыбке: выпускает горсточку пузырьков из кольца.

        Пузырьки — обычные картинки холста: двигаем их сдвигом
        координат в _fish_tick, кадр не пересобираем вовсе — поэтому
        анимация почти бесплатная по ресурсам.
        """
        fades = self.__dict__.get("_bub_fades", [])
        if not pos or not fades:
            return
        cx, cy, rr = pos
        now = time.time()
        # подчистим отлётевших и ограничим общую тучу, чтобы даже
        # азартные клики по рыбке не разогнали множество элементов
        self._bubbles = [b for b in self._bubbles
                         if now - b["born"] < 1.6]
        room = max(0, 22 - len(self._bubbles))
        for _ in range(min(random.randint(4, 6), room)):
            self._bubbles.append({
                "item": None,
                "x": cx + random.uniform(-rr * 0.55, rr * 0.55),
                "y": cy + random.uniform(-8, 8),
                "vx": random.uniform(-0.4, 0.4),
                "vy": random.uniform(1.6, 3.1),
                "ph": random.uniform(0.0, 6.283),
                "born": now,
                "fi": 0,
            })
        self._bubbles_draw()

    def _fish_tick(self):
        """Качает рыбу в «Обзоре» и гонит пузырьки вверх.

        Тик стоит почти ничего: смена координат готовых элементов
        холста, кадр не пересчитывается вообще. Частота ~60 Гц:
        движение гладкое, а нагрузка всё так же копеечная. Сдвиг
        считаем от реального времени между тиками (dt) — тогда при
        любом запоздании цикла скорость остаётся прежней, без рывков.
        Координаты рыбы берём свежие из _hero_fish_pos — окно могли
        подвинуть или растянуть.
        """
        try:
            now = time.time()
            last = getattr(self, "_fish_last", None)
            # Ограничение сверху: длинная пауза (свернули окно, уснула
            # система) не должна выбрасывать пузырьки в небеса рывком.
            dt = 0.05 if last is None else max(0.0, min(0.1, now - last))
            self._fish_last = now
            k = dt / 0.05      # скорости заданы в «пикселях за 50 мс»

            pos = self.__dict__.get("_hero_fish_pos")
            item = self.__dict__.get("_fish_item")
            if item and pos and self.tab == 0:
                t = now - self._fish_t0
                self._tkcv.coords(item, pos[0], pos[1] + math.sin(t * 2.4) * 4)

            # Пузырьки: вверх с лёгким покачиванием, к концу жизни
            # тают (если есть кадры затухания).
            fades = self.__dict__.get("_bub_fades", [])
            alive = []
            for b in self.__dict__.get("_bubbles", []):
                age = now - b["born"]
                if age > 1.6:
                    if b["item"] is not None:
                        try:
                            self._tkcv.delete(b["item"])
                        except Exception:
                            pass
                    continue
                b["y"] -= b["vy"] * k
                b["x"] += (b["vx"] + math.sin(age * 5.0 + b["ph"]) * 0.5) * k
                if len(fades) > 1:
                    b["fi"] = min(len(fades) - 1,
                                  int(age / 1.6 * len(fades)))
                if b["item"] is not None and self.tab == 0:
                    try:
                        self._tkcv.coords(b["item"], b["x"], b["y"])
                        # Кадр затухания подменяем, только когда он
                        # сменился: иначе при 60 Гц холсту достаётся
                        # сотня холостых перенастроек в секунду.
                        if (len(fades) > 1
                                and b["fi"] != b.get("_fi_shown", -1)):
                            self._tkcv.itemconfig(
                                b["item"], image=fades[b["fi"]])
                            b["_fi_shown"] = b["fi"]
                    except Exception:
                        # элемент удалился с кадром — пересоздастся
                        # на следующей отрисовке через _bubbles_draw
                        b["item"] = None
                alive.append(b)
            self._bubbles = alive
        except Exception:
            pass
        try:
            self.after(16, self._fish_tick)
        except Exception:
            pass

    def _hero(self, x1, y1, x2, y2):
        """Верхний блок: эмблема, счётчик улова и график темпа."""
        c = self.cv
        s = self.stats
        self.panel(x1, y1, x2, y2)

        pad = 18
        # --- эмблема слева ---
        ex1, ey1 = x1 + pad, y1 + pad
        ex2, ey2 = ex1 + 196, y2 - pad
        self._well(ex1, ey1, ex2, ey2, 10)

        # Круг с кольцом: доля зачётных в улове. Раньше рыба тонула
        # в тёмной подложке — теперь у неё есть подсветка и рамка.
        cx, cy = (ex1 + ex2) / 2, (ey1 + ey2) / 2
        rr = min(ex2 - ex1, ey2 - ey1) * 0.36
        c.create_oval(cx - rr, cy - rr, cx + rr, cy + rr,
                      fill=EMBLEM_BG, outline="")
        by = s.by_category()
        good = by.get("trophy", 0) + by.get("zachet", 0)
        total = max(1, sum(by.values()))
        c.create_arc(cx - rr, cy - rr, cx + rr, cy + rr,
                     start=90, extent=-359.9 * good / total,
                     style="arc", outline=ACCENT, width=5)
        # Красивая рыба с заставки вместо нарисованной линиями.
        # Кладётся отдельным элементом холста ПОСЛЕ сборки кадра
        # (см. _place_hero_fish) — тогда для покачивания хватает
        # сдвига координат, а кадр не пересчитывается. Если PNG
        # недоступен — прежняя рисованная эмблема, так тоже работает.
        if self.__dict__.get("_fish_img") is not None:
            self._hero_fish_pos = (cx, cy, rr)
        else:
            emblem_fish(c, ex1, ey1, ex2, ey2, EMBLEM_FISH)

        # --- счётчик ---
        tx = ex2 + 28
        c.create_text(tx, y1 + 48, anchor="w", fill=MID,
                      font=(FONT, 9, "bold"), text="ВСЕГО ПОЙМАНО")
        c.create_text(tx, y1 + 92, anchor="w", fill=FG,
                      font=(FONT_NUM, 30), text=str(len(s.catches())))
        c.create_text(tx, y1 + 130, anchor="w", fill=CHECKLINE,
                      font=(FONT, 8), text="Рыб за текущий период")

        # вертикальный разделитель
        divx = tx + 200
        c.create_line(divx, y1 + 26, divx, y2 - 26, fill=DIVLINE)

        # --- график темпа справа ---
        gx1 = divx + 28
        c.create_text(gx1, y1 + 34, anchor="w", fill=MID,
                      font=(FONT, 9, "bold"), text="ТЕМП СЕССИИ")
        c.create_text(gx1, y1 + 54, anchor="w", fill=CHECKLINE,
                      font=(FONT, 8), text="Среднее количество рыб в час")
        c.create_text(x2 - pad, y1 + 44, anchor="e", fill=ACCENT,
                      font=(FONT_NUM, 26), text=f"{s.per_hour():.1f}")
        self._spark(gx1, y1 + 86, x2 - pad, y2 - pad)

    def _spark(self, x1, y1, x2, y2):
        """Мини-график активности по последним уловам."""
        c = self.cv
        catches = self.stats.catches()
        w = x2 - x1
        h = y2 - y1
        if w < 40 or h < 20:
            return

        # Считаем уловы по 12 равным отрезкам последнего часа активности.
        buckets = 12
        vals = [0.0] * buckets
        if catches:
            last = catches[-1][0]
            first = catches[0][0]
            span = max((last - first).total_seconds(), 1.0)
            for ts, _e, _c in catches:
                k = int((ts - first).total_seconds() / span * (buckets - 1))
                vals[max(0, min(buckets - 1, k))] += 1

        peak = max(vals) or 1.0
        # Сглаживаем: соседние значения усредняем, иначе линия дёргается.
        smooth = []
        for i in range(buckets):
            lo = max(0, i - 1)
            hi = min(buckets, i + 2)
            smooth.append(sum(vals[lo:hi]) / (hi - lo))

        pts = []
        for i, v in enumerate(smooth):
            px = x1 + w * i / (buckets - 1)
            py = y2 - (h - 6) * (v / peak) - 3
            pts.extend([px, py])

        # Заливку строим по УЖЕ сглаженным точкам, а сам многоугольник
        # рисуем без сглаживания. Иначе кривая протягивалась и через
        # нижние углы, превращая график в бесформенное пятно.
        curve = pts
        if SMOOTH:
            try:
                from smooth_canvas import _spline
                xy = [(pts[i], pts[i + 1]) for i in range(0, len(pts) - 1, 2)]
                sp = _spline(xy, 16)
                curve = [v for p in sp for v in p]
            except Exception:
                curve = pts
        area = curve + [x2, y2, x1, y2]
        c.create_polygon(area, fill=SPARK_FILL, outline="",
                         smooth=not SMOOTH)
        c.create_line(curve, fill=ACCENT, width=2, smooth=not SMOOTH,
                      capstyle="round")
        # точка на последнем значении
        c.create_oval(pts[-2] - 3.5, pts[-1] - 3.5,
                      pts[-2] + 3.5, pts[-1] + 3.5,
                      fill=ACCENT, outline="")

    def _metrics_strip(self, x1, y1, x2, y2, items):
        """Полоса показателей: иконка, подпись, значение, пояснение."""
        c = self.cv
        self.panel(x1, y1, x2, y2)

        n = len(items)
        cw = (x2 - x1) / n
        for i, (ico, icol, label, value, note, vcol) in enumerate(items):
            cx = x1 + i * cw
            # разделитель между ячейками
            if i:
                c.create_line(cx, y1 + 18, cx, y2 - 18, fill=DIVLINE)

            ico(c, cx + 28, y1 + 26, 0.78, icol)
            c.create_text(cx + 46, y1 + 26, anchor="w", fill=DIM,
                          font=(FONT, 9),
                          text=self._fit(label, cw - 58))
            c.create_text(cx + 22, y1 + 56, anchor="w", fill=vcol,
                          font=(FONT_NUM, 15),
                          text=self._fit(value, cw - 34))
            c.create_text(cx + 22, y1 + 78, anchor="w", fill=CHECKLINE,
                          font=(FONT, 8),
                          text=self._fit(note, cw - 34))

            # Последняя ячейка («Последний улов») раскрывает подробности
            # по наведению: в узкую колонку название, вес, длина и опыт
            # разом не помещаются.
            if i == n - 1 and self._last_catch:
                self._tip_zone = (cx, y1, cx + cw, y2)
                # та же зона в списке быстрых — подсказка всплывает сразу
                self._hot_btns["m_last"] = (cx, y1, cx + cw, y2,
                                            ACCENT, ACCENT, R_CARD)

            # Первые три ячейки — категории. По наведению показываем,
            # ЧТО именно за рыба в этой категории: одна цифра «6»
            # ничего не говорит, а список видов сразу отвечает на
            # вопрос «какие у меня трофеи».
            if i < 3 and self.stats.fish:
                ckey = ("trophy", "zachet", "small")[i]
                self._cat_zones[ckey] = (cx, y1, cx + cw, y2)
                self._hot_btns[f"m_cat_{ckey}"] = (cx, y1, cx + cw, y2,
                                                   vcol, vcol, R_CARD)

    def _tooltip(self, x, y, lines, width=None):
        """Всплывающая подсказка поверх кадра.

        Рисуется нативными фигурами Tk, а не через пересчёт картинки:
        так она появляется сразу, а не через пару секунд.
        """
        cv = self.cv
        fast = hasattr(cv, "overlay_round_rect")
        pad = 10
        lh = 17
        w = width or (max(self._text_w(t, (FONT, 9)) for _, t in lines)
                      + pad * 2 + 54)
        h = len(lines) * lh + pad * 2
        W = self.cv.winfo_width()
        H = self.cv.winfo_height()
        # Держим подсказку в пределах окна с обеих сторон. Раньше
        # ограничение было только справа, и у крайней левой плитки
        # окошко уезжало за край экрана.
        x = max(8, min(x, W - w - 8))
        y = max(8, min(y, H - h - 8))

        if fast:
            cv.overlay_round_rect(x + 2, y + 3, x + w + 2, y + h + 3, 9,
                                  fill=BGDEEP)
            cv.overlay_round_rect(x, y, x + w, y + h, 9, fill=CHIP2,
                                  outline=GHOSTEDGE, width=1)
        else:
            round_rect(cv, x + 2, y + 3, x + w + 2, y + h + 3, 9,
                       fill=BGDEEP, outline="")
            round_rect(cv, x, y, x + w, y + h, 9, fill=CHIP2,
                       outline="")
            round_outline(cv, x, y, x + w, y + h, 9, GHOSTEDGE)

        ty = y + pad + lh / 2
        for lab, val in lines:
            if fast:
                cv.overlay_text(x + pad, ty, lab, fill=MID,
                                font=(FONT, 8), anchor="w")
                cv.overlay_text(x + w - pad, ty, val, fill=PALE,
                                font=(FONT, 9), anchor="e")
            else:
                cv.create_text(x + pad, ty, anchor="w", fill=MID,
                               font=(FONT, 8), text=lab)
                cv.create_text(x + w - pad, ty, anchor="e", fill=PALE,
                               font=(FONT, 9), text=val)
            ty += lh

    def _draw_cat_tip(self, ckey):
        """Список рыб выбранной категории — по наведению на её плитку.

        Счётчик показывает только число. «Шесть трофеев» — это хорошо,
        но какие именно, из плитки не видно, а лезть в галерею ради
        одного взгляда неудобно.
        """
        zone = self._cat_zones.get(ckey)
        if not zone:
            return
        cnt = Counter(f[1] for f in self.stats.fish
                      if len(f) > 5 and f[5] == ckey and f[1])
        if not cnt:
            return
        title = {"trophy": "Трофеи", "zachet": "Зачётные",
                 "small": "Мелочь"}.get(ckey, ckey)
        # Самый крупный экземпляр каждого вида — приятнее сухого счёта.
        best = {}
        for f in self.stats.fish:
            if len(f) > 5 and f[5] == ckey and f[1] and f[2]:
                if f[2] > best.get(f[1], 0):
                    best[f[1]] = f[2]
        lines = [("", f"{title}: {sum(cnt.values())}")]
        for name, n in cnt.most_common(8):
            w = best.get(name)
            right = f"{n} шт" + (f" · до {w:.3f} кг" if w else "")
            lines.append((name, right))
        if len(cnt) > 8:
            lines.append(("", f"и ещё видов: {len(cnt) - 8}"))
        x1, y1, x2, y2 = zone
        # Подсказка рисуется ОТ ЛЕВОГО КРАЯ переданной точки, поэтому
        # центр плитки сдвигает её вправо на половину ширины. Вычитаем
        # половину сами — иначе окошко висит заметно правее того места,
        # куда наведён курсор.
        w = 260
        self._tooltip((x1 + x2) / 2 - w / 2, y2 + 6, lines, width=w)

    def _draw_last_tip(self):
        """Подсказка о последнем улове — поверх всей вкладки."""
        rec = getattr(self, "_last_catch", None)
        zone = getattr(self, "_tip_zone", None)
        if not rec or not zone or self._hover_btn != "m_last":
            return
        ts, name, w = rec[0], rec[1], rec[2]
        exp = rec[3] if len(rec) > 3 else 0
        kind = rec[5] if len(rec) > 5 else ""
        ln = rec[6] if len(rec) > 6 else 0
        lines = [("Рыба", name or "—")]
        lines.append(("Категория", {"trophy": "Трофей",
                                    "zachet": "Зачётная",
                                    "small": "Незачёт"}.get(kind, "—")))
        lines.append(("Вес", f"{w:.3f} кг" if w else "—"))
        lines.append(("Длина", f"{ln} см" if ln else "—"))
        lines.append(("Опыт", f"{exp:,}".replace(",", " ") if exp else "—"))
        lines.append(("Поймана", ts.strftime("%d.%m.%Y  %H:%M")))
        self._tooltip(zone[0] + 8, zone[3] + 8, lines)

    def _panels(self, x1, y1, x2, y2):
        """Три панели: виды рыбы, рекорды по весу и последний улов."""
        gap = 12
        # Правая колонка под карточку улова уже остальных: там фото
        # фиксированной ширины, растягивать её незачем.
        right_w = min(330, (x2 - x1) * 0.30)
        left_w = (x2 - x1 - right_w - gap * 2) / 2

        a1 = x1
        a2 = a1 + left_w
        b1 = a2 + gap
        b2 = b1 + left_w
        c1 = x2 - right_w

        self._panel_species(a1, y1, a2, y2)
        self._panel_records(b1, y1, b2, y2)
        self._panel_last(c1, y1, x2, y2)

    def _panel_last(self, x1, y1, x2, y2):
        """Лучший улов: фото и все характеристики рекордной рыбы.

        Раньше здесь был последний улов, но он и так виден в полосе
        показателей. Рекорд же хочется рассмотреть — ему и место
        под фотографией.
        """
        c = self.cv
        self.panel(x1, y1, x2, y2)
        icon_trophy(c, x1 + 26, y1 + 21, 0.72, GOLD)
        c.create_text(x1 + 40, y1 + 20, anchor="w", fill=DIM,
                      font=(FONT, 9), text="Лучший улов")

        fish = getattr(self.stats, "fish", [])
        best = self.stats.records(1)
        if not fish or not best:
            icon_fish(c, (x1 + x2) / 2, y1 + 88, 3.4, GHOSTEDGE)
            c.create_text((x1 + x2) / 2, y1 + 120, fill=CHECKLINE,
                          font=(FONT, 9),
                          text="Рекорд появится здесь")
            return

        rec = best[0]
        ts, name, w = rec[0], rec[1], rec[2]
        exp = rec[3] if len(rec) > 3 else 0
        photo = rec[4] if len(rec) > 4 else ""
        kind = rec[5] if len(rec) > 5 else ""
        ln = rec[6] if len(rec) > 6 else 0

        pad = 16
        iw = int(x2 - x1 - pad * 2)
        ih = 132

        # Фото. Если снимок есть — по нему можно щёлкнуть и рассмотреть
        # крупно, как в галерее. Рамка при наведении показывает, что
        # блок кликабельный.
        # Подсветка вместо увеличения — по той же причине, что и
        # в галерее: пересчёт миниатюры на каждый кадр анимации
        # заметно тормозил окно.
        img = self._photo(photo, iw, ih) if photo else None
        if img:
            c.create_image((x1 + x2) / 2, y1 + 42 + ih / 2, image=img)
            self._hot_zones["best_photo"] = (x1 + pad - 2, y1 + 40,
                                             x2 - pad + 2, y1 + 44 + ih)
            self._ov_hit = self._ov_hit
            self._ov_hit.append((x1 + pad, y1 + 42, x2 - pad, y1 + 42 + ih,
                                 lambda r=rec: self._open_photo(r),
                                 "best_photo", "hand2"))
        else:
            self._well(x1 + pad, y1 + 42, x2 - pad, y1 + 42 + ih, 10)
            icon_fish(c, (x1 + x2) / 2, y1 + 36 + ih / 2, 3.2, GHOSTEDGE)
            c.create_text((x1 + x2) / 2, y1 + 42 + ih - 18, fill=FAINT2,
                          font=(FONT, 8), text="снимок не сохранён")

        # плашка категории поверх фото
        if kind == "trophy":
            lbl, col, ico = "ТРОФЕЙ", GOLD, icon_star
        elif kind == "zachet":
            lbl, col, ico = "ЗАЧЁТНАЯ", GREEN, icon_check
        elif kind == "small":
            lbl, col, ico = "НЕЗАЧЁТ", RED, icon_cross
        else:
            lbl, col, ico = "НЕ ОПРЕДЕЛЕНО", DIM, None
        bw = 20 + self._text_w(lbl, (FONT, 8, "bold")) + (14 if ico else 0)
        self._well(x1 + pad + 6, y1 + 50, x1 + pad + 6 + bw, y1 + 70, 10)
        tx = x1 + pad + 16
        if ico:
            ico(c, tx, y1 + 60, 0.52, col)
            tx += 13
        c.create_text(tx, y1 + 60, anchor="w", fill=col,
                      font=(FONT, 8, "bold"), text=lbl)

        # название
        ty = y1 + 42 + ih + 22
        c.create_text(x1 + pad, ty, anchor="w", fill=FG,
                      font=(FONT, 12, "bold"),
                      text=self._fit(name or "Без названия",
                                     x2 - x1 - pad * 2))

        # характеристики построчно
        rows = []
        if w:
            rows.append(("Вес", f"{w:.3f} кг", SOFT))
        if ln:
            rows.append(("Длина", f"{ln} см", SOFT))
        if exp:
            rows.append(("Опыт", f"{exp:,}".replace(",", " "), EXP))
        rows.append(("Поймана", ts.strftime("%d.%m  %H:%M"), DIM))

        ry = ty + 26
        for lbl2, val, vcol in rows:
            if ry > y2 - 16:
                break
            c.create_text(x1 + pad, ry, anchor="w", fill=DIMDEEP,
                          font=(FONT, 9), text=lbl2)
            c.create_text(x2 - pad, ry, anchor="e", fill=vcol,
                          font=(FONT_NUM, 11) if vcol is EXP
                          else (FONT, 10), text=val)
            ry += 22
            c.create_line(x1 + pad, ry - 11, x2 - pad, ry - 11,
                          fill=FAINT)

    def _panel_species(self, x1, y1, x2, y2):
        c = self.cv
        self.panel(x1, y1, x2, y2)
        icon_fish(c, x1 + 26, y1 + 21, 0.7)
        c.create_text(x1 + 40, y1 + 20, anchor="w", fill=DIM,
                      font=(FONT, 9), text="Виды рыбы")

        top = self.stats.top_species(60)
        if not top:
            self._hint(x1 + 20, y1 + 52, x2 - 20, "названиях")
            return

        mx = top[0][1]
        row_h = 42          # выше строка — текст не липнет к полоске
        head = 50
        view = max(1, int((y2 - y1 - head - 12) // row_h))
        total = len(top)
        self.scroll_max[0] = max(0, total - view) * row_h
        off = min(self.scroll.get(0, 0) // row_h, max(0, total - view))

        pad = 20
        bx1 = x1 + pad
        bx2 = x2 - pad          # полоска во всю ширину панели

        yy = y1 + head
        for name, n in top[off:off + view]:
            # Название слева, счётчик справа — обе подписи НАД полоской,
            # чтобы цифра не наезжала на неё и читалась сразу.
            c.create_text(bx1, yy, anchor="w", fill=PALE,
                          font=(FONT, 10),
                          text=self._fit(name or "Без названия",
                                         bx2 - bx1 - 46))
            c.create_text(bx2, yy, anchor="e", fill=SOFT,
                          font=(FONT_NUM, 11), text=str(n))
            by = yy + 15
            self._well(bx1, by, bx2, by + 6, 3)
            w = (bx2 - bx1) * (n / mx)
            if w > 4:
                # углы капсулы залиты цветом ванночки: шва не видно
                img = self._bar_img(int(w), 6, SINK)
                if img is not None:
                    c.create_image(bx1, by, anchor="nw", image=img)
                else:
                    round_rect(c, bx1, by, bx1 + w, by + 6, 3,
                               fill=ACCENT, outline="")
            yy += row_h

        self._scrollbar(x2 - 6, y1 + head - 8, y2 - 12,
                        total * row_h, view * row_h, off * row_h)

    def _panel_records(self, x1, y1, x2, y2):
        c = self.cv
        self.panel(x1, y1, x2, y2)
        c.create_text(x1 + 20, y1 + 20, anchor="w", fill=DIM,
                      font=(FONT, 9), text="Рекорды по весу")
        recs = self.stats.records(50)
        if not recs:
            self._hint(x1 + 20, y1 + 52, x2 - 20)
            return

        row_h = 30
        head = 46
        view = int((y2 - y1 - head - 10) // row_h)
        yy = y1 + head
        for i, rec in enumerate(recs[:view]):
            name, w = rec[1], rec[2]
            kind = rec[5] if len(rec) > 5 else ""
            medal = (GOLD, "#C9D4DE", "#C98A5B")[i] if i < 3 else CHECKLINE
            c.create_oval(x1 + 20, yy + 4, x1 + 30, yy + 14,
                          fill=medal, outline="")
            if kind == "trophy":
                icon_star(c, x1 + 42, yy + 9, 0.5, GOLD)
                tx = x1 + 54
            elif kind == "zachet":
                icon_check(c, x1 + 42, yy + 9, 0.5, GREEN)
                tx = x1 + 54
            else:
                tx = x1 + 40
            c.create_text(tx, yy + 9, anchor="w", fill=PALE,
                          font=(FONT, 10),
                          text=self._fit(name or "Без названия",
                                         x2 - tx - 96))
            c.create_text(x2 - 20, yy + 9, anchor="e", fill=GOLD,
                          font=(FONT_NUM, 12), text=f"{w:.3f} кг")
            yy += row_h

    def _hint(self, x, y, xmax, what="весе"):
        """Подсказка, когда данных ещё нет.

        Текст зависит от того, работает ли распознавание: если оно
        вообще не запускалось, советовать калибровку бессмысленно.
        """
        c = self.cv
        log = os.path.join(self.data_dir(), "ocr_debug.log")
        if not os.path.exists(log):
            msg = ("Распознавание улова не запущено.\n"
                   "Запусти бота — оно поднимется само,\n"
                   "либо открой ocr_watch.pyw вручную.")
        elif not self.stats.fish:
            msg = ("Ждём первый улов.\n"
                   "Данные появятся после поимки рыбы.")
        else:
            msg = (f"Уловы есть, но нет данных о {what}.\n"
                   "Проверь зоны: python ocr_watch.py --calibrate")
        c.create_text(x, y, anchor="nw", fill=DIMDEEP, font=(FONT, 9),
                      width=max(120, xmax - x), text=msg)

    # ------------------------------------------------ галерея
    GAL_SORTS = (("time", "По дате"), ("weight", "По весу"),
                 ("exp", "По опыту"), ("name", "По названию"))

    def _gallery_rows(self):
        """Снимки после фильтра и сортировки."""
        rows = [f for f in getattr(self.stats, "fish", [])
                if len(f) > 4 and f[4]]
        if self.gal_filter != "all":
            rows = [r for r in rows
                    if (r[5] if len(r) > 5 else "") == self.gal_filter]
        order = {"trophy": 3, "zachet": 2, "small": 1, "": 0}
        keys = {
            "time": lambda r: r[0].timestamp(),
            "weight": lambda r: r[2] or 0.0,
            "exp": lambda r: (r[3] if len(r) > 3 else 0) or 0,
            "name": lambda r: (r[1] or "").lower(),
            "kind": lambda r: order.get(r[5] if len(r) > 5 else "", 0),
        }
        rows.sort(key=keys.get(self.gal_sort, keys["time"]),
                  reverse=self.gal_desc)
        return rows

    def _gallery(self, x1, y1, x2, y2):
        """Карточки пойманной рыбы: фильтры, сортировка, страницы."""
        c = self.cv
        self._gal_ui = []
        self._gal_hit = []
        self._gal_imgs = getattr(self, "_gal_imgs", {})

        rows = self._gallery_rows()
        total_all = len([f for f in getattr(self.stats, "fish", [])
                         if len(f) > 4 and f[4]])

        # ---------- панель управления ----------
        bar = y1
        fx = float(x1)
        for key, label, icn in self.JR_FILTERS:
            on = (self.gal_filter == key)
            press = (self._gal_press == key)
            fnt = (FONT, 9, "bold") if on else (FONT, 9)
            w = self._chip_w(label, fnt)
            col = (GOLD if key == "trophy" else GREEN if key == "zachet"
                   else RED if key == "small" else ACCENT)
            d = 1.5 if press else 0
            if on or press:
                self._face(fx + d, bar + d, fx + w - d, bar + 30 - d, 15,
                           on=True)
            self._chip_content(fx, w, bar + 15, label, fnt,
                               col if on else MUTE,
                               _ICONS.get(icn, icon_fish), col, 0.52)
            self._gal_ui.append((fx, bar, fx + w, bar + 30,
                                 lambda k=key: self._gal_set_filter(k),
                                 f"gal_f_{key}", "hand2"))
            # Зона подсветки: без неё было непонятно, что чип кликабелен.
            self._hot_btns[f"gal_f_{key}"] = (fx, bar, fx + w, bar + 30,
                                              col, col, 15)
            fx += w + 6

        # сортировка
        sx = fx + 14
        c.create_text(sx, bar + 15, anchor="w", fill=DIM,
                      font=(FONT, 8), text="Сортировка:")
        sx += self._text_w("Сортировка:", (FONT, 8)) + 10
        for key, label in self.GAL_SORTS:
            on = (self.gal_sort == key)
            fnt = (FONT, 9, "bold") if on else (FONT, 9)
            # Стрелка направления живёт в правом слоте капсулы (12 px),
            # подпись центрируется между ним и левым полем.
            w = self._chip_w(label, fnt, tail=12, icon=False) + 4
            if on:
                self._face(sx, bar + 3, sx + w, bar + 27, 12, on=True)
            self._chip_content(
                sx, w, bar + 15, label, fnt, ACCENT if on else SOFT,
                tail_fn=lambda cc, ccx, cy, o=on: icon_sort(
                    cc, ccx, cy, 0.44, ACCENT if o else HOTFILL,
                    self.gal_desc, active=o),
                tail=12)
            self._gal_ui.append((sx, bar + 3, sx + w, bar + 27,
                                 lambda k=key: self._gal_set_sort(k),
                                 f"gal_s_{key}", "hand2"))
            self._hot_btns[f"gal_s_{key}"] = (sx, bar + 3, sx + w,
                                              bar + 27, ACCENT, ACCENT, 12)
            sx += w + 8

        # ---------- кнопки справа ----------
        bx2 = x2
        if self.gal_pick:
            # режим выбора: удалить, выбрать всё, отмена
            n_sel = len(self.gal_sel)
            if n_sel:
                lbl = f"Удалить ({n_sel})"
                w = self._chip_w(lbl, (FONT, 9, "bold")) + 2
                round_rect(c, bx2 - w, bar, bx2, bar + 30, 8,
                           fill="#5B1F24", outline="")
                round_outline(c, bx2 - w, bar, bx2, bar + 30, 8, RED)
                self._chip_content(bx2 - w, w, bar + 15, lbl,
                                   (FONT, 9, "bold"), "#FFD9D9",
                                   icon_trash, REDSOFT, 0.55)
                self._gal_ui.append((bx2 - w, bar, bx2, bar + 30,
                                     self._gal_delete_selected,
                                     "gal_del", "hand2"))
                self._hot_btns["gal_del"] = (bx2 - w, bar, bx2, bar + 30,
                                             "#C43D2E", "#FF7A6B", 8)
                bx2 -= w + 8

            # «Выбрать всё» берёт только текущую страницу — так и просили
            page_keys = {r[0] for r in self._gal_page_rows()}
            all_on = bool(page_keys) and page_keys <= self.gal_sel
            lbl = "Снять всё" if all_on else "Выбрать всё"
            w = self._chip_w(lbl, (FONT, 9)) + 2
            self._face(bx2 - w, bar, bx2, bar + 30, 8)
            self._chip_content(
                bx2 - w, w, bar + 15, lbl, (FONT, 9), SOFT,
                lambda cc, ccx, cy, s, _cl, a=all_on: icon_checkbox(
                    cc, ccx, cy, 0.6, ACCENT if a else DIMDEEP, a))
            self._gal_ui.append((bx2 - w, bar, bx2, bar + 30,
                                 self._gal_toggle_page, "gal_all", "hand2"))
            self._hot_btns["gal_all"] = (bx2 - w, bar, bx2, bar + 30,
                                         ACCENT, ACCENT, 8)
            bx2 -= w + 8

            lbl = "Отмена"
            w = self._chip_w(lbl, (FONT, 9), icon=False) + 6
            self._face(bx2 - w, bar, bx2, bar + 30, 8)
            self._chip_content(bx2 - w, w, bar + 15, lbl, (FONT, 9), SOFT)
            self._gal_ui.append((bx2 - w, bar, bx2, bar + 30,
                                 self._gal_pick_off, "gal_cancel", "hand2"))
            self._hot_btns["gal_cancel"] = (bx2 - w, bar, bx2, bar + 30,
                                            HOTEDGE, MID, 8)
            bx2 -= w + 8
        else:
            lbl = "Очистить"
            w = self._chip_w(lbl, (FONT, 9)) + 2
            self._face(bx2 - w, bar, bx2, bar + 30, 9)
            self._chip_content(bx2 - w, w, bar + 15, lbl, (FONT, 9),
                               SOFT, icon_trash, MID, 0.5)
            # Подсветку рисует быстрый слой — мгновенно, без пересчёта
            # всего кадра.
            self._hot_btns["gal_clean"] = (bx2 - w, bar, bx2, bar + 30,
                                           "#C43D2E", "#FF7A6B", 9)
            self._gal_ui.append((bx2 - w, bar, bx2, bar + 30,
                                 self._gal_cleanup_dialog,
                                 "gal_clean", "hand2"))
            bx2 -= w + 8

        # сколько места занимают снимки. Выводим, только если строка
        # управления не упёрлась в кнопки справа — иначе подпись
        # наезжала на последний чип сортировки (особенно на светлой
        # теме, где капсулы стали чуть просторнее).
        mb = self._photos_size_mb()
        if mb:
            _t = f"{total_all} снимков · {mb:.0f} МБ"
            if bx2 - self._text_w(_t, (FONT, 8)) - 12 > sx:
                c.create_text(bx2 - 6, bar + 15, anchor="e", fill=DIMDEEP,
                              font=(FONT, 8), text=_t)

        # ---------- сетка карточек ----------
        top = bar + 42
        bottom = y2 - 34
        if not rows:
            self.panel(x1, top, x2, bottom)
            msg = ("Пока пусто. Здесь появятся фото пойманной рыбы."
                   if not total_all
                   else "Ничего не найдено — измени фильтр.")
            c.create_text(x1 + 24, top + 40, anchor="nw", fill=DIM,
                          font=(FONT, 10), width=x2 - x1 - 48, text=msg)
            self._gal_pages = 1
            return

        gap = 12
        cols = max(1, int((x2 - x1 + gap) // (240 + gap)))
        cw = (x2 - x1 - gap * (cols - 1)) / cols
        # 192 вместо 216: панель фильтров и полоса страниц забрали
        # высоту, и третий ряд переставал помещаться — внизу зияла
        # пустая полоса в целый ряд.
        ch = 192
        step = ch + gap
        rows_fit = max(1, int((bottom - top + gap) // step))
        per = cols * rows_fit

        total = len(rows)
        pages = max(1, -(-total // per))
        self.gal_page = max(0, min(self.gal_page, pages - 1))
        self._gal_pages = pages
        self._gal_per = per
        off = self.gal_page * per

        self._gal_shown = rows[off:off + per]
        for i, rec in enumerate(self._gal_shown):
            r, col = divmod(i, cols)
            cx = x1 + col * (cw + gap)
            cy = top + r * step
            self._gal_card(cx, cy, cx + cw, cy + ch, rec)
            self._gal_hit.append((cx, cy, cx + cw, cy + ch, rec))
            if self.gal_pick:
                sel = rec[0] in self.gal_sel
                # затемняем невыбранные, чтобы отмеченные читались сразу
                if sel:
                    round_outline(c, cx, cy, cx + cw, cy + ch,
                                  R_CARD, ACCENT, 2)
                icon_checkbox(c, cx + cw - 20, cy + 18, 0.62,
                              ACCENT if sel else DIMDEEP, sel)

        # ---------- страницы ----------
        first = off + 1
        last = min(total, off + per)
        c.create_text(x1, y2 - 14, anchor="w", fill=DIMDEEP,
                      font=(FONT, 8),
                      text=f"{first}–{last} из {total}"
                           + (f"   ·   всего снимков: {total_all}"
                              if total != total_all else ""))
        self._pager(x1, x2, y2 - 14, pages, self.gal_page,
                    self._gal_goto, self._gal_ui, "gal_p")

    def _gal_card(self, x1, y1, x2, y2, rec):
        c = self.cv
        ts, name, w = rec[0], rec[1], rec[2]
        exp = rec[3] if len(rec) > 3 else 0
        photo = rec[4] if len(rec) > 4 else ""
        kind = rec[5] if len(rec) > 5 else ""
        ln = rec[6] if len(rec) > 6 else 0

        # Карточка — общая неоморфная панель, как всё окно. Раньше
        # у незачёта и трофея были собственные тёмные лица: на светлой
        # теме они оставались чужеродными тёмными окошками, и тёмный
        # текст названия тонул на них начисто. У трофеев по-прежнему
        # золотой ореол.
        if kind == "trophy":
            self.panel(x1, y1, x2, y2, glow=GOLD, glow_k=0.45)
        else:
            self.panel(x1, y1, x2, y2)

        edge = (GOLD if kind == "trophy" else
                GREEN if kind == "zachet" else
                RED if kind == "small" else CHECKLINE)
        round_rect(c, x1 + 2, y1 + 14, x1 + 5, y2 - 14, 1.5,
                   fill=edge, outline="")

        ph = 104
        # Подсветка под курсором. Масштабировать сам снимок нельзя:
        # каждый новый размер — это новая миниатюра через LANCZOS,
        # а перерисовывается вся страница целиком. Пятнадцать карточек
        # превращали плавное наведение в слайд-шоу по 3-4 секунды.
        # Рамка и подложка дают тот же эффект «живого» элемента,
        # но не трогают тяжёлую картинку.
        # Область снимка запоминаем — подсветку под курсором рисует
        # быстрый слой поверх кадра (см. _paint_hover). Через полную
        # перерисовку это стоило бы десятки миллисекунд на каждое
        # движение мыши, отсюда и были задержки в пару секунд.
        img = self._photo(photo, int(x2 - x1 - 28), ph)
        if img:
            c.create_image((x1 + x2) / 2, y1 + 14 + ph / 2, image=img)
            self._hot_zones[f"gal_{ts.timestamp()}"] = (
                x1 + 12, y1 + 12, x2 - 12, y1 + 16 + ph)
        else:
            self._well(x1 + 14, y1 + 14, x2 - 14, y1 + 14 + ph, 8)
            icon_fish(c, (x1 + x2) / 2, y1 + 8 + ph / 2, 2.4, PH_FISH)
            c.create_text((x1 + x2) / 2, y1 + ph, fill=FAINT2,
                          font=(FONT, 8), text="нет фото")

        # Значок и подпись категории: только иконки было мало —
        # непонятно, что означает символ.
        # Плашка категории поверх фото — читается на любом снимке.
        if kind == "trophy":
            lbl, col, ico = "ТРОФЕЙ", GOLD, icon_star
        elif kind == "zachet":
            lbl, col, ico = "ЗАЧЁТНАЯ", GREEN, icon_check
        elif kind == "small":
            lbl, col, ico = "НЕЗАЧЁТ", RED, icon_cross
        else:
            lbl, col, ico = "НЕ ОПРЕДЕЛЕНО", DIM, None
        bw = 20 + self._text_w(lbl, (FONT, 8, "bold")) + (14 if ico else 0)
        self._well(x1 + 12, y1 + 18, x1 + 12 + bw, y1 + 38, 10)
        tx = x1 + 22
        if ico:
            ico(c, tx, y1 + 28, 0.52, col)
            tx += 13
        c.create_text(tx, y1 + 28, anchor="w", fill=col,
                      font=(FONT, 8, "bold"), text=lbl)

        ty = y1 + 14 + ph + 18
        c.create_text(x1 + 16, ty, anchor="w", fill=FG,
                      font=(FONT, 10, "bold"),
                      text=self._fit(name or "Без названия",
                                     x2 - x1 - 32))
        parts = []
        if w:
            parts.append(f"{w:.3f} кг")
        if ln:
            parts.append(f"{ln} см")
        c.create_text(x1 + 16, ty + 20, anchor="w", fill=SOFT,
                      font=(FONT, 9), text="   ".join(parts) or "—")
        if exp:
            c.create_text(x2 - 16, ty + 16, anchor="e", fill=EXP,
                          font=(FONT_NUM, 11),
                          text=f"{exp:,}".replace(",", " "))
            c.create_text(x2 - 16, ty + 30, anchor="e", fill=CHECKLINE,
                          font=(FONT, 7), text="опыта")
        # Дата и подсказка раньше стояли на одной строке и налезали
        # друг на друга: в карточку шириной 216 px обе не помещаются.
        # Подсказку показываем, только если реально остаётся место.
        date_txt = ts.strftime("%d.%m.%Y  %H:%M")
        c.create_text(x1 + 16, ty + 40, anchor="w", fill=CHECKLINE,
                      font=(FONT, 8), text=date_txt)
        if photo:
            hint = "открыть"
            need = (self._text_w(date_txt, (FONT, 8))
                    + self._text_w(hint, (FONT, 8)) + 44)
            if need <= (x2 - x1):
                c.create_text(x2 - 16, ty + 40, anchor="e", fill=FAINT2,
                              font=(FONT, 8), text=hint)

    def _scrollbar(self, x, y1, y2, total, view, off):
        """Тонкая полоса прокрутки справа от панели."""
        if total <= view:
            return
        c = self.cv
        h = max(28, (y2 - y1) * view / total)
        pos = y1 + (y2 - y1 - h) * (off / max(1, total - view))
        round_rect(c, x, y1, x + 4, y2, 2, fill=SINK, outline="")
        round_rect(c, x, pos, x + 4, pos + h, 2, fill=SCROLL, outline="")

    def _fit(self, text, px):
        """Обрезает строку по ширине в пикселях, а не по числу символов."""
        if not text:
            return ""
        max_chars = max(6, int(px / 7.2))
        return text if len(text) <= max_chars else text[:max_chars - 1] + "…"

    def _photo(self, fname, w, h):
        """Загружает и кэширует миниатюру. Возвращает PhotoImage или None."""
        if not fname:
            return None
        # Размер округляем до 4 пикселей: при плавном увеличении под
        # курсором иначе рождался бы новый файл кэша на каждый кадр,
        # и за минуту наведения в памяти оседали сотни картинок.
        w, h = (int(w) // 4) * 4, (int(h) // 4) * 4
        key = f"{fname}|{w}x{h}"
        cache = getattr(self, "_gal_imgs", None)
        if cache is None:
            cache = self._gal_imgs = {}
        if key in cache:
            return cache[key]
        if len(cache) > 400:            # страховка от разрастания
            cache.clear()
        path = os.path.join(os.path.dirname(self.csv_path), "photos", fname)
        if not os.path.exists(path):
            cache[key] = None
            return None
        try:
            from PIL import Image, ImageTk
            im = Image.open(path)
            im.thumbnail((w, h), Image.LANCZOS)
            img = ImageTk.PhotoImage(im)
            # Сглаживающему слою нужен исходник: он рисует картинку
            # сам, в увеличенном масштабе, а не отдаёт её Tk.
            img._pil_src = im.convert("RGB")
        except Exception:
            try:
                img = tk.PhotoImage(file=path)
                # без Pillow уменьшаем целочисленно
                k = max(1, img.width() // max(1, w), img.height() // max(1, h))
                if k > 1:
                    img = img.subsample(k, k)
            except Exception:
                img = None
        cache[key] = img
        return img

    # ------------------------------------------------ журнал
    JR_COLS = (("time", "Время"), ("name", "Рыба"), ("kind", "Категория"),
               ("weight", "Вес"), ("length", "Длина"), ("exp", "Опыт"))
    # Порядок как в образце: Все, Зачётные, Незачёт, Трофеи
    JR_FILTERS = (("all", "Все", "list"), ("zachet", "Зачётные", "check"),
                  ("small", "Незачёт", "xmark"), ("trophy", "Трофеи", "star"))

    def _jr_weight_range(self):
        """Границы ползунка веса — по всем записям, что есть.

        Считаем без учёта текущего фильтра: иначе шкала прыгала бы
        при каждом переключении категории.
        """
        ws = [f[2] for f in getattr(self.stats, "fish", []) if f[2]]
        if not ws:
            return 0.0, 1.0
        lo, hi = min(ws), max(ws)
        if hi - lo < 0.05:
            hi = lo + 0.05
        return lo, hi

    def _jr_slider_geo(self, left, right, bar):
        """Дорожка ползунка веса: (начало, конец, Y по центру).

        Ползунок живёт в свободном промежутке между чипами фильтров и
        кнопкой «Выбрать всё» — в той же строке, а не под ней. Слева
        оставляем место под подпись «Вес, кг», справа — под значения
        диапазона и крестик сброса.
        """
        lab = 52                      # «Вес, кг»
        val = 92                      # «0.06 – 5.05» и крестик
        tx1 = left + lab
        tx2 = right - val
        if tx2 - tx1 < 90:            # окно сузили — ползунок прячем
            return None
        return tx1, min(tx2, tx1 + 260), bar + 15

    def _journal_rows(self):
        """Записи журнала после фильтра, поиска и сортировки."""
        rows = []
        for rec in getattr(self.stats, "fish", []):
            ts, name, w = rec[0], rec[1], rec[2]
            exp = rec[3] if len(rec) > 3 else 0
            photo = rec[4] if len(rec) > 4 else ""
            kind = rec[5] if len(rec) > 5 else ""
            ln = rec[6] if len(rec) > 6 else 0
            # Снимок носим с собой: по клику на названии открываем фото,
            # а искать запись заново по метке времени — лишняя работа.
            rows.append((ts, name, w, exp, kind, ln, photo))

        if self.jr_filter != "all":
            rows = [r for r in rows if r[4] == self.jr_filter]
        q = self.jr_query.strip().lower()
        if q:
            rows = [r for r in rows if q in (r[1] or "").lower()]

        # Диапазон веса. Записи без веса показываем только когда
        # ползунок стоит на всю ширину — иначе они молча исчезали бы,
        # хотя пользователь про них не спрашивал.
        lo, hi = self._jr_weight_range()
        if (self.jr_wmin is not None or self.jr_wmax is not None):
            a = self.jr_wmin if self.jr_wmin is not None else lo
            b = self.jr_wmax if self.jr_wmax is not None else hi
            rows = [r for r in rows if r[2] is not None and a <= r[2] <= b]

        # Пустые значения не должны перемешиваться с числами, поэтому
        # у каждого ключа есть безопасная замена.
        order = {"trophy": 3, "zachet": 2, "small": 1, "": 0}
        keys = {
            "time": lambda r: r[0].timestamp(),
            "name": lambda r: (r[1] or "").lower(),
            "kind": lambda r: order.get(r[4], 0),
            "weight": lambda r: r[2] or 0.0,
            "length": lambda r: r[5] or 0,
            "exp": lambda r: r[3] or 0,
        }
        rows.sort(key=keys.get(self.jr_sort, keys["time"]),
                  reverse=self.jr_desc)
        return rows

    def _journal(self, x1, y1, x2, y2):
        """Список уловов: поиск, фильтры, сортировка, выделение."""
        c = self.cv
        self.panel(x1, y1, x2, y2)
        self._jr_hit = []          # кликабельные области этой вкладки

        rows = self._journal_rows()
        total_all = len(getattr(self.stats, "fish", []))

        # ---------- строка управления ----------
        bar = y1 + 16
        # поиск
        sx1, sx2 = x1 + 20, x1 + 250
        act = self.jr_search_on
        self._well(sx1, bar, sx2, bar + 30, 8)
        if act:
            round_outline(c, sx1, bar, sx2, bar + 30, 8, ACCENT)
        icon_search(c, sx1 + 16, bar + 15, 0.62,
                    ACCENT if act else DIMDEEP)
        q = self.jr_query
        if q:
            txt, col = self._fit(q, sx2 - sx1 - 58), FG
        else:
            txt, col = ("Поиск по названию" if not act else ""), CHECKLINE
        c.create_text(sx1 + 30, bar + 15, anchor="w", fill=col,
                      font=(FONT, 9), text=txt)
        if act:                     # мигающий курсор не нужен — просто черта
            cw = self._text_w(txt, (FONT, 9))
            c.create_line(sx1 + 32 + cw, bar + 8,
                          sx1 + 32 + cw, bar + 22, fill=ACCENT)
        if q:
            bx = sx2 - 18
            icon_cross(c, bx, bar + 15, 0.42, DIM)
            self._jr_hit.append((bx - 9, bar + 6, bx + 9, bar + 24,
                                 self._jr_clear_query, None, "hand2"))
        self._jr_hit.append((sx1, bar, sx2 - 24, bar + 30,
                             self._jr_focus_search, None, "xterm"))

        # Фильтры по категории. Значок всегда яркий и цветной, подпись
        # справа от него. Капсула-подложка появляется только у
        # выбранного — так на панели нет лишних рамок.
        fx = float(sx2 + 14)
        for key, label, icn in self.JR_FILTERS:
            on = (self.jr_filter == key)
            press = (self._jr_press == key)     # кадр «нажатия»
            fnt = (FONT, 9, "bold") if on else (FONT, 9)
            w = self._chip_w(label, fnt)
            col = (GOLD if key == "trophy" else GREEN if key == "zachet"
                   else RED if key == "small" else ACCENT)
            # при нажатии капсула чуть поджимается — эффект «вдавливания»
            d = 1.5 if press else 0
            if on or press:
                self._face(fx + d, bar + d, fx + w - d, bar + 30 - d, 15,
                           on=True)
            self._chip_content(fx, w, bar + 15, label, fnt,
                               col if on else MUTE,
                               _ICONS.get(icn, icon_fish), col, 0.52)
            self._jr_hit.append((fx, bar, fx + w, bar + 30,
                                 lambda k=key: self._jr_set_filter(k),
                                 f"jr_f_{key}", "hand2"))
            self._hot_btns[f"jr_f_{key}"] = (fx, bar, fx + w, bar + 30,
                                             col, col, 15)
            fx += w + 6

        # кнопки справа: выделить всё / снять / удалить
        n_sel = len(self.jr_sel)
        bx2 = x2 - 20
        if n_sel:
            lbl = f"Удалить ({n_sel})"
            w = self._chip_w(lbl, (FONT, 9, "bold")) + 2
            round_rect(c, bx2 - w, bar, bx2, bar + 30, 8,
                       fill="#5B1F24", outline="")
            round_outline(c, bx2 - w, bar, bx2, bar + 30, 8, RED)
            self._chip_content(bx2 - w, w, bar + 15, lbl,
                               (FONT, 9, "bold"), "#FFD9D9",
                               icon_trash, REDSOFT, 0.55)
            self._jr_hit.append((bx2 - w, bar, bx2, bar + 30,
                                 self._jr_delete_selected,
                                 "jr_del", "hand2"))
            bx2 -= w + 8

        if n_sel == 1:
            # Ровно одна запись — можно переименовать. Заодно это
            # обучение OCR: пара «как записал бот -> как должно быть»
            # сохраняется в names_map.txt, и следующие такие же
            # опечатки правятся сами ещё до записи в журнал.
            lbl = "Переименовать"
            w = self._chip_w(lbl, (FONT, 9)) + 2
            self._face(bx2 - w, bar, bx2, bar + 30, 8)
            self._chip_content(bx2 - w, w, bar + 15, lbl, (FONT, 9),
                               SOFT, icon_pen, ACCENT, 0.55)
            self._jr_hit.append((bx2 - w, bar, bx2, bar + 30,
                                 self._jr_rename_selected,
                                 "jr_ren", "hand2"))
            self._hot_btns["jr_ren"] = (bx2 - w, bar, bx2, bar + 30,
                                        ACCENT, ACCENT, 8)
            bx2 -= w + 8

        vis_keys = {r[0] for r in rows}
        all_on = bool(vis_keys) and vis_keys <= self.jr_sel
        lbl = "Снять всё" if all_on else "Выбрать всё"
        w = self._chip_w(lbl, (FONT, 9)) + 2
        self._face(bx2 - w, bar, bx2, bar + 30, 8)
        self._chip_content(
            bx2 - w, w, bar + 15, lbl, (FONT, 9), SOFT,
            lambda cc, ccx, cy, s, _cl, a=all_on: icon_checkbox(
                cc, ccx, cy, 0.6, ACCENT if a else DIMDEEP, a))
        self._jr_hit.append((bx2 - w, bar, bx2, bar + 30,
                             self._jr_toggle_all, "jr_all", "hand2"))
        btn_left = bx2 - w          # левый край самой левой кнопки

        # ---------- ползунок диапазона веса ----------
        # Стоит в одной строке с фильтрами, в промежутке до кнопки
        # «Выбрать всё»: отдельная строка под панелью выглядела как
        # оторванный от всего элемент.
        self._jr_track = None
        geo = self._jr_slider_geo(fx + 10, btn_left - 16, bar)
        if geo:
            wlo, whi = self._jr_weight_range()
            a = self.jr_wmin if self.jr_wmin is not None else wlo
            b = self.jr_wmax if self.jr_wmax is not None else whi
            tx1, tx2, ty = geo
            touched = (self.jr_wmin is not None or self.jr_wmax is not None)
            c.create_text(tx1 - 10, ty, anchor="e",
                          fill=SOFT if touched else DIM,
                          font=(FONT, 8), text="Вес, кг")
            span = max(1e-6, whi - wlo)
            px1 = tx1 + (tx2 - tx1) * (a - wlo) / span
            px2 = tx1 + (tx2 - tx1) * (b - wlo) / span
            self._well(tx1, ty - 3, tx2, ty + 3, 3)
            round_rect(c, px1, ty - 3, px2, ty + 3, 3,
                       fill=ACCENT, outline="")
            for hx, tag in ((px1, "lo"), (px2, "hi")):
                hot = (self._jr_drag == tag
                       or self._hover_btn == f"jr_s_{tag}")
                c.create_oval(hx - 7, ty - 7, hx + 7, ty + 7,
                              fill=HANDLE,
                              outline=ACCENT if hot else CHECKLINE, width=2)
                self._jr_hit.append((hx - 9, ty - 10, hx + 9, ty + 10,
                                     lambda: None, f"jr_s_{tag}",
                                     "sb_h_double_arrow"))
            c.create_text(tx2 + 10, ty, anchor="w",
                          fill=SOFT if touched else DIM,
                          font=(FONT_NUM, 9), text=f"{a:.2f} – {b:.2f}")
            self._jr_track = (tx1, tx2, ty, wlo, whi)
            if touched:
                rx = tx2 + 78
                icon_cross(c, rx, ty, 0.42, DIM)
                self._jr_hit.append((rx - 9, ty - 10, rx + 9, ty + 10,
                                     self._jr_reset_weight, None, "hand2"))

        # ---------- заголовки столбцов ----------
        head_y = bar + 46
        cb = x1 + 20                     # колонка флажков
        cols = self._jr_col_x(x1, x2)
        for (key, label), cxp in zip(self.JR_COLS, cols):
            on = (self.jr_sort == key)
            hov = (self._hover_btn == f"jr_h_{key}")
            head = label.upper()
            c.create_text(cxp, head_y, anchor="w",
                          fill=ACCENT if on else (SOFT if hov else DIM),
                          font=(FONT, 8, "bold"), text=head)
            aw = self._text_w(head, (FONT, 8, "bold"))
            # Стрелки рисуем у КАЖДОГО столбца: пара бледных значит
            # «сюда тоже можно нажать», одна яркая — текущий порядок.
            icon_sort(c, cxp + aw + 9, head_y, 0.5,
                      ACCENT if on else (MUTE if hov else HOTFILL),
                      self.jr_desc, active=on)
            self._jr_hit.append((cxp - 6, head_y - 11,
                                 cxp + aw + 20, head_y + 11,
                                 lambda k=key: self._jr_set_sort(k),
                                 f"jr_h_{key}", "hand2"))
            self._hot_btns[f"jr_h_{key}"] = (cxp - 8, head_y - 12,
                                             cxp + aw + 22, head_y + 12,
                                             ACCENT, ACCENT, 6)
        c.create_line(x1 + 20, head_y + 15, x2 - 20, head_y + 15, fill=LINE)

        # ---------- строки ----------
        row_h = 30
        top = head_y + 24
        bottom = y2 - 56          # ниже — полоса страниц
        per = max(1, int((bottom - top) // row_h))
        total = len(rows)
        pages = max(1, -(-total // per))       # округление вверх
        self.jr_page = max(0, min(self.jr_page, pages - 1))
        off = self.jr_page * per
        view = per
        self.scroll_max[2] = 0     # прокрутки в журнале больше нет
        self._jr_per = per
        self._jr_pages = pages

        if not rows:
            msg = ("Пока пусто." if not total_all
                   else "Ничего не найдено — измени фильтр или запрос.")
            c.create_text(x1 + 20, top + 16, anchor="w", fill=DIM,
                          font=(FONT, 10), text=msg)
        yy = top + 6
        for rec in rows[off:off + view]:
            ts, name, w, exp, kind, ln, photo = rec
            sel = ts in self.jr_sel
            if sel:
                round_rect(c, x1 + 12, yy - 13, x2 - 12, yy + 15, 6,
                           fill="#16324A", outline="")
            # флажок
            icon_checkbox(c, cb + 6, yy, 0.56,
                          ACCENT if sel else CHECKLINE, sel)
            self._jr_hit.append((cb - 4, yy - 13, cb + 18, yy + 15,
                                 lambda t=ts: self._jr_toggle_one(t),
                                 None, "hand2"))

            c.create_text(cols[0], yy, anchor="w", fill=DIM,
                          font=(FONT, 9), text=ts.strftime("%d.%m %H:%M:%S"))
            col = (GOLD if kind == "trophy" else GREEN if kind == "zachet"
                   else RED if kind == "small" else PALE)
            # Название — ссылка на снимок. Кликабельно только когда файл
            # реально записан: иначе клик молча ничего не делал бы.
            nm_txt = self._fit(name or "Без названия",
                               cols[2] - cols[1] - 14)
            has_photo = bool(photo)
            c.create_text(cols[1], yy, anchor="w", fill=col,
                          font=(FONT, 10), text=nm_txt)
            if has_photo:
                nw = self._text_w(nm_txt, (FONT, 10))
                key = f"jr_n_{ts.timestamp()}"
                self._jr_hit.append(
                    (cols[1] - 4, yy - 12, cols[1] + nw + 6, yy + 12,
                     lambda r=rec: self._jr_open_photo(r), key, "hand2"))
                # Подсветку рисует быстрый слой поверх кадра. Раньше
                # название подсвечивалось прямо здесь, а значит требовало
                # полной перерисовки окна — отсюда задержка в секунды.
                self._hot_zones[key] = (cols[1] - 4, yy - 11,
                                        cols[1] + nw + 4, yy + 11)
            klbl = {"trophy": "Трофей", "zachet": "Зачётная",
                    "small": "Незачёт"}.get(kind, "—")
            if kind == "trophy":
                icon_star(c, cols[2] + 6, yy, 0.46, GOLD)
            elif kind == "zachet":
                icon_check(c, cols[2] + 6, yy, 0.46, GREEN)
            elif kind == "small":
                icon_cross(c, cols[2] + 6, yy, 0.46, RED)
            c.create_text(cols[2] + 17, yy, anchor="w", fill=col,
                          font=(FONT, 9), text=klbl)
            c.create_text(cols[3], yy, anchor="w", fill=SOFT,
                          font=(FONT, 9), text=f"{w:.3f} кг" if w else "—")
            c.create_text(cols[4], yy, anchor="w", fill=SOFT,
                          font=(FONT, 9), text=f"{ln} см" if ln else "—")
            c.create_text(cols[5], yy, anchor="w", fill=EXP,
                          font=(FONT_NUM, 10),
                          text=f"{exp:,}".replace(",", " ") if exp else "—")
            yy += row_h
            c.create_line(x1 + 20, yy - 14, x2 - 20, yy - 14, fill=FAINT)

        # ---------- страницы ----------
        self._jr_pager(x1, x2, y2 - 30, pages, total, per)

        # ---------- итог внизу ----------
        first = off + 1 if total else 0
        last = min(total, off + per)
        parts = [f"{first}–{last} из {total}"] if total else ["записей нет"]
        if total != total_all:
            parts.append(f"всего в журнале: {total_all}")
        if n_sel:
            parts.append(f"выбрано: {n_sel}")
        tw = sum(r[2] or 0 for r in rows)
        if tw:
            parts.append(f"вес: {tw:.2f} кг")
        te = sum(r[3] or 0 for r in rows)
        if te:
            parts.append(f"опыт: {te:,}".replace(",", " "))
        c.create_text(x1 + 20, y2 - 16, anchor="w", fill=DIMDEEP,
                      font=(FONT, 8), text="     ".join(parts))

    def _pager(self, x1, x2, y, pages, cur, goto, sink, tag):
        """Полоса страниц. Общая для журнала и галереи.

        sink — список зон клика той вкладки, tag — префикс имени для
        подсветки при наведении.
        """
        c = self.cv
        if pages <= 1:
            return

        # Номера страниц: соседи текущей + первая и последняя, разрывы
        # обозначаем многоточием — иначе на сотне страниц полоса уехала
        # бы за край окна.
        nums = sorted({0, pages - 1, cur, cur - 1, cur + 1}
                      & set(range(pages)))
        items, prev = [], None
        for n in nums:
            if prev is not None and n - prev > 1:
                items.append(None)
            items.append(n)
            prev = n

        w_total = 0
        for it in items:
            w_total += (30 if it is None
                        else max(26, 16 + self._text_w(str(it + 1),
                                                       (FONT, 9))) + 4)
        bx = (x1 + x2) / 2 - w_total / 2

        def arrow(px, to, enabled, name):
            col = SOFT if enabled else CHECKLINE
            self._face(px, y - 13, px + 26, y + 13, 7)
            _ICONS["angle"](c, px + 13, y, 0.78, col, name)
            if enabled:
                sink.append((px, y - 13, px + 26, y + 13,
                             lambda p=to: goto(p), None, "hand2"))

        arrow(bx - 62, 0, cur > 0, "first")
        arrow(bx - 32, cur - 1, cur > 0, "left")

        for it in items:
            if it is None:
                c.create_text(bx + 13, y, fill=CHECKLINE,
                              font=(FONT, 9), text="…")
                bx += 30
                continue
            w = max(26, 16 + self._text_w(str(it + 1), (FONT, 9)))
            on = (it == cur)
            if on or self._hover_btn == f"{tag}_{it}":
                self._face(bx, y - 13, bx + w, y + 13, 7, on=True)
            c.create_text(bx + w / 2, y, fill=ACCENT if on else SOFT,
                          font=(FONT, 9, "bold") if on else (FONT, 9),
                          text=str(it + 1))
            if not on:
                sink.append((bx, y - 13, bx + w, y + 13,
                             lambda p=it: goto(p), f"{tag}_{it}", "hand2"))
            bx += w + 4

        arrow(bx + 6, cur + 1, cur < pages - 1, "right")
        arrow(bx + 36, pages - 1, cur < pages - 1, "last")

    def _jr_pager(self, x1, x2, y, pages, total, per):
        """Страницы журнала."""
        if total:
            self._pager(x1, x2, y, pages, self.jr_page,
                        self._jr_goto, self._jr_hit, "jr_p")

    # --- действия галереи ---
    def _gal_set_filter(self, key):
        self.gal_filter = key
        self.gal_page = 0
        self._gal_press = key
        self.draw()
        self.after(90, self._gal_unpress)

    def _gal_unpress(self):
        if self._gal_press is not None:
            self._gal_press = None
            self.draw()

    def _gal_set_sort(self, key):
        if self.gal_sort == key:
            self.gal_desc = not self.gal_desc
        else:
            self.gal_sort = key
            self.gal_desc = (key != "name")
        self.gal_page = 0
        self.draw()

    def _gal_goto(self, page):
        self.gal_page = page
        self.draw()

    def _photos_dir(self):
        return os.path.join(self.data_dir(), "photos")

    def _photos_size_mb(self):
        """Сколько весит папка снимков. Считаем раз в 30 секунд.

        Обход папки на каждую перерисовку — лишняя работа с диском,
        а число меняется медленно.
        """
        now = time.time()
        cached = getattr(self, "_ph_size", None)
        if cached and now - cached[0] < 30:
            return cached[1]
        total = 0
        try:
            d = self._photos_dir()
            for fn in os.listdir(d):
                try:
                    total += os.path.getsize(os.path.join(d, fn))
                except OSError:
                    pass
        except OSError:
            pass
        mb = total / (1024 * 1024)
        self._ph_size = (now, mb)
        return mb

    # ------------------------------------------------ своё диалоговое окно
    def dialog(self, title, text, buttons, icon=None, width=460):
        """Окно вопроса в стиле программы.

        Системный messagebox выпадает белым прямоугольником с чужими
        шрифтами — на тёмном интерфейсе это выглядит инородно. Здесь
        то же самое, но своими руками.

        buttons — список (подпись, значение, вид). Вид: "primary",
        "danger" или "ghost". Возвращает значение нажатой кнопки
        (или None, если закрыли).
        """
        win = tk.Toplevel(self)
        win.withdraw()
        win.configure(bg=BG)
        win.transient(self)

        lines = text.split("\n")
        pad = 24
        head_h = 64 if icon else 52
        line_h = 19
        btn_h = 38
        H = head_h + len(lines) * line_h + 26 + btn_h + pad
        W = width

        tkcv = tk.Canvas(win, bg=BG, highlightthickness=0,
                         width=W, height=H)
        tkcv.pack(fill="both", expand=True)
        cv = SmoothCanvas(tkcv, BG) if SMOOTH else tkcv
        win._cv = cv

        res = {"v": None}
        zones = []
        state = {"hot": {}, "goal": {}, "job": None}

        def close(_e=None):
            try:
                win.grab_release()
            except Exception:
                pass
            try:
                win.destroy()
            except Exception:
                pass

        def pick(v):
            res["v"] = v
            close()

        def paint():
            cv.delete("all")
            round_rect(cv, 0, 0, W - 1, H - 1, 14, fill=DIALOG_BG,
                       outline="")
            round_outline(cv, 0, 0, W - 1, H - 1, 14, DIALOG_EDGE)

            tx = pad
            if icon:
                ic = {"trash": icon_trash, "shield": icon_shield,
                      "star": icon_star, "check": icon_check,
                      "cross": icon_cross}.get(icon)
                if ic:
                    col = RED if icon in ("trash", "cross") else ACCENT
                    ic(cv, pad + 10, 30, 0.85, col)
                    tx = pad + 30
            cv.create_text(tx, 30, anchor="w", fill=FG,
                           font=(FONT, 12, "bold"), text=title)

            yy = head_h + 4
            for ln in lines:
                bold = ln.startswith("**")
                s = ln.strip("*")
                cv.create_text(pad, yy, anchor="w",
                               fill=FG if bold else SOFT,
                               font=(FONT, 9, "bold") if bold
                               else (FONT, 9), text=s)
                yy += line_h

            del zones[:]
            bx = W - pad
            # Ключ подсветки — НОМЕР кнопки, а не её значение. У «Отмены»
            # значение None, и сравнение None == None давало ложное
            # совпадение: кнопка светилась, когда курсор был вообще
            # вне окна, а на само наведение не отзывалась.
            for idx in range(len(buttons) - 1, -1, -1):
                label, value, kind = buttons[idx]
                bw = 30 + self._text_w(label, (FONT, 9, "bold"))
                t = state["hot"].get(idx, 0.0)
                # Каждая кнопка светлеет ОТ СВОЕГО цвета. Раньше
                # «Отмена» была почти того же тона, что подсветка
                # соседей, и выглядело так, будто темнеет именно она,
                # а сама на курсор не отзывается.
                if kind == "danger":
                    base, hot_c, tc = "#7A2A22", "#E8503C", "#FFFFFF"
                elif kind == "primary":
                    base, hot_c, tc = ACTFACE, ACTHOT, "#FFFFFF"
                else:
                    base, hot_c, tc = CHIP2, NEUHOT, PALE
                g = 2.0 * t
                round_rect(cv, bx - bw - g, H - pad - btn_h - g,
                           bx + g, H - pad + g, 9,
                           fill=self._mix(base, hot_c, t), outline="")
                if t > 0.05:
                    # тонкая светлая рамка — видно, что кнопка «поднялась»
                    round_outline(cv, bx - bw - g, H - pad - btn_h - g,
                                  bx + g, H - pad + g, 9,
                                  self._mix(hot_c, "#FFFFFF", 0.35 * t),
                                  max(1, int(1 + t)))
                cv.create_text(bx - bw / 2, H - pad - btn_h / 2,
                               fill=(self._mix(tc, "#FFFFFF", t)
                                     if kind in ("danger", "primary")
                                     else tc),
                               font=(FONT, 9, "bold"), text=label)
                zones.append((bx - bw, H - pad - btn_h, bx, H - pad,
                              idx, value))
                bx -= bw + 10
            if SMOOTH:
                cv.flush(size=(W, H))

        def animate():
            state["job"] = None
            moving = False
            # Шаг крупный: окно диалога маленькое, но каждый кадр — это
            # всё равно пересчёт картинки в Pillow. Пять-шесть кадров
            # дают ощущение плавности и не грузят машину.
            for k, goal in state["goal"].items():
                cur = state["hot"].get(k, 0.0)
                if abs(cur - goal) > 0.06:
                    state["hot"][k] = cur + (goal - cur) * 0.45
                    moving = True
                else:
                    state["hot"][k] = goal
            t0 = time.perf_counter()
            paint()
            cost = (time.perf_counter() - t0) * 1000
            if moving:
                state["job"] = win.after(max(16, int(cost)), animate)

        def hover(e):
            hit = -1                      # -1 = курсор вне кнопок
            for zx1, zy1, zx2, zy2, i, _v in zones:
                if zx1 <= e.x <= zx2 and zy1 <= e.y <= zy2:
                    hit = i
                    break
            changed = False
            for i in range(len(buttons)):
                goal = 1.0 if i == hit else 0.0
                if state["goal"].get(i) != goal:
                    state["goal"][i] = goal
                    changed = True
            try:
                # именно >= 0: у первой кнопки индекс 0, и обычная
                # проверка «if hit» сочла бы её за отсутствие наведения
                tkcv.config(cursor="hand2" if hit >= 0 else "")
            except Exception:
                pass
            if changed and state["job"] is None:
                state["job"] = win.after(1, animate)

        def click(e):
            for zx1, zy1, zx2, zy2, _i, v in zones:
                if zx1 <= e.x <= zx2 and zy1 <= e.y <= zy2:
                    pick(v)
                    return

        paint()
        tkcv.bind("<Motion>", hover)
        tkcv.bind("<Button-1>", click)
        win.bind("<Escape>", close)
        win.protocol("WM_DELETE_WINDOW", close)

        # по центру родительского окна
        self.update_idletasks()
        px = self.winfo_rootx() + (self.winfo_width() - W) // 2
        py = self.winfo_rooty() + (self.winfo_height() - H) // 3
        win.geometry(f"{W}x{H}+{max(0, px)}+{max(0, py)}")
        win.overrideredirect(True)
        win.deiconify()
        win.attributes("-topmost", True)
        win.lift()
        win.focus_force()
        try:
            win.grab_set()
        except Exception:
            pass
        self.wait_window(win)
        return res["v"]

    def _gal_page_rows(self):
        """Снимки, показанные на текущей странице."""
        return getattr(self, "_gal_shown", [])

    def _gal_pick_on(self):
        self.gal_pick = True
        self.gal_sel = set()
        self.draw()

    def _gal_pick_off(self):
        self.gal_pick = False
        self.gal_sel = set()
        self.draw()

    def _gal_toggle_one(self, ts):
        self.gal_sel.symmetric_difference_update({ts})
        self.draw()

    def _gal_toggle_page(self):
        """Отмечает всю ТЕКУЩУЮ страницу — или снимает, если уже вся."""
        keys = {r[0] for r in self._gal_page_rows()}
        if keys and keys <= self.gal_sel:
            self.gal_sel -= keys
        else:
            self.gal_sel |= keys
        self.draw()

    def _gal_delete_selected(self):
        """Удаляет снимки отмеченных карточек."""
        if not self.gal_sel:
            return
        rows = [r for r in self._gallery_rows() if r[0] in self.gal_sel]
        n = len(rows)
        if self.dialog(
                "Удалить выбранные снимки?",
                f"**Отмечено фотографий: {n}**\n"
                "Записи об улове останутся в журнале —\n"
                "исчезнут только сами картинки.",
                [("Удалить", "yes", "danger"),
                 ("Отмена", None, "ghost")],
                icon="trash") != "yes":
            return
        done = self._delete_photos([r[4] for r in rows if len(r) > 4])
        self.gal_sel = set()
        self.gal_pick = False
        self._ph_size = None
        self._gal_imgs = {}
        self._stamp = None
        self.reload()
        self.dialog("Готово", f"Удалено снимков: {done}",
                    [("Хорошо", None, "primary")], icon="check")

    def _gal_cleanup_dialog(self):
        """Первый шаг очистки: удалить всё или выбрать вручную."""
        mb = self._photos_size_mb()
        total = len([f for f in getattr(self.stats, "fish", [])
                     if len(f) > 4 and f[4]])
        ans = self.dialog(
            "Очистка снимков",
            f"Сейчас на диске {total} снимков — это {mb:.0f} МБ.\n"
            "Записи об улове в журнале останутся в любом случае,\n"
            "исчезнут только фотографии.",
            [("Удалить всё", "all", "danger"),
             ("Вручную", "pick", "primary"),
             ("Отмена", None, "ghost")],
            icon="trash")

        if ans == "pick":
            self._gal_pick_on()
        elif ans == "all":
            self._gal_confirm_all(total, mb)

    def _gal_confirm_all(self, total, mb):
        """Второй шаг: подтверждение полного удаления."""
        if not total:
            self.dialog("Очистка", "Снимков и так нет.",
                        [("Понятно", None, "primary")], icon="check")
            return
        ans = self.dialog(
            "Удалить все снимки?",
            f"**Будут удалены все {total} фотографий ({mb:.0f} МБ).**\n"
            "Отменить это действие нельзя.\n\n"
            "Записи об улове, вес, длина и опыт останутся\n"
            "в журнале — пропадут только сами картинки.",
            [("Да, удалить всё", "yes", "danger"),
             ("Отмена", None, "ghost")],
            icon="trash", width=500)
        if ans != "yes":
            return
        n = self._purge_old_photos(0, force=True)
        self._ph_size = None
        self._gal_imgs = {}
        self._stamp = None
        self.reload()
        self.dialog("Готово", f"Удалено снимков: {n}",
                    [("Хорошо", None, "primary")], icon="check")

    def _delete_photos(self, names):
        """Удаляет файлы снимков и чистит ссылки на них в журнале."""
        d = self._photos_dir()
        gone = set()
        for fn in names:
            if not fn:
                continue
            try:
                os.remove(os.path.join(d, fn))
                gone.add(fn)
            except OSError:
                pass
        if gone:
            self._forget_photos(gone)
        return len(gone)

    def _forget_photos(self, names):
        """Убирает имена удалённых файлов из fish_log.csv.

        Сами записи об улове остаются — пропадает только ссылка на файл,
        иначе в галерее висели бы карточки с битыми картинками.
        """
        path = os.path.join(self.data_dir(), "fish_log.csv")
        if not os.path.exists(path):
            return
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                rows = list(csv.reader(f, delimiter=";"))
            changed = False
            for r in rows:
                if len(r) > 4 and r[4].strip() in names:
                    r[4] = ""
                    changed = True
            if not changed:
                return
            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
                csv.writer(f, delimiter=";").writerows(rows)
            os.replace(tmp, path)
        except Exception:
            pass

    def _purge_old_photos(self, keep=None, force=False):
        """Оставляет только последние `keep` снимков.

        Вызывается сама раз в 10 минут: за долгую сессию папка иначе
        разрастается до сотен мегабайт. Удаляются именно старые файлы —
        свежие уловы всегда под рукой.
        """
        # Именно `is None`, а не `or`: keep=0 значит «удалить всё»,
        # но при `or` ноль считался бы «не задано» и подставлялось 300.
        if keep is None:
            keep = self.cfg.get("keep_photos", KEEP_PHOTOS)
        if not force and not self.cfg.get("auto_purge", AUTO_PURGE):
            return 0
        d = self._photos_dir()
        try:
            files = [(os.path.getmtime(os.path.join(d, f)), f)
                     for f in os.listdir(d)
                     if os.path.isfile(os.path.join(d, f))]
        except OSError:
            return 0
        if len(files) <= keep:
            return 0
        files.sort(reverse=True)             # свежие первыми
        # Снимок рекордной рыбы не удаляем НИКОГДА: «Лучший улов» в
        # обзоре должен радовать фотографией, а не пропадать по
        # расписанию уборки. Из-за защиты снимков может остаться
        # на один больше лимита — это нормально.
        best = self._best_photo_name()
        doomed = [f for _, f in files[keep:] if f != best]
        return self._delete_photos(doomed)

    def _best_photo_name(self):
        """Имя файла снимка лучшего (самого тяжёлого) улова.

        Пустая строка, если рекорда нет или у него нет снимка —
        тогда уборке защищать нечего.
        """
        try:
            best = self.stats.records(1)
            if best and len(best[0]) > 4 and best[0][4]:
                return best[0][4]
        except Exception:
            pass
        return ""

    def _auto_purge_tick(self):
        """Периодическая уборка снимков в фоне."""
        try:
            n = self._purge_old_photos()
            if n:
                self._ph_size = None
                self._gal_imgs = {}
                self._stamp = None
                self.reload()
        except Exception:
            pass
        finally:
            self.after(600000, self._auto_purge_tick)   # раз в 10 минут

    def _jr_open_photo(self, rec):
        """Открывает снимок улова по клику на названии в журнале.

        В журнале свой порядок полей, а окно просмотра ждёт формат
        галереи (ts, name, weight, exp, photo, kind, length) — здесь
        и переставляем, чтобы не плодить вторую копию окна.
        """
        ts, name, w, exp, kind, ln, photo = rec
        self._open_photo((ts, name, w, exp, photo, kind, ln))

    def _jr_goto(self, page):
        self.jr_page = page
        self.draw()

    def _jr_reset_weight(self):
        self.jr_wmin = self.jr_wmax = None
        self.jr_page = 0
        self.draw()

    # ----------------------------------------------- «О программе» (№51)
    # Вкладка про нас самих: название, автор, что за программа и по
    # каким принципам собрана. Внизу — два оставшихся окна-переключателя
    # (тема и защита); настройки АВТОМАТИЗАЦИИ переехали в Менеджер.
    ABOUT_SECTIONS = (
        ("О названии", icon_pen, (
            "Название читается как «троф-приди» — пожелание, чтобы "
            "хорошая рыба приходила сама.",
            "«Усадьба рыбака» — наш тихий угол на берегу: здесь ловят, "
            "а не спешат.")),
        ("Об авторе", icon_anchor, (
            "Пишет и рисует: flkn69 (Telegram: tg/flkn69).",
            "Сломалось? Скриншот и пара слов в личку — чиню быстро.")),
        ("О программе «Статистика»", icon_book, (
            "• ведёт журнал каждого улова: фото, вес, длина, опыт — "
            "через распознавание окна игры;",
            "• галерея трофеев и спокойный журнал с поиском, "
            "сортировкой и удалением;",
            "• сессии: когда ловил, сколько поймал и какой был темп.")),
        ("Клавиши", icon_angle, (
            "F5 — обновить данные · F6 — спрятать/вернуть окно · "
            "F8 — закрыть (и бота тоже).",
            "PgDn — пауза бота · шапку можно тянуть мышью, двойной "
            "клик — во весь экран.")),
    )

    def _wrap_px(self, text, font, maxw):
        """Режет строку на подстроки по ширине (мягкий перенос)."""
        out = []
        for chunk in text.split("\n"):
            line = ""
            for word in chunk.split(" "):
                cand = (line + " " + word).strip()
                if line and self._text_w(cand, font) > maxw:
                    out.append(line)
                    line = word
                else:
                    line = cand
            out.append(line)
        return out

    def _about_toggle(self, x, y, key, title, icn, note, tx):
        """Одна строка настройки: иконка — подпись с примечанием —
        тумблер в точке tx (у правого края панели). Места посчитаны
        так, чтобы подпись, ВКЛ/ВЫКЛ и сам тумблер не налезали
        друг на друга (№52)."""
        c = self.cv
        on = ((self.cfg.get("theme") == "light") if key == "theme"
              else bool(self.cfg.get(key)))
        hov = (self._hover_btn == f"set_{key}")
        self._hot_btns[f"set_{key}"] = (tx - 25, y - 7, tx + 25,
                                        y + 19, ACCENT, ACCENT, 13)
        ic = {"shield": icon_shield, "sun": icon_sun}.get(icn)
        if ic:
            ic(c, x + 8, y + 6, 0.72, ACCENT if on else DIMDEEP)
        c.create_text(x + 30, y, anchor="w", fill=FG,
                      font=(FONT, 10, "bold"), text=title)
        c.create_text(x + 30, y + 17, anchor="w", fill=DIMDEEP,
                      font=(FONT, 8), text=note)
        self._toggle(tx, y + 6, self._toggle_frac(key, on), hov)
        # запоминаем точку тумблера: оверлей-анимации (№59) нужно
        # знать, куда рисовать едущий бегунок поверх кадра
        if not hasattr(self, "_tg_pos"):
            self._tg_pos = {}
        self._tg_pos[key] = (tx, y + 6)
        c.create_text(tx - 34, y + 6, anchor="e",
                      fill=ACCENT if on else DIMDEEP,
                      font=(FONT, 8, "bold"),
                      text="ВКЛ" if on else "ВЫКЛ")
        self._set_hit.append((tx - 26, y - 8, tx + 26, y + 20,
                              lambda k=key: self._toggle_setting(k),
                              f"set_{key}", "hand2"))

    def _about_tab(self, x1, y1, x2, y2):
        """«О программе»: кто мы и зачем. Настройки автоматизации
        переехали в TrofPridi Manager (№51) — тут только про нас."""
        c = self.cv
        self._set_hit = []
        self.panel(x1, y1, x2, y2)
        pad = 26
        top = y1 + pad

        icon_info(c, x1 + pad + 16, top + 14, 1.35, ACCENT)
        tx = x1 + pad + 44
        c.create_text(tx, top + 6, anchor="w", fill=FG,
                      font=(FONT, 15, "bold"),
                      text="TrofPridi · Статистика")
        c.create_text(tx, top + 27, anchor="w", fill=DIMDEEP,
                      font=(FONT, 9),
                      text="УСАДЬБА РЫБАКА  ·  " + VERSION)
        c.create_line(x1 + pad, top + 46, x2 - pad, top + 46, fill=LINE)

        yy = top + 64
        body_w = x2 - x1 - pad * 2 - 34
        for title, icn, lines in self.ABOUT_SECTIONS:
            icn(c, x1 + pad + 8, yy + 2, 0.62, ACCENT)
            c.create_text(x1 + pad + 24, yy, anchor="w", fill=ACCENT,
                          font=(FONT, 10, "bold"), text=title)
            yy += 18
            for raw in lines:
                for ln in self._wrap_px(raw, (FONT, 9), body_w):
                    c.create_text(x1 + pad + 24, yy, anchor="w", fill=SOFT,
                                  font=(FONT, 9), text=ln)
                    yy += 14
            yy += 8

        # Два оставшихся тумблера — тема и защита. Даём каждому
        # полноценную строку на всю ширину панели: иконка, подпись
        # с примечанием, а тумблер честно прижат к правому краю —
        # ничего не теснится и не налезает (№52).
        c.create_line(x1 + pad, y2 - 124, x2 - pad, y2 - 124, fill=LINE)
        icon_gear(c, x1 + pad + 8, y2 - 108, 0.58, DIMDEEP)
        ty = y2 - 109
        c.create_text(x1 + pad + 22, ty, anchor="w", fill=DIMDEEP,
                      font=(FONT, 9, "bold"), text="Оформление и защита")
        self._about_toggle(x1 + pad + 6, y2 - 84, "theme",
                           "Светлая тема", "sun",
                           "светлое оформление вместо тёмного", x2 - 50)
        self._about_toggle(x1 + pad + 6, y2 - 42, "capture_guard",
                           "Защита от скриншотов", "shield",
                           "окно невидимо для снимков экрана", x2 - 50)
        if self.cfg.get("capture_guard"):
            ok = getattr(self, "_hidden_from_capture", False)
            c.create_text(x1 + pad + 36, y2 - 10, anchor="w",
                          fill=GREEN if ok else GOLD, font=(FONT, 8),
                          text=("Защита активна — программа невидима "
                                "для снимков."
                                if ok else
                                "Защита не сработала: нужна Windows 10 "
                                "версии 2004 или новее."))

    def _bar_img(self, w, h, bg=CARD):
        """Градиентная капсула прогресса (или None, если Pillow нет)."""
        key = (int(w), int(h), bg)
        im = self._bar_imgs.get(key)
        if im is None:
            if not SMOOTH:
                return None
            try:
                from PIL import Image as _Im, ImageTk
                spr = bar_gradient(key[0], key[1])
                src = _Im.new("RGB", spr.size, bg)
                src.paste(spr, (0, 0), spr)
                im = ImageTk.PhotoImage(src)
                im._pil_src = src
            except Exception:
                im = None
            self._bar_imgs[key] = im
        return im

    def _toggle_setting(self, key):
        """Переключает настройку и сразу применяет её.

        Положение бегунка анимируется: новое значение применяем сразу,
        а визуальный «приезд» дорисовывают кадры _toggle_tick.
        """
        old_on = ((self.cfg.get("theme") == "light") if key == "theme"
                  else bool(self.cfg.get(key)))
        if key == "theme":
            self.set_theme("light" if self.cfg.get("theme") != "light"
                           else "dark")
        else:
            self.cfg[key] = not self.cfg.get(key)
            self.save_settings()
            if key == "capture_guard":
                self._apply_capture_hide()
        self._start_toggle_anim(key, old_on, not old_on)
        self.draw()

    def set_theme(self, name):
        """Меняет тему оформления на лету.

        Палитра подменяется глобально (apply_palette), живые виджеты
        перекрашиваем руками, спрайты (тумблеры, бары, панели) идут в
        мусор — они запечены под старую тему, — и всё перерисовываем.
        Имя темы падает в configs\stats.ini: меню бота читает тот же
        INI раз в секунду и перекрашивается следом само (№51).
        """
        name = apply_palette(name)
        self.cfg["theme"] = name
        self.save_settings()
        try:
            self.configure(bg=BG)
            self._tkcv.configure(bg=BG)
            if isinstance(self.cv, SmoothCanvas):
                self.cv.bg = BG      # фон следующих кадров
        except Exception:
            pass
        # Спрайты, запечённые в старой теме, недействительны.
        self._bar_imgs.clear()
        self.draw()

    def _jr_col_x(self, x1, x2):
        """Позиции столбцов: тянутся вместе с шириной окна."""
        left = x1 + 46
        w = max(560, x2 - 20 - left)
        return [left,
                left + int(w * 0.16),
                left + int(w * 0.42),
                left + int(w * 0.60),
                left + int(w * 0.73),
                left + int(w * 0.86)]

    # --- действия журнала ---
    def _jr_set_sort(self, key):
        if self.jr_sort == key:
            self.jr_desc = not self.jr_desc
        else:
            self.jr_sort = key
            # у времени и чисел естественный порядок — по убыванию,
            # у названия — по алфавиту
            self.jr_desc = (key != "name")
        self.jr_page = 0
        self.draw()

    def _jr_set_filter(self, key):
        self.jr_filter = key
        self.jr_page = 0
        # Короткая отдача на нажатие: рисуем чип «вдавленным», через
        # 90 мс возвращаем обратно. Без этого клик ощущается мёртвым.
        self._jr_press = key
        self.draw()
        self.after(90, self._jr_unpress)

    def _jr_unpress(self):
        if self._jr_press is not None:
            self._jr_press = None
            self.draw()

    def _jr_focus_search(self):
        self.jr_search_on = True
        self.draw()

    def _jr_clear_query(self):
        self.jr_query = ""
        self.jr_page = 0
        self.draw()

    def _jr_toggle_one(self, ts):
        self.jr_sel.symmetric_difference_update({ts})
        self.draw()

    def _jr_toggle_all(self):
        """Отмечает всё видимое — или снимает, если уже всё отмечено."""
        keys = {r[0] for r in self._journal_rows()}
        if keys and keys <= self.jr_sel:
            self.jr_sel -= keys
        else:
            self.jr_sel |= keys
        self.draw()

    def _on_escape(self, _e=None):
        """Escape: сначала выходим из поиска, и только потом из окна.

        Иначе попытка отменить ввод закрывала бы всю статистику.
        """
        if self.tab == 2 and (self.jr_search_on or self.jr_sel):
            self.jr_search_on = False
            self.jr_sel.clear()
            self.draw()
            return "break"
        self._close()

    def _jr_key(self, e):
        """Ввод в поле поиска. Работает, пока курсор стоит в нём."""
        if self.tab != 2 or not self.jr_search_on:
            return
        if e.keysym == "BackSpace":
            self.jr_query = self.jr_query[:-1]
        elif e.keysym in ("Return", "KP_Enter", "Escape"):
            self.jr_search_on = False
        elif e.char and e.char.isprintable():
            if len(self.jr_query) < 30:
                self.jr_query += e.char
        else:
            return
        self.jr_page = 0
        self.draw()
        return "break"

    # --- переименование рыбы (обучает OCR) ---
    def _jr_rename_selected(self):
        """Открывает окно переименования для единственной отмеченной."""
        if len(self.jr_sel) != 1:
            return
        ts = next(iter(self.jr_sel))
        name = ""
        for rec in getattr(self.stats, "fish", []):
            if rec[0] == ts:
                name = rec[1] or ""
                break
        self._rename_dialog(ts, name)

    def _rename_dialog(self, ts, old):
        """Поле ввода нового названия в маленьком модальном окне.

        Своё Toplevel (как у dialog()) — клавиатура приходит прямо в
        него, основное окно не трогаем. «Сохранить» правит журнал и
        кладёт пару в names_map.txt: OCR-наблюдатель читает её при
        каждой записи и впредь называет такую же рыбу уже правильно.
        """
        W, H = 500, 232
        win = tk.Toplevel(self)
        win.withdraw()
        win.configure(bg=BG)
        win.transient(self)

        tkcv = tk.Canvas(win, bg=BG, highlightthickness=0,
                         width=W, height=H)
        tkcv.pack(fill="both", expand=True)
        cv = SmoothCanvas(tkcv, BG) if SMOOTH else tkcv
        win._cv = cv

        st = {"text": old, "res": None}
        zones = {"save": None, "cancel": None}

        def close(_e=None):
            try:
                win.grab_release()
            except Exception:
                pass
            try:
                win.destroy()
            except Exception:
                pass

        def save(_e=None):
            st["res"] = st["text"].strip(" -")
            close()

        def on_key(e):
            if e.keysym == "BackSpace":
                st["text"] = st["text"][:-1]
            elif e.keysym in ("Return", "KP_Enter"):
                save()
                return "break"
            elif e.keysym == "Escape":
                close()
                return "break"
            elif e.char and e.char.isprintable():
                if len(st["text"]) < 40:
                    st["text"] += e.char
            else:
                return
            paint()

        def paint(_e=None):
            cv.delete("all")
            pad = 24
            round_rect(cv, 0, 0, W - 1, H - 1, 14, fill=DIALOG_BG,
                       outline="")
            round_outline(cv, 0, 0, W - 1, H - 1, 14, DIALOG_EDGE)
            icon_pen(cv, pad + 10, 30, 0.85, ACCENT)
            cv.create_text(pad + 30, 30, anchor="w", fill=FG,
                           font=(FONT, 12, "bold"),
                           text="Переименовать рыбу")
            cv.create_text(pad, 58, anchor="w", fill=SOFT, font=(FONT, 8),
                           text="Новое название запомнится: в следующий раз")
            cv.create_text(pad, 72, anchor="w", fill=SOFT, font=(FONT, 8),
                           text="бот назовёт такую же рыбу уже без ошибки.")
            # поле ввода
            fx1, fy1, fx2, fy2 = pad, 92, W - pad, 126
            if SMOOTH and isinstance(cv, SmoothCanvas):
                cv.sink(fx1, fy1, fx2, fy2, 8, fill=SINK, dark=NEU_DARK,
                        light=NEU_LIGHT, dk=SINK_DK, hi=SINK_HI,
                        dist=2, blur=2)
            else:
                round_rect(cv, fx1, fy1, fx2, fy2, 8, fill=SINK, outline="")
            round_outline(cv, fx1, fy1, fx2, fy2, 8, ACCENT)
            shown = self._fit(st["text"], fx2 - fx1 - 30)
            cv.create_text(fx1 + 12, (fy1 + fy2) / 2, anchor="w", fill=FG,
                           font=(FONT, 10), text=shown)
            cw = self._text_w(shown, (FONT, 10))
            cv.create_line(fx1 + 14 + cw, fy1 + 8, fx1 + 14 + cw, fy2 - 8,
                           fill=ACCENT)
            if old and old.strip() != st["text"].strip():
                cv.create_text(fx1, fy2 + 12, anchor="w", fill=DIMDEEP,
                               font=(FONT, 8),
                               text=self._fit(f"было: {old}",
                                              W - pad * 2))
            # кнопки
            by1, by2 = H - 62, H - 24
            for tag, label, kind, x2 in (
                    ("cancel", "Отмена", "ghost", W - pad),
                    ("save", "Сохранить", "primary", W - pad - 100)):
                bw = 24 + self._text_w(label, (FONT, 9, "bold"))
                x1 = x2 - bw
                hot = zones.get("_hot") == tag
                if kind == "primary":
                    base, tc = (ACTHOT if hot else ACTFACE), "#FFFFFF"
                else:
                    base, tc = (NEUHOT if hot else CHIP2), PALE
                round_rect(cv, x1, by1, x2, by2, 8, fill=base, outline="")
                cv.create_text((x1 + x2) / 2, (by1 + by2) / 2, anchor="c",
                               fill=tc, font=(FONT, 9, "bold"), text=label)
                zones[tag] = (x1, by1, x2, by2)
            if SMOOTH and isinstance(cv, SmoothCanvas):
                # Размер задаём явно: первый paint() идёт, пока окно ещё
                # скрыто (withdraw), и у холста winfo_width() == 1 —
                # без size картинка рождалась 1×1 и поле ввода
                # появлялось только после первого нажатия клавиши.
                cv.flush(size=(W, H))

        def on_move(e):
            hot = None
            for tag in ("cancel", "save"):
                z = zones.get(tag)
                if z and z[0] <= e.x <= z[2] and z[1] <= e.y <= z[3]:
                    hot = tag
            if hot != zones.get("_hot"):
                zones["_hot"] = hot
                paint()
            tkcv.configure(
                cursor="hand2" if hot else "xterm")

        def on_click(e):
            for tag, fn in (("cancel", close), ("save", save)):
                z = zones.get(tag)
                if z and z[0] <= e.x <= z[2] and z[1] <= e.y <= z[3]:
                    fn()
                    return

        tkcv.bind("<Motion>", on_move)
        tkcv.bind("<Button-1>", on_click)
        win.bind("<Key>", on_key)
        win.protocol("WM_DELETE_WINDOW", close)
        paint()

        # по центру родительского окна — как у остальных диалогов
        self.update_idletasks()
        px = self.winfo_rootx() + (self.winfo_width() - W) // 2
        py = self.winfo_rooty() + (self.winfo_height() - H) // 3
        win.geometry(f"{W}x{H}+{max(0, px)}+{max(0, py)}")
        win.overrideredirect(True)
        win.deiconify()
        win.attributes("-topmost", True)
        win.lift()
        win.focus_force()
        try:
            win.grab_set()
        except Exception:
            pass
        win.wait_window()

        new = st["res"]
        if new and new.strip() != old.strip():
            self._apply_rename(ts, old, new.strip())

    def _apply_rename(self, ts, old, new):
        """Правит имя в fish_log.csv и учит его в names_map.txt.

        Запись меняем только у выбранной строки (по метке времени) —
        остальные уловы с тем же ошибочным названием трогать нельзя:
        вдруг там была настоящая другая рыба. А вот БУДУЩИЕ записи с
        такой опечаткой переименуются сами: именно для этого карта.
        """
        path = os.path.join(self.data_dir(), "fish_log.csv")
        stamp = ts.strftime("%Y-%m-%d %H:%M:%S")
        changed = False
        try:
            rows, header = [], None
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                for r in csv.reader(f, delimiter=";"):
                    if not r:
                        continue
                    if r[0] == "timestamp":
                        header = r
                        continue
                    if r[0].strip() == stamp and (r[1] if len(r) > 1
                                                  else "") == old:
                        r[1] = new
                        changed = True
                    rows.append(r)
            if changed:
                tmp = path + ".tmp"
                with open(tmp, "w", encoding="utf-8-sig",
                          newline="") as f:
                    w = csv.writer(f, delimiter=";")
                    w.writerow(header or ["timestamp", "name", "weight_kg",
                                          "exp", "photo", "kind",
                                          "length_cm", "release_exp"])
                    w.writerows(rows)
                os.replace(tmp, path)
        except Exception:
            return

        # Карта обучения: «как записал бот» -> «как должно быть».
        # Пустое исходное имя (рыба без названия) в карту не идёт —
        # сравнивать не с чем, а пустой ключ бесполезен.
        if old.strip():
            try:
                mp = load_name_map(self._name_map_path())
                if old.strip().lower() != new.lower():
                    mp[old.strip().lower()] = new
                    save_name_map(self._name_map_path(), mp)
            except Exception:
                pass

        self.jr_sel.discard(ts)
        self.reload()

    def _name_map_path(self):
        return os.path.join(self.data_dir(), "names_map.txt")

    def _jr_delete_selected(self):
        """Удаляет отмеченные записи из fish_log.csv."""
        if not self.jr_sel:
            return
        n = len(self.jr_sel)
        if not messagebox.askyesno(
                "Удаление",
                f"Удалить выбранные записи ({n} шт.)?\n\n"
                "Строки будут убраны из журнала, снимки —\n"
                "перемещены в папку backup. Отменить нельзя."):
            return

        path = os.path.join(self.data_dir(), "fish_log.csv")
        if not os.path.exists(path):
            return
        kill = {t.strftime("%Y-%m-%d %H:%M:%S") for t in self.jr_sel}
        # Какие снимки принадлежат удаляемым строкам — заодно уносим их,
        # иначе папка photos копила бы мусор.
        photos, kept, header = [], [], None
        try:
            with open(path, "r", encoding="utf-8-sig", newline="") as f:
                for r in csv.reader(f, delimiter=";"):
                    if not r:
                        continue
                    if r[0] == "timestamp":
                        header = r
                        continue
                    if r[0].strip() in kill:
                        if len(r) > 4 and r[4].strip():
                            photos.append(r[4].strip())
                        continue
                    kept.append(r)

            tmp = path + ".tmp"
            with open(tmp, "w", encoding="utf-8-sig", newline="") as f:
                w = csv.writer(f, delimiter=";")
                w.writerow(header or ["timestamp", "name", "weight_kg", "exp",
                                      "photo", "kind", "length_cm",
                                      "release_exp"])
                w.writerows(kept)
            os.replace(tmp, path)

            src = os.path.join(self.data_dir(), "photos")
            dst = os.path.join(self.data_dir(), "backup", "photos")
            if photos:
                os.makedirs(dst, exist_ok=True)
                for fn in photos:
                    a = os.path.join(src, fn)
                    if os.path.exists(a):
                        try:
                            shutil.move(a, os.path.join(dst, fn))
                        except Exception:
                            pass
        except Exception as ex:
            messagebox.showerror("Удаление", f"Не получилось:\n{ex}")
            return

        self.jr_sel.clear()
        self._gal_imgs = {}
        self._stamp = None
        self.reload()

    def _sessions_tab(self, x1, y1, x2, y2):
        """Вкладка «Сессии»: шапка-итоги + аккуратная таблица.

        Раньше вкладка была голой таблицей слева с пустой правой
        половиной — «по старому, пусто, криво». Теперь сверху полоса
        мини-итогов (привычный язык окна), а таблица занимает всю
        ширину: колонки по пропорции, числа выровнены вправо,
        сессии сгруппированы по дням, чётные строки едва тонированы.
        """
        c = self.cv
        self.panel(x1, y1, x2, y2)
        pad = 22
        s = self.stats
        sess = s.sessions()

        # ------------------------------------------------ мини-итоги
        fish = getattr(s, "fish", [])
        all_exp = sum(f[3] for f in fish if len(f) > 3 and f[3])
        wt = s.total_weight()
        chips = (
            (icon_chart, ACCENT, "Сессий", str(len(sess))),
            (icon_clock, ACCENT, "Время в игре", fmt_dur(s.total_time())),
            (icon_speed, ACCENT, "Самая долгая",
             fmt_dur(s.longest_session()) if sess else "—"),
            (icon_fish, ACCENT, "Всего рыб", str(len(s.catches()))),
            (icon_weight, ACCENT, "Общий вес",
             f"{wt:.1f} кг" if wt else "—"),
            (icon_star, EXP, "Опыт за всё время",
             f"{all_exp:,}".replace(",", " ") if all_exp else "—"),
        )
        gap = 10
        cw = int((x2 - x1 - pad * 2 - gap * (len(chips) - 1)) / len(chips))
        cy1, cy2 = y1 + 16, y1 + 70
        chx = x1 + pad
        fillc = self._mix(CARD, FG, 0.03)
        edgec = self._mix(CARD, FG, 0.08)
        for icn, icol, lbl, val in chips:
            round_rect(c, chx, cy1, chx + cw, cy2, 10,
                       fill=fillc, outline="")
            round_outline(c, chx, cy1, chx + cw, cy2, 10, edgec)
            try:
                icn(c, chx + 14, cy1 + 16, 0.62, icol)
            except Exception:
                pass
            c.create_text(chx + 26, cy1 + 16, anchor="w", fill=DIMDEEP,
                          font=(FONT, 8), text=lbl)
            vcol = icol if icol is EXP else FG
            c.create_text(chx + 14, cy1 + 38, anchor="w", fill=vcol,
                          font=(FONT_NUM, 12, "bold"), text=val)
            chx += cw + gap

        # ------------------------------------------------ таблица
        heads = ("Начало", "Длительность", "Поймано", "Опыт",
                 "Вес", "Темп, р./ч")
        # доли ширины + выравнивание колонок; в режиме выбора слева
        # освобождаем дорожку под круглишки
        fracs = (0.24, 0.13, 0.11, 0.15, 0.14, 0.13)
        aligns = ("w", "e", "e", "e", "e", "e")
        gutter = 30 if self._ses_sel is not None else 0
        iw = x2 - x1 - pad * 2 - gutter
        colx, acc = [], 0.0
        for fr, al in zip(fracs, aligns):
            acc += fr
            colx.append(x1 + pad + gutter if al == "w" and not colx
                        else x1 + pad + gutter + iw * acc)

        ty = cy2 + 26
        icon_book(c, x1 + pad + 7, ty + 1, 0.6, ACCENT)
        c.create_text(x1 + pad + 16, ty, anchor="w", fill=DIM,
                      font=(FONT, 9, "bold"), text="История сессий")

        # --- кнопки справа: язык тот же, что у галереи в режиме выбора ---
        sel_mode = self._ses_sel is not None
        bx2 = x2 - pad
        by1, by2 = ty - 10, ty + 18
        if sess and sel_mode:
            n_sel = len(self._ses_sel)
            if n_sel:
                lbl = f"Удалить ({n_sel})"
                w = self._chip_w(lbl, (FONT, 9, "bold")) + 2
                round_rect(c, bx2 - w, by1, bx2, by2, 8,
                           fill="#5B1F24", outline="")
                round_outline(c, bx2 - w, by1, bx2, by2, 8, RED)
                self._chip_content(bx2 - w, w, (by1 + by2) / 2, lbl,
                                   (FONT, 9, "bold"), "#FFD9D9",
                                   icon_trash, REDSOFT, 0.55)
                self._ses_hit.append((bx2 - w, by1, bx2, by2,
                                      self._ses_delete_selected))
                self._hot_btns["ses_del"] = (bx2 - w, by1, bx2, by2,
                                             "#C43D2E", "#FF7A6B", 8)
                bx2 -= w + 8

            all_on = bool(self._ses_list_all) and \
                {a for a, _b, _d in self._ses_list_all} <= self._ses_sel
            lbl = "Снять всё" if all_on else "Выбрать всё"
            w = self._chip_w(lbl, (FONT, 9)) + 2
            self._face(bx2 - w, by1, bx2, by2, 8)
            self._chip_content(
                bx2 - w, w, (by1 + by2) / 2, lbl, (FONT, 9), SOFT,
                lambda cc, ccx, cy, s, _cl, a=all_on: icon_checkbox(
                    cc, ccx, cy, 0.6, ACCENT if a else DIMDEEP, a))
            self._ses_hit.append((bx2 - w, by1, bx2, by2,
                                  self._ses_select_all))
            self._hot_btns["ses_all"] = (bx2 - w, by1, bx2, by2,
                                         ACCENT, ACCENT, 8)
            bx2 -= w + 8

            lbl = "Отмена"
            w = self._chip_w(lbl, (FONT, 9), icon=False) + 6
            self._face(bx2 - w, by1, bx2, by2, 8)
            self._chip_content(bx2 - w, w, (by1 + by2) / 2, lbl,
                               (FONT, 9), SOFT)
            self._ses_hit.append((bx2 - w, by1, bx2, by2,
                                  self._ses_cancel_sel))
            self._hot_btns["ses_cancel"] = (bx2 - w, by1, bx2, by2,
                                            HOTEDGE, MID, 8)
            bx2 -= w + 8
        elif sess:
            lbl = "Очистить"
            w = self._chip_w(lbl, (FONT, 9)) + 2
            self._face(bx2 - w, by1, bx2, by2, 8)
            self._chip_content(bx2 - w, w, (by1 + by2) / 2, lbl,
                               (FONT, 9), SOFT, icon_trash, MID, 0.5)
            self._ses_hit.append((bx2 - w, by1, bx2, by2,
                                  self._ses_enter_sel))
            self._hot_btns["ses_clear"] = (bx2 - w, by1, bx2, by2,
                                           CHIP2, GHOSTEDGE, 8)
            bx2 -= w + 8

        hy = ty + 26
        for h, xx, al in zip(heads, colx, aligns):
            c.create_text(xx + (0 if al == "w" else -4), hy, anchor=al,
                          fill=DIM, font=(FONT, 9, "bold"), text=h)
        c.create_line(x1 + pad, hy + 12, x2 - pad, hy + 12, fill=LINE)

        if not sess:
            c.create_text(x1 + pad, hy + 40, anchor="w", fill=DIM,
                          font=(FONT, 10), text="Сессий пока нет.")
            return

        catches = s.catches()
        row_h = 30
        grp_h = 26
        units = []                # (вид, данные)
        prev_day = None
        catches_idx = [x[0] for x in catches]
        self._ses_list_all = [(a, b, d) for a, b, d in sess]
        for a, b, d in reversed(sess):
            day = a.date()
            if day != prev_day:
                prev_day = day
                units.append(("grp", day))
            n = sum(1 for t in catches_idx if a <= t <= b)
            fs = [f for f in fish if len(f) > 2 and a <= f[0] <= b]
            exp = sum(f[3] for f in fs if len(f) > 3 and f[3])
            wg = sum(f[2] for f in fs if f[2])
            hrs = d.total_seconds() / 3600
            temp = (f"{n / hrs:.1f}" if hrs >= 0.05 and n else "—")
            units.append(("row", (a, b, d, n, exp, wg, temp)))

        # Страницы вместо полосы прокрутки — как в журнале и галерее:
        # каждая страница кладёт строки и разделители дней по высоте.
        head = hy + 20
        foot = 44
        view_h = max(60, y2 - head - foot)
        pages, cur, acc_h = [], [], 0
        for u in units:
            uh = grp_h if u[0] == "grp" else row_h
            if acc_h + uh > view_h and cur:
                pages.append(cur)
                cur, acc_h = [], 0
            cur.append(u)
            acc_h += uh
        if cur:
            pages.append(cur)
        self._ses_pages = max(1, len(pages))
        self.ses_page = max(0, min(self.ses_page, self._ses_pages - 1))
        show = pages[self.ses_page] if pages else []

        yy = head + 6
        shown = 0
        shade = self._mix(CARD, FG, 0.022)
        for kind, data in show:
            if kind == "grp":
                d_lbls = {0: "пн", 1: "вт", 2: "ср", 3: "чт",
                          4: "пт", 5: "сб", 6: "вс"}
                lbl = data.strftime("%d.%m.%Y") + " · " \
                      + d_lbls[data.weekday()]
                c.create_text(x1 + pad + gutter, yy + 2, anchor="w",
                              fill=DIMDEEP, font=(FONT, 8, "bold"),
                              text=lbl)
                lx = (x1 + pad + gutter
                      + self._text_w(lbl, (FONT, 8, "bold")) + 10)
                c.create_line(lx, yy + 3, x2 - pad, yy + 3, fill=DIVLINE)
                yy += grp_h
                shown += 1
                continue
            a, b, d, n, exp, wg, temp = data
            selected = sel_mode and a in self._ses_sel
            if selected:
                round_rect(c, x1 + 12, yy - 9, x2 - 12, yy + row_h - 9,
                           7, fill=self._mix(CARD, ACCENT, 0.14),
                           outline="")
                round_outline(c, x1 + 12, yy - 9, x2 - 12,
                              yy + row_h - 9, 7,
                              self._mix(ACCENT, FG, 0.25))
            elif (shown % 2) == 1:
                round_rect(c, x1 + 12, yy - 9, x2 - 12, yy + row_h - 9,
                           7, fill=shade, outline="")
            if sel_mode:
                # круглишок выбора — как в галерее, всё строка кликабельна
                icon_checkbox(c, x1 + pad + 10, yy + 6, 0.62,
                              ACCENT if selected else DIMDEEP, selected)
                self._ses_hit.append(
                    (x1 + 12, yy - 9, x2 - 12, yy + row_h - 9,
                     lambda key=a: self._ses_toggle(key)))
                self._hot_btns[f"ses_row_{a.timestamp()}"] = (
                    x1 + 12, yy - 9, x2 - 12, yy + row_h - 9,
                    CHIP2, GHOSTEDGE, 7)
            vals = (a.strftime("%d.%m.%Y %H:%M"), fmt_dur(d), str(n),
                    f"{exp:,}".replace(",", " ") if exp else "—",
                    f"{wg:.2f} кг" if wg else "—", temp)
            colors = (DIM, FG, ACCENT, EXP, SOFT, SOFT)
            fonts = ((FONT, 10), (FONT_NUM, 10), (FONT_NUM, 10),
                     (FONT_NUM, 10, "bold"), (FONT_NUM, 10),
                     (FONT, 10))
            for v, xx, al, cl, fo in zip(vals, colx, aligns,
                                         colors, fonts):
                c.create_text(xx + (2 if al == "w" else -8), yy,
                              anchor=al, fill=cl, font=fo, text=v)
            yy += row_h
            shown += 1
            c.create_line(x1 + pad + gutter, yy - 14, x2 - pad, yy - 14,
                          fill=DIVLINE)

        # ------------------------------------------------ итог внизу
        c.create_line(x1 + pad, y2 - 30, x2 - pad, y2 - 30, fill=LINE)
        if sel_mode:
            foot_txt = (f"Выбрано сессий: {len(self._ses_sel)}"
                        if self._ses_sel else
                        "Клик по строке — выбрать сессию")
            c.create_text(x1 + pad, y2 - 15, anchor="w", fill=ACCENT,
                          font=(FONT, 9), text=foot_txt)
        else:
            c.create_text(x1 + pad, y2 - 15, anchor="w", fill=DIM,
                          font=(FONT, 9),
                          text=f"Всего сессий: {len(sess)}")
            if all_exp:
                c.create_text(x2 - pad, y2 - 15, anchor="e", fill=EXP,
                              font=(FONT_NUM, 11),
                              text=f"опыта за всё время: "
                                   f"{all_exp:,}".replace(",", " "))
        self._pager(x1, x2, y2 - 15, self._ses_pages, self.ses_page,
                    self._ses_goto, self._ses_hit, "ses_p")

    # ------------------------------------- выбор сессий «круглишками»
    def _ses_goto(self, page):
        self.ses_page = page
        self.draw()

    def _ses_enter_sel(self):
        """«Очистить» переводит таблицу в режим выбора: системных окон
        больше нет — рядом появляются «Выбрать всё», «Удалить» и
        «Отмена», а у каждой строки свой круглишок, как в галерее."""
        if not self.stats.sessions():
            return
        self._ses_sel = set()
        self.draw()

    def _ses_cancel_sel(self):
        self._ses_sel = None
        self.draw()

    def _ses_toggle(self, key):
        if self._ses_sel is None:
            return
        if key in self._ses_sel:
            self._ses_sel.discard(key)
        else:
            self._ses_sel.add(key)
        self.draw()

    def _ses_select_all(self):
        if self._ses_sel is None:
            return
        # «Выбрать всё» берёт все сессии; повторное нажатие снимает всё
        keys = {a for a, _b, _d in self._ses_list_all}
        if keys and keys <= self._ses_sel:
            self._ses_sel = set()
        else:
            self._ses_sel = keys
        self.draw()

    def _ses_delete_selected(self):
        """Удаляет выбранные сессии со всеми событиями внутри них.

        Из stats.csv уходят строки событий этих периодов, из
        fish_log.csv — пойманная в них рыба. САМАЯ ТЯЖЁЛАЯ РЫБА
        («Лучший улов») защищена: её строка остаётся, даже если она
        внутри удаляемой сессии. Фотографии не трогаем. Перед записью
        обе копии файлов уезжают в backup/<штамп> — вернуть можно
        руками.
        """
        if not self._ses_sel:
            return
        n = len(self._ses_sel)
        ok = self.dialog(
            "Удаление сессий",
            f"Удалить выбранные сессии ({n} шт.)?\n\n"
            "Из журнала уйдут все события этих периодов, из списка\n"
            "уловов — рыба, пойманная в эти сессии. «Лучший улов»\n"
            "защищён и останется. Фотографии не трогаем.\n"
            "Копии файлов сохранятся в папке backup.",
            [("Удалить", True, "danger"),
             ("Отмена", None, "ghost")], icon="trash")
        if not ok:
            return

        intervals = [(a, b) for a, b, _d in self._ses_list_all
                     if a in self._ses_sel]
        d = self.data_dir()
        fish_csv = os.path.join(d, "fish_log.csv")

        def parse_ts(s):
            try:
                from datetime import datetime as _d
                return _d.strptime(s.strip(), "%Y-%m-%d %H:%M:%S")
            except Exception:
                return None

        def in_iv(t):
            return any(a <= t <= b for a, b in intervals)

        import shutil
        from datetime import datetime as _dt
        stamp = _dt.now().strftime("%Y%m%d_%H%M%S")
        try:
            bak = os.path.join(d, "backup", stamp)
            os.makedirs(bak, exist_ok=True)
            if os.path.isfile(self.csv_path):
                shutil.copy2(self.csv_path,
                             os.path.join(bak, "stats.csv"))
            if os.path.isfile(fish_csv):
                shutil.copy2(fish_csv,
                             os.path.join(bak, "fish_log.csv"))
        except Exception:
            pass                    # бэкап не вышел — чистим так

        def rewrite(path, protect_best):
            if not os.path.isfile(path):
                return
            try:
                raw = open(path, "r", encoding="utf-8-sig").read()
            except Exception:
                return
            lines = raw.splitlines()
            best_w = None
            if protect_best:
                for ln in lines:
                    ps = ln.split(";")
                    if len(ps) > 2:
                        try:
                            w = float(ps[2].replace(",", "."))
                        except Exception:
                            continue
                        if best_w is None or w > best_w:
                            best_w = w
            keep = []
            for ln in lines:
                ps = ln.split(";")
                t = parse_ts(ps[0]) if ps else None
                if t is not None and in_iv(t):
                    if protect_best and len(ps) > 2 and best_w is not None:
                        try:
                            w = float(ps[2].replace(",", "."))
                        except Exception:
                            w = None
                        if w is not None and abs(w - best_w) < 1e-9:
                            keep.append(ln)   # «Лучший улов» — не трогаем
                            continue
                    continue                # событие удаляемой сессии
                keep.append(ln)
            try:
                with open(path, "w", encoding="utf-8-sig") as f:
                    f.write("\n".join(keep) + "\n")
            except Exception:
                pass

        rewrite(self.csv_path, False)
        rewrite(fish_csv, True)

        self._ses_sel = None
        self._stamp = None            # заставляем перечитать файлы
        try:
            self.reload(async_load=True)
        except Exception:
            self.draw()

    def _footer(self, W, H):
        c = self.cv
        # уголок для изменения размера (окно без рамки иначе не тянется)
        for i in range(3):
            o = i * 4
            c.create_line(W - 6 - o, H - 3, W - 3, H - 6 - o, fill=FAINT2)
        self._grip = (W - 20, H - 20, W, H)

        # слева — состояние хранения и распознавания
        icon_shield(c, 28, H - 22, 0.62, ACCENT)
        save_txt = f"Данные сохраняются автоматически  ·  {VERSION}"
        c.create_text(42, H - 22, anchor="w", fill=CHECKLINE,
                      font=(FONT, 8), text=save_txt)
        ocr_txt = ("OCR распознаёт улов" if self._ocr_alive()
                   else "OCR ожидает настройки")
        ox = 42 + self._text_w(save_txt, (FONT, 8)) + 18
        c.create_text(ox, H - 22, anchor="w", fill=CHECKLINE,
                      font=(FONT, 8), text=ocr_txt)

        # Если кнопку на панели задач выставить не удалось, честно
        # предупреждаем: иначе непонятно, запущена статистика или нет.
        if not getattr(self, "_taskbar_ok", True):
            ox2 = ox + self._text_w(ocr_txt, (FONT, 8)) + 18
            c.create_text(ox2, H - 22, anchor="w", fill="#7A6030",
                          font=(FONT, 8),
                          text="нет кнопки на панели задач")

        # справа — основная кнопка
        self._btns = []
        bw, bh = 156, 30
        bx2, by1 = W - 24, H - 38
        bx1, by2 = bx2 - bw, by1 + bh
        # Отдача при нажатии: кнопка на миг проседает на пиксель.
        # Без этого клик визуально никак не отзывался — палец нажал,
        # а интерфейс промолчал.
        dy = self._press_offset("newperiod")
        by1 += dy
        by2 += dy
        self._face(bx1, by1, bx2, by2, 8, style="primary")
        self._hot_btns["newperiod"] = (bx1, by1, bx2, by2,
                                       ACTHOT, ACCENT, 8)
        # Круговая стрелка вместо плюса: кнопка НЕ добавляет период,
        # она уносит накопленное в backup и начинает счёт заново.
        # Плюс обещал прямо противоположное.
        # Иконка+подпись центрируются как единый блок: раньше обе были
        # прибиты к левому краю, и справа зияла пустота.
        _fnt = (FONT, 9, "bold")
        _tw = self._text_w("Начать заново", _fnt)
        _gx = bx1 + max(16.0, (bw - (20 + _tw)) / 2)
        icon_restart(c, _gx + 8, (by1 + by2) / 2, 0.80, "#FFFFFF")
        c.create_text(_gx + 20, (by1 + by2) / 2, anchor="w", fill="#FFFFFF",
                      font=_fnt, text="Начать заново")
        self._btns.append((bx1, by1, bx2, by2, self.reset_stats))

    # ------------------------------------------------ события
    def _gallery_click(self, e):
        """Клик в галерее: сперва панель, затем карточки."""
        for h in self._gal_ui:
            if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                h[4]()
                return True
        for x1, y1, x2, y2, rec in self._gal_hit:
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                # В режиме выбора клик отмечает карточку, а не
                # открывает снимок — иначе отметить их было бы нечем.
                if self.gal_pick:
                    self._gal_toggle_one(rec[0])
                    return True
                photo = rec[4] if len(rec) > 4 else ""
                if photo:
                    self._open_photo(rec)
                return True
        return False

    def _open_photo(self, rec):
        """Полноразмерный снимок в своём окне, без системной рамки.

        Важно: окно сначала строится скрытым, и только потом показывается
        поверх остальных. Раньше оно создавалось сразу и уходило ЗА главное
        окно, а grab_set() при этом блокировал клики — со стороны выглядело
        так, будто программа зависла.
        """
        ts, name, w = rec[0], rec[1], rec[2]
        exp = rec[3] if len(rec) > 3 else 0
        photo = rec[4] if len(rec) > 4 else ""
        kind = rec[5] if len(rec) > 5 else ""
        ln = rec[6] if len(rec) > 6 else 0

        path = os.path.join(self.data_dir(), "photos", photo)
        if not os.path.exists(path):
            messagebox.showinfo("Снимок", "Файл не найден:\n" + photo)
            return

        win = tk.Toplevel(self)
        win.withdraw()                       # строим невидимым
        win.configure(bg=BG)

        try:
            sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
            maxw, maxh = int(sw * 0.86), int(sh * 0.80)

            img = None
            try:
                from PIL import Image, ImageTk
                pim = Image.open(path)
                pim.thumbnail((maxw, maxh - 96), Image.LANCZOS)
                img = ImageTk.PhotoImage(pim, master=win)
            except Exception:
                try:
                    img = tk.PhotoImage(file=path, master=win)
                except Exception:
                    img = None

            iw = img.width() if img else 720
            ih = img.height() if img else 405
            pad = 14
            W = iw + pad * 2
            H = ih + 44 + 56 + pad

            tkcv = tk.Canvas(win, bg=BG, highlightthickness=0,
                             width=W, height=H)
            tkcv.pack(fill="both", expand=True)
            # Тот же сглаживающий слой, что и в главном окне, иначе
            # рамка и крестик здесь остались бы ступенчатыми.
            cv = SmoothCanvas(tkcv, BG) if SMOOTH else tkcv
            # Держим слой у окна: иначе он живёт только до конца этой
            # функции, а вместе с ним пропадает и готовая картинка.
            win._cv = cv
            if SMOOTH and img is not None:
                img._pil_src = pim.convert("RGB")
            round_outline(cv, 0, 0, W - 1, H - 1, 10, LINE)

            col = (GOLD if kind == "trophy" else
                   GREEN if kind == "zachet" else
                   RED if kind == "small" else SOFT)
            cv.create_text(pad + 2, 22, anchor="w", fill=col,
                           font=(FONT, 11, "bold"), text=name)

            bx1, by1, bx2, by2 = W - 44, 8, W - 10, 38
            top = 44
            fy = top + ih + 16
            bits = []
            if w:
                bits.append(f"{w:.3f} кг")
            if ln:
                bits.append(f"{ln} см")
            bits.append(ts.strftime("%d.%m.%Y  %H:%M"))
            info = "      ".join(bits)

            state = {"hot": 0.0, "goal": 0.0, "job": None}

            def paint():
                """Перерисовывает окно целиком. Дёшево: элементов мало."""
                cv.delete("all")
                round_outline(cv, 0, 0, W - 1, H - 1, 10, LINE)
                cv.create_text(pad + 2, 22, anchor="w", fill=col,
                               font=(FONT, 11, "bold"), text=name)

                # Крестик рисуем линиями: символа «✕» в Segoe UI нет,
                # вместо него выводился пустой квадрат. При наведении
                # кнопка наливается красным и слегка подрастает —
                # так сразу понятно, что она живая.
                t = state["hot"]
                mx, my = (bx1 + bx2) / 2, (by1 + by2) / 2
                gx = 2.0 * t                      # насколько «вырос» фон
                round_rect(cv, bx1 - gx, by1 - gx, bx2 + gx, by2 + gx, 8,
                           fill=self._mix(CHIP2, "#C42B1C", t),
                           outline="")
                arm = 5.0 + 0.8 * t
                lc = self._mix(SOFT, "#FFFFFF", t)
                cv.create_line(mx - arm, my - arm, mx + arm, my + arm,
                               fill=lc, width=1.5 + 0.5 * t,
                               capstyle="round")
                cv.create_line(mx - arm, my + arm, mx + arm, my - arm,
                               fill=lc, width=1.5 + 0.5 * t,
                               capstyle="round")

                if img:
                    cv.create_image(W // 2, top + ih // 2, image=img)
                else:
                    cv.create_text(W // 2, top + ih // 2, fill=DIM,
                                   font=(FONT, 11),
                                   text="Не удалось открыть изображение")

                cv.create_text(pad + 2, fy, anchor="w", fill=SOFT,
                               font=(FONT, 10), text=info)
                if exp:
                    cv.create_text(W - pad - 2, fy, anchor="e", fill=EXP,
                                   font=(FONT_NUM, 13),
                                   text=f"{exp:,}".replace(",", " ")
                                        + " опыта")
                cv.create_text(W // 2, fy + 24, fill=FAINT2,
                               font=(FONT, 8),
                               text="Esc или клик по фону — закрыть")
                if SMOOTH:
                    cv.flush(size=(W, H))

            if img:
                win._img = img       # ссылку держим, иначе GC съест картинку

            win.geometry(f"{W}x{H}+{(sw - W) // 2}+{max(0, (sh - H) // 2)}")

            def close(_e=None):
                try:
                    win.destroy()
                except Exception:
                    pass

            def animate():
                """Подтягивает подсветку крестика к цели."""
                state["job"] = None
                cur, goal = state["hot"], state["goal"]
                if abs(cur - goal) < 0.03:
                    if cur != goal:
                        state["hot"] = goal
                        paint()
                    return
                state["hot"] = cur + (goal - cur) * 0.3
                paint()
                state["job"] = win.after(16, animate)

            def hover(e):
                inside = (bx1 - 4 <= e.x <= bx2 + 4
                          and by1 - 4 <= e.y <= by2 + 4)
                goal = 1.0 if inside else 0.0
                try:
                    tkcv.config(cursor="hand2" if inside else "")
                except Exception:
                    pass
                if goal != state["goal"]:
                    state["goal"] = goal
                    if state["job"] is None:
                        state["job"] = win.after(1, animate)

            drag = {}

            def on_click(e):
                if e.y <= 44:
                    if e.x >= bx1 - 4:          # попали в крестик
                        close()
                        return
                    drag["x"] = e.x_root - win.winfo_x()
                    drag["y"] = e.y_root - win.winfo_y()
                else:
                    close()

            def on_move(e):
                if drag:
                    win.geometry(f"+{e.x_root - drag['x']}"
                                 f"+{e.y_root - drag['y']}")

            paint()
            tkcv.bind("<Button-1>", on_click)
            tkcv.bind("<B1-Motion>", on_move)
            tkcv.bind("<Motion>", hover)
            tkcv.bind("<Leave>", lambda _e: hover(type("E", (), {
                "x": -99, "y": -99})()))
            win.bind("<Escape>", close)
            win.protocol("WM_DELETE_WINDOW", close)

            # Показываем в самом конце: без рамки, поверх всех, с фокусом.
            win.overrideredirect(True)
            win.deiconify()
            win.attributes("-topmost", True)
            win.lift()
            win.focus_force()
        except Exception as e:
            self._last_error = f"просмотр фото: {e}"
            try:
                win.destroy()
            except Exception:
                pass

    def on_press(self, e):
        """Один вход для всех кликов: кнопки, вкладки, ресайз, перенос."""
        g = getattr(self, "_grip", None)
        if g and g[0] <= e.x <= g[2] and g[1] <= e.y <= g[3]:
            self._rs_start(e)
            return
        if e.y <= 52 and e.x <= getattr(self, "_drag_limit", 0):
            self._drag_start(e)
            return
        if self.tab == 1 and self._gallery_click(e):
            return
        # Ручки ползунка веса: берём ближайшую к курсору.
        if self.tab == 2 and getattr(self, "_jr_track", None):
            tx1, tx2, ty, wlo, whi = self._jr_track
            if tx1 - 12 <= e.x <= tx2 + 12 and abs(e.y - ty) <= 12:
                a = self.jr_wmin if self.jr_wmin is not None else wlo
                b = self.jr_wmax if self.jr_wmax is not None else whi
                span = max(1e-6, whi - wlo)
                pa = tx1 + (tx2 - tx1) * (a - wlo) / span
                pb = tx1 + (tx2 - tx1) * (b - wlo) / span
                self._jr_drag = "lo" if abs(e.x - pa) <= abs(e.x - pb) else "hi"
                self._jr_drag_move(e)
                return
        # Отдача нажатия — сразу при касании кнопки мышью, до click:
        # квадрат под курсором «продавливается» мгновенно, и видно,
        # что нажатие принято. Быстрые зоны покрывают все кликабельные
        # кнопки (вкладки, фильтры, чипы, «Обновить», «Начать заново»…),
        # и эффект получают они все разом, без правки каждой ветки.
        pressed = False
        for _k, _b in getattr(self, "_hot_btns", {}).items():
            if _b[0] <= e.x <= _b[2] and _b[1] <= e.y <= _b[3]:
                self._press_fx(_k)
                pressed = True
                break
        if not pressed:
            # Остальные кликабельные места (чекбоксы журнала, фото
            # обзора, фильтры галереи): у них нет быстрой зоны, но
            # отдача нажатия положена и им — «продавливаются» все.
            self._press_fx_any(e)
        # Форсируем отрисовку быстрого слоя ДО команды: «Обновить»,
        # запуск бота и пр. могут занять заметное время, и без этого
        # пользователь видел задержку вместо нажатия.
        try:
            self.update_idletasks()
        except Exception:
            pass
        self.on_click(e)

    def on_drag(self, e):
        if getattr(self, "_rs", None):
            self._rs_move(e)
        elif getattr(self, "_jr_drag", None):
            self._jr_drag_move(e)
        elif self._drag:
            self._drag_move(e)

    def _jr_drag_move(self, e):
        """Тянем ручку ползунка веса."""
        tx1, tx2, ty, wlo, whi = self._jr_track
        t = (e.x - tx1) / max(1.0, tx2 - tx1)
        val = wlo + (whi - wlo) * max(0.0, min(1.0, t))
        a = self.jr_wmin if self.jr_wmin is not None else wlo
        b = self.jr_wmax if self.jr_wmax is not None else whi
        if self._jr_drag == "lo":
            self.jr_wmin = min(val, b)
            self.jr_wmax = b
        else:
            self.jr_wmax = max(val, a)
            self.jr_wmin = a
        # Ползунок на всю ширину = фильтр не задан. Иначе записи без
        # веса пропадали бы навсегда, даже когда границы не трогали.
        if (self.jr_wmin <= wlo + 1e-9) and (self.jr_wmax >= whi - 1e-9):
            self.jr_wmin = self.jr_wmax = None
        self.jr_page = 0
        self._draw_soon()

    def on_release(self, e):
        self._drag = None
        self._rs = None
        self._jr_drag = None

    def on_wheel(self, e, direction=None):
        if direction is None:
            direction = 1 if getattr(e, "delta", 0) > 0 else -1
        # В галерее теперь тоже страницы, а не прокрутка.
        if self.tab == 1:
            pages = getattr(self, "_gal_pages", 1)
            new = max(0, min(self.gal_page - direction, pages - 1))
            if new != self.gal_page:
                self.gal_page = new
                self.draw()
            return
        # В журнале прокрутки нет — колесо перелистывает страницы.
        if self.tab == 2:
            pages = getattr(self, "_jr_pages", 1)
            new = max(0, min(self.jr_page - direction, pages - 1))
            if new != self.jr_page:
                self.jr_page = new
                self.draw()
            return
        # В сессиях — так же: страницы, а не полоса прокрутки.
        if self.tab == 3:
            pages = getattr(self, "_ses_pages", 1)
            new = max(0, min(self.ses_page - direction, pages - 1))
            if new != self.ses_page:
                self.ses_page = new
                self.draw()
            return
        # В галерее шаг равен высоте ряда: прокрутка на 60 пикселей
        # оставляла ряды разрезанными пополам.
        step = 228 if self.tab == 1 else 60
        cur = self.scroll.get(self.tab, 0)
        new = cur - direction * step
        new = max(0, min(new, self.scroll_max.get(self.tab, 0)))
        if new != cur:
            self.scroll[self.tab] = new
            # Без битмап-трюков: куски готового кадра в реальном окне
            # расползались по слоям, и меню «улетало». Честная
            # перерисовка на каждый клик — содержимое движется строго
            # внутри своей панели, ничего не разъезжается.
            self.draw()

    def on_double(self, e):
        if e.y <= 52 and e.x <= getattr(self, "_drag_limit", 0):
            self.toggle_max()

    def on_click(self, e):
        for x1, y1, x2, y2, cmd, _lb in getattr(self, "_wbtn", []):
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                cmd()
                return
        # Переключатели на вкладке «О программе».
        if self.tab == 4:
            for h in self._set_hit:
                if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                    h[4]()
                    return

        # Вкладка «Сессии»: «Очистить».
        if self.tab == 3:
            for h in self._ses_hit:
                if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                    h[4]()
                    return

        # Клик по рыбке в «Обзоре» — выпускает пузырьки.
        if self.tab == 0:
            pos = self.__dict__.get("_hero_fish_pos")
            if pos and ((e.x - pos[0]) ** 2 + (e.y - pos[1]) ** 2
                        <= (pos[2] + 12) ** 2):
                self._bubble_spawn(pos)
                return

        # Кликабельные области обзора (фото лучшего улова).
        if self.tab == 0:
            for h in self._ov_hit:
                if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                    h[4]()
                    return

        # Элементы журнала: флажки, фильтры, заголовки, кнопки.
        if self.tab == 2:
            for hit in self._jr_hit:
                x1, y1, x2, y2, cmd = hit[:5]
                if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                    cmd()
                    return
            # клик мимо поля поиска убирает из него курсор
            if self.jr_search_on:
                self.jr_search_on = False
                self.draw()
        for x1, y1, x2, y2, i in self._tabhit:
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                if i == "refresh":
                    # Кнопка сначала должна ОЩУТИМО нажаться: сами
                    # чтение файлов и кадр — через 120 мс, когда
                    # «продавливание» уже видно. Иначе заморозка
                    # перечитывания съедала весь отклик.
                    self.after(120, self._refresh_now)
                else:
                    self.tab = i
                    self.draw()
                return
        for x1, y1, x2, y2, cmd in getattr(self, "_btns", []):
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                # Сначала отдача, потом дело: диалог подтверждения
                # блокирует цикл, и без этого нажатие осталось бы
                # вообще без отклика.
                self._press_start("newperiod")
                self.update_idletasks()
                cmd()
                return

    def on_move(self, e):
        """Одно движение мыши — одно решение о подсветке.

        Раньше блоки вкладок шли по очереди и каждый сам звал
        обновление: первый не находил цель и гасил подсветку, второй
        находил и зажигал её заново. На каждое движение — сброс, отсюда
        мигание. Теперь сперва определяем цель целиком, и только потом
        один раз применяем.
        """
        new_h = None
        cursor = None

        # кнопки окна (свернуть / развернуть / закрыть)
        for x1, y1, x2, y2, _cmd, lb in self._wbtn:
            if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                new_h, cursor = lb, "hand2"
                break
        # кнопка «Обновить» на линии вкладок
        if new_h is None:
            for x1, y1, x2, y2, i in self._tabhit:
                if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                    new_h = "refresh" if i == "refresh" else None
                    cursor = "hand2"
                    break
        # главная кнопка внизу
        if new_h is None and cursor is None:
            for x1, y1, x2, y2, _cmd in self._btns:
                if x1 <= e.x <= x2 and y1 <= e.y <= y2:
                    new_h, cursor = "newperiod", "hand2"
                    break

        # содержимое активной вкладки
        if new_h is None and cursor is None:
            zones = ()
            if self.tab == 0:
                zones = self._ov_hit
            elif self.tab == 1:
                zones = self._gal_ui
            elif self.tab == 2:
                zones = self._jr_hit
            elif self.tab == 3:
                zones = self._ses_hit
            elif self.tab == 4:
                zones = self._set_hit
            for h in zones:
                if h[0] <= e.x <= h[2] and h[1] <= e.y <= h[3]:
                    cursor = h[6] if len(h) > 6 else "hand2"
                    if len(h) > 5 and h[5]:
                        new_h = h[5]
                    break

            # карточки галереи и подсказка обзора — после кнопок,
            # чтобы панель имела приоритет над содержимым
            if new_h is None and cursor is None:
                if self.tab == 1:
                    for gx1, gy1, gx2, gy2, rec in self._gal_hit:
                        if gx1 <= e.x <= gx2 and gy1 <= e.y <= gy2:
                            if len(rec) > 4 and rec[4]:
                                new_h = f"gal_{rec[0].timestamp()}"
                                cursor = "hand2"
                            break
                elif self.tab == 0:
                    z = self._tip_zone
                    if z and z[0] <= e.x <= z[2] and z[1] <= e.y <= z[3]:
                        new_h = "m_last"
                    else:
                        # Плитки категорий: показываем, какие именно
                        # рыбы стоят за цифрой.
                        for ck, zz in self._cat_zones.items():
                            if (zz[0] <= e.x <= zz[2]
                                    and zz[1] <= e.y <= zz[3]):
                                new_h = f"m_cat_{ck}"
                                break

        # курсор-рука над рыбкой в «Обзоре» — намёк, что она живая
        if cursor is None and self.tab == 0:
            pos = self.__dict__.get("_hero_fish_pos")
            if pos and ((e.x - pos[0]) ** 2 + (e.y - pos[1]) ** 2
                        <= (pos[2] + 12) ** 2):
                cursor = "hand2"

        if new_h != self._hover_btn:
            self._hover_btn = new_h
            self._hover_changed()

        W = self.cv.winfo_width()
        H = self.cv.winfo_height()
        if e.x > W - 18 and e.y > H - 18:
            self._set_cursor("size_nw_se")
        else:
            self._set_cursor(cursor or "")

    def pick_file(self):
        p = filedialog.askopenfilename(
            title="Выбери stats.csv",
            filetypes=[("CSV", "*.csv"), ("Все файлы", "*.*")])
        if p:
            self.csv_path = p
            self.reload()

    def reset_stats(self):
        """Полный сброс: события, уловы и фото — одной кнопкой.

        Раньше переименовывался только stats.csv, а fish_log.csv и папка
        с фото оставались — приходилось чистить вручную.
        """
        d = self.data_dir()
        fish_csv = os.path.join(d, "fish_log.csv")
        photos = os.path.join(d, "photos")

        n_ev = len(self.stats.rows)
        n_fish = len(self.stats.fish)
        n_ph = 0
        if os.path.isdir(photos):
            try:
                n_ph = len([f for f in os.listdir(photos)
                            # save_photo пишет .jpg — считать только .png
                            # нельзя: в диалоге всегда было «фотографий: 0»
                            if f.lower().endswith((".jpg", ".jpeg", ".png"))])
            except OSError:
                n_ph = 0

        if not (n_ev or n_fish or n_ph):
            messagebox.showinfo("Сброс", "Статистика и так пустая.")
            return

        if not messagebox.askyesno(
                "Сброс статистики",
                f"Удалить всё накопленное?\n\n"
                f"событий бота: {n_ev}\n"
                f"записей об улове: {n_fish}\n"
                f"фотографий: {n_ph}\n\n"
                f"Файлы переносятся в папку backup — их можно вернуть."):
            return

        import shutil
        from datetime import datetime as _dt
        stamp = _dt.now().strftime("%Y%m%d_%H%M%S")
        bak = os.path.join(d, "backup", stamp)
        errors = []

        # Каждый шаг в СВОЁМ try. Раньше все три операции стояли в одном
        # блоке: стоило перемещению папки со снимками споткнуться (на
        # Windows она бывает занята — открыт просмотрщик, антивирус
        # дочитывает файл), как csv уже уехали в backup, а
        # os.makedirs(photos) до выполнения не доходил. Дальше
        # распознавание писало снимки в несуществующую папку и молча
        # теряло их: в журнале оставались только категории от бота.
        try:
            os.makedirs(bak, exist_ok=True)
        except Exception as e:
            errors.append(f"не создать папку backup: {e}")

        for src in (self.csv_path, fish_csv):
            if not os.path.exists(src):
                continue
            try:
                shutil.move(src, os.path.join(bak, os.path.basename(src)))
            except Exception as e:
                errors.append(f"{os.path.basename(src)}: {e}")

        try:
            if os.path.isdir(photos) and os.listdir(photos):
                shutil.move(photos, os.path.join(bak, "photos"))
        except Exception as e:
            # Не смогли унести целиком — переносим по одному файлу.
            # Занятым обычно оказывается один снимок, а не вся папка.
            moved, stuck = 0, 0
            try:
                os.makedirs(os.path.join(bak, "photos"), exist_ok=True)
                for fn in os.listdir(photos):
                    try:
                        shutil.move(os.path.join(photos, fn),
                                    os.path.join(bak, "photos", fn))
                        moved += 1
                    except Exception:
                        stuck += 1
            except Exception:
                pass
            if stuck:
                errors.append(f"снимки: перенесено {moved}, "
                              f"занято {stuck} ({e})")

        # Папка снимков обязана существовать ПОСЛЕ любого исхода.
        # Это и есть то самое «важное, что удаляется»: распознавание
        # запомнило путь при старте и продолжает писать именно туда.
        try:
            os.makedirs(photos, exist_ok=True)
        except Exception as e:
            errors.append(f"не создать папку снимков: {e}")

        # Сообщаем распознаванию, что период начат заново.
        #
        # У него в памяти висит последний записанный улов: имя, вес,
        # длина и время. Пока не пройдёт COOLDOWN_SEC, точно такая же
        # рыба считается повтором и не пишется. После сброса журнал
        # пуст, а память осталась — и первая же рыба могла молча
        # исчезнуть. Файл-отметку распознавание видит и забывает
        # прошлый улов.
        try:
            with open(os.path.join(d, "RESET"), "w", encoding="utf-8") as f:
                f.write(f"{int(time.time())}\n")
        except Exception:
            pass

        # чистим кэш миниатюр, иначе останутся старые картинки
        self._gal_imgs = {}
        self._stamp = None
        self.stats = Stats()
        self.scroll = {k: 0 for k in self.scroll}
        # Журнал тоже начинаем с чистого листа: старый фильтр и поиск
        # на пустых данных выглядели бы как «ничего не найдено».
        self.jr_sel.clear()
        self.jr_filter = "all"
        self.jr_query = ""
        self.jr_search_on = False
        self.reload()

        if errors:
            messagebox.showwarning(
                "Сброс", "Частично не удалось:\n" + "\n".join(errors)
                + "\n\nВозможно, файл занят — закрой OCR и повтори.")
        else:
            messagebox.showinfo(
                "Готово", f"Статистика очищена.\nКопия сохранена в:\n{bak}")


# ---------------------------------------------------------- одно окно
# №53: бот поднимает статистику вместе с Менеджером, и Менеджер тоже
# умеет её поднимать — оба могли случайно открыть по копии. Замок по
# PID: вторая копия видит живое окно и тихо уходит, никаких близнецов.
_STATS_LOCK = None


def _pid_alive(pid):
    try:
        pid = int(pid or 0)
    except (TypeError, ValueError):
        return False
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            h = ctypes.windll.kernel32.OpenProcess(0x1000, False, pid)
            if h:
                ctypes.windll.kernel32.CloseHandle(h)
                return True
            return False
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except PermissionError:
        return True        # сигналить нельзя, но процесс точно жив
    except (OSError, OverflowError):
        return False


def _stats_unlock():
    global _STATS_LOCK
    if _STATS_LOCK:
        try:
            with open(_STATS_LOCK, encoding="ascii") as f:
                old = int((f.read() or "0").strip())
            if old == os.getpid():
                os.remove(_STATS_LOCK)
        except Exception:
            pass
        _STATS_LOCK = None


def _stats_single_instance():
    """True — окно можно открывать; False — уже есть живое, выходим."""
    global _STATS_LOCK
    try:
        d = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "TrofPridi_data")
        os.makedirs(d, exist_ok=True)
        lock = os.path.join(d, "stats_app.lock")
        try:
            with open(lock, encoding="ascii") as f:
                old = int((f.read() or "0").strip())
        except Exception:
            old = 0
        if old and old != os.getpid() and _pid_alive(old):
            return False
        with open(lock, "w", encoding="ascii") as f:
            f.write(str(os.getpid()))
        _STATS_LOCK = lock
        import atexit
        atexit.register(_stats_unlock)
        return True
    except Exception:
        # диск капризничает — запускаемся (лучше дубль, чем пустота)
        return True


def _license_gate():
    """№72: подписка кончилась — статистика показывает только замок.

    Менеджер и ключ — вне её: здесь только честное окно с HWID.
    """
    try:
        import manager_core as mc
    except ImportError:
        return                              # нет ядра — не наш суд
    try:
        mc.sync_license_state()
        if mc.license_state()[0] != "expired":
            return
    except Exception:
        return                              # сбой проверки — не наказываем
    import tkinter as _tk
    from tkinter import messagebox as _mb
    _r = _tk.Tk()
    _r.withdraw()
    _mb.showerror(
        "TrofPridi — подписка",
        "Подписка закончилась.\n\n"
        "Открой Менеджер и введи ключ — всё продолжит работать.\n"
        "Твой HWID (нужен для ключа): " + mc.hwid())
    _r.destroy()
    raise SystemExit(0)


if __name__ == "__main__":
    _license_gate()
    if _stats_single_instance():
        App().mainloop()

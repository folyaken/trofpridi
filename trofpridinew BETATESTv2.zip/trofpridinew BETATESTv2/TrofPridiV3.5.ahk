﻿#Persistent
#NoEnv
SetWorkingDir %A_ScriptDir%
SendMode Input
CoordMode, Pixel, Screen
SetBatchLines, -1 ; Максимальная скорость работы

; Своя иконка в трее и в списке процессов вместо стандартной
; зелёной буквы H. Файл лежит рядом со скриптом; если его нет,
; бот работает как обычно — просто со значком AutoHotkey.
IconFile := A_ScriptDir . "\trofpridi.ico"
if (FileExist(IconFile))
    Menu, Tray, Icon, %IconFile%
Menu, Tray, Tip, TrofPridi v3.5 - статистика рыбалки

; ==========================================
; DPI: без этого на 2К с масштабом Windows 125/150%
; A_ScreenWidth врёт (1706 вместо 2560) и ImageSearch мажет.
; Должно стоять ДО создания GUI.
; ==========================================
DllCall("User32\SetProcessDPIAware")

; генератор случайных чисел засевается от времени: при вариативности
; задержки не повторяются от запуска к запуску
Random, , NewSeed

OnMessage(0x0201, "WM_LBUTTONDOWN")

global isActive := false
global isCasting := false
global isEvaluating := false
global isShiftDown := false
global isRButtonDown := false
global lastFishTime := 0
global fishFirstSeenTime := 0
global coffeeTimerLimit := 0
global nextFoodCheck := 0
global nextCoffeeCheck := 0
global nextSunCheck := 0
global consumeLockUntil := 0
global nextConsumeScan := 0
; «Слот пуст»: считаем промахи расходников. Если после нажатия 4/5
; вылезло красное уведомление — значит еды/кофе нет. Пять промахов
; подряд — кнопки 4 и 5 не трогаем 5-8 минут (рандом до миллисекунд);
; потом пробуем снова (вдруг уже купил еды).
global consumeGiveUpUntil := 0  ; до этой метки кнопки 4/5 — табу
global consumeFailCount := 0    ; промахи «Слот пуст» подряд
global SessionStartTime := A_TickCount
global TotalCaught := 0
global TotalKept := 0
global TotalTrophy := 0
global TotalReleased := 0
; --- ТЕМА ОФОРМЛЕНИЯ МЕНЮ (dark/light) ---
; Палитра живёт в переменных C_*: функция ApplyOsdTheme() перекрашивает
; уже построенное меню, а тему читает из configs\stats.ini — того же
; INI, что пишет окно статистики (тумблер «Светлая тема»), см. №51.
global OsdTheme := "dark"
; Последние подписи меню — RebuildOSD() вернёт их после пересоздания.
global lastStage := "Пауза", lastFish := "—", lastBar := "—"
global C_BG := "1B222B", C_TITLE := "00A2FF", C_SOFT := "9AA9B8"
global C_DIM := "6C7B8B", C_MUTE := "5A6B7C", C_FAINT := "4A5B6C"
global C_FG := "FFFFFF", C_STAGE := "FFB300", C_ACCENT := "00A2FF"
global C_GREEN := "00E6B8", C_RED := "FF5555", C_BITE := "00FF00"
global C_WORK := "009900", C_WARN := "B08D00"
global C_LINE_RAW := "2A3036"   ; серая дорожка/линия баров (тёмная тема)
; ----------------------------------------------------------
; БАРЫ МЕНЮ — «СТЕКЛЯННЫЙ СЛОЙ», НИ ОДНОГО КОНТРОЛА WINDOWS.
; Родной Progress на этой машине Windows упорно красит в чёрный и
; замирает (пробовали и PBM-сообщения, и снятие темы — бесполезно),
; а Text/Text-прямоугольники система вообще рисует прозрачными.
; Поэтому полоски рисуем САМИ, попиксельно через GDI+, в отдельное
; прозрачное окно-«стекло» поверх меню: клики оно пропускает, за
; меню ездит следом. Кадр уходит на экран одной командой
; UpdateLayeredWindow целиком (та же техника, что у игровых
; оверлеев) — поэтому ни мерцания, ни чёрных полос быть не может:
; Windows над этими пикселями власти не имеет вообще.
; ----------------------------------------------------------
global pTokenGdip := 0
global hGlass := 0
global glassDC := 0, glassHBM := 0, glassOBM := 0, glassGfx := 0
global GlassW := 310, GlassH := 171   ; полотно: клиент (20,70)..(330,241)
global GlassDX := 20, GlassDY := 70   ; сдвиг слоя от УГЛА ОКНА меню
global GlassSig := ""                 ; подпись последнего кадра (антидёрг)
; Последний процент каждого живого бара (-1 = ещё не задавали): нужен,
; чтобы после пересборки меню вернуть шкалам их значения. Бар №1 —
; статичный, изначально полный (100).
global LastBarPct1 := 100, LastBarPct2 := -1, LastBarPct3 := -1
global LastCoffeePct := 0
; АФК-перерывы (работают только при включённой вариативности):
; nextAfk — когда уходить «покурить», afkUntil — до каких пор отдыхаем,
; afkCount — сколько перерывов уже было за сессию (счётчик в меню).
global nextAfk := 0
global afkUntil := 0
global afkCount := 0
; «Пора в перерыв»: ставится будильником, а сам перерыв встанет
; ТОЛЬКО после ближайшей оценки улова. Никогда посреди ожидания
; клёва: раньше бот «засыпал» с клюнувшей рыбой и, проснувшись,
; не зажимал ЛКМ — рыба сходила без всякой борьбы.
global afkPending := false
; Страховка катушки: помним, что снасть в воде и что ЛКМ зажата.
; Если реальность с флагом рассинхронизируется (перерыв, пауза),
; EnsureReelHeld дожмёт кнопку обратно уже на следующем такте.
global tackleInWater := false
global resumeUntil := 0        ; №60: дотяжка после паузы (см. EnsureReelHeld)
global isLButtonDown := false
; Самоспасение из «тишины»: когда от игры 30+ минут нет ни заброса,
; ни поклёвки, ни улова, бот сам один раз в 30 минут мотает снасть
; (подсечкой ПКМ без рыбы) и закидывает заново. lastRecastAt — тик
; последней такой попытки; сбрасывается при любой жизни (TouchAction).
global lastRecastAt := 0
; ПКМ при борьбе с рыбой (только с вариативностью): после того как
; рыба замечена, ждём случайные 2-8 сек, потом жмём рывками по 3-12
; секунд с передышками 1-7 секунд — как человек «покачивает» катушкой.
; rmbPressAfter — задержка до первого нажатия ПКМ, shiftPressAfter —
; задержка до зажатия Shift (человек не жмёт в тот же миг, как заметил
; значок), rmbUntil — до какого такта держим, rmbNextAt — когда жать
; снова, rmbLastMs/rmbGapMs — длины рывка и передышки (их честно
; показываем в меню).
global rmbPressAfter := 0
global shiftPressAfter := 0
global rmbUntil := 0
global rmbNextAt := 0
global rmbLastMs := 0
global rmbGapMs := 0
; Текущее смещение курсора от «дрожания» мыши (максимум ±10 пикселей
; от исходной точки, рядом с ней бывает чаще, у краёв — реже).
global jitX := 0
global jitY := 0
; «Сторож»: помним момент последнего удачного действия (заброс,
; поклёвка, улов). Бот активен, а от игры 30+ минут тишина — пишем
; об этом прямо в меню: раньше такое молчаливое стояние выглядело
; как «встал АФК» без всяких пояснений.
global lastActionTime := A_TickCount
global quietShown := false
global quietLogged := false
; Служебные файлы держим в отдельной папке, чтобы не засорять корень
global DataDir := A_ScriptDir . "\TrofPridi_data"
global StatsFile := DataDir . "\stats.csv"
; №53: маяк для Менеджера — раз в секунду пишем сюда время и режим
; бота, карточка «Спиннинг» читает его и честно показывает статус.
global BotStateFile := DataDir . "\bot_state.ini"
; --- №72: ЗАМОК ПОДПИСКИ ---
; Менеджер/статистика пишут lic_state.ini (active=1/0). Файла нет —
; работаем: свежая установка, триал ещё никем не был помечен.
global LicStateFile := DataDir . "\lic_state.ini"
global LicBlocked := false
global licTicks := 0
global StatsPID := 0
global ManagerPID := 0
global LastStatCol := ""
global LastStatTxt := ""
; --- ВАРИАТИВНОСТЬ ЗАДЕРЖЕК ---
; Тумблер «Safe Mode» в TrofPridi Manager (configs\bot_spin.ini, ключ
; variability). Раньше лежал в общем settings.txt — №51 перенёс сюда.
; 0 (по умолчанию) — все задержки ровно как в прежней версии.
; 1 — паузы между действиями каждый раз немного случайные: заброс
; идёт то быстрее, то медленнее, кофе пьётся не секунда в секунду.
global Variability := 0
; Длина текущего кофе-цикла (при вариативности плавает около 20 мин).
global coffeeSpan := 1200000

; №72: перечитывает замок из lic_state.ini. true = подписки нет.
LicCheck() {
    global LicStateFile, LicBlocked
    if (!FileExist(LicStateFile)) {
        LicBlocked := false
        return false
    }
    IniRead, licA, %LicStateFile%, lic, active, 1
    LicBlocked := (Trim(licA) = "0")
    return LicBlocked
}

LicBlockedMsg() {
    MsgBox, 48, TrofPridi, Подписка закончилась.`nОткрой Менеджер и введи ключ — и ловим дальше!`nТвой HWID — на вкладке «Активация».
}

; Случайная вариация числа v в пределах v*kLo .. v*kHi.
; При выключенной вариативности возвращает исходное v — поэтому без
; включённой настройки бот работает именно так, как работал раньше.
; Возвращает ЛЮБОЕ целое из пределов (например, 237 или 462 мс,
; а не круглые 1000/2000) — случайность вплоть до миллисекунд.
Var(v, kLo := 0.8, kHi := 1.25) {
    global Variability
    if (!Variability)
        return v
    lo := Round(v * kLo)
    hi := Round(v * kHi)
    if (hi < lo)
        hi := lo
    Random, r, %lo%, %hi%
    return r
}

; Случайное целое ровно от lo до hi включительно — нужно, когда границы
; заданы сами по себе (например, 2000-8000 мс), а не долями от базы.
; При выключенной вариативности возвращает base — прежнее фиксированное
; значение, то есть без настройки бот работает как раньше.
VarRange(base, lo, hi) {
    global Variability
    if (!Variability)
        return base
    Random, r, %lo%, %hi%
    return r
}

; Миллисекунды в короткую подпись для меню: меньше секунды — «534 мс»,
; больше — секунды с десятыми, «9.6 с» (число меняется жёлтой строчкой
; прямо на глазах, поэтому длинные хвосты ни к чему).
FmtMs(ms) {
    if (ms < 0)
        ms := 0
    if (ms >= 1000)
        return Format("{:0.1f} с", ms / 1000)
    return ms " мс"
}

; Лёгкое «дрожание» мыши: курсор смещается от своей исходной точки
; не дальше radius пикселей. Смещение НЕ равномерное — берём среднее
; двух случайных: возле исходной точки курсор бывает чаще, у краёв
; реже. jitX/jitY помнят накопленное смещение, поэтому курсор не
; «уползает» по экрану, а весь вечер кружит в тех же ±10 пикселях.
; Обычный MouseMove — как движение рукой, в игру ничего не внедряется.
; При выключенной вариативности не делает ничего.
JitterMouse(radius := 10) {
    global Variability, jitX, jitY, isRButtonDown, isShiftDown
    if (!Variability)
        return
    ; Пока зажата ПКМ (борьба с рыбой), игра САМА ведёт камеру и прячет
    ; курсор: наши относительные сдвиги копятся «вслепую», и в момент
    ; отпускания кнопки курсор заметно подпрыгивал. Не трогаем его,
    ; пока идёт подсечка/подмотка — это был тот самый резкий рывок.
    if (isRButtonDown or isShiftDown)
        return
    Random, a1, -%radius%, %radius%
    Random, a2, -%radius%, %radius%
    tx := (a1 + a2) // 2
    Random, b1, -%radius%, %radius%
    Random, b2, -%radius%, %radius%
    ty := (b1 + b2) // 2
    dx := tx - jitX
    dy := ty - jitY
    ; Курсор мог подвинуть сам игрок или игра — тогда наша «база»
    ; jitX/jitY разъехалась с реальным положением. Раньше шаг просто
    ; обрезали до 2*radius, и курсор СКОЛЬЗИЛ на эти 20 пикселей —
    ; заметный резкий рывок. Шаг больше radius не бывает честным:
    ; мелкая дрожь так далеко не целится. Значит, цель устарела —
    ; не двигаемся, а переснимаем базу: следующие сдвиги крошечные.
    if (dx > radius or dx < -radius or dy > radius or dy < -radius) {
        jitX := tx
        jitY := ty
        return
    }
    if (dx = 0 and dy = 0)
        return
    ; не «телепорт», а плавное движение с разгоном и торможением
    HumanMove(dx, dy)
    jitX += dx
    jitY += dy
}

; Двигает курсор на (dx, dy) относительно текущей точки КАК РУКА:
; шагами, с разгоном в начале и торможением в конце. Размеры шагов
; считаются по кривой smoothstep (3t^2-2t^3), между шагами паузы
; 6-16 мс — итого движение занимает доли секунды и выглядит живым,
; а не как мгновенный прыжок «из точки А в точку Б». Обычный
; MouseMove + Sleep, в игру ничего не внедряется.
HumanMove(dx, dy) {
    Random, steps, 6, 10
    px := 0
    py := 0
    Loop, %steps% {
        t := A_Index / steps
        e := 3 * t * t - 2 * t * t * t
        nx := Round(dx * e)
        ny := Round(dy * e)
        mx := nx - px
        my := ny - py
        px := nx
        py := ny
        if (mx <> 0 or my <> 0)
            MouseMove, %mx%, %my%, 0, R
        Random, stepPause, 6, 16
        Sleep, %stepPause%
    }
}

; Долгая пауза с «дрожанием» курсора: суммарно ждём ровно ms
; (те мс, что написаны в меню), но за это время курсор пару раз
; чуть съезжает — ожидание выглядит живым. Короткие паузы
; (до 800 мс) и выключенная вариативность — обычный Sleep, как раньше.
SleepJitter(ms) {
    global Variability
    if (!Variability or ms < 800) {
        Sleep, %ms%
        return
    }
    Random, pieces, 2, 4
    deadline := A_TickCount + ms
    Loop, %pieces% {
        left := deadline - A_TickCount
        if (left <= 0)
            break
        part := left // (pieces - A_Index + 1)
        if (part > 0)
            Sleep, %part%
        JitterMouse(10)
    }
    left := deadline - A_TickCount
    if (left > 0)
        Sleep, %left%
}


; ==========================================
; 📐 МАСШТАБИРОВАНИЕ ПОД ЛЮБОЕ РАЗРЕШЕНИЕ
; База: 1920x1080. Интерфейс игры тянется по высоте экрана,
; поэтому коэффициент считаем от высоты.
; 1920x1080 -> 1.0 | 2560x1440 -> 1.3333 | 3840x2160 -> 2.0
; ==========================================
global BaseW := 1920
global BaseH := 1080
global UIScale := A_ScreenHeight / BaseH

; Ручное переопределение, если авто-масштаб не угадал.
; 0 = авто. Пример: UIScaleOverride := 1.25
global UIScaleOverride := 0
if (UIScaleOverride > 0)
    UIScale := UIScaleOverride

; Папка с шаблонами под родное разрешение: img_2560x1440 и т.п.
; Если она есть — картинки берутся оттуда БЕЗ масштабирования (точнее всего).
; Если нет — берутся из папки скрипта и растягиваются на лету.
global NativeDir := A_ScriptDir . "\img_" . A_ScreenWidth . "x" . A_ScreenHeight
if (!InStr(FileExist(NativeDir), "D"))
    NativeDir := ""

; Сколько красных пикселей должно найтись в зоне, чтобы считать
; параметр упавшим в ноль. Замер: голодная шкала даёт 45, полная — 0.
; 12 = уверенный запас в обе стороны.
global RedPixelsNeeded := 12   ; пересчитывается ниже под разрешение
; Сколько строк с цветом плашки нужно найти, чтобы признать категорию.
; Плашка высотой 28-45 точек при шаге 2 даёт 14-22 строки, порог 8
; отсекает случайные блики и не пропускает настоящую плашку.
global BadgeRowsNeeded := 8
global ImgCache := {}

; --- Пересчёт координат ---
; SC  - размер/расстояние
; LX  - X от левого края          RX - X от правого края
; TY  - Y от верха                BY - Y от низа
; CX  - X от центра экрана
SC(v) {
    global UIScale
    return Round(v * UIScale)
}
LX(v) {
    global UIScale
    return Round(v * UIScale)
}
RX(v) {
    global UIScale, BaseW
    return A_ScreenWidth - Round((BaseW - v) * UIScale)
}
TY(v) {
    global UIScale
    return Round(v * UIScale)
}
BY(v) {
    global UIScale, BaseH
    return A_ScreenHeight - Round((BaseH - v) * UIScale)
}
CX(v) {
    global UIScale, BaseW
    return Round(A_ScreenWidth / 2 + (v - BaseW / 2) * UIScale)
}

; Не даём зоне вылезти за экран (иначе ImageSearch/PixelSearch = ошибка)
Clamp(ByRef x1, ByRef y1, ByRef x2, ByRef y2) {
    x1 := (x1 < 0) ? 0 : x1
    y1 := (y1 < 0) ? 0 : y1
    x2 := (x2 > A_ScreenWidth - 1)  ? A_ScreenWidth - 1  : x2
    y2 := (y2 > A_ScreenHeight - 1) ? A_ScreenHeight - 1 : y2
    if (x2 < x1)
        x2 := x1
    if (y2 < y1)
        y2 := y1
}

; Тема из configs\stats.ini (№51: раньше это был общий settings.txt —
; его читаем запасным путём, пока статистика/Менеджер не пересохранили
; настройки в новый формат).
ReadOsdTheme() {
    cfgS := A_ScriptDir . "\TrofPridi_data\configs\stats.ini"
    IniRead, t, %cfgS%, ui, theme, __M__
    if (t != "__M__")
        return (t = "light") ? "light" : "dark"
    cfgFile := A_ScriptDir . "\TrofPridi_data\settings.txt"
    if FileExist(cfgFile) {
        FileRead, cfgText, %cfgFile%
        if (!ErrorLevel and RegExMatch(cfgText, "theme\s*=\s*light"))
            return "light"
    }
    return "dark"
}

; Перекрашивает готовое меню в тёмную или светлую тему.
; Бары — стеклянный слой: перерисовываем его новой палитрой в конце
; (BarGlass_Render), контролов Windows среди баров больше нет.
ApplyOsdTheme(name) {
    global
    OsdTheme := (name = "light") ? "light" : "dark"
    if (OsdTheme = "light") {
        C_BG := "E4E7ED", C_TITLE := "0078D2", C_SOFT := "46525F"
        C_DIM := "67727F", C_MUTE := "8490A0", C_FAINT := "AEB6C2"
        C_FG := "1B2430", C_STAGE := "C98A00", C_ACCENT := "0078D2"
        C_GREEN := "00A87E", C_RED := "E04848", C_BITE := "0A9E2E"
        C_WORK := "1A7A34", C_WARN := "8F6E00"
        ; Бары в светлой теме — светлые бороздки, а не чёрные дыры.
        C_LINE_RAW := "B4BDCC"
    } else {
        C_BG := "1B222B", C_TITLE := "00A2FF", C_SOFT := "9AA9B8"
        C_DIM := "6C7B8B", C_MUTE := "5A6B7C", C_FAINT := "4A5B6C"
        C_FG := "FFFFFF", C_STAGE := "FFB300", C_ACCENT := "00A2FF"
        C_GREEN := "00E6B8", C_RED := "FF5555", C_BITE := "00FF00"
        C_WORK := "009900", C_WARN := "B08D00"
        C_LINE_RAW := "2A3036"
    }
    ; Функция зовётся и ДО построения окна (стартовая палитра):
    ; тогда красить нечего — только запоминаем цвета в переменных.
    if (!hOSD)
        return
    Gui, OSD: Color, %C_BG%
    ; Статичные тексты — каждому своя роль. Прозрачный Text при смене
    ; шрифта сам себя стирает, поэтому просто меняем начертание.
    Gui, OSD: Font, s11 wBold c%C_TITLE%, Segoe UI
    GuiControl, OSD: Font, TitleText
    Gui, OSD: Font, s8 wNorm c%C_MUTE%, Segoe UI
    GuiControl, OSD: Font, ByText
    Gui, OSD: Font, s9 wBold c%C_DIM%, Segoe UI
    GuiControl, OSD: Font, KeysText
    Gui, OSD: Font, s9 wNorm c%C_SOFT%, Segoe UI
    GuiControl, OSD: Font, StatText
    Gui, OSD: Font, s10 wNorm c%C_SOFT%, Segoe UI
    GuiControl, OSD: Font, LblAction
    GuiControl, OSD: Font, LblFish
    GuiControl, OSD: Font, LblBar
    GuiControl, OSD: Font, LblCoffee
    Gui, OSD: Font, s10 wNorm c%C_DIM%, Segoe UI Emoji
    GuiControl, OSD: Font, FishIcon
    GuiControl, OSD: Font, BarIcon
    Gui, OSD: Font, s10 wNorm c%C_GREEN%, Segoe UI Emoji
    GuiControl, OSD: Font, CoffeeIcon
    Gui, OSD: Font, s11 wBold c%C_GREEN%, Segoe UI
    GuiControl, OSD: Font, CoffeeText
    Gui, OSD: Font, s10 wBold c%C_FG%, Segoe UI
    GuiControl, OSD: Font, FishText
    GuiControl, OSD: Font, BarText
    Gui, OSD: Font, s9 wNorm c%C_DIM%, Segoe UI
    GuiControl, OSD: Font, SessionText
    GuiControl, OSD: Font, CaughtText
    Gui, OSD: Font, s7 wNorm c%C_FAINT%, Segoe UI
    GuiControl, OSD: Font, VerText
    ; Действие и его значок: в работе — акцентные, на паузе — золотые.
    stCol := isActive ? C_ACCENT : C_STAGE
    Gui, OSD: Font, s10 wBold c%stCol%, Segoe UI
    GuiControl, OSD: Font, StageText
    Gui, OSD: Font, s10 wNorm c%stCol%, Segoe UI Emoji
    GuiControl, OSD: Font, StatusIcon
    ; Угловой индикатор: жёлтый — пауза/АФК/тишина, зелёный — работа.
    tiCol := (isActive and !quietShown and !(afkUntil > 0)) ? C_WORK : C_WARN
    Gui, OSD: Font, s7 wBold c%tiCol%, Segoe UI
    GuiControl, OSD: Font, TopIndicator
    ; Стеклянный слой баров — перерисовать свежей палитрой. Если слоя
    ; ещё нет (тему применили до постройки меню), функция промолчит,
    ; а при пересборке меню его нарисуют заново.
    BarGlass_Render(1)
    ; Точка статуса кэширует свой цвет: сбрасываем кэш, чтобы её
    ; таймер перекрасил её новой темой уже на следующем тике.
    LastStatCol := ""
}

; Меню пересоздаём ЦЕЛИКОМ при смене темы: так каждый контрол
; получает краски заново, без хвостов от предыдущей темы.
RebuildOSD() {
    global
    BarGlass_Destroy()              ; стеклянный слой умирает вместе с меню
    Gui, OSD: Destroy
    Gosub, BuildOSD
    ; вернуть динамические тексты (UpdateOSD сам их подставит)
    UpdateOSD(lastStage, lastFish, lastBar)
    if (isActive) {
        GuiControl, OSD:, StatusIcon, 🟢
        GuiControl, OSD:, TopIndicator, ▶ РАБОТА
    } else {
        GuiControl, OSD:, StatusIcon, ⏺
        GuiControl, OSD:, TopIndicator, ⏸ ПАУЗА
    }
    ; докрасить по текущему состоянию (пауза/работа) и новые hwnd полосок
    ApplyOsdTheme(OsdTheme)
    Gosub, UpdateClock
    UpdateStatDot()
    HideFromCapture(hOSD, (CaptureGuard = 0) ? 0 : 1)
    HideFromCapture(hGlass, (CaptureGuard = 0) ? 0 : 1)
    ; (бары вернёт BarGlass_Create: она рисует слой по кэшу процентов)
}

; Кофе-бар: меняем процент каждую секунду. Сам процент кэшируется,
; а слой перерисуется, только если кадр реально изменился (см.
; подпись кадра в BarGlass_Render) — рисуем мы сами, Windows над
; барами не властна: не почернеют никогда.
SetCoffeeBar(pct, force := 0) {
    global
    pct := Round(pct < 0 ? 0 : (pct > 100 ? 100 : pct))
    if (!force && pct = LastCoffeePct)
        return                          ; то же значение — не дёргаем
    LastCoffeePct := pct
    BarGlass_Render(force)
}

; Живой бар-таймер под строкой меню.
; idx — 1..3: 1 — под «Действием» (СТАТИЧНЫЙ: всегда полный, цвет —
; как у самого действия: в работе синий, на паузе/АФК янтарный),
; 2 — под «Значком рыбы» (задержка до Shift, заливка белая), 3 —
; под «Тягой (ПКМ)» (держим — тает, передышка — наполняется,
; оранжевая). Цвета жёсткие: рисуем мы сами попиксельно.
SetTimerBar(idx, pct, force := 0) {
    global
    pct := Round(pct < 0 ? 0 : (pct > 100 ? 100 : pct))
    if (!force && pct = LastBarPct%idx%)
        return                          ; то же значение — не дёргаем
    LastBarPct%idx% := pct
    BarGlass_Render(force)
}

; Пересчитывает три живых бара из текущих таймеров бота. Зовём на
; каждом такте цикла (~150 мс): шкала ПКМ «бегает туда-сюда» точно
; по статусу (зажат — тает, передышка — наполняется), шкала Shift
; наполняется до момента нажатия. Бар №1 («Действие») — статичный:
; просто всегда полный и красится в цвет действия — не дёргается.
UpdateTimerBars() {
    global
    now := A_TickCount
    SetTimerBar(1, 100)         ; статичный индикатор под цвет действия
    ; пауза, заброс, оценка улова, АФК-перерыв — шкалы отдыхают
    if (!isActive || isCasting || isEvaluating
        || (afkUntil > 0 && now < afkUntil)) {
        SetTimerBar(2, 0)
        SetTimerBar(3, 0)
        return
    }
    fighting := (lastFishTime > 0 && now - lastFishTime < 3500)
    if (!fighting) {
        SetTimerBar(2, 0)
        SetTimerBar(3, 0)
        return
    }
    ; --- 2. задержка реакции до Shift: наполняется и замирает ---
    if (isShiftDown || shiftPressAfter <= 0)
        SetTimerBar(2, 100)
    else
        SetTimerBar(2, 100.0 * (now - fishFirstSeenTime) / shiftPressAfter)
    ; --- 3. тяга ПКМ: зажат — тает, передышка — наполняется ---
    tsf := now - fishFirstSeenTime
    if (rmbPressAfter > 0 && tsf <= rmbPressAfter)
        SetTimerBar(3, 100.0 * tsf / rmbPressAfter)   ; «жму через…»
    else if (!Variability)
        SetTimerBar(3, isRButtonDown ? 100 : 0)        ; держим всегда
    else if (isRButtonDown && rmbLastMs > 0)
        SetTimerBar(3, 100.0 * (rmbUntil - now) / rmbLastMs)
    else if (!isRButtonDown && rmbGapMs > 0)
        SetTimerBar(3, 100 - 100.0 * (rmbNextAt - now) / rmbGapMs)
    else
        SetTimerBar(3, 0)
}

; После (пере)создания меню возвращает барам их текущие значения
; (стеклянный слой после пересборки пуст — красим по кэшу процентов).
RenderOSDBars() {
    global
    Loop, 3
        SetTimerBar(A_Index, LastBarPct%A_Index% < 0 ? 0 : LastBarPct%A_Index%, 1)
    SetCoffeeBar(LastCoffeePct, 1)      ; принудительно: слой новый
}

; ==========================================================
; СТЕКЛЯННЫЙ СЛОЙ БАРОВ (GDI+ → UpdateLayeredWindow)
; Ни одного контрола Windows: цвета не чернеют на любой теме,
; перерисовка целым кадром — без мерцаний.
; ==========================================================

; Старт GDI+ (gdiplus.dll встроена в Windows ещё с XP).
Gdip_Startup() {
    if (!DllCall("GetModuleHandle", "str", "gdiplus", "ptr"))
        DllCall("LoadLibrary", "str", "gdiplus")
    VarSetCapacity(si, A_PtrSize = 8 ? 24 : 16, 0)
    NumPut(1, si, 0, "uint")
    if (DllCall("gdiplus\GdiplusStartup", "ptr*", pToken
            , "ptr", &si, "ptr", 0) != 0)
        return 0                        ; не стартанул — бары скроем
    return pToken
}

; "RRGGBB" -> 0xFFRRGGBB (полностью непрозрачный пиксель GDI+)
ARGBof(hex) {
    r := "0x" . SubStr(hex, 1, 2)
    g := "0x" . SubStr(hex, 3, 2)
    b := "0x" . SubStr(hex, 5, 2)
    return 0xFF000000 | (r + 0) << 16 | (g + 0) << 8 | (b + 0)
}

; 32-битный DIB с альфой (верхний ряд первым — высота отрицательная)
CreateDIBSection(w, h) {
    hdc0 := DllCall("GetDC", "ptr", 0, "ptr")
    VarSetCapacity(bi, 40, 0)
    NumPut(40, bi, 0, "uint")
    NumPut(w, bi, 4, "int")
    NumPut(-h, bi, 8, "int")
    NumPut(1, bi, 12, "ushort")
    NumPut(32, bi, 14, "ushort")
    hbm := DllCall("CreateDIBSection", "ptr", hdc0, "ptr", &bi, "uint", 0
        , "ptr*", bits, "ptr", 0, "uint", 0, "ptr")
    DllCall("ReleaseDC", "ptr", 0, "ptr", hdc0)
    return hbm
}

_GlassFill(gfx, br, x, y, w, h) {
    if (w > 0 && h > 0)
        DllCall("gdiplus\GdipFillRectangle", "ptr", gfx, "ptr", br
            , "float", x, "float", y, "float", w, "float", h)
}

; Создаёт прозрачное окно-«стекло» поверх меню и рисует на нём бары.
; Зовём после Show меню: слой встаёт ровно над клиентской областью.
BarGlass_Create() {
    global
    Critical                            ; рисуем строго по очереди
    BarGlass_Destroy()
    if (!pTokenGdip)
        pTokenGdip := Gdip_Startup()
    if (!pTokenGdip || !hOSD) {
        Critical, Off
        return
    }
    Gui, Glass: -DPIScale -Caption +ToolWindow +AlwaysOnTop +E0x80020 +HwndhGlass
    Gui, Glass: +Owner%hOSD%
    ; полотно: 32-бит DIB + контекст GDI+ на весь срок жизни меню
    glassDC := DllCall("CreateCompatibleDC", "ptr", 0, "ptr")
    glassHBM := CreateDIBSection(GlassW, GlassH)
    glassOBM := DllCall("SelectObject", "ptr", glassDC, "ptr", glassHBM, "ptr")
    DllCall("gdiplus\GdipCreateFromHDC", "ptr", glassDC, "ptr*", glassGfx)
    ; сдвиг слоя от УГЛА ОКНА меню до точки (20,70) КЛИЕНТА — рамка
    ; учитывается здесь один раз, дальше позиция считается простым wx+DX
    WinGetPos, wx, wy,,, ahk_id %hOSD%
    VarSetCapacity(pt, 8, 0)
    DllCall("ClientToScreen", "ptr", hOSD, "ptr", &pt)
    GlassDX := NumGet(pt, 0, "int") - wx + 20
    GlassDY := NumGet(pt, 4, "int") - wy + 70
    GlassSig := ""
    BarGlass_Render(1)                  ; кадр готовим скрытым...
    Gui, Glass: Show, NoActivate        ; ...и показываем сразу готовым
    Critical, Off
}

; Стирает стеклянный слой вместе с его полотном (пересборка, выход).
BarGlass_Destroy() {
    global
    Critical
    if (hGlass) {
        Gui, Glass: Destroy
        hGlass := 0
    }
    if (glassGfx)
        DllCall("gdiplus\GdipDeleteGraphics", "ptr", glassGfx), glassGfx := 0
    if (glassDC) {
        if (glassOBM)
            DllCall("SelectObject", "ptr", glassDC, "ptr", glassOBM, "ptr"), glassOBM := 0
        DllCall("DeleteDC", "ptr", glassDC), glassDC := 0
    }
    if (glassHBM)
        DllCall("DeleteObject", "ptr", glassHBM), glassHBM := 0
    GlassSig := ""
    Critical, Off
}

; Рисует кадр баров и выводит его на экран ОДНИМ вызовом
; UpdateLayeredWindow — поэтому перерисовка не мерцает. Если ничего
; не изменилось (та же подпись кадра), вообще ничего не делает.
BarGlass_Render(force := 0) {
    global
    if (!hGlass || !glassGfx || !hOSD)
        return
    Critical
    p1 := (LastBarPct1 < 0) ? 0 : LastBarPct1
    p2 := (LastBarPct2 < 0) ? 0 : LastBarPct2
    p3 := (LastBarPct3 < 0) ? 0 : LastBarPct3
    pc := (LastCoffeePct < 0) ? 0 : LastCoffeePct
    ; Бар действия — под цвет самого действия (в работе синий, на
    ; паузе/АФК янтарный), бар Shift — белый, ПКМ — оранжевый, кофе —
    ; мятный. Все цвета участвуют в подписи, чтобы смена темы или
    ; пауза перекрасили кадр сами.
    actHex := isActive ? C_ACCENT : C_STAGE
    sig := p1 "|" p2 "|" p3 "|" pc "|" C_LINE_RAW "|" C_GREEN "|" C_STAGE "|" C_FG "|" actHex
    if (!force && sig = GlassSig) {
        Critical, Off
        return                          ; кадр тот же — не дёргаем слой
    }
    GlassSig := sig
    DllCall("gdiplus\GdipCreateSolidFill", "uint", ARGBof(C_LINE_RAW), "ptr*", brT)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", ARGBof(actHex), "ptr*", br1)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", ARGBof(C_FG), "ptr*", brW)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", ARGBof(C_STAGE), "ptr*", brO)
    DllCall("gdiplus\GdipCreateSolidFill", "uint", ARGBof(C_GREEN), "ptr*", brG)
    DllCall("gdiplus\GdipGraphicsClear", "ptr", glassGfx, "uint", 0) ; прозрачно
    ; разделитель — тонюсенькая серая линия (клиентская y75 → локальная 5)
    _GlassFill(glassGfx, brT, 0, 5, GlassW, 1)
    ; три живых бара: серая дорожка всегда на месте, заливка ездит в ней
    _GlassFill(glassGfx, brT, 0, 45, GlassW, 2)
    _GlassFill(glassGfx, br1, 0, 45, Round(GlassW * p1 / 100), 2)
    _GlassFill(glassGfx, brT, 0, 85, GlassW, 2)
    _GlassFill(glassGfx, brW, 0, 85, Round(GlassW * p2 / 100), 2)
    _GlassFill(glassGfx, brT, 0, 125, GlassW, 2)
    _GlassFill(glassGfx, brO, 0, 125, Round(GlassW * p3 / 100), 2)
    ; кофе-бар — классический трёхпиксельный, мятный, как значок ☕
    _GlassFill(glassGfx, brT, 0, 165, GlassW, 3)
    _GlassFill(glassGfx, brG, 0, 165, Round(GlassW * pc / 100), 3)
    ; весь кадр — одним движением на экран, заодно и позиция слоя
    WinGetPos, wx, wy,,, ahk_id %hOSD%
    VarSetCapacity(pt, 8, 0)
    NumPut(wx + GlassDX, pt, 0, "int")
    NumPut(wy + GlassDY, pt, 4, "int")
    DllCall("UpdateLayeredWindow", "ptr", hGlass, "ptr", 0, "ptr", &pt
        , "int64*", GlassW | (GlassH << 32), "ptr", glassDC, "int64*", 0
        , "uint", 0, "uint*", (255 << 16) | (1 << 24), "uint", 2)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", brT)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", br1)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", brW)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", brO)
    DllCall("gdiplus\GdipDeleteBrush", "ptr", brG)
    Critical, Off
}

; Меню переехало — висящее поверх него «стекло» должно ехать следом.
; Зовём из часового таймера и из сообщений о перемещении окна.
BarGlass_Follow(force := 0) {
    global
    static lastX := -99999, lastY := -99999
    if (!hGlass || !hOSD)
        return
    WinGetPos, wx, wy,,, ahk_id %hOSD%
    if (!force && wx = lastX && wy = lastY)
        return
    lastX := wx, lastY := wy
    DllCall("SetWindowPos", "ptr", hGlass, "ptr", 0
        , "int", wx + GlassDX, "int", wy + GlassDY
        , "int", 0, "int", 0, "uint", 0x0015)   ; NOSIZE|NOZORDER|NOACTIVATE
}

WM_MOVE_Handler() {
    BarGlass_Follow(1)                  ; окно встало — слой встаёт точно
}

; 0x0216 WM_MOVING: приходит на каждый рывок мыши во время перетаскивания
; меню — слой едет СЛЕДОМ, а не догоняет потом.
WM_MOVING_Handler(wParam, lParam, msg, hwnd) {
    global hGlass, hOSD, GlassDX, GlassDY
    if (!hGlass || hwnd != hOSD)
        return
    DllCall("SetWindowPos", "ptr", hGlass, "ptr", 0
        , "int", NumGet(lParam + 0, 0, "int") + GlassDX
        , "int", NumGet(lParam + 0, 4, "int") + GlassDY
        , "int", 0, "int", 0, "uint", 0x0015)   ; NOSIZE|NOZORDER|NOACTIVATE
}

; Реальный размер PNG (нужен, чтобы посчитать *w *h для ImageSearch)
GetImgSize(file, ByRef w, ByRef h) {
    w := 0
    h := 0
    if (!FileExist(file))
        return false
    hbm := LoadPicture(file)
    if (!hbm)
        return false
    size := (A_PtrSize = 8) ? 32 : 24
    VarSetCapacity(BM, size, 0)
    if (DllCall("GetObject", "Ptr", hbm, "Int", size, "Ptr", &BM)) {
        w := NumGet(BM, 4, "Int")
        h := NumGet(BM, 8, "Int")
    }
    DllCall("DeleteObject", "Ptr", hbm)
    return (w > 0 && h > 0)
}

; Готовая строка параметров для ImageSearch:
; "*w120 *h48 *80 C:\...\catch.png"
; Шаблон растягивается под текущее разрешение.
ImgOpt(name, tol) {
    global ImgCache, NativeDir, UIScale
    key := name . "|" . tol
    if (ImgCache.HasKey(key))
        return ImgCache[key]

    ; 1) родной шаблон под это разрешение — масштаб не нужен
    if (NativeDir != "" && FileExist(NativeDir . "\" . name)) {
        ImgCache[key] := "*" . tol . " " . NativeDir . "\" . name
        return ImgCache[key]
    }

    ; 2) базовый шаблон 1920x1080 — тянем под экран
    path := A_ScriptDir . "\" . name
    opt := "*" . tol . " " . path
    if (Abs(UIScale - 1) > 0.01) {
        if (GetImgSize(path, iw, ih)) {
            nw := Round(iw * UIScale)
            nh := Round(ih * UIScale)
            if (nw > 0 && nh > 0)
                opt := "*w" . nw . " *h" . nh . " *" . tol . " " . path
        }
    }
    ImgCache[key] := opt
    return opt
}



; ==========================================
; ЛОГ СОБЫТИЙ ДЛЯ PYTHON-СТАТИСТИКИ
; ==========================================
; Пишем каждое событие строкой в stats.csv. Питон читает этот файл
; и строит по нему графики. Формат: время;событие;категория
LogEvent(kind, category) {
    global StatsFile, DataDir
    if (!InStr(FileExist(DataDir), "D"))
        FileCreateDir, %DataDir%
    FormatTime, ts, , yyyy-MM-dd HH:mm:ss
    ; Строку собираем заранее — так точка с запятой гарантированно
    ; не будет принята за начало комментария.
    if (!FileExist(StatsFile)) {
        head := "timestamp" . Chr(59) . "event" . Chr(59) . "category" . "`n"
        FileAppend, %head%, %StatsFile%, UTF-8
    }
    line := ts . Chr(59) . kind . Chr(59) . category . "`n"
    FileAppend, %line%, %StatsFile%, UTF-8
}

; ==========================================
; ПРОВЕРКА ИНДИКАТОРА (вместо PixelSearch)
; ==========================================
; PixelSearch срабатывает на ОДНОМ пикселе нужного цвета, поэтому
; ловил блики, руку и оранжевые тона. Здесь считаем ДОЛЮ красных
; пикселей в зоне: полоска красная только когда параметр реально в нуле.
;
; Красный = R заметно больше G и B одновременно.
; Это надёжнее фиксированного 0xDD2222 с большим допуском.
IsBarRed(x1, y1, x2, y2) {
    global RedPixelsNeeded
    ; ШАГ 1 — быстрый отсев одним PixelSearch (аппаратный, ~0.1 мс).
    ; Если в зоне вообще нет красноватых пикселей — сразу выходим.
    PixelSearch, px, py, x1, y1, x2, y2, 0xCC2020, 90, Fast RGB
    if (ErrorLevel != 0)
        return false

    ; ШАГ 2 — считаем АБСОЛЮТНОЕ число красных пикселей.
    ; Проценты не годятся: шкала пустеет справа налево, красным
    ; остаётся лишь маленький остаток слева, а PAD добавляет в зону
    ; строки воды. Доля получается низкой даже когда параметр в нуле.
    ; Поэтому просто: есть красное пятно заметного размера — голоден.
    red := 0
    y := y1
    while (y <= y2) {
        x := x1
        while (x <= x2) {
            PixelGetColor, c, x, y, RGB
            r := (c >> 16) & 0xFF
            g := (c >> 8) & 0xFF
            b := c & 0xFF
            if (r > 110 && r > g * 1.9 && r > b * 1.9 && g < 95 && b < 95) {
                red++
                if (red >= RedPixelsNeeded)   ; хватит, выходим раньше
                    return true
            }
            x += 2
        }
        y += 2
    }
    return false
}

; Красное уведомление об ошибке справа внизу («нет места в садке»,
; «нет еды» и т.п.). Зона и цвет те же, что у проверки полного садка.
; ВАЖНО: зовём её только сразу после СВОЕГО действия (поели, положили
; рыбу) — в остальное время там может мелькать постороннее.
IsRedError() {
    global ErrorStartX, ErrorStartY, ErrorEndX, ErrorEndY
    global NotifStartX, NotifStartY, NotifEndX, NotifEndY
    ; «Слот пуст» — тёмно-красная панель в самом углу (≈#7A2626 и
    ; темнее). Её ловим ПЕРВОЙ, в узкой зоне: надёжнее и быстрее.
    PixelSearch, errX, errY, NotifStartX, NotifStartY, NotifEndX, NotifEndY, 0x7A2626, 50, Fast RGB
    if (ErrorLevel == 0)
        return true
    ; Ярко-красные панели («нет места в садке») — широкая зона.
    PixelSearch, errX, errY, ErrorStartX, ErrorStartY, ErrorEndX, ErrorEndY, 0xDD2222, 60, Fast RGB
    return (ErrorLevel == 0)
}

; Единый подсчёт промахов расходников («Слот пуст»). Вызывается
; ТОЛЬКО сразу после нашего нажатия кнопки 4 или 5: уведомление —
; реакция именно на нашу попытку.
;   Промаха нет (поели/выпили) — счётчик обнуляем.
;   Пять промахов подряд — еды/кофе нет вообще: кнопки 4 и 5 не
;   трогаем следующие 5-8 минут (рандом по миллисекундам), потом
;   снова пробуем одиночные попытки.
CheckConsumeFail() {
    global consumeFailCount, consumeGiveUpUntil, isActive
    ; уведомление появляется не мгновенно и живёт пару секунд —
    ; ждём и смотрим несколько раз
    Loop, 6 {
        Sleep, % Var(420, 0.75, 1.5)
        if (IsRedError()) {
            consumeFailCount++
            LogEvent("consume", "slot-empty-" consumeFailCount)
            if (consumeFailCount >= 5) {
                ; 5-8 минут, рандомно ДО МИЛЛИСЕКУНД — при любой
                ; настройке вариативности, потому что просили прямо.
                Random, cd, 300000, 480000
                consumeGiveUpUntil := A_TickCount + cd
                consumeFailCount := 0
                LogEvent("consume", "giveup-5x")
            }
            return
        }
        if (!isActive)
            return
    }
    ; красного не нашлось ни разу — приём удался
    consumeFailCount := 0
}




; ==========================================
; 💎 МЕНЮ (СТРОГИЙ МИНИМАЛИЗМ)
; ==========================================
; ДОБАВЛЕН -DPIScale, ЧТОБЫ МЕНЮ НЕ ОБРЕЗАЛОСЬ И НЕ СЪЕЗЖАЛО!
; Стартовая палитра — из файла настроек: статистика и меню в одной теме.
ApplyOsdTheme(ReadOsdTheme())
; Бары меню — не контролы: их рисует наш «стеклянный» слой через
; GDI+ (кадр целиком — UpdateLayeredWindow), готовим движок заранее.
pTokenGdip := Gdip_Startup()
; Меню таскают мышью — слою баров положено ехать следом
OnMessage(0x0003, "WM_MOVE_Handler")
OnMessage(0x0216, "WM_MOVING_Handler")
Gosub, BuildOSD

; Прячем меню от скриншотов: распознавание улова снимает весь экран,
; и панель попадала прямо в кадр поверх фотографии рыбы.
; Состоянием управляет настройка в окне статистики — проверяем её
; раз в секунду, чтобы тумблер срабатывал сразу, без перезапуска.
CaptureGuard := -1
SetTimer, CaptureGuardTimer, 1000
GoSub, CaptureGuardTimer

; Поднимаем статистику вместе с ботом (тихо: нет Python — не мешаем)
SetTimer, AutoStartStats, -1500
SetTimer, StatDotTimer, 1000

; №53 — СВЯЗКА ПРИЛОЖЕНИЙ.
; Запустили бота — поднимаются и статистика, и менеджер; запустили
; менеджер — он сам поднимет статистику; статистика никого не трогает.
; Менеджеру даём старт позже статистики: ему всё равно, зато Python
; ставиться будет один (через LaunchStats), а не дважды.
SetTimer, AutoStartManager, -4000
; Маяк для Менеджера: раз в секунду пишем состояние бота.
SetTimer, BotStateTimer, 1000
GoSub, BotStateTimer
; №72: на старте — если замок висит, даже меню не начинаем
LicCheck()
if (LicBlocked) {
    LicBlockedMsg()
    ExitApp
}
; Гасим маяк при ЛЮБОМ выходе (F8, трей): Менеджер сразу увидит
; «Не запущен», а не будет ждать, пока файл протухнет.
OnExit("BotExitCleanup")

; ==========================================
; КАТЕГОРИЯ УЛОВА ПО ЦВЕТУ ПЛАШКИ
; ==========================================
; ImageSearch ищет картинку РОВНО того размера, что у шаблона. У разных
; игроков интерфейс игры отрисован крупнее или мельче: на проверенном
; скриншоте плашка «Трофей» занимала 116x38 точек вместо 98x28 у
; шаблона — и трофей не находился, рыба уходила в отпуск.
;
; Цвет плашки при этом всегда один и тот же:
;   золотой  252,195,0   — Трофей
;   зелёный  155,200,63  — Зачётная
; Считаем, сколько таких точек в зоне под названием рыбы. Размер
; интерфейса на это не влияет.
CountBadgeRows(colorHex, tol, x1, y1, x2, y2) {
    ; Считаем СТРОКИ, в которых нашёлся нужный цвет, а не каждую точку.
    ; PixelSearch выполняется внутри AutoHotkey на C и просматривает
    ; целую строку за один вызов — это в сотни раз быстрее, чем
    ; перебирать пиксели через PixelGetColor (25 тысяч вызовов на зону
    ; занимали бы пару секунд, а окно улова висит всего три).
    n := 0
    y := y1
    while (y < y2) {
        PixelSearch, px, py, x1, y, x2, y, colorHex, tol, Fast RGB
        if (ErrorLevel = 0)
            n++
        y += 2
    }
    return n
}

; Возвращает: 2 — трофей, 1 — зачётная, 0 — не найдено.
DetectCatchKind() {
    global ZachetStartX, ZachetStartY, ZachetEndX, ZachetEndY, BadgeRowsNeeded
    ; Плашка высотой 28-45 точек, при шаге 2 это минимум 14 строк
    ; подряд. Случайный блик такой полосы не даёт.
    gold := CountBadgeRows(0xFCC300, 30, ZachetStartX, ZachetStartY
                                       , ZachetEndX, ZachetEndY)
    if (gold >= BadgeRowsNeeded)
        return 2
    green := CountBadgeRows(0x9BC83F, 30, ZachetStartX, ZachetStartY
                                        , ZachetEndX, ZachetEndY)
    if (green >= BadgeRowsNeeded)
        return 1
    return 0
}

HideFromCapture(hwnd, enable := 1) {
    ; SetWindowDisplayAffinity — штатный способ Windows убрать окно
    ; из любых снимков экрана. Само окно на мониторе видно как обычно,
    ; но система не включает его в кадр: ни BitBlt, ни OBS, ни наш OCR.
    ;
    ; 0x11 = WDA_EXCLUDEFROMCAPTURE — окно исчезает из снимка целиком,
    ;        то, что под ним, видно нормально. Windows 10 2004 и новее.
    ; 0x01 = WDA_MONITOR — запасной вариант для старых сборок: окно
    ;        попадёт в кадр чёрным прямоугольником, но текст не выдаст.
    ; 0x00 = WDA_NONE — защита снята, меню снова видно на скриншотах.
    if (hwnd = 0)
        return 0
    if (!enable) {
        DllCall("user32\SetWindowDisplayAffinity", "Ptr", hwnd, "UInt", 0x00)
        return 0
    }
    if DllCall("user32\SetWindowDisplayAffinity", "Ptr", hwnd, "UInt", 0x11)
        return 2
    if DllCall("user32\SetWindowDisplayAffinity", "Ptr", hwnd, "UInt", 0x01)
        return 1
    return 0
}

WM_LBUTTONDOWN() {
    if (A_Gui == "OSD")
        PostMessage, 0xA1, 2,,, A
}

; ==========================================
; ЗОНЫ ПОИСКА (пересчитываются под экран)
; ==========================================
; Рыба — левая нижняя четверть, уже относительная
FishStartX := 0
FishStartY := A_ScreenHeight // 2
FishEndX := A_ScreenWidth // 2
FishEndY := A_ScreenHeight

; Готовность снасти — вся нижняя половина, уже относительная
ReadyStartX := 0
ReadyStartY := A_ScreenHeight // 2
ReadyEndX := A_ScreenWidth
ReadyEndY := A_ScreenHeight

; Зачёт/трофей — панель по центру сверху, привязка к центру экрана.
; Нижняя граница 200, а не 170: у игроков с более крупным интерфейсом
; плашка опускается ниже — на проверенном скриншоте её низ был на 171,
; то есть ровно на старой границе, и распознавание срывалось.
; Ниже 215 опускать нельзя: там начинается зелёная шкала-линейка,
; и её цвет совпадает с цветом плашки «Зачётная» — трофей мог бы
; определиться как обычная рыба.
ZachetStartX := CX(420)
ZachetStartY := TY(0)
ZachetEndX := CX(1500)
ZachetEndY := TY(200)
Clamp(ZachetStartX, ZachetStartY, ZachetEndX, ZachetEndY)

; Энергия / еда / здоровье / солнце — левый нижний угол.
; Координаты ИЗМЕРЕНЫ по реальному скриншоту 1920x1080.
; Полоски сверху вниз: молния, вилка, сердце, солнце.
; Берём узкую вертикальную полосу в НАЧАЛЕ шкалы (X 190..300):
; там заливка исчезает первой, когда параметр падает.
PAD := SC(3)
; Узкая полоса в САМОМ НАЧАЛЕ шкалы.
; Полоска пустеет справа налево, поэтому начало краснеет
; только когда параметр реально упал в ноль.
; Пороги в ТОЧКАХ зависят от размера зоны, а зона растёт вместе
; с разрешением. На 2K и 4K зона крупнее, и прежний порог 12 срабатывал
; бы от меньшей доли заливки — то есть от случайного блика. Умножаем
; на квадрат масштаба: доля остаётся такой же, как на 1920x1080.
RedPixelsNeeded := Round(12 * UIScale * UIScale)
if (RedPixelsNeeded < 6)
    RedPixelsNeeded := 6

; Плашка зачёта/трофея тоже крупнее — строк в ней больше.
BadgeRowsNeeded := Round(8 * UIScale)
if (BadgeRowsNeeded < 5)
    BadgeRowsNeeded := 5

BarX1 := LX(188)
BarX2 := LX(205)

EnergyStartX := BarX1
EnergyStartY := BY(954) - PAD
EnergyEndX   := BarX2
EnergyEndY   := BY(963) + PAD
Clamp(EnergyStartX, EnergyStartY, EnergyEndX, EnergyEndY)

FoodStartX := BarX1
FoodStartY := BY(985) - PAD
FoodEndX   := BarX2
FoodEndY   := BY(994) + PAD
Clamp(FoodStartX, FoodStartY, FoodEndX, FoodEndY)

; Здоровье (сердце) — в оригинале не проверялось, зона на будущее
HealthStartX := BarX1
HealthStartY := BY(1016) - PAD
HealthEndX   := BarX2
HealthEndY   := BY(1025) + PAD
Clamp(HealthStartX, HealthStartY, HealthEndX, HealthEndY)

SunStartX := BarX1
SunStartY := BY(1047) - PAD
SunEndX   := BarX2
SunEndY   := BY(1056) + PAD
Clamp(SunStartX, SunStartY, SunEndX, SunEndY)

; Ошибка "садок полон" — правый нижний угол
ErrorStartX := RX(1500)
ErrorStartY := BY(900)
ErrorEndX := A_ScreenWidth - 1
ErrorEndY := A_ScreenHeight - 1
Clamp(ErrorStartX, ErrorStartY, ErrorEndX, ErrorEndY)

; Панель «Слот пуст» (нет еды/кофе) — тёмно-красная, стоит в самом
; низу справа. Зона заужена до её реального места: диск компаса
; тогда не лезет в кадр и не даёт ложных срабатываний. Доли от
; экрана, а не база-1920: панель держится за самый край на любом
; разрешении (замер по скриншоту игрока 1568x882: x≈1240..1545,
; y≈787..861).
NotifStartX := Round(A_ScreenWidth * 0.78)
NotifStartY := Round(A_ScreenHeight * 0.86)
NotifEndX   := A_ScreenWidth - 1
NotifEndY   := Round(A_ScreenHeight * 0.995)
Clamp(NotifStartX, NotifStartY, NotifEndX, NotifEndY)

; ==========================================
; КНОПКА ВКЛ/ВЫКЛ
; ==========================================
*PgDn::
    GoSub, ToggleBot
return

; №61: включение/пауза помощника — общая метка: её зовёт и
; клавиша PgDn, и Telegram-бот (/pause /resume через tg_cmd.txt).
ToggleBot:
    ; №72: без подписки бот не стартует (пауза/выкл — всегда можно)
    if (!isActive and LicCheck()) {
        LicBlockedMsg()
        return
    }
    isActive := !isActive
    if (isActive) {
        isCasting := false
        isEvaluating := false
        lastFishTime := 0
        fishFirstSeenTime := 0
        rmbUntil := 0
        rmbNextAt := 0
        rmbPressAfter := 0
        shiftPressAfter := 0
        afkCount := 0

        coffeeSpan := Var(1200000, 0.85, 1.15)
        coffeeTimerLimit := A_TickCount + coffeeSpan
        nextFoodCheck := A_TickCount + Var(3000, 0.8, 1.5)
        nextCoffeeCheck := A_TickCount + Var(3000, 0.8, 1.5)
        nextSunCheck := A_TickCount + Var(3000, 0.8, 1.5)
        consumeLockUntil := 0
        nextConsumeScan := 0
        consumeGiveUpUntil := 0
        consumeFailCount := 0
        lastActionTime := A_TickCount
        quietShown := false
        quietLogged := false
        lastRecastAt := 0
        ; первый АФК-перерыв через случайные 1-3 часа
        nextAfk := A_TickCount + VarRange(3600000, 3600000, 10800000)
        afkPending := false
        afkUntil := 0

        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText
        Gui, OSD: Font, s10 wNorm c%C_ACCENT%, Segoe UI Emoji
        GuiControl, OSD: Font, StatusIcon
        GuiControl, OSD:, StatusIcon, 🟢

        Gui, OSD: Font, s7 wBold c%C_WORK%, Segoe UI
        GuiControl, OSD: Font, TopIndicator
        GuiControl, OSD:, TopIndicator, ▶ РАБОТА
        BarGlass_Render(1)                 ; бар действия — сразу синий

        LogEvent("session", "start")
        ; №60: вернулись с паузы — леска в игре из воды не
        ; вылетала. Правило возврата: смотрим на «рыбку» и на
        ; «снасть готова»; ни того ни другого — держим ЛКМ
        ; (тянем) до 20 секунд или до их появления, дальше —
        ; обычный цикл. Любой живой ответ игры снимает лимит.
        resumeUntil := 0
        if (tackleInWater)
            resumeUntil := A_TickCount + 20000
        UpdateOSD("Анализ...", "—", "—")
        SetTimer, UpdateClock, 1000
        SetTimer, CheckGameLogic, 150
    } else {
        SetTimer, CheckGameLogic, Off
        SetTimer, UpdateClock, Off
        LogEvent("session", "stop")
        ; №58-59: tackleInWater НЕ трогаем — пауза леску из воды
        ; не вытаскивает, и после повторного PgDn страховка катушки
        ; обязана зажать ЛКМ обратно (№56 занулял флаг — бот
        ; «забывал» тянуть поводок). От гонки страхует само
        ; условие (isActive and tackleInWater): спящий хук,
        ; проснувшись после выключения, пережать не сможет.
        ReleaseAll()

        Gui, OSD: Font, s10 wBold c%C_STAGE%, Segoe UI
        GuiControl, OSD: Font, StageText
        Gui, OSD: Font, s10 wNorm c%C_STAGE%, Segoe UI Emoji
        GuiControl, OSD: Font, StatusIcon
        GuiControl, OSD:, StatusIcon, ⏺

        Gui, OSD: Font, s7 wBold c%C_WARN%, Segoe UI
        GuiControl, OSD: Font, TopIndicator
        GuiControl, OSD:, TopIndicator, ⏸ ПАУЗА

        UpdateOSD("Пауза", "—", "—")
        GuiControl, OSD:, CoffeeText, 00:00
        SetCoffeeBar(0)
        SetTimerBar(2, 0)                  ; живые шкалы отдыхают
        SetTimerBar(3, 0)
        SetTimerBar(1, 100)                ; бар действия — статичный
        BarGlass_Render(1)                 ; цвета паузы — сразу,
                                           ; не дожидаясь тика

        Gui, OSD: Font, s10 wBold c%C_FG%, Segoe UI
        GuiControl, OSD: Font, FishText
        GuiControl, OSD: Font, BarText
        Gui, OSD: Font, s10 wNorm c%C_DIM%, Segoe UI Emoji
        GuiControl, OSD: Font, FishIcon
        GuiControl, OSD: Font, BarIcon
    }
return

; ------------------------------------------
; СБОРКА МЕНЮ (подпрограмма)
; Вынесено из автозапуска: при смене темы окно пересоздаётся целиком
; (RebuildOSD) — так живые бары, кофе-бар и тексты всегда перекрашены
; свежими цветами, без хвостов от предыдущей темы.
BuildOSD:
Gui, OSD: -DPIScale +AlwaysOnTop -Caption +ToolWindow +HwndhOSD
; Вынесено из автозапуска: при смене темы окно пересоздаётся целиком
; целиком пересоздаётся и стеклянный слой (RebuildOSD) — свежая
; палитра без хвостов от предыдущей темы.
Gui, OSD: Color, %C_BG%
Gui, OSD: Font, s11 wBold c%C_TITLE%, Segoe UI
Gui, OSD: Add, Text, vTitleText x0 y10 w350 Center BackgroundTrans, 🐟 TrofPridi 🐟
; --- ИНДИКАТОР В ЛЕВОМ ВЕРХНЕМ УГЛУ ---
Gui, OSD: Font, s7 wBold c%C_WARN%, Segoe UI
Gui, OSD: Add, Text, vTopIndicator x15 y14 w150 Left BackgroundTrans, ⏸ ПАУЗА
; --- индикатор статистики: правый верхний угол ---
; Точка статуса — обычный Text (цвет ей задаёт UpdateStatDot).
Gui, OSD: Font, s9 wNorm c%C_SOFT%, Segoe UI
Gui, OSD: Add, Text, vStatText x232 y14 w80 Right BackgroundTrans, Статистика
Gui, OSD: Font, s12 wBold c%C_RED%, Segoe UI
Gui, OSD: Add, Text, vStatDot x316 y10 w16 Center BackgroundTrans, ●
Gui, OSD: Font, s8 wNorm c%C_MUTE%, Segoe UI
Gui, OSD: Add, Text, vByText x0 y30 w350 Center BackgroundTrans, by tg/flkn69
Gui, OSD: Font, s9 wBold c%C_DIM%, Segoe UI
Gui, OSD: Add, Text, vKeysText x0 y50 w350 Center BackgroundTrans, PgDn вкл/выкл | F6 статистика | F8 выход
; === БАРЫ ===
; Бары (разделитель y75, шкалы y115/y155/y195, кофе y235) рисует
; стеклянный слой — см. BarGlass_*: сами попиксельно, без контролов
; Windows, целым кадром через UpdateLayeredWindow (не чернеют, не
; мерцают). Тут остаются только строки-надписи.
Gui, OSD: Font, s10 wNorm c%C_STAGE%, Segoe UI Emoji
Gui, OSD: Add, Text, vStatusIcon x20 y90 w20 BackgroundTrans, ⏺
Gui, OSD: Font, s10 wNorm c%C_SOFT%, Segoe UI
Gui, OSD: Add, Text, vLblAction x45 y90 w100 BackgroundTrans, Действие
Gui, OSD: Font, s10 wBold c%C_STAGE%, Segoe UI
Gui, OSD: Add, Text, vStageText x150 y89 w180 Right BackgroundTrans, Пауза
Gui, OSD: Font, s10 wNorm c%C_DIM%, Segoe UI Emoji
Gui, OSD: Add, Text, vFishIcon x20 y130 w25 BackgroundTrans, 🎣
Gui, OSD: Font, s10 wNorm c%C_SOFT%, Segoe UI
Gui, OSD: Add, Text, vLblFish x45 y130 w100 BackgroundTrans, Значок рыбы
Gui, OSD: Font, s10 wBold c%C_FG%, Segoe UI
Gui, OSD: Add, Text, vFishText x150 y129 w180 Right BackgroundTrans, —
Gui, OSD: Font, s10 wNorm c%C_DIM%, Segoe UI Emoji
Gui, OSD: Add, Text, vBarIcon x20 y170 w25 BackgroundTrans, ⚖
Gui, OSD: Font, s10 wNorm c%C_SOFT%, Segoe UI
Gui, OSD: Add, Text, vLblBar x45 y170 w100 BackgroundTrans, Тяга (ПКМ)
Gui, OSD: Font, s10 wBold c%C_FG%, Segoe UI
Gui, OSD: Add, Text, vBarText x150 y169 w180 Right BackgroundTrans, —
Gui, OSD: Font, s10 wNorm c%C_GREEN%, Segoe UI Emoji
Gui, OSD: Add, Text, vCoffeeIcon x20 y210 w25 BackgroundTrans, ☕
Gui, OSD: Font, s10 wNorm c%C_SOFT%, Segoe UI
Gui, OSD: Add, Text, vLblCoffee x45 y210 w100 BackgroundTrans, Кофе через
Gui, OSD: Font, s11 wBold c%C_GREEN%, Segoe UI
Gui, OSD: Add, Text, vCoffeeText x150 y209 w180 Right BackgroundTrans, 00:00
; (кофе-бар y235 — как и остальные бары, рисует стеклянный слой)
Gui, OSD: Font, s9 wNorm c%C_DIM%, Segoe UI
Gui, OSD: Add, Text, x20 y255 w150 vSessionText BackgroundTrans, ⏱ Сессия 00:00:00
Gui, OSD: Add, Text, x140 y255 w150 Right vCaughtText BackgroundTrans, 🐟 Поймано: 0
Gui, OSD: Font, s7 wNorm c%C_FAINT%, Segoe UI
Gui, OSD: Add, Text, vVerText x294 y257 w36 Right BackgroundTrans, v3.30.1

; Расположение меню смещено вниз на 40 пикселей
OSD_X := A_ScreenWidth - 370
OSD_Y := 200
Gui, OSD: Show, x%OSD_X% y%OSD_Y% w350 h285 NoActivate, OSD_Window
; По HWND, а не по ahk_class — иначе можно обрезать окно чужого AHK-скрипта
WinSet, Region, 0-0 w350 h285 R20-20, ahk_id %hOSD%
WinSet, Transparent, 210, ahk_id %hOSD%
; Стеклянный слой с барами создаём после Show: он встаёт ровно над
; клиентской областью меню и сразу рисует кадр по кэшу процентов
RenderOSDBars()
BarGlass_Create()
return

AutoStartStats:
    SetTimer, AutoStartStats, Off
    LaunchStats(true)
return

AutoStartManager:
    SetTimer, AutoStartManager, Off
    LaunchManager(true)
return

; Маяк для Менеджера (№53): свежесть файла = «бот жив»,
; режим = ведёт ли ловлю прямо сейчас (PgDn вкл/выкл).
BotStateTimer:
    if (!InStr(FileExist(DataDir), "D"))
        FileCreateDir, %DataDir%
    FormatTime, bsNow,, yyyyMMddHHmmss
    IniWrite, %bsNow%, %BotStateFile%, state, tick
    IniWrite, % (isActive ? "running" : "paused"), %BotStateFile%, state, mode
    ; №61: команды из Telegram. OCR-помощник кладёт tg_cmd.txt
    ; (pause/resume) — выполняем, будто сами нажали PgDn.
    tgCmd := DataDir . "\tg_cmd.txt"
    IfExist, %tgCmd%
    {
        FileRead, tgTxt, %tgCmd%
        FileDelete, %tgCmd%
        if (!ErrorLevel)                 ; удалился — команда наша
        {
            tgTxt := Trim(tgTxt, " `r`n`t")
            if (tgTxt = "pause" and isActive)
                GoSub, ToggleBot
            else if (tgTxt = "resume" and !isActive)
                GoSub, ToggleBot
        }
    }
    ; №72: раз в час перепроверяем замок; истекла — молча на паузу
    licTicks += 1
    if (licTicks >= 3600) {
        licTicks := 0
        if (LicCheck() and isActive)
            GoSub, ToggleBot
    }
return

StatDotTimer:
    UpdateStatDot()
return

UpdateClock:
    sessionSecs := (A_TickCount - SessionStartTime) // 1000
    h := sessionSecs // 3600
    mS := Mod(sessionSecs, 3600) // 60
    sS := Mod(sessionSecs, 60)
    GuiControl, OSD:, SessionText, % Format("⏱ Сессия {:02}:{:02}:{:02}", h, mS, sS)
    BarGlass_Follow()                   ; меню куда-то переехало — догнать
    if (!isActive)
        return
    ; страховка для живых баров: помимо тактов цикла, подровнять их
    ; раз в секунду (часы тикают, даже когда логика занята)
    UpdateTimerBars()
    ; во время перерыва показываем остаток АФК прямо в шапке, рядом
    ; с номером перерыва («☕ АФК №1 12:34»), и дублируем в строке
    ; действия — раньше время было только внизу, его не замечали
    if (afkUntil > 0 and A_TickCount < afkUntil) {
        left := (afkUntil - A_TickCount) // 1000
        mmss := Format("{:02}:{:02}", left // 60, Mod(left, 60))
        GuiControl, OSD:, TopIndicator, % "☕ АФК №" afkCount " " mmss
        GuiControl, OSD:, StageText, % "☕ перерыв ещё " mmss
        return
    }

    ; Паузу «нет еды» в меню НЕ показываем: иначе индикатор вместо
    ; «▶ РАБОТА» показывал бы таймер, и непонятно, жив ли бот.
    ; «Сторож тишины»: бот активен, но 30+ минут ни заброса, ни
    ; поклёвки, ни улова. Значит, ИГРА перестала отвечать (снасть
    ; сломалась, кончилась наживка, сменилась локация…) — раньше
    ; это молчание выглядело как «встал АФК» без всякой записи.
    if (lastActionTime > 0 and A_TickCount - lastActionTime > 1800000) {
        qmin := (A_TickCount - lastActionTime) // 60000
        if (!quietShown) {
            Gui, OSD: Font, s7 wBold c%C_WARN%, Segoe UI
            GuiControl, OSD: Font, TopIndicator
        }
        quietShown := true
        GuiControl, OSD:, TopIndicator, % "⏸ ТИШИНА " qmin "м"
        if (!quietLogged) {
            quietLogged := true      ; один раз на период тишины
            LogEvent("afk", "quiet")
        }
    } else if (quietShown) {
        quietShown := false          ; клёв возобновился
        Gui, OSD: Font, s7 wBold c%C_WORK%, Segoe UI
        GuiControl, OSD: Font, TopIndicator
        GuiControl, OSD:, TopIndicator, ▶ РАБОТА
    }

    timeLeft := (coffeeTimerLimit - A_TickCount) // 1000
    if (timeLeft < 0)
        timeLeft := 0

    m := timeLeft // 60
    s := Mod(timeLeft, 60)
    GuiControl, OSD:, CoffeeText, % Format("{:02}:{:02}", m, s)

    ; при вариативности длина цикла плавает — полоса считается
    ; от текущей длины, иначе в начале цикла показывала бы неправду
    span := coffeeSpan // 1000
    if (span < 1)
        span := 1
    percent := (timeLeft / span) * 100
    SetCoffeeBar(percent)
return

SafeSleep(ms) {
    ; №76: сон кусочками по 50 мс — если в это время нажали паузу
    ; (PgDn или Telegram), просыпаемся моментально и честно говорим
    ; об этом вызывающему (true = прервано паузой). Раньше долгий
    ; Sleep между клавишами 4/5 глотал паузу: флаг менялся, а бот
    ; донажимал оставшиеся порции.
    global isActive
    deadline := A_TickCount + ms
    Loop {
        if (!isActive)
            return true
        left := deadline - A_TickCount
        if (left <= 0)
            return false
        chunk := left
        if (chunk > 50)
            chunk := 50
        Sleep, %chunk%
    }
}

SafePress(key, times) {
    global isShiftDown, Variability, isActive
    needRestore := false

    if (isShiftDown) {
        Send, {LShift Up}
        needRestore := true
        if (SafeSleep(Var(50, 0.7, 1.6))) {
            if (needRestore) {
                Send, {LShift Down}
            }
            return
        }
    }

    ; С вариативностью «порция» случайная: то одна нажатие, то
    ; несколько (например, еды съедается 1-4 вместо всегда трёх,
    ; кофе/солнце 1-3 вместо всегда двух), и между нажатиями
    ; человеческая пауза 400-1200 мс вместо ровного ритма.
    ; Без вариативности — ровно `times` нажатий через 300 мс, как было.
    n := times
    if (Variability) {
        maxN := times + 1
        Random, n, 1, %maxN%
    }

    Loop, %n% {
        if (!isActive)          ; пауза — мгновенный стоп (№76)
            break
        Send, {%key%}
        if (SafeSleep(VarRange(300, 400, 1200)))
            break               ; уснули — а встали уже на паузе
    }

    if (needRestore) {
        Send, {LShift Down}
    }
}

; ==========================================
; ОСНОВНОЙ ЦИКЛ БОТА
; ==========================================
CheckGameLogic:
    if (!isActive)
        return
    ; период тикера тоже слегка плавает: следующий такт через
    ; случайные ~105-240 мс вместо ровно 150
    SetTimer, CheckGameLogic, % Var(150, 0.7, 1.6)
    ; Живые бары под строками меню: пересчёт из текущих таймеров
    ; каждый такт — шкалы ползут прямо на глазах (и на АФК/паузах
    ; рывков честно стоят на нулях).
    UpdateTimerBars()
    ; --- Редкие АФК-перерывы: раз в час 10-15 минут «человек отошёл» ---
    ; Только при включённой вариативности. Без неё — как раньше.
    if (afkUntil > 0) {
        if (A_TickCount < afkUntil)
            return              ; отдыхаем: ничего не нажимаем
        afkUntil := 0         ; перерыв кончился — следующий через 1-3 часа
        nextAfk := A_TickCount + VarRange(3600000, 3600000, 10800000)
        UpdateOSD("Анализ...", "—", "—")
        Gui, OSD: Font, s7 wBold c%C_WORK%, Segoe UI
        GuiControl, OSD: Font, TopIndicator
        GuiControl, OSD:, TopIndicator, ▶ РАБОТА
    } else if (Variability and !afkPending and A_TickCount >= nextAfk) {
        ; ВАЖНО: перерыв здесь НЕ начинается — только поднимаем флаг.
        ; Сам перерыв встанет строго после ближайшей оценки улова
        ; (StartAfkBreak зовётся в её конце): там снасть в руке,
        ; рыбы на крючке нет и, проснувшись, бот честно закинет
        ; заново и зажмёт ЛКМ — как человек после перекура.
        afkPending := true
    }
    if (!isCasting and !isEvaluating) {
        ; Расходники проверяем раз в 2 секунды, а не каждые 150 мс:
        ; полоски меняются медленно, а сканирование пикселей дорогое
        ; и тормозит поиск рыбы в этом же цикле.
        if (A_TickCount < nextConsumeScan)
            actionTaken := true
        else {
            nextConsumeScan := A_TickCount + Var(2000, 0.75, 1.5)
            ; Пауза после приёма: полоска обновляется не мгновенно.
            actionTaken := (A_TickCount < consumeLockUntil)
        }

        if (!actionTaken and A_TickCount > nextSunCheck) {
            if (A_TickCount < consumeGiveUpUntil) {
                ; Пауза «5 х Слот пуст»: кнопки 4/5 не трогаем вовсе.
                nextSunCheck := A_TickCount + Var(30000, 0.8, 1.4)
            } else if (IsBarRed(SunStartX, SunStartY, SunEndX, SunEndY)) {
                SafePress("5", 2)
                LogEvent("consume", "sun")
                consumeLockUntil := A_TickCount + Var(3000, 0.8, 1.5)
                nextSunCheck := A_TickCount + Var(30000, 0.8, 1.4)
                coffeeSpan := Var(1200000, 0.85, 1.15)
                coffeeTimerLimit := A_TickCount + coffeeSpan
                nextCoffeeCheck := A_TickCount + Var(20000, 0.8, 1.4)
                actionTaken := true
                CheckConsumeFail()
            } else {
                nextSunCheck := A_TickCount + Var(5000, 0.8, 1.4)
            }
        }

        ; Кофе тоже на кнопке 5 — под тем же запретом после «Слот пуст».
        if (!actionTaken and A_TickCount >= consumeGiveUpUntil) {
            needsCoffee := false
            if (A_TickCount > coffeeTimerLimit) {
                needsCoffee := true
            } else if (A_TickCount > nextCoffeeCheck) {
                if (IsBarRed(EnergyStartX, EnergyStartY, EnergyEndX, EnergyEndY))
                    needsCoffee := true
                nextCoffeeCheck := A_TickCount + Var(5000, 0.8, 1.4)
            }
            if (needsCoffee) {
                SafePress("5", 2)
                LogEvent("consume", "coffee")
                consumeLockUntil := A_TickCount + Var(3000, 0.8, 1.5)
                coffeeSpan := Var(1200000, 0.85, 1.15)
                coffeeTimerLimit := A_TickCount + coffeeSpan
                nextCoffeeCheck := A_TickCount + Var(20000, 0.8, 1.4)
                actionTaken := true
                CheckConsumeFail()
            }
        }

        if (!actionTaken and A_TickCount > nextFoodCheck) {
            if (A_TickCount < consumeGiveUpUntil) {
                ; Пауза «5 х Слот пуст»: кнопку 4 (и 5 тоже) не трогаем.
                nextFoodCheck := A_TickCount + Var(30000, 0.8, 1.4)
            } else if (IsBarRed(FoodStartX, FoodStartY, FoodEndX, FoodEndY)) {
                SafePress("4", 3)
                LogEvent("consume", "food")
                consumeLockUntil := A_TickCount + Var(3000, 0.8, 1.5)
                nextFoodCheck := A_TickCount + Var(20000, 0.8, 1.4)
                actionTaken := true
                ; Сразу после СВОЕЙ попытки смотрим, не ответила ли
                ; игра красным «Слот пуст». Внутри — счётчик промахов:
                ; 5 подряд = пауза 5-8 минут (рандом по мс) на 4/5.
                CheckConsumeFail()
            } else {
                nextFoodCheck := A_TickCount + Var(5000, 0.8, 1.4)
            }
        }
    }
    if (isCasting or isEvaluating)
        return

    ; №78: страховка катушки — на КАЖДОМ такте цикла. Раньше звали
    ; её только из веток «вижу поклёвку»: если после возврата с
    ; паузы экран молчал (тишина за водоёмом), такт в те ветки не
    ; заходил, страховка не срабатывала — и бот «переставал
    ; зажимать ЛКМ совсем». Одна точка вызова — дожмём всегда.
    EnsureReelHeld()

    ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, % ImgOpt("catch.png", 80)
    if (ErrorLevel == 0) {
        isEvaluating := true
        ReleaseAll()
        tackleInWater := false      ; улов на экране — снасть уже из воды
        TouchAction()          ; улов на экране — сторож в норме

        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText
        UpdateOSD("Оценка улова...", "—", "—")

        TotalCaught++
        GuiControl, OSD:, CaughtText, 🐟 Поймано: %TotalCaught%

        ; Держим окно улова подольше: во-первых, распознаванию нужно
        ; успеть прочитать название, вес и опыт, во-вторых, человек
        ; тоже «думает», отпускать рыбу или брать. С вариативностью
        ; случайные 3-8 секунд вплоть до мс, без неё — 2.6 с, как было.
        evalMs := VarRange(2600, 3000, 8000)
        UpdateOSD("Оценка улова (" FmtMs(evalMs) ")", "—", "—")
        SleepJitter(evalMs)
        if (!isActive) {
            isEvaluating := false
            return
        }

        ; Сначала по цвету плашки — способ не зависит от размера
        ; интерфейса, поэтому трофей находится у всех.
        kind := DetectCatchKind()
        trophyFound := (kind = 2)
        zachetFound := (kind = 1)

        ; Если цвет почему-то не распознался, пробуем по картинке —
        ; вдруг у игрока другая тема оформления.
        if (!zachetFound and !trophyFound) {
            ImageSearch, tX, tY, ZachetStartX, ZachetStartY, ZachetEndX, ZachetEndY, % ImgOpt("trophy.png", 80)
            trophyFound := (ErrorLevel == 0)
            ImageSearch, zX, zY, ZachetStartX, ZachetStartY, ZachetEndX, ZachetEndY, % ImgOpt("zachet.png", 80)
            zachetFound := (ErrorLevel == 0)
        }

        ; Плашка появляется не мгновенно — даём ей время и пробуем ещё раз.
        if (!zachetFound and !trophyFound) {
            Sleep, % Var(1000, 0.8, 1.3)
            kind := DetectCatchKind()
            trophyFound := (kind = 2)
            zachetFound := (kind = 1)
        }

        ; Трофей всегда важнее: если вдруг нашлось и то и другое,
        ; рыбу оставляем как трофейную.
        if (trophyFound)
            zachetFound := false

        if (zachetFound or trophyFound) {
            Gui, OSD: Font, s10 wBold c%C_BITE%, Segoe UI
            GuiControl, OSD: Font, BarText
            if (trophyFound) {
                UpdateOSD("В садок", "—", "⭐ ТРОФЕЙ!")
                TotalTrophy++
                LogEvent("catch", "trophy")
            } else {
                UpdateOSD("В садок", "—", "Зачётная")
                LogEvent("catch", "zachet")
            }
            TotalKept++
            Send, {Space down}
            Sleep, % Var(50, 0.7, 1.6)
            Send, {Space up}

            Sleep, % Var(1000, 0.7, 1.5)
            ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, % ImgOpt("catch.png", 80)
            if (ErrorLevel == 0) {
                PixelSearch, errX, errY, ErrorStartX, ErrorStartY, ErrorEndX, ErrorEndY, 0xDD2222, 60, Fast RGB
                if (ErrorLevel == 0) {
                    UpdateOSD("САДОК ПОЛОН", "—", "Выброс")
                    LogEvent("keepnet", "full")
                    Sleep, % Var(1000, 0.7, 1.5)
                    Send, {Backspace down}
                    Sleep, % Var(50, 0.7, 1.6)
                    Send, {Backspace up}
                }
            }
        } else {
            Gui, OSD: Font, s10 wBold c%C_RED%, Segoe UI
            GuiControl, OSD: Font, BarText
            UpdateOSD("Выброс", "—", "Мелочь")
            TotalReleased++
            LogEvent("catch", "small")
            Send, {Backspace down}
            Sleep, % Var(50, 0.7, 1.6)
            Send, {Backspace up}
        }

        ; Ждём закрытия окна улова. Если знакомый пиксель «залип»
        ; (совпал с другим элементом игры), цикл крутился бы бесконечно
        ; и бот молча умирал: главный поток до ловли не доходил, а
        ; боковые такты только дёргали еду. Ровно так «завис» тот
        ; утренний бот. Потолок 30 секунд, потом идём дальше и пишем
        ; событие в журнал.
        waitT0 := A_TickCount
        Loop {
            if (!isActive)
                return
            ImageSearch, FoundX, FoundY, 0, 0, A_ScreenWidth, A_ScreenHeight, % ImgOpt("catch.png", 80)
            if (ErrorLevel != 0)
                break
            if (A_TickCount - waitT0 > 30000) {
                LogEvent("catch", "window-stuck")
                break
            }
            Sleep, % Var(500, 0.7, 1.5)
        }

        Sleep, % Var(1000, 0.8, 1.5)
        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText
        UpdateOSD("Жду снасть...", "—", "—")
        isEvaluating := false
        ; АФК-перерыв стартует ЕДИНСТВЕННЫМ местом — отсюда, сразу
        ; после оценки улова: снасть в руке, рыбы на крючке нет.
        ; Раньше «☕» мог встать с клюнувшей рыбой — и она сходила.
        if (afkPending) {
            afkPending := false
            if (Variability)     ; тумблер могли выключить, пока ждали
                StartAfkBreak()
        }
        return
    }

    foundReady := false
    ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_morning.png", 90)
    if (ErrorLevel == 0) {
        foundReady := true
    } else {
        ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_day.png", 90)
        if (ErrorLevel == 0) {
            foundReady := true
        } else {
            ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_night.png", 90)
            if (ErrorLevel == 0)
                foundReady := true
        }
    }

    if (foundReady) {
        isCasting := true
        ReleaseAll()
        TouchAction()          ; снасть готова — сторож в норме

        ; Заметив «снасть готова», человек не бросает в тот же миг —
        ; дожидается случайные 1.2-6 секунд. Без вариативности — сразу,
        ; как было всегда.
        readyWaitMs := VarRange(0, 1200, 6000)
        if (readyWaitMs > 0) {
            Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
            GuiControl, OSD: Font, StageText
            UpdateOSD("Заброс через " FmtMs(readyWaitMs), "—", "—")
            SleepJitter(readyWaitMs)
            if (!isActive) {
                isCasting := false
                return
            }
        }

        ; В меню всегда пишем ТОЧНО, сколько будем ждать: меньше
        ; секунды — в мс («534 мс»), больше — «9.6 с».
        prepMs := Var(500, 0.7, 1.6)
        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText
        UpdateOSD("Замах (" FmtMs(prepMs) ")", "—", "—")
        Sleep, %prepMs%

        if (!isActive) {
            isCasting := false
            return
        }

        Click, Down Left
        Sleep, % Var(50, 0.7, 1.6)
        Send, {LShift Down}

        ; держим замах: чуть дольше/короче — заброс получается
        ; немного разной силы. Пока держим, курсор чуть «дрожит».
        swingMs := Var(1200, 0.85, 1.15)
        UpdateOSD("Замах (" FmtMs(swingMs) ")", "—", "—")
        SleepJitter(swingMs)

        Click, Up Left
        Sleep, % Var(50, 0.7, 1.6)
        Send, {LShift Up}

        ; Полёт и приводнение. Без вариативности — ровно 5000 мс, как
        ; раньше; с ней — случайные 3000–10000 мс, из них какое число
        ; выпало — такое и написано в меню (и подождём ровно столько).
        flightMs := Var(5000, 0.6, 2.0)
        UpdateOSD("Полет (" FmtMs(flightMs) ")", "—", "—")
        SleepJitter(flightMs)

        if (!isActive) {
            isCasting := false
            return
        }

        Click, Down Left
        isLButtonDown := true      ; помним: катушка зажата
        tackleInWater := true      ; и снасть точно в воде
        isCasting := false
        LogEvent("cast", "ok")
        UpdateOSD("Ловлю", "Нет", "—")
        return
    }

    foundFish := false
    ImageSearch, FoundX, FoundY, FishStartX, FishStartY, FishEndX, FishEndY, % ImgOpt("fish_morning.png", 70)
    if (ErrorLevel == 0) {
        foundFish := true
    } else {
        ImageSearch, FoundX, FoundY, FishStartX, FishStartY, FishEndX, FishEndY, % ImgOpt("fish_day.png", 70)
        if (ErrorLevel == 0) {
            foundFish := true
        } else {
            ImageSearch, FoundX, FoundY, FishStartX, FishStartY, FishEndX, FishEndY, % ImgOpt("fish_night.png", 70)
            if (ErrorLevel == 0)
                foundFish := true
        }
    }

    if (foundFish) {
        lastFishTime := A_TickCount
        TouchAction()          ; поклёвка — сторож в норме
        if (fishFirstSeenTime == 0) {
            fishFirstSeenTime := A_TickCount
            ; Случайные задержки реакции: до Shift — 150-4500 мс,
            ; до первого нажатия ПКМ — 2-8 сек. Как у человека, который
            ; «догоняет» рыбу — то быстрее, то медленнее. Без
            ; вариативности — Shift сразу, ПКМ ровно через 3 сек.
            shiftPressAfter := VarRange(0, 150, 4500)
            rmbPressAfter := VarRange(3000, 2000, 8000)
        }
    }

    if (lastFishTime > 0 and (A_TickCount - lastFishTime < 3500)) {
        EnsureReelHeld()       ; катушка должна быть зажата всегда
        Gui, OSD: Font, c%C_FG%
        GuiControl, OSD: Font, FishText
        Gui, OSD: Font, s10 wNorm c%C_FG%, Segoe UI Emoji
        GuiControl, OSD: Font, FishIcon
        timeSinceFish := A_TickCount - fishFirstSeenTime

        ; Shift зажимаем не мгновенно, а через свою случайную задержку
        ; (150-4500 мс с вариативностью, сразу — без неё)
        if (isShiftDown) {
            FishStatus := "Вижу (Shift)"
        } else if (timeSinceFish >= shiftPressAfter) {
            Send, {LShift Down}
            isShiftDown := true
            FishStatus := "Вижу (Shift)"
        } else {
            FishStatus := "Shift через " FmtMs(shiftPressAfter - timeSinceFish)
        }

        if (timeSinceFish > rmbPressAfter) {
            Gui, OSD: Font, c%C_STAGE%
            GuiControl, OSD: Font, BarText
            Gui, OSD: Font, s10 wNorm c%C_STAGE%, Segoe UI Emoji
            GuiControl, OSD: Font, BarIcon

            if (Variability) {
                ; Рывки ПКМ: зажали случайно на 3-12 секунд, отпустили,
                ; передышка 1-7 секунд, и снова. Всё совершенно рандомно
                ; вплоть до миллисекунд, а в меню видно, сколько осталось
                ; до конца рывка или передышки.
                if (isRButtonDown and A_TickCount >= rmbUntil) {
                    Click, Up Right
                    isRButtonDown := false
                    rmbGapMs := VarRange(3000, 1000, 7000)
                    rmbNextAt := A_TickCount + rmbGapMs
                }
                if (!isRButtonDown and A_TickCount >= rmbNextAt) {
                    Click, Down Right
                    isRButtonDown := true
                    rmbLastMs := VarRange(6000, 3000, 12000)
                    rmbUntil := A_TickCount + rmbLastMs
                }
                if (isRButtonDown)
                    BarStatus := "ПКМ " FmtMs(rmbUntil - A_TickCount)
                else
                    BarStatus := "пауза " FmtMs(rmbNextAt - A_TickCount)
            } else {
                BarStatus := "ЗАЖАТА (ПКМ)"

                if (!isRButtonDown) {
                    Click, Down Right
                    isRButtonDown := true
                }
            }
        } else {
            Gui, OSD: Font, c%C_FG%
            GuiControl, OSD: Font, BarText
            Gui, OSD: Font, s10 wNorm c%C_FG%, Segoe UI Emoji
            GuiControl, OSD: Font, BarIcon

            ; ждём свою случайную задержку (2-8 сек) и показываем,
            ; сколько осталось до нажатия ПКМ
            BarStatus := "жму через " FmtMs(rmbPressAfter - timeSinceFish)

            if (isRButtonDown) {
                Click, Up Right
                isRButtonDown := false
            }
        }

        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText
        UpdateOSD("Борьба!", FishStatus, BarStatus)

    } else {
        EnsureReelHeld()       ; и между поклёвками — тоже зажата
        fishFirstSeenTime := 0
        Gui, OSD: Font, s10 wBold c%C_FG%, Segoe UI
        GuiControl, OSD: Font, FishText
        GuiControl, OSD: Font, BarText

        Gui, OSD: Font, s10 wNorm c%C_DIM%, Segoe UI Emoji
        GuiControl, OSD: Font, FishIcon
        GuiControl, OSD: Font, BarIcon

        Gui, OSD: Font, s10 wBold c%C_ACCENT%, Segoe UI
        GuiControl, OSD: Font, StageText

        FishStatus := "Нет"
        BarStatus := "—"

        if (isShiftDown) {
            Send, {LShift Up}
            isShiftDown := false
        }
        if (isRButtonDown) {
            Click, Up Right
            isRButtonDown := false
        }
        ; рыба ушла/рывок кончился — цикл ПКМ начнём с чистого листа
        rmbUntil := 0
        rmbNextAt := 0
        rmbPressAfter := 0
        shiftPressAfter := 0
        UpdateOSD("Ловлю", FishStatus, BarStatus)

        ; --- Самоспасение из «тишины» ---------------------------------
        ; Если игра молчит 30+ минут (ни заброса, ни поклёвки, ни
        ; улова), человек бы давно перезакинул снасть: то ли наживка
        ; смылась, то ли снасть у игры «залипла». Делаем ровно это:
        ; короткий подсечный рывок ПКМ без рыбы вытягивает снасть из
        ; воды — дальше ближайший такт увидит значок «снасть готова» и
        ; обычный заброс пойдёт сам, как после схода рыбы. Повтор не
        ; чаще раза в 30 минут молчания, а любой живой ответ игры
        ; (TouchAction) сбрасывает счётчик в ноль.
        if (lastActionTime > 0
                and A_TickCount - lastActionTime > 1800000
                and A_TickCount - lastRecastAt > 1800000) {
            lastRecastAt := A_TickCount
            LogEvent("afk", "recast")
            ; №85: раньше был ОДИН короткий рывок ПКМ — приманка
            ; с дальнего заброса оставалась в воде, флаг «в воде»
            ; уже снят → столб до бесконечности. Теперь выматываем
            ; до «снасть готова», иначе честно доматываем ЛКМ.
            ExtractTackle("recast")
        }
    }
return

; Начало АФК-перерыва. Зовётся ТОЛЬКО из конца оценки улова (см.
; флаг afkPending): улов снят с экрана, снасть в руке, рыбы на
; крючке нет — уйти «покурить» безопасно. Проснувшись, ближайший
; такт увидит «снасть готова» и дальше всё идёт как после любого
; улова: заброс → ЛКМ зажата → ловля.
StartAfkBreak() {
    global afkUntil, afkCount, C_WARN
    afkUntil := A_TickCount + VarRange(600000, 480000, 960000)  ; 8-16 мин
    afkCount++
    ReleaseAll()
    LogEvent("afk", "break")
    ; уведомление в меню: в углу «☕ АФК №N mm:ss» — номер перерыва
    ; за сессию и сразу видимый отсчёт, сколько ещё отдыхаем.
    ; Дальше каждую секунду время обновляет UpdateClock.
    afkLeft := (afkUntil - A_TickCount) // 1000
    afkMmSs := Format("{:02}:{:02}", afkLeft // 60, Mod(afkLeft, 60))
    Gui, OSD: Font, s7 wBold c%C_WARN%, Segoe UI
    GuiControl, OSD: Font, TopIndicator
    GuiControl, OSD:, TopIndicator, % "☕ АФК №" afkCount " " afkMmSs
    GuiControl, OSD:, StageText, % "☕ перерыв ещё " afkMmSs
}

; Страховка катушки: пока снасть в воде, ЛКМ обязана быть зажата —
; иначе поклёвка кончится сходом без борьбы. Если кнопка «ушла»
; (кончился перерыв, вернулись с паузы), дожимаем её обратно сразу,
; на том же такте — бот больше не может «встать посередине работы»,
; показывая РАБОТА с пустой катушкой.
EnsureReelHeld() {
    global tackleInWater, isLButtonDown, isActive, resumeUntil
    ; №60: на паузе — трогать кнопку запрещено. Именно из-за
    ; пропущенной проверки прерванный PgDn поток дожимал ЛКМ
    ; уже после ReleaseAll — «крутил катушку дальше».
    if (!isActive)
        return
    ; №60: дотяжка после паузы кончилась, а игра так и молчит —
    ; значит снасти в воде нет. №78: раньше здесь просто отпускали
    ; ЛКМ — и если игровые значки не мелькнули, бот застывал с
    ; пустой рукой «совсем», до 30-минутного самоспасения. Делаем
    ; пустой подсечный рывок ПКМ (короткое вычерчивание): снасть
    ; точно выносится, следующий такт видит «снасть готова» — и
    ; обычный заброс зажимает ЛКМ заново.
    if (resumeUntil and A_TickCount > resumeUntil) {
        resumeUntil := 0
        LogEvent("session", "resume-recast")
        ; №85: одиночного короткого рывка здесь больше нет (см.
        ; ExtractTackle) — дальний заброс он не доставал, и бот
        ; вставал с удочкой «посередине пути» навсегда.
        ExtractTackle("resume")
        return
    }
    if (tackleInWater and !isLButtonDown) {
        Click, Down Left
        isLButtonDown := true
        LogEvent("reel", "restore")
    }
}

; №85: ОБЩИЙ спасатель «снасть застряла в воде» — и после паузы,
; и из «тишины». Корень бага «бот встал с заброшенной удочкой
; посередине пути»: старый код дёргал снасть ОДНИМ коротким рывком
; ПКМ (1.2-3.2 с), а дальний заброс такой рывок до берега не
; тащит. Флаг tackleInWater при этом уже снимался → игра «снасть
; готова» не показывала → заброса не было → ЛКМ больше никто не
; зажимал → столб навсегда, и каждый повтор наступал на те же
; грабли. Теперь по-взрослому:
;   1) рывки ПКМ идут ПОДРЯД, и после каждого смотрим «снасть
;      готова» — вытащили (даже с 3-4 попыток) → обычный заброс;
;   2) за ~28 секунд не вытащили — снасть НЕ бросаем: зажимаем
;      ЛКМ и медленно доматываем катушкой до победного. Встать
;      посередине пути больше просто нечем.
ExtractTackle(why) {
    global tackleInWater, isLButtonDown, isActive
    global ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY
    ReleaseAll()
    UpdateOSD("Перезаброс...", "—", "—")
    deadline := A_TickCount + 28000
    while (isActive and A_TickCount < deadline) {
        Click, Down Right
        Sleep, % VarRange(1500, 1600, 2800)
        Click, Up Right
        Sleep, % Var(400, 0.7, 1.5)
        if (!isActive)            ; PgDn на фоне — выходим сразу
            return
        foundReady := false
        ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_morning.png", 90)
        if (ErrorLevel == 0) {
            foundReady := true
        } else {
            ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_day.png", 90)
            if (ErrorLevel == 0) {
                foundReady := true
            } else {
                ImageSearch, FoundX, FoundY, ReadyStartX, ReadyStartY, ReadyEndX, ReadyEndY, % ImgOpt("ready_night.png", 90)
                if (ErrorLevel == 0)
                    foundReady := true
            }
        }
        if (foundReady) {
            tackleInWater := false   ; снасть точно в руке
            TouchAction()            ; жизнь есть — сторож в норме
            LogEvent("afk", why "-ok")
            UpdateOSD("Ловлю", "Нет", "—")
            return
        }
        ; не готова — следующий рывок. Клюнувшую за это время рыбу
        ; на выходе подберёт обычный такт (увидит «рыбку» изображение)
    }
    tackleInWater := true
    Click, Down Left
    isLButtonDown := true
    LogEvent("reel", why "-lmb")
    UpdateOSD("Доматываю...", "—", "—")
    Sleep, % Var(1500, 0.8, 1.5)
}

ReleaseAll() {
    global isActive, isShiftDown, isRButtonDown, fishFirstSeenTime
    global rmbUntil, rmbNextAt, rmbPressAfter, shiftPressAfter
    global jitX, jitY, isLButtonDown
    fishFirstSeenTime := 0
    Click, Up Left
    isLButtonDown := false
    if (isShiftDown) {
        Send, {LShift Up}
        isShiftDown := false
    }
    if (isRButtonDown) {
        ; Курсор был спрятан мотанием (ПКМ) — накопленное дрожание
        ; сбрасываем в ноль: «догоняющий» сдвиг к старой цели
        ; выглядел бы внезапным рывком при появлении курсора.
        Click, Up Right
        isRButtonDown := false
        jitX := 0
        jitY := 0
    }
    rmbUntil := 0
    rmbNextAt := 0
    rmbPressAfter := 0
    shiftPressAfter := 0
}

; Отмечаем, что бот дождался от игры чего-то живого: заброс, поклёвка
; или улов. По этой метке меню понимает, что ловля идёт, а не стоит
; мёртво — см. счётчик «тишины» в UpdateClock.
TouchAction() {
    global lastActionTime, quietLogged, lastRecastAt, resumeUntil
    resumeUntil := 0          ; №60: игра ожила — лимит дотяжки снят
    lastActionTime := A_TickCount
    quietLogged := false
    lastRecastAt := 0     ; жизнь есть — счётчик самоспасения в ноль
}

UpdateOSD(stage, fish, bar) {
    global lastStage, lastFish, lastBar
    lastStage := stage
    lastFish := fish
    lastBar := bar
    GuiControl, OSD:, StageText, %stage%
    GuiControl, OSD:, FishText, %fish%
    GuiControl, OSD:, BarText, %bar%
}

; Физический клик игрока не должен ронять наш зажим ЛКМ: вернули
; кнопку обратно и обновили флаг катушки. Во время ☕-перерыва
; перехват ОТКЛЮЧЁН: клик во время «покурить» — просто клик, а
; держать катушку с пустой снастью не надо (раньше бот после
; перерыва мог оказаться с зажатой ЛКМ и заряженным замахом).
#If isActive and !isCasting and !isEvaluating and (afkUntil = 0 or A_TickCount >= afkUntil)
; №58: $ — хук ловит только ФИЗИЧЕСКИЙ клик игрока и не
; срабатывает на клики самого бота (без $ Send-поджигал его,
; а условный пережим №56 глотал ботовые нажатия: заброс и
; ведение «видели снасть готова», но кнопки не было).
$*LButton::
    Click, Up Left
    isLButtonDown := false
    Sleep, % Var(30, 0.7, 1.7)
    ; №56: PgDn мог успеть выключить бота, пока длилась эта пауза —
    ; зажимать ЛКМ обратно тогда нельзя, кнопка оставалась вжатой.
    if (isActive and tackleInWater) {
        Click, Down Left
        isLButtonDown := true
    }
return

$*LButton Up::
    Click, Up Left
    isLButtonDown := false
    Sleep, % Var(30, 0.7, 1.7)
    if (isActive and tackleInWater) {
        Click, Down Left
        isLButtonDown := true
    }
return
#If


; ==========================================
; АВТОЗАПУСК ОКНА СТАТИСТИКИ
; ==========================================
; Статистика поднимает OCR сама, поэтому здесь только одна цепочка:
; бот -> stats.pyw -> ocr_watch.pyw
LaunchStats(silent := false) {
    global StatsPID, DataDir
    py := A_ScriptDir . "\stats.pyw"
    if (!FileExist(py)) {
        if (!silent)
            MsgBox, 48, TrofPridi, Не найден stats.pyw рядом со скриптом.
        return
    }

    ; Окно уже открыто? Тогда F6 не запускает второй экземпляр, а просто
    ; показывает существующее: разворачивает, если свёрнуто, и выводит
    ; поверх игры. Раньше каждое нажатие плодило новый процесс — они
    ; писали в одни и те же файлы и мешали друг другу.
    ;
    ; Признак «окно живо» — свежий alive.txt: статистика обновляет его
    ; раз в секунду. Файл надёжнее PID, потому что окно могли закрыть
    ; крестиком или запустить отдельно от бота.
    if (StatsAlive()) {
        ShowStatsWindow()
        return
    }

    ; Убираем файл-сигнал, если остался от прошлого выхода,
    ; иначе только что запущенное окно сразу закроется.
    stop := A_ScriptDir . "\TrofPridi_data\STOP"
    if (FileExist(stop))
        FileDelete, %stop%

    ; pythonw = без чёрного окна консоли. PID запоминаем, чтобы
    ; закрыть процесс при выходе по F8.
    Run, pythonw.exe "%py%", %A_ScriptDir%, UseErrorLevel, pid
    if (ErrorLevel) {
        Run, python.exe "%py%", %A_ScriptDir%, UseErrorLevel, pid
        if (ErrorLevel) {
            ; Python на чистой машине: не просим человека ничего
            ; ставить руками — качаем официальный установщик сами.
            pid := EnsurePython(py)
            if (!pid) {
                if (!silent)
                    MsgBox, 48, TrofPridi, Python не найден, и автоматическая установка не удалась (проверь интернет).`nМожно поставить вручную с python.org — отметь "Add to PATH".
                return
            }
        }
    }
    StatsPID := pid
}

; Качает и тихо ставит Python (как у обычного пользователя, со
; всем нужным: tkinter для окна и pip для библиотек), потом
; запускает этим свежим Python'ом нашу статистику. Возвращает PID.
EnsurePython(py) {
    global DataDir
    UpdateOSD("Установка Python...", "—", "—")
    tmp := A_Temp . "\trofpridi-python-setup.exe"
    FileDelete, %tmp%
    ; Точная версия, чтобы путь установки был известен наперечёт.
    url := "https://www.python.org/ftp/python/3.12.9/python-3.12.9-amd64.exe"
    UrlDownloadToFile, %url%, %tmp%
    if (ErrorLevel or !FileExist(tmp))
        return 0
    ; /passive — молча, без вопросов; tk, pip и PATH включены.
    RunWait, "%tmp%" /passive InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_tcltk=1 Include_test=0 AssociateFiles=0, , Hide
    FileDelete, %tmp%
    ; per-user установка кладёт интерпретатор сюда; запускаем
    ; абсолютным путём — PATH нашего процесса ещё старый.
    pw := A_LocalAppData . "\Programs\Python\Python312\pythonw.exe"
    Run, "%pw%" "%py%", %A_ScriptDir%, UseErrorLevel, pid
    if (ErrorLevel)
        return 0
    UpdateOSD("Ловлю", "Нет", "—")
    return pid
}

; Работает ли окно статистики прямо сейчас.
; Оно раз в секунду обновляет alive.txt; если отметка старше 5 секунд,
; окно закрыто. Проверять по PID нельзя: пользователь мог закрыть окно
; крестиком, а процесс с тем же PID успела занять другая программа.
StatsAlive() {
    global DataDir
    f := DataDir . "\alive.txt"
    if (!FileExist(f))
        return false
    FileGetTime, mt, %f%, M
    diff := A_Now
    EnvSub, diff, %mt%, Seconds
    return (diff >= 0 and diff <= 5)
}

; ==========================================
; TROFPRIDI MANAGER — поднимаем вместе с ботом (№53)
; ==========================================
; Менеджер — окно на Flet (тот же Python). Жив ли он — по маяку
; manager_alive.txt (обновляется каждые 2 секунды, порог с запасом).
ManagerAlive() {
    global DataDir
    f := DataDir . "\manager_alive.txt"
    if (!FileExist(f))
        return false
    FileGetTime, mt, %f%, M
    diff := A_Now
    EnvSub, diff, %mt%, Seconds
    return (diff >= 0 and diff <= 6)
}

LaunchManager(silent := true) {
    global ManagerPID
    py := A_ScriptDir . "\manager.pyw"
    if (!FileExist(py)) {
        if (!silent)
            MsgBox, 48, TrofPridi, Не найден manager.pyw рядом со скриптом.
        return
    }
    if (ManagerAlive())
        return
    ; pythonw — без чёрной консоли. Нет Python — не мешаем: его
    ; ставит статистика своим автоустановщиком (EnsurePython).
    Run, pythonw.exe "%py%", %A_ScriptDir%, UseErrorLevel, pid
    if (ErrorLevel) {
        Run, python.exe "%py%", %A_ScriptDir%, UseErrorLevel, pid
        if (ErrorLevel)
            return
    }
    ManagerPID := pid
}

; OnExit-чистилка (№53): маяк не должен переживать бота ни при
; каком способе выхода, иначе Менеджер рисует «Запущен» на трупе.
BotExitCleanup() {
    global BotStateFile
    if (FileExist(BotStateFile))
        FileDelete, %BotStateFile%
    return 0
}

; Показывает уже открытое окно статистики.
; У окна убрана системная рамка (overrideredirect), поэтому оно может
; быть свёрнуто через WinAPI, о чём Tk не знает. Разворачиваем и
; поднимаем поверх остальных окон.
ShowStatsWindow() {
    prev := A_DetectHiddenWindows
    DetectHiddenWindows, On
    hwnd := 0
    ; Ищем по заголовку: его задаёт stats_app.py -> self.title(...)
    WinGet, hwnd, ID, TrofPridi — статистика
    if (!hwnd)
        WinGet, hwnd, ID, TrofPridi
    DetectHiddenWindows, %prev%
    if (!hwnd) {
        ; Окно живо (alive.txt свежий), но найти его не удалось —
        ; просим показаться через файл-сигнал, его читает stats_app.
        FileAppend, show, % DataDir . "\SHOW", UTF-8
        return
    }
    ; 9 = SW_RESTORE: разворачивает свёрнутое окно и не трогает обычное.
    DllCall("ShowWindow", "Ptr", hwnd, "Int", 9)
    WinShow, ahk_id %hwnd%
    ; Поднимаем наверх даже из-под игры: голый SetForegroundWindow
    ; Windows часто игнорирует, поэтому фокус тырим честно —
    ; привязываемся на мгновение к потоку активного окна, а краткий
    ; «топмост» выталкивает окно поверх, но не липнет (сразу снимаем).
    fgw := DllCall("GetForegroundWindow", "Ptr")
    myTid := DllCall("GetCurrentThreadId", "UInt")
    fgTid := DllCall("GetWindowThreadProcessId", "Ptr", fgw, "Ptr", 0)
    DllCall("AttachThreadInput", "UInt", myTid, "UInt", fgTid, "Int", 1)
    DllCall("SetForegroundWindow", "Ptr", hwnd)
    DllCall("BringWindowToTop", "Ptr", hwnd)
    DllCall("AttachThreadInput", "UInt", myTid, "UInt", fgTid, "Int", 0)
    ; -1 = HWND_TOPMOST, -2 = HWND_NOTOPMOST; 0x0003 = NOSIZE|NOMOVE
    DllCall("SetWindowPos", "Ptr", hwnd, "Ptr", -1, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x0003)
    Sleep, 60
    DllCall("SetWindowPos", "Ptr", hwnd, "Ptr", -2, "Int", 0, "Int", 0, "Int", 0, "Int", 0, "UInt", 0x0003)
}

; ==========================================
; ИНДИКАТОР СОСТОЯНИЯ СТАТИСТИКИ
; ==========================================
; Окно статистики раз в секунду обновляет alive.txt:
;   строка 1 — ok / err, строка 2 — время, строка 3 — жив ли OCR.
; Если файл не обновлялся дольше 5 секунд, считаем, что окно закрыто.
UpdateStatDot() {
    global
    f := DataDir . "\alive.txt"
    col := C_RED          ; красный — статистика не работает

    if (FileExist(f)) {
        FileRead, raw, %f%
        if (!ErrorLevel) {
            parts := StrSplit(raw, "`n")
            state := Trim(parts[1], " `r`t")
            stamp := Trim(parts[2], " `r`t") + 0
            ocr := Trim(parts[3], " `r`t")

            nowUtc := A_NowUTC
            EnvSub, nowUtc, 19700101000000, Seconds
            age := nowUtc - stamp

            if (age >= 0 and age < 6) {
                if (state = "err" or ocr != "1")
                    col := C_STAGE      ; оранжевый — работает с оговорками
                else
                    col := C_GREEN      ; зелёный — всё в порядке
            }
        }
    }

    ; Мигание убрано: постоянный цвет не отвлекает во время игры.
    shown := col

    if (shown != LastStatCol) {
        LastStatCol := shown
        ; Прозрачный Text не стирает прежний символ сам — очищаем вручную,
        ; иначе цвета накладываются друг на друга.
        GuiControl, OSD:, StatDot, % ""
        Gui, OSD: Font, s12 wBold c%shown%, Segoe UI
        GuiControl, OSD: Font, StatDot
        GuiControl, OSD:, StatDot, % Chr(9679)
    }
}


; ==========================================
; ЗАВЕРШЕНИЕ ВСЕГО, ЧТО ЗАПУСТИЛ БОТ
; ==========================================
; Три способа подряд — если один не сработает, добьёт следующий:
;   1) файл-сигнал STOP: питон видит его и закрывается сам, красиво;
;   2) убийство по PID — процессы, которые запускали именно мы;
;   3) поиск по командной строке — на случай, если что-то осталось
;      с прошлого запуска (например, бот падал и PID потерялся).
ShutdownAll() {
    global StatsPID
    global ManagerPID
    dir := A_ScriptDir . "\TrofPridi_data"
    if (!InStr(FileExist(dir), "D"))
        FileCreateDir, %dir%
    stop := dir . "\STOP"

    ; 1) Мягко: питон видит файл STOP и закрывается сам.
    FileAppend, stop, %stop%, UTF-8
    Sleep, 800

    ; 2) По PID — процессы, которые запускали именно мы.
    if (StatsPID) {
        Process, Close, %StatsPID%
        StatsPID := 0
    }
    if (ManagerPID) {                       ; №53: менеджер — тоже наш
        Process, Close, %ManagerPID%
        ManagerPID := 0
    }

    ; 3) Добиваем всё наше, что могло остаться с прошлых запусков.
    ;    ComObjGet может бросить исключение, поэтому ловим ошибку —
    ;    иначе скрипт не выйдет по F8 вообще.
    try {
        wmi := ComObjGet("winmgmts:")
        q := "SELECT ProcessId, CommandLine FROM Win32_Process"
           . " WHERE Name='pythonw.exe' OR Name='python.exe'"
           . " OR Name='pyw.exe'"
        for proc in wmi.ExecQuery(q) {
            cl := proc.CommandLine
            if (cl = "")
                continue
            if (InStr(cl, "stats.pyw") or InStr(cl, "ocr_watch.pyw")
                or InStr(cl, "stats_app.py") or InStr(cl, "ocr_watch.py")
                or InStr(cl, "manager.py")) {   ; №53: 'manager.py' как
                pid := proc.ProcessId           ; подстрока покрывает
                Process, Close, %pid%           ; и manager.pyw
            }
        }
    } catch e {
        ; WMI недоступен — довольствуемся первыми двумя способами
    }

    ; 4) №55: ОКНО МЕНЕДЖЕРА ДОБИВАЕМ ПО ЗАГОЛОВКУ. Видимое окно
    ;    принадлежит движку flet (часто НЕ тому процессу pythonw,
    ;    что мы запускали) — поэтому «менеджер выключался
    ;    не полностью». По заголовку находим реального владельца окна
    ;    и закрываем именно его.
    DetectHiddenWindows, On
    WinGet, mWinPid, PID, TrofPridi Manager
    DetectHiddenWindows, Off
    if (mWinPid)
        Process, Close, %mWinPid%

    Sleep, 200
    if (FileExist(stop))
        FileDelete, %stop%

    ; №53: гасим маяк для Менеджера — карточка сразу покажет
    ; «Не запущен», не дожидаясь, пока bot_state.ini протухнет.
    bsf := dir . "\bot_state.ini"
    if (FileExist(bsf))
        FileDelete, %bsf%
}


; ==========================================
; F6 — ОКНО СТАТИСТИКИ (Python)
; ==========================================
*F6::
    ToggleStats()
return

; F6 работает как выключатель: окно статистики видно — сворачивает,
; свёрнуто — разворачивает и поднимает поверх, не запущено — запускает.
ToggleStats() {
    if (!StatsAlive()) {
        LaunchStats()
        return
    }
    prev := A_DetectHiddenWindows
    DetectHiddenWindows, On
    hwnd := 0
    ; Ищем по заголовку: его задаёт stats_app.py -> self.title(...)
    WinGet, hwnd, ID, TrofPridi — статистика
    if (!hwnd)
        WinGet, hwnd, ID, TrofPridi
    DetectHiddenWindows, %prev%
    if (!hwnd) {
        ; окно живо, но найти его не удалось — старый файл-сигнал
        ShowStatsWindow()
        return
    }
    if (DllCall("IsIconic", "Ptr", hwnd))
        ShowStatsWindow()                          ; свёрнуто: развернуть
    else
        DllCall("ShowWindow", "Ptr", hwnd, "Int", 6)   ; видно: свернуть
}

; ==========================================
; F7 — ПРОВЕРКА МАСШТАБА (что видит бот сейчас)
; ==========================================
*F7::
    msg := "Экран: " A_ScreenWidth "x" A_ScreenHeight "   UIScale: " Round(UIScale, 4) "`n"
    msg .= "Шаблоны: " (NativeDir != "" ? "родные из " NativeDir : "базовые 1920x1080 + растяжение") "`n"
    msg .= "----------------------------------------`n"
    msg .= "Зачёт:   " ZachetStartX "," ZachetStartY " - " ZachetEndX "," ZachetEndY "`n"
    msg .= "Энергия: " EnergyStartX "," EnergyStartY " - " EnergyEndX "," EnergyEndY "`n"
    msg .= "Еда:     " FoodStartX "," FoodStartY " - " FoodEndX "," FoodEndY "`n"
    msg .= "Солнце:  " SunStartX "," SunStartY " - " SunEndX "," SunEndY "`n"
    msg .= "Ошибка:  " ErrorStartX "," ErrorStartY " - " ErrorEndX "," ErrorEndY "`n"
    msg .= "----------------------------------------`n"
    for i, f in ["catch.png", "zachet.png", "trophy.png", "ready_morning.png", "ready_day.png", "ready_night.png", "fish_morning.png", "fish_day.png", "fish_night.png"] {
        tol := InStr(f, "fish_") ? 70 : (InStr(f, "ready_") ? 90 : 80)
        o := ImgOpt(f, tol)
        ImageSearch, dx, dy, 0, 0, A_ScreenWidth, A_ScreenHeight, %o%
        st := (ErrorLevel = 0) ? ("НАЙДЕНО  X=" dx " Y=" dy) : (ErrorLevel = 1 ? "не видно" : "ОШИБКА ФАЙЛА")
        msg .= f "  ->  " st "`n"
    }
    MsgBox, 64, Проверка масштаба, %msg%
return

*F8::
    ReleaseAll()
    ShutdownAll()
    ExitApp
return

; ==========================================
; СКРЫТИЕ ОКНА ОТ СКРИНШОТОВ
; ==========================================
; ВАЖНО: метка стоит в самом конце файла. Раньше она была в середине,
; сразу после Gui Show — а метка обрывает автозапуск, и всё, что ниже
; (зоны поиска зачёта, полосок еды, ошибки садка), просто не
; вычислялось. Из-за этого DetectCatchKind искал плашку в пустой зоне
; 0,0-0,0 и любая рыба, включая трофей, считалась мелочью.
CaptureGuardTimer:
    ; №51: единых настроек больше нет — у каждого компонента свой INI
    ; в TrofPridi_data\configs\: защита и тема — stats.ini [ui],
    ; вариативность — bot_spin.ini [bot] (её пишет TrofPridi Manager).
    ; Нет файлов — защита включена по умолчанию (как было раньше).
    want := 1
    newTheme := ""
    cfgS := A_ScriptDir . "\TrofPridi_data\configs\stats.ini"
    cfgB := A_ScriptDir . "\TrofPridi_data\configs\bot_spin.ini"
    IniRead, cg, %cfgS%, ui, capture_guard, __M__
    if (cg = "0")
        want := 0
    IniRead, th, %cfgS%, ui, theme, __M__
    if (th != "__M__")
        newTheme := (th = "light") ? "light" : "dark"
    ; Тумблер вариативности подхватываем на лету — без перезапуска.
    IniRead, vr, %cfgB%, bot, variability, __M__
    if (vr != "__M__")
        Variability := (vr = "1") ? 1 : 0
    ; Запасной путь — старый общий settings.txt (до обновления №51).
    cfgFile := A_ScriptDir . "\TrofPridi_data\settings.txt"
    if FileExist(cfgFile) {
        FileRead, cfgText, %cfgFile%
        if (!ErrorLevel) {
            if (cg = "__M__" and RegExMatch(cfgText, "capture_guard\s*=\s*0"))
                want := 0
            if (vr = "__M__")
                Variability := RegExMatch(cfgText, "variability\s*=\s*1") ? 1 : 0
            if (th = "__M__")
                newTheme := RegExMatch(cfgText, "theme\s*=\s*light") ? "light" : "dark"
        }
    }
    if (newTheme != "" and newTheme != OsdTheme) {
        ApplyOsdTheme(newTheme)
        RebuildOSD()
    }
    if (want != CaptureGuard) {
        CaptureGuard := want
        HideFromCapture(hOSD, want)
        HideFromCapture(hGlass, want)   ; слой баров — та же защита
    }
return

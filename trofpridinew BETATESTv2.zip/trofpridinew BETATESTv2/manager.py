# -*- coding: utf-8 -*-
"""
TrofPridi Manager — окно менеджера на Flet (№53–57, по макету).

Слева — сайдбар с градиентом: помощники с точками состояния, раздел
«Приложение» (Статистика, Активация, Справка) и блок лицензии.
Справа — карточка помощника: статус-бар с «Запустить/Остановить»,
настройки полноширинными строками (пишутся в свой INI). Шапка окна —
своя, без системной рамки Windows. Нижняя строка — на всю ширину.

Справка — с краткой инструкцией по видам ловли (№55).

№57 — два важных дела:
  1) Окно менеджера теперь ПРИНАДЛЕЖИТ нашему процессу. Раньше это
     было окно движка flet (отдельный процесс), а защиту от
     скриншотов (SetWindowDisplayAffinity) Windows разрешает
     ставить только собственным окнам — поэтому меню бота и
     статистика прятались, а менеджер нет. Теперь интерфейс на том
     же Flet, но показывается внутри WebView2-окна, которое создаёт
     сам python-процесс, — защита наконец работает и на менеджере.
     Если WebView2 в системе нет — тихий откат на прежний режим.
  2) Кнопки «Запустить/Остановить» меняют вид по состоянию бота
     (активная подсвечивается, вторая гаснет), так всё видно без
     чтения надписей.

Вся рабочая логика — в manager_core.py, тут только рисование.
Запуск без консоли — через manager.pyw. Пакеты доустанавливаем сами
с окном прогресса и размером скачиваемых МБ (ensure_runtime()).

Связка процессов: запускаешь бота — поднимаются статистика и
менеджер; запускаешь менеджер — поднимается статистика; статистика
никого не трогает. F8 в боте гасит всё — включая это окно.
"""

import asyncio
import os
import subprocess
import sys
import threading
import time

import manager_core as core

ft = None          # flet подключается в ensure_runtime() (может доустановить)

# [web]: свой сервер интерфейса внутри WebView2-окна (основной режим
# №57). Пакет desktop-окна (запасной режим) flet доустановит сам
# на месте, если мы туда откатимся — заранее не качаем лишнее.
FLET_SPEC = "flet[web]>=0.25,<0.29"

# окно №57: хост интерфейса (WebView2) — окно принадлежит нам, поэтому
# на него действует защита от скриншотов
WEBVIEW_SPEC = "pywebview"
WEB_MODE = False      # True — рисуемся внутри нашего WebView2-окна
WEB_VIEW = None       # объект окна pywebview (для свернуть/закрыть/таск)
WEB_DPR = 1.0         # масштаб монитора для плавного перетаскивания

# палитра макета: тёмный сайдбар с градиентом, контент, синие кнопки
BG = "#161A1F"           # фон контента
NAV_TOP = "#20262F"      # сайдбар — верх градиента
NAV_BOT = "#191E24"      # сайдбар — низ градиента (плашка: NAV_BG)
NAV_BG = "#1D232B"
CARD = "#20262E"         # карточки
CARD_TOP = "#242C36"     # карточки — верх градиента
EDGE = "#2A323C"         # разделители и рамки
SELECT = "#25303E"       # выбранный пункт меню (тёплый синий оттенок)
FIELD_FILL = "#1B212A"   # поля ввода
FG = "#FFFFFF"
SOFT = "#9AA6B2"
DIM = "#6E7987"
BLUE = "#3D7FE0"         # «Запустить» — как в макете
BTN_DARK = "#2A323C"     # «Остановить» — тёмная, как в макете
ACCENT = "#00A2FF"
GREEN = "#00E6B8"
GOLD = "#FFB300"
RED = "#FF5555"

HELPER_ICONS = {
    "spin": ("SETMEAL", "PHISHING", "SPORTS_BAR", "STAR"),
    "feeder": ("ANCHOR", "SAILING", "WATER"),
    "marine": ("WAVES", "WATER", "SAILING"),
    "craft": ("HANDYMAN", "BUILD", "CONSTRUCTION"),
}

STATUS_COLOR = {"running": GREEN, "paused": GOLD, "stopped": DIM}


def _small_loader(title):
    """Мини-окно прогресса на голом tkinter (он всегда под рукой) —
    показываем, что ставится и сколько мегабайт грузится (№57).
    №58: окно — НЕ поверх всех и у правого нижнего угла: первый
    запуск докачивает пакеты прямо во время ловли, и перекрывать
    игру/красть клики этому окну категорически нельзя.
    Нет tkinter — вернём (None, молчаливый апдейтер)."""
    try:
        import tkinter as tk
        win = tk.Tk()
        win.title("TrofPridi Manager")
        w, h = 380, 130
        x = max(0, win.winfo_screenwidth() - w - 24)
        y = max(0, win.winfo_screenheight() - h - 90)
        win.geometry("%dx%d+%d+%d" % (w, h, x, y))
        win.configure(bg="#161A1F")
        tk.Label(win, text=title, fg="#FFFFFF", bg="#161A1F",
                 font=("Segoe UI", 11, "bold")).pack(
                     anchor="w", padx=16, pady=(16, 4))
        info = tk.Label(win, text="Подключение…", fg="#9AA6B2",
                        bg="#161A1F", font=("Segoe UI", 10),
                        justify="left", anchor="w")
        info.pack(anchor="w", padx=16, fill="x")
        win.update()

        def upd(text):
            try:
                info.config(text=text)
                win.update()
            except Exception:
                pass

        def done():
            try:
                win.destroy()
            except Exception:
                pass
        return upd, done
    except Exception:
        return (lambda _text: None), (lambda: None)


def _pip_install_with_sizes(specs, upd):
    """pip install с живым отчётом: имя пакета и суммарно скачанные
    мегабайты (строчки «Downloading имя (N.N MB)» парсим на лету)."""
    import re
    rx = re.compile(rb"Downloading\s+(\S+?)\s*\(([\d.,]+)\s*"
                    rb"(kB|KB|MB|GB|B)\)")
    unit = {"B": 1 / 1048576, "KB": 1 / 1024, "MB": 1.0, "GB": 1024.0}
    total = [0.0]
    core.boot_log("pip install: %s" % " ".join(specs))
    try:
        proc = subprocess.Popen(
            [sys.executable, "-m", "pip", "install",
             "--disable-pip-version-check", "--no-input",
             "--progress-bar", "off"] + list(specs),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception as e:
        core.boot_log("pip не стартовал: %s" % e)
        return 1
    try:
        for raw in iter(proc.stdout.readline, b""):
            m = rx.search(raw)
            if not m:
                continue
            name = m.group(1).decode("utf-8", "ignore")
            name = name.rsplit("/", 1)[-1]
            pkg = name.split("-")[0].replace("_", "-")
            try:
                total[0] += float(m.group(2).replace(",", ".")) \
                    * unit.get(m.group(3).decode().upper(), 1.0)
            except Exception:
                pass
            upd("Пакет: %s\nСкачано: %.1f МБ" % (pkg, total[0]))
        proc.stdout.close()
    except Exception:
        pass
    try:
        rc = proc.wait()
    except Exception:
        rc = 1
    core.boot_log("pip rc=%s, скачано %.1f МБ" % (rc, total[0]))
    return rc


def ensure_runtime():
    """Все пакеты, нужные менеджеру (№57): flet (+ веб-слой для нашего
    собственного окна), fastapi/uvicorn, pywebview (+pythonnet на
    Windows — под ним живёт WebView2). Чего нет — доставляем сами,
    показывая размер скачиваемого. Да — все зависимости ставятся
    автоматически, ничего руками качать не надо.

    Ветка flet 0.25–0.28: на ней проверен весь API приложения.
    """
    global ft
    need = []
    try:
        import flet as _f
        ft = _f
    except Exception:
        need.append("flet")
    for mod in ("flet_web", "fastapi", "uvicorn"):
        try:
            __import__(mod)
        except Exception:
            need.append(mod)
    if os.name == "nt":
        for mod in ("webview", "clr"):
            try:
                __import__(mod)
            except Exception:
                need.append(mod)
    if not need:
        return True
    core.boot_log("не хватает пакетов: %s — ставим" % ", ".join(need))
    upd, done = _small_loader("Первая настройка менеджера —\n"
                              "догружаем компоненты:")
    specs = [FLET_SPEC]
    if os.name == "nt":
        specs.append(WEBVIEW_SPEC)
    rc = _pip_install_with_sizes(specs, upd)
    if rc == 0:
        upd("Установка завершена — открываем менеджер…")
        import importlib
        importlib.invalidate_caches()
        try:
            import flet as _f
            ft = _f
        except Exception as e:
            core.boot_log("flet не импортируется после установки: %s" % e)
            rc = 1
    done()
    core.boot_log("ensure_runtime -> %s" % ("ok" if rc == 0 else "FAIL"))
    return rc == 0 and ft is not None


def _webview2_ready():
    """True, когда можем показать своё окно (№57): Windows, пакет
    pywebview с движком и установленный WebView2 Runtime. Иначе —
    тихий откат на прежний режим с окном движка flet."""
    if os.name != "nt":
        return False
    try:
        import webview  # noqa: F401
        import clr      # noqa: F401 (pythonnet — под ним WebView2)
    except Exception:
        return False
    try:
        import winreg
        guid = (r"Microsoft\EdgeUpdate\Clients"
                r"\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}")
        for root in (winreg.HKEY_LOCAL_MACHINE,
                     winreg.HKEY_CURRENT_USER):
            for pref in (r"SOFTWARE\WOW6432Node\\", r"SOFTWARE\\"):
                try:
                    k = winreg.OpenKey(root, pref + guid)
                    pv, _t = winreg.QueryValueEx(k, "pv")
                    if pv and pv != "0.0.0.0":
                        return True
                except OSError:
                    continue
    except Exception:
        pass
    return False


def _run_webview_host():
    """Окно менеджера внутри WebView2, принадлежащее НАШЕМУ процессу
    (№57): интерфейс — тот же Flet, но поднятый как локальный
    сервер; страницу показывает WebView2-окно python-процесса. Только
    так Windows разрешает прятать окно от скриншотов — защита можно
    ставить лишь на собственные окна, а flet-desktop рисует окно
    своим отдельным движком (поэтому раньше не прятался)."""
    global WEB_MODE, WEB_VIEW, WEB_DPR
    import socket
    import webview
    import uvicorn

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    assets = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "assets")
    asgi = ft.app(target=main, export_asgi_app=True,
                  assets_dir=assets)
    server = uvicorn.Server(uvicorn.Config(
        asgi, host="127.0.0.1", port=port, log_level="error",
        access_log=False))
    threading.Thread(target=server.run, daemon=True).start()
    up = False
    for _i in range(100):                        # ждём подъём сервера
        time.sleep(0.1)
        try:
            c = socket.create_connection(("127.0.0.1", port), 0.25)
            c.close()
            up = True
            break
        except Exception:
            pass
    if not up:
        raise RuntimeError("локальный сервер интерфейса не поднялся")

    WEB_MODE = True
    core.boot_log("webview: создаём окно (порт %d)" % port)
    win = webview.create_window(
        "TrofPridi Manager", "http://127.0.0.1:%d/" % port,
        width=1000, height=700, min_size=(920, 630),
        # №74: easy_drag=True — плюс штатный механизм драга pywebview
        # (наш жест по шапке остаётся вторым независимым способом)
        frameless=True, easy_drag=True, background_color="#161A1F",
        text_select=False, zoomable=False)
    WEB_VIEW = win

    def _remember_scale(_w=win):
        global WEB_DPR
        try:
            v = _w.evaluate_js("window.devicePixelRatio || 1")
            WEB_DPR = float(v) if v else 1.0
        except Exception:
            pass

    def _mark_ok(_w=win):
        # №58: маркер «своё окно точно поднялось» ставим, только когда
        # окно реально показалось и прожило пару секунд. Если процесс
        # умрёт где-то раньше (тихое падение движка), маркер так и
        # останется «try» — и следующий запуск сам откатится на
        # прежний режим, не мучая человека мёртвым запуском второй раз.
        time.sleep(2)
        try:
            core.wv_state_set("ok")
            core.boot_log("webview: окно показано, режим закреплён")
        except Exception:
            pass

    try:
        win.events.shown += lambda: (
            _remember_scale(),
            threading.Thread(target=_mark_ok, daemon=True).start())
    except Exception:
        pass

    # значок окна в таскбаре/alt+tab — родной у движка (картинка
    # python — это он и есть, когда иконку не передали), тикер с
    # WM_SETICON подстраховывает (№59)
    kwargs = {"debug": False}
    ico = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       "assets", "manager_icon.ico")
    if os.path.isfile(ico):
        kwargs["icon"] = ico
    try:
        webview.start(**kwargs)
    except TypeError:
        kwargs.pop("icon", None)
        webview.start(**kwargs)
    core.boot_log("webview: окно закрыто")
    core.wv_state_set("ok")  # нормальное закрытие — режим рабочий
    try:
        server.should_exit = True
    except Exception:
        pass


def _ico(*names, default="CIRCLE"):
    """Первый существующий значок (в разных flet имена гуляют)."""
    box = getattr(ft, "Icons", None) or getattr(ft, "icons", None)
    for n in names:
        ic = getattr(box, n, None)
        if ic is not None:
            return ic
    return getattr(box, default)


def _dot(size=8, color=DIM):
    """Круглая точка-индикатор (статусы в меню и на панелях)."""
    return ft.Container(width=size, height=size,
                        border_radius=ft.border_radius.all(size / 2),
                        bgcolor=color)


def _grad(c1, c2, begin=None, end=None):
    """Мягкий вертикальный градиент (№55). Старый flet — вернёт None,
    тогда остаётся плоский цвет."""
    try:
        al = ft.alignment
        return ft.LinearGradient(begin=begin or al.top_center,
                                 end=end or al.bottom_center,
                                 colors=[c1, c2])
    except Exception:
        return None


def _selectable(txt, size=13, color=FG):
    """Текст, который можно выделить и скопировать (HWID и т.п.)."""
    st = getattr(ft, "SelectableText", None)
    if st is not None:
        try:
            return st(txt, size=size, color=color)
        except Exception:
            pass
    try:
        return ft.Text(txt, size=size, color=color, selectable=True)
    except Exception:
        pass
    sa = getattr(ft, "SelectionArea", None)
    body = ft.Text(txt, size=size, color=color)
    if sa is not None:
        try:
            return sa(body)
        except Exception:
            pass
    return body


def _switch(value=False, disabled=False, on_change=None):
    """Компактный тумблер (№54): родной здоровенький, ужимаем."""
    try:
        return ft.Switch(value=value, disabled=disabled,
                         on_change=on_change, scale=0.78)
    except Exception:
        return ft.Switch(value=value, disabled=disabled,
                         on_change=on_change)


def _round_style(radius=10, txt=None):
    """Кнопки со скруглением, как в макете (m3-стадия — через style).
    №60: крупица текста кнопок ужата — 14 px был здоровым."""
    try:
        kw = {"shape": ft.RoundedRectangleBorder(radius=radius)}
        if txt:
            kw["text_style"] = ft.TextStyle(size=txt)
        return ft.ButtonStyle(**kw)
    except Exception:
        return None


def _style_field(ctl, radius=8):
    """Поля ввода и списки — в едином виде (№55): чуть скруглённые,
    с заливкой и аккуратной рамкой, в фокусе — фирменный синий."""
    for k, v in (("filled", True), ("fill_color", FIELD_FILL),
                 ("border_color", EDGE), ("focused_border_color", ACCENT),
                 ("border_width", 1), ("focused_border_width", 1),
                 ("border_radius", radius),
                 ("text_size", 12.5), ("dense", True)):
        try:
            setattr(ctl, k, v)
        except Exception:
            pass
    try:
        ctl.content_padding = ft.padding.symmetric(horizontal=12,
                                                   vertical=10)
    except Exception:
        pass
    return ctl


class ManagerApp:
    def __init__(self, page):
        self.page = page
        self.view_key = "spin"          # что показано справа
        self.guide_sub = "main"         # main/how/spin — разделы справки
        self.nav = {}                   # key -> dict(c, icon, text, dot)
        self.live = {}                  # живые контролы текущего вида
        self.lic_dot = None
        self.lic_text = None
        self.status_line = None
        self.frameless = False
        self._note = ""
        self._icon_done = False
        self._icon_tries = 0
        self._hwnd = None
        self._guard_state = None
        self._glow_items = []           # «бегающие» рамки плашек (№57)
        self._drag_fx = 0.0             # дробные остатки перетаскивания
        self._drag_fy = 0.0             # (№57, окно WebView2)
        core.ensure_default_inis()      # INI на месте (миграция)
        core.touch_manager_alive()      # бот видит: менеджер тоже жив

    # -------------------------------------------------- примитивы
    def note(self, text):
        """Однострочная обратная связь вместо системных тостов —
        переживёт любую версию flet."""
        self._note = "%s · %s" % (time.strftime("%H:%M:%S"), text)
        if self.status_line is not None:
            try:
                self.status_line.value = self._note
                self.page.update()
            except Exception:
                pass

    def window_setup(self):
        pg = self.page
        self.frameless = False
        try:
            pg.title = "TrofPridi Manager"
            pg.theme_mode = "dark"
        except Exception:
            pass
        pg.bgcolor = BG
        try:
            pg.padding = 0
        except Exception:
            pass
        if WEB_MODE:
            # №57: окно — наш WebView2, размеры задаёт host; системной
            # шапки нет (frameless), свою рисуем сами
            self.frameless = True
            return
        # окно по макету (№56): всё помещается, без системной шапки
        try:
            win = getattr(pg, "window", None)
            if win is not None:
                win.width, win.height = 960, 660
                win.min_width, win.min_height = 880, 600
                # №54: системную шапку Windows убираем — рисуем свою
                try:
                    win.frameless = True
                    self.frameless = True
                except Exception:
                    try:
                        win.title_bar_hidden = True
                        self.frameless = True
                    except Exception:
                        pass
                # значок окна (таскбар/alt+tab подстрахуем WinAPI ниже)
                for cand in ("manager_icon.ico", "manager_icon.png"):
                    try:
                        win.icon = cand
                        break
                    except Exception:
                        continue
                return
            pg.window_width, pg.window_height = 960, 660
            pg.window_min_width, pg.window_min_height = 880, 600
        except Exception:
            pass

    def _find_hwnd(self):
        """HWND нашего окна (владельцем может быть движок flet — но
        заголовок у окна один, FindWindow по нему надёшен)."""
        if self._hwnd:
            return self._hwnd
        if os.name != "nt":
            return None
        try:
            import ctypes
            from ctypes import wintypes
            u32 = ctypes.windll.user32
            # №60: без типов 64-битные дескрипторы Windows резала
            # до 32 бит — отсюда иконка таскбара и «промахивалась».
            u32.FindWindowW.argtypes = [wintypes.LPCWSTR,
                                        wintypes.LPCWSTR]
            u32.FindWindowW.restype = ctypes.c_void_p
            hwnd = ctypes.windll.user32.FindWindowW(None,
                                                    "TrofPridi Manager")
            if hwnd:
                self._hwnd = hwnd
        except Exception:
            hwnd = None
        return self._hwnd

    def _apply_taskbar_icon(self):
        """Значок окна в таскбаре/alt+tab через WM_SETICON (№54).

        True — сделано или некритично; False — окно ещё не появилось,
        спросим на следующем такте тикера.
        """
        if os.name != "nt":
            return True
        try:
            import ctypes
            from ctypes import wintypes
            ico = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                               "assets", "manager_icon.ico")
            if not os.path.isfile(ico):
                return True
            hwnd = self._find_hwnd()
            if not hwnd:
                return False
            u32 = ctypes.windll.user32
            u32.LoadImageW.argtypes = [ctypes.c_void_p, wintypes.LPCWSTR,
                                       wintypes.UINT, ctypes.c_int,
                                       ctypes.c_int, wintypes.UINT]
            u32.LoadImageW.restype = ctypes.c_void_p
            u32.SendMessageW.argtypes = [ctypes.c_void_p, wintypes.UINT,
                                         ctypes.c_size_t,
                                         ctypes.c_void_p]
            u32.SendMessageW.restype = ctypes.c_ssize_t
            # WM_SETICON: ICON_BIG=1, ICON_SMALL=0; LR_LOADFROMFILE=0x10
            for which, size in ((1, 32), (0, 16)):
                h = u32.LoadImageW(0, ico, 1, size, size, 0x10)
                if h:
                    u32.SendMessageW(hwnd, 0x80, which, h)
            return True
        except Exception:
            return True

    def _apply_capture_guard(self):
        """Прячем Менеджер от скриншотов по общему тумблеру (№55–57):
        stats.ini [ui] capture_guard — как меню бота и статистика.

        Окно на мониторе видно как обычно, но в кадры снимков и
        захвата экрана Windows его не включает. №57: со своим окном
        (WebView2 в нашем процессе) это наконец работает — раньше
        окном владел движок flet, а affinity Windows разрешает
        ставить только собственному окну. Ставим ВСЕМ окнам с нашим
        заголовком и проверяем результат чтением назад: пока не
        встало — тикаем дальше, «промазать и забыть» тут нельзя.
        """
        if os.name != "nt":
            return
        try:
            want = (core.read_value("stats.ini", "ui", "capture_guard",
                                    "1") or "1").strip() != "0"
        except Exception:
            want = True
        if want == self._guard_state:
            return                              # уже встало
        try:
            import ctypes
            from ctypes import wintypes
            u32 = ctypes.windll.user32
            u32.EnumWindows.argtypes = [ctypes.c_void_p,
                                        ctypes.c_void_p]
            u32.GetWindowTextW.argtypes = [wintypes.HWND,
                                           wintypes.LPWSTR,
                                           ctypes.c_int]
            u32.SetWindowDisplayAffinity.argtypes = [wintypes.HWND,
                                                     wintypes.DWORD]
            u32.SetWindowDisplayAffinity.restype = wintypes.BOOL
            u32.GetWindowDisplayAffinity.argtypes = [wintypes.HWND,
                ctypes.POINTER(wintypes.DWORD)]
            u32.GetWindowDisplayAffinity.restype = wintypes.BOOL

            targets = []
            WNDENUM = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND,
                                         wintypes.LPARAM)

            def _enum(hwnd, _lp):
                buf = ctypes.create_unicode_buffer(64)
                u32.GetWindowTextW(hwnd, buf, 64)
                if buf.value == "TrofPridi Manager":
                    targets.append(hwnd)
                return True

            u32.EnumWindows(WNDENUM(_enum), 0)
            if not targets:
                return                          # окно ещё не нарисовалось
            ok_all = True
            for hwnd in targets:
                cur = wintypes.DWORD(0)
                if not self._apply_affinity_one(u32, hwnd, want, cur):
                    ok_all = False
            self._guard_tries = getattr(self, "_guard_tries", 0) + 1
            if ok_all or self._guard_tries > 25:
                self._guard_state = want
                self._guard_tries = 0
        except Exception:
            # не критично для окна: тихо считаем состояние применённым,
            # чтобы не дёргать WinAPI каждый такт в бою с исключением
            self._guard_state = want

    @staticmethod
    def _apply_affinity_one(u32, hwnd, want, cur):
        """Ставит affinity одному HWND; True — стоит как надо (с чтением
        назад), False — надо дожать на следующем такте."""
        import ctypes
        if not want:
            u32.SetWindowDisplayAffinity(hwnd, 0x00)          # снять
        else:
            if not u32.SetWindowDisplayAffinity(hwnd, 0x11):  # из кадра
                u32.SetWindowDisplayAffinity(hwnd, 0x01)      # чёрным
        try:
            if u32.GetWindowDisplayAffinity(hwnd,
                                            ctypes.byref(cur)):
                got = cur.value
                if want:
                    return got in (0x01, 0x11)
                return got == 0x00
        except Exception:
            pass
        return False

    def _mini_label(self, txt):
        """Мелкая секция-заголовок капсом, как «НАСТРОЙКИ» в макете."""
        return ft.Text(txt, size=10.5, color=DIM,
                       weight=ft.FontWeight.W_600)

    # -------------------------------------------------- своя шапка
    def _build_titlebar(self):
        """Компактная шапка вместо системной: значок, имя, перетаскивание,
        свернуть/закрыть (№54)."""
        try:
            icon_img = ft.Image(src="manager_icon.png", width=18,
                                height=18, fit=ft.ImageFit.CONTAIN)
        except Exception:
            icon_img = ft.Icon(_ico("SETMEAL", "STAR"), size=16,
                               color=ACCENT)

        def minimize(_e):
            try:
                if WEB_MODE and WEB_VIEW is not None:
                    WEB_VIEW.minimize()     # №57: своё окно, свой метод
                else:
                    self.page.window.minimized = True
            except Exception:
                pass

        def close(_e):
            try:
                if WEB_MODE and WEB_VIEW is not None:
                    WEB_VIEW.destroy()      # закроет окно и сервер
                else:
                    self.page.window.close()
            except Exception:
                pass

        def _btn(ic, tip, fn, hover=None):
            kw = dict(icon_size=14, tooltip=tip, on_click=fn,
                      icon_color=SOFT)
            if hover:
                try:
                    return ft.IconButton(ic, hover_color=hover, **kw)
                except Exception:
                    pass
            return ft.IconButton(ic, **kw)

        row = ft.Row([
            ft.Container(width=12),
            icon_img,
            ft.Container(width=8),
            ft.Text("TrofPridi Manager", size=12.5, color=SOFT,
                    weight=ft.FontWeight.W_600),
            ft.Container(width=8),
            ft.Text(core.APP_VERSION, size=10.5, color=DIM),
            self._drag_area(),
            _btn(_ico("REMOVE", "HORIZONTAL_LINE"), "Свернуть",
                 minimize),
            _btn(_ico("CLOSE"), "Закрыть", close,
                 hover="#33FF5555"),
            ft.Container(width=8),
        ], spacing=0, vertical_alignment="center")
        bar = dict(height=38, content=row,
                   border=ft.border.only(bottom=ft.BorderSide(1, EDGE)))
        g = _grad(NAV_TOP, NAV_BG)
        if g is not None:
            bar["gradient"] = g
        else:
            bar["bgcolor"] = NAV_BG
        bar_c = ft.Container(**bar)
        # №74: тянем ЗА ВСЮ шапку (раньше жест был только на пустом
        # середке — за значок/имя не хваталось, искали «ту полоску»)
        # №75: БЕЗ expand=True! В корневой колонке рядом ещё
        # expand-элемент main_row — с expand шапка жрала ПОЛОВИНУ
        # окна, и весь интерфейс «съезжал» вниз (скрин от юзера).
        if WEB_MODE:
            try:
                return ft.GestureDetector(
                    content=bar_c,
                    on_pan_start=lambda _e: self._native_drag_start())
            except Exception:
                pass
        return bar_c

    def _drag_area(self):
        """Полоса перетаскивания в шапке. У движка flet есть родная
        WindowDragArea; в своём WebView2-окне двигаем через
        WM_NCHITTEST (см. _patch_native_drag): Windows сама ведёт
        окно — ни рывков, ни «плюсика» вместо курсора (№59)."""
        if not WEB_MODE:
            return ft.WindowDragArea(
                content=ft.Container(expand=True, height=38),
                expand=True, maximizable=False)
        # №73: патч WM_NCHITTEST (№59) промахивался — мышь в области
        # содержимого ловит дочернее окно Chromium, а не наше хост-
        # окно, и шапка «не двигалась». Классика фреймлесса:
        # жест по шапке → ReleaseCapture + SC_MOVE(HTCAPTION) — окно
        # ведёт сама Windows, мышь можно хоть через монитор носить.
        area = ft.Container(expand=True, height=38)
        try:
            return ft.GestureDetector(
                content=area, expand=True,
                on_pan_start=lambda _e: self._native_drag_start())
        except Exception:
            return area

    def _native_drag_start(self):
        """Начать таскание окна за шапку (своё WebView2-окно) —

        №76, третий способ, грубый и потому надёжный: НИКАКОЙ магии
        Windows (SC_MOVE из №74 у юзера так и не сработал), мы сами
        в потоке следим за курсором через GetCursorPos и двигаем окно
        SetWindowPos, пока зажата ЛКМ. Срабатывает в любом случае,
        лишь бы жест-обработчик flet вообще услышал мышь."""
        if os.name != "nt":
            return
        try:
            hwnd = self._find_hwnd()
            if not hwnd:
                return
            self._follow_mouse_drag(hwnd)
        except Exception:
            pass

    def _follow_mouse_drag(self, hwnd):
        """Поток-«таскалка»: запоминаем точку захвата и ведём окно
        за курсором ~125 раз в секунду, пока зажата левая кнопка."""
        import ctypes
        from ctypes import wintypes
        u32 = ctypes.windll.user32
        u32.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
        u32.GetWindowRect.argtypes = [ctypes.c_void_p,
                                      ctypes.POINTER(wintypes.RECT)]
        u32.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                     ctypes.c_int, ctypes.c_int,
                                     ctypes.c_int, ctypes.c_int,
                                     wintypes.UINT]
        u32.GetAsyncKeyState.restype = ctypes.c_short

        def _go():
            try:
                pt0 = wintypes.POINT()
                rc = wintypes.RECT()
                u32.GetCursorPos(ctypes.byref(pt0))
                u32.GetWindowRect(ctypes.c_void_p(hwnd),
                                  ctypes.byref(rc))
                x0, y0 = rc.left, rc.top
                t_end = time.time() + 30          # страховка от вечного цикла
                # SWP_NOSIZE | SWP_NOACTIVATE: размер тот же, фокус не крадём
                while time.time() < t_end:
                    if not (u32.GetAsyncKeyState(1) & 0x8000):
                        break                     # ЛКМ отпущена — стоп
                    pt = wintypes.POINT()
                    u32.GetCursorPos(ctypes.byref(pt))
                    u32.SetWindowPos(ctypes.c_void_p(hwnd), None,
                                     x0 + pt.x - pt0.x, y0 + pt.y - pt0.y,
                                     0, 0, 0x0001 | 0x0010)
                    time.sleep(0.008)
            except Exception:
                pass
        threading.Thread(target=_go, daemon=True).start()

    def _patch_native_drag(self):
        """Подменяем hit-test своего окна (№59): верхние ~38 css-px
        шапки считаются системным заголовком (HTCAPTION) — после
        этого окно таскает сама Windows, родным плавным циклом.
        Жест-драг из №57 подёргивался: каждый move() шёл через
        очередь потоков движка. Края окна не трогаем — родной ресайз
        pywebview работает, вернув из старого обработчика свой ответ."""
        if os.name != "nt" or not WEB_MODE:
            return True
        if getattr(self, "_drag_ready", False):
            return True
        hwnd = self._find_hwnd()
        if not hwnd:
            return False                    # окно ещё не появилось
        self._drag_ready = True             # попытка одна, не спамим
        try:
            import ctypes
            from ctypes import wintypes
            u32 = ctypes.windll.user32
            u32.GetClientRect.argtypes = [wintypes.HWND,
                                          ctypes.POINTER(wintypes.RECT)]
            u32.ScreenToClient.argtypes = [wintypes.HWND,
                                           ctypes.POINTER(wintypes.POINT)]
            u32.SetWindowLongPtrW.argtypes = [wintypes.HWND,
                                              ctypes.c_int,
                                              ctypes.c_void_p]
            u32.SetWindowLongPtrW.restype = ctypes.c_ssize_t
            u32.CallWindowProcW.argtypes = [ctypes.c_void_p,
                                            wintypes.HWND,
                                            wintypes.UINT,
                                            ctypes.c_size_t,
                                            ctypes.c_ssize_t]
            u32.CallWindowProcW.restype = ctypes.c_ssize_t
            state = {"old": None}
            WNDPROC = ctypes.WINFUNCTYPE(
                ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT,
                ctypes.c_size_t, ctypes.c_ssize_t)

            def _proc(h, msg, wp, lp):
                if msg == 0x0084:           # WM_NCHITTEST
                    res = u32.CallWindowProcW(state["old"], h, msg,
                                              wp, lp)
                    if res == 1:            # HTCLIENT — решим сами
                        rc = wintypes.RECT()
                        u32.GetClientRect(h, ctypes.byref(rc))
                        cw = max(1, rc.right - rc.left)
                        ch = max(1, rc.bottom - rc.top)
                        sx = ctypes.c_short(lp & 0xFFFF).value
                        sy = ctypes.c_short((lp >> 16) & 0xFFFF).value
                        pt = wintypes.POINT(sx, sy)
                        u32.ScreenToClient(h, ctypes.byref(pt))
                        # шапка ~38 css-px при окне 1000x700; справа
                        # ~100 css-px живут кнопки свернуть/закрыть
                        if (0 <= pt.y <= ch * 38 // 700
                                and 0 <= pt.x < cw * (1000 - 100)
                                // 1000):
                            return 2        # HTCAPTION
                    return res
                return u32.CallWindowProcW(state["old"], h, msg, wp,
                                           lp)

            proc = WNDPROC(_proc)
            prev = u32.SetWindowLongPtrW(hwnd, -4, proc)  # GWLP_WNDPROC
            if prev:
                state["old"] = prev
                self._wndproc_refs = (proc, state)   # живут вместе с нами
        except Exception:
            pass
        return True

    # -------------------------------------------------- сайдбар
    def _nav_item(self, key, title, icon_names, with_dot=False):
        dot = _dot(7, GOLD) if with_dot else None
        ic = ft.Icon(_ico(*icon_names), size=17, color=SOFT)
        tx = ft.Text(title, size=13, color=SOFT, expand=True)
        # №55: у выбранного пункта — цветная полоска слева (как в примере)
        strip = ft.Container(width=3, height=17,
                             border_radius=ft.border_radius.all(2),
                             bgcolor=None)
        controls = [strip, ic, tx] + ([dot] if dot is not None else [])
        c = ft.Container(
            content=ft.Row(controls, spacing=10,
                           vertical_alignment="center"),
            padding=ft.padding.symmetric(horizontal=10, vertical=9),
            border_radius=ft.border_radius.all(8),
            margin=ft.margin.symmetric(horizontal=8, vertical=1),
            on_click=lambda _e, k=key: self.select(k))
        self.nav[key] = {"c": c, "icon": ic, "text": tx, "dot": dot,
                         "strip": strip}

    def _section_label(self, txt):
        return ft.Container(
            padding=ft.padding.only(left=18, top=14, right=18, bottom=6),
            content=self._mini_label(txt))

    def _build_sidebar(self):
        items = [ft.Container(
            padding=ft.padding.only(left=18, top=16, right=18, bottom=14),
            content=ft.Column([
                ft.Text("TrofPridi Manager", size=17,
                        weight=ft.FontWeight.W_600, color=FG),
                ft.Text("Помощники рыбака · %s" % core.APP_VERSION,
                        size=11, color=DIM),
            ], spacing=2)),
            ft.Divider(height=1, thickness=1, color=EDGE),
            self._section_label("ПОМОЩНИКИ")]
        for h in core.HELPERS:
            self._nav_item(h["key"], h["title"],
                           HELPER_ICONS.get(h["key"], ("STAR",)),
                           with_dot=True)
            items.append(self.nav[h["key"]]["c"])
        items.append(self._section_label("ПРИЛОЖЕНИЕ"))
        self._nav_item("stats", "Статистика", ("BAR_CHART", "SHOW_CHART"))
        items.append(self.nav["stats"]["c"])
        self._nav_item("act", "Активация", ("LOCK", "VPN_KEY", "KEY"))
        items.append(self.nav["act"]["c"])
        self._nav_item("guide", "Справка", ("MENU_BOOK", "HELP", "BOOK"))
        items.append(self.nav["guide"]["c"])
        items.append(ft.Container(expand=True))
        items.append(ft.Divider(height=1, thickness=1, color=EDGE))
        self.lic_dot = _dot(8, RED)
        self.lic_text = ft.Text("Лицензия…", size=11.5, color=RED)
        items.append(ft.Container(
            padding=ft.padding.only(left=18, top=12, right=18, bottom=14),
            content=ft.Column([
                ft.Row([self.lic_dot, self.lic_text], spacing=8,
                       vertical_alignment="center"),
                ft.Text("Подписка и уведомления —\nв разделе «Активация»",
                        size=10, color=DIM),
            ], spacing=6)))
        bar = dict(width=248,
                   border=ft.border.only(right=ft.BorderSide(1, EDGE)),
                   content=ft.Column(items, spacing=0, expand=True))
        g = _grad(NAV_TOP, NAV_BOT)
        if g is not None:
            bar["gradient"] = g
        else:
            bar["bgcolor"] = NAV_BG
        return ft.Container(**bar)

    def _paint_selection(self):
        for k, it in self.nav.items():
            sel = (k == self.view_key)
            try:
                it["c"].bgcolor = SELECT if sel else None
                it["icon"].color = FG if sel else SOFT
                it["text"].color = FG if sel else SOFT
                it["strip"].bgcolor = ACCENT if sel else None
            except Exception:
                pass

    def select(self, key):
        self.view_key = key
        if key == "guide":
            self.guide_sub = "main"
        self.body.content = self._build_view(key)
        self._paint_selection()
        self._apply_status(*self._cached_status())
        try:
            self.page.update()
        except Exception:
            pass

    def _guide(self, sub):
        """Внутренняя навигация справки: main/how/вид ловли (№55)."""
        self.guide_sub = sub
        self.body.content = self._build_view("guide")
        try:
            self.page.update()
        except Exception:
            pass

    # -------------------------------------------------- вьюхи
    def _build_view(self, key):
        self.live = {}                  # старые ссылки мертвы вместе с видом
        self._glow_items = []           # и «змейки» старого вида (№57)
        # №72: подписка истекла — все вкладки ведут на активацию
        try:
            if (core.license_state()[0] == "expired"
                    and key != "act"):
                self.note("Подписка истекла — введи ключ "
                          "на вкладке «Активация»")
                key = "act"
        except Exception:
            pass
        if key in core.HELPER_BY_KEY:
            return self._build_helper(core.HELPER_BY_KEY[key])
        if key == "stats":
            return self._build_stats()
        if key == "guide":
            return self._build_guide()
        return self._build_activation()

    def _field_control(self, helper, section, k, typ, val, avail, cur):
        """Контрол настройки: тумблер, список, число или текст."""
        ini = helper["ini"]

        def save(s, kk, v):
            try:
                core.update_values(ini, {(s, kk): v})
                self.note("Сохранено: %s" % ini)
            except Exception as e:
                self.note("Не удалось сохранить: %s" % e)

        def save_int(s, kk, raw, ctl):
            try:
                iv = int(str(raw).strip())
            except ValueError:
                self.note("Нужно число — значение не изменилось")
                try:
                    # свежее значение из файла, а не снимок при открытии
                    ctl.value = str(core.read_value(ini, s, kk, "0"))
                    self.page.update()
                except Exception:
                    pass
                return
            save(s, kk, iv)

        if typ == "bool":
            return _switch(value=bool(val), disabled=not avail,
                           on_change=(lambda e, s=section, kk=k:
                                      save(s, kk, bool(e.control.value))))

        if isinstance(typ, tuple) and typ and typ[0] == "choice":
            # выбор из списка (№54, №59). Родной Dropdown рисует себя
            # сам и норовит быть толще соседних полей — заменили на
            # аккуратную кнопку-выбор со всплывающим меню: высота
            # ровно как у числовых полей, границы нас слушаются.
            try:
                titles = dict(typ[1])
                lbl = ft.Text(titles.get(str(val), str(val)),
                              size=12.5, color=FG, expand=True)

                def pick(ov, ot, s=section, kk=k):
                    save(s, kk, ov)
                    lbl.value = ot
                    lbl.color = FG
                    try:
                        self.page.update()
                    except Exception:
                        pass

                items = []
                for ov, ot in typ[1]:
                    items.append(ft.PopupMenuItem(
                        text=ot,
                        on_click=(lambda _e, v=ov, t=ot: pick(v, t))))
                pm = ft.PopupMenuButton(
                    items=items, disabled=not avail,
                    tooltip="Выбрать вид проводки",   # №60: у дефолта
                    content=ft.Row([                  # был англ. текст
                        lbl,
                        ft.Icon(_ico("KEYBOARD_ARROW_DOWN",
                                     "ARROW_DROP_DOWN"),
                                size=15, color=SOFT),
                    ], spacing=6, vertical_alignment="center"))
                return ft.Container(
                    width=230, height=32, bgcolor=FIELD_FILL,
                    border=ft.border.all(1, EDGE),
                    border_radius=ft.border_radius.all(8),
                    padding=ft.padding.only(left=10, right=8),
                    content=pm)
            except Exception:
                pass            # старый flet — тихий откат на текст

        if typ == "int":
            tf = ft.TextField(value=str(val), disabled=not avail,
                              width=90,
                              text_align=ft.TextAlign.RIGHT)
            tf.on_submit = (lambda e, s=section, kk=k, c=tf:
                            save_int(s, kk, e.control.value, c))
            tf.on_blur = (lambda e, s=section, kk=k, c=tf:
                          save_int(s, kk, e.control.value, c))
            return _style_field(tf)
        tf = ft.TextField(value=str(val), disabled=not avail,
                          width=230,
                          on_submit=(lambda e, s=section, kk=k:
                                     save(s, kk, e.control.value)))
        return _style_field(tf)

    def _settings_rows(self, helper, avail, cur):
        """Настройки — полноширинные строки в один столбец (№56, как в
        примере): подпись с подсказкой слева, контрол справа, между
        строками тонкий разделитель."""
        rows = []
        for field in helper["fields"]:
            section, k, typ, label, hint, default = field
            val = cur(section, k, default)
            ctl = self._field_control(helper, section, k, typ, val,
                                      avail, cur)
            rows.append(ft.Container(
                padding=ft.padding.symmetric(horizontal=2, vertical=9),
                content=ft.Row([
                    ft.Column([
                        ft.Text(label, size=13, color=FG,
                                weight=ft.FontWeight.W_500),
                        ft.Text(hint, size=11, color=DIM),
                    ], spacing=2, expand=True),
                    ctl,
                ], vertical_alignment="center")))
            rows.append(ft.Divider(height=1, thickness=1, color=EDGE))
        return ft.Column(rows, spacing=0)

    def _warn_safe_mode(self):
        """Плашка-предупреждение (№57): свой тёплый фон янтаря и
        живая обводка по периметру — по контуру рамки бежит
        «змейка» фирменного жёлтого, чтобы глаз сам падал сюда."""
        inner = ft.Container(
            bgcolor="#2A220F",
            border_radius=ft.border_radius.all(9),
            padding=ft.padding.symmetric(horizontal=12, vertical=10),
            content=ft.Row([
                ft.Icon(_ico("WARNING_AMBER", "ERROR_OUTLINE",
                             "PRIORITY_HIGH"), color=GOLD, size=17),
                ft.Text("Точные параметры (вид проводки и задержки) "
                        "действуют при выключенном Safe Mode.",
                        size=12.5, color="#E8D9A8", expand=True),
            ], spacing=10, vertical_alignment="center"))
        try:
            al = ft.alignment
            grad = ft.LinearGradient(
                begin=al.center_left, end=al.center_right,
                colors=[GOLD, "#3A2E0E", "#3A2E0E", "#3A2E0E"],
                stops=[0.0, 0.25, 0.6, 1.0], rotation=0.0)
        except Exception:
            grad = None
        if grad is None:                 # старый flet — просто рамка
            return ft.Container(
                border=ft.border.all(1.2, "#8A6A16"),
                border_radius=ft.border_radius.all(10),
                content=inner)
        wrapper = ft.Container(
            gradient=grad, padding=ft.padding.all(1.4),
            border_radius=ft.border_radius.all(10), content=inner)
        # рамка оживает в _glow_loop; умершие ссылки оттуда вычистим
        self._glow_items.append({"g": grad, "c": wrapper})
        return wrapper

    async def _glow_loop(self):
        """Анимация «неоновой змейки» (№57): крутим градиент рамки —
        яркий участок плавно обегает плашку по периметру (~4 сек/круг).
        Своя корутина: тикер статусов слишком медленный для этого."""
        while True:
            await asyncio.sleep(0.07)
            if not self._glow_items:
                continue
            dead = []
            for it in self._glow_items:
                try:
                    it["g"].rotation = (float(it["g"].rotation or 0)
                                        + 0.11) % 6.2832
                    it["c"].update()
                except Exception:
                    dead.append(it)      # вид закрыт — вычёркиваем
            for it in dead:
                try:
                    self._glow_items.remove(it)
                except Exception:
                    pass

    def _build_helper(self, helper):
        key = helper["key"]
        avail = helper["available"]
        ini_now = core.read_ini(helper["ini"])

        def cur(section, k, default):
            try:
                raw = ini_now.get(section, k)
            except Exception:
                raw = None
            if raw is None:
                return default
            if isinstance(default, bool):
                return raw.strip() in ("1", "true", "да", "on")
            if isinstance(default, int):
                try:
                    return int(raw)
                except ValueError:
                    return default
            return raw

        # --- панель действия: точка+статус слева, кнопки справа
        st_dot = _dot(9, DIM)
        st_txt = ft.Text("…", size=13, color=SOFT)
        shape = _round_style(10, 12.5)
        run_kw = dict(bgcolor=BLUE, color="#FFFFFF", height=32,
                      width=142, animate_opacity=150)
        stop_kw = dict(bgcolor=BTN_DARK, color=SOFT, height=32,
                       width=130, animate_opacity=150)
        if shape is not None:
            run_kw["style"] = shape
            stop_kw["style"] = shape
        run_b = ft.ElevatedButton(
            "Запустить", icon=_ico("PLAY_ARROW"), disabled=not avail,
            on_click=lambda _e, k=key: self._launch(k), **run_kw)
        stop_b = ft.ElevatedButton(
            "Остановить", icon=_ico("STOP", "CIRCLE"), disabled=not avail,
            on_click=lambda _e: self._stop(), **stop_kw)
        if not avail:
            st_txt.value = "В разработке"
            st_txt.color = GOLD
            st_dot.bgcolor = GOLD
        else:
            self.live["st_dot"] = st_dot
            self.live["st_txt"] = st_txt
            self.live["run_b"] = run_b
            self.live["stop_b"] = stop_b
        bar_body = dict(border=ft.border.all(1, EDGE),
                        border_radius=ft.border_radius.all(12),
                        padding=ft.padding.symmetric(horizontal=14,
                                                     vertical=11),
                        content=ft.Row(
                            [st_dot, st_txt, ft.Container(expand=True),
                             run_b, stop_b], spacing=12,
                            vertical_alignment="center"))
        g = _grad(CARD_TOP, CARD)
        if g is not None:
            bar_body["gradient"] = g
        else:
            bar_body["bgcolor"] = CARD
        bar = ft.Container(**bar_body)

        # --- хвост: предупреждение у живого бота, иначе пояснение.
        # «Место под новые настройки» убрали (№57) — пользователям
        # про внутренние планы рассказывать не нужно.
        if avail:
            tail = [ft.Container(height=10),
                    self._warn_safe_mode()]
        else:
            tail = [ft.Container(height=14),
                    self._mini_label("ПОЯВИТСЯ В ОБНОВЛЕНИЯХ"),
                    ft.Container(height=4),
                    ft.Text("Этот помощник в разработке. Настройки "
                            "можно подготовить заранее — они уже "
                            "сохраняются.", size=11.5, color=DIM)]

        return ft.Column([
            ft.Text(helper["title"], size=21, weight=ft.FontWeight.W_600,
                    color=FG),
            ft.Container(height=2),
            ft.Text(helper["desc"], size=12, color=SOFT),
            ft.Container(height=12),
            bar,
            ft.Container(height=14),
            self._mini_label("НАСТРОЙКИ"),
            ft.Divider(height=1, thickness=1, color=EDGE),
            self._settings_rows(helper, avail, cur),
        ] + tail + [
            ft.Container(height=10),
            ft.Text("Файл настроек: TrofPridi_data\\configs\\%s"
                    % helper["ini"], size=10, color=DIM),
        ], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO)

    def _key_row(self, kn, kd):
        chip = ft.Container(border=ft.border.all(1, EDGE),
                            border_radius=ft.border_radius.all(6),
                            padding=ft.padding.symmetric(horizontal=8,
                                                         vertical=2),
                            content=ft.Text(kn, size=11, color=FG))
        return ft.Row([chip, ft.Text(kd, size=11.5, color=SOFT)],
                      spacing=10, vertical_alignment="center")

    def _build_stats(self):
        dot = _dot(9, DIM)
        txt = ft.Text("…", size=13, color=SOFT)
        self.live["stats_dot"] = dot
        self.live["stats_txt"] = txt
        shape = _round_style(10, 12.5)
        btn_kw = dict(bgcolor=GREEN, color="#08241C", height=32)
        if shape is not None:
            btn_kw["style"] = shape
        open_b = ft.ElevatedButton(
            "Открыть статистику", icon=_ico("OPEN_IN_NEW", "STAR"),
            on_click=lambda _e: self._open_stats(), **btn_kw)
        folder_kw = dict(height=32)
        if shape is not None:
            folder_kw["style"] = shape
        folder_b = ft.OutlinedButton(
            "Папка с данными", icon=_ico("FOLDER", "STAR"),
            on_click=lambda _e: self.note(core.open_data_dir()[1]),
            **folder_kw)
        bar_body = dict(border=ft.border.all(1, EDGE),
                        border_radius=ft.border_radius.all(12),
                        padding=ft.padding.symmetric(horizontal=14,
                                                     vertical=11),
                        content=ft.Row(
                            [dot, txt, ft.Container(expand=True),
                             open_b, folder_b], spacing=12,
                            vertical_alignment="center"))
        g = _grad(CARD_TOP, CARD)
        if g is not None:
            bar_body["gradient"] = g
        else:
            bar_body["bgcolor"] = CARD
        bar = ft.Container(**bar_body)
        return ft.Column([
            ft.Text("Статистика", size=21, weight=ft.FontWeight.W_600,
                    color=FG),
            ft.Container(height=2),
            ft.Text("Уловы, галерея, журнал, сессии и «О программе».",
                    size=12, color=SOFT),
            ft.Container(height=12),
            bar,
            ft.Container(height=14),
            self._mini_label("АВТОЗАПУСК"),
            ft.Divider(height=1, thickness=1, color=EDGE),
            ft.Container(height=4),
            ft.Text("• запускаешь бота — открываются статистика "
                    "и менеджер\n"
                    "• запускаешь менеджер — открывается статистика\n"
                    "• статистика открывается и отдельно, сама по себе",
                    size=12, color=SOFT),
            ft.Container(height=8),
            ft.Text("Клавиша F6 в боте разворачивает и прячет это окно.",
                    size=11, color=DIM),
        ], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO)

    # -------------------------------------------------- справка (№55)
    def _link(self, txt, fn):
        """Кнопка-ссылка (как в макете): синий текст, подчёркивается
        фирменным цветом, без плашки."""
        try:
            return ft.TextButton(
                content=ft.Text(txt, size=12.5, color=ACCENT),
                on_click=fn)
        except Exception:
            return ft.TextButton(txt, on_click=fn)

    def _build_guide(self):
        if self.guide_sub == "how":
            return self._build_guide_how()
        if self.guide_sub == "spin":
            return self._build_guide_spin()
        # --- главная справки
        return ft.Column([
            ft.Text("Справка", size=21, weight=ft.FontWeight.W_600,
                    color=FG),
            ft.Container(height=2),
            ft.Text("TrofPridi — набор помощников для «Русской "
                    "Рыбалки 4»: бот сам ловит рыбу, статистика "
                    "считает улов, а менеджер управляет всем этим "
                    "из одного окна.", size=12, color=SOFT),
            ft.Container(height=12),
            self._mini_label("КАК НАЧАТЬ"),
            ft.Divider(height=1, thickness=1, color=EDGE),
            ft.Container(height=4),
            ft.Text("1. Запустите игру и встаньте на точку ловли.\n"
                    "2. Нажмите «Запустить» на карточке «Спиннинг».\n"
                    "3. Вернитесь в игру и нажмите PgDn — ловля "
                    "началась.", size=12, color=SOFT),
            self._link("Прочитайте краткую инструкцию →",
                       lambda _e: self._guide("how")),
            ft.Container(height=6),
            self._mini_label("КЛАВИШИ БОТА"),
            ft.Divider(height=1, thickness=1, color=EDGE),
            ft.Container(height=4),
            ft.Column([
                self._key_row("PgDn", "старт / пауза ловли"),
                self._key_row("F6", "окно статистики"),
                self._key_row("F7", "что видит бот (масштаб)"),
                self._key_row("F8", "полный выход "
                                  "+ статистика и менеджер"),
            ], spacing=5),
            ft.Container(height=10),
            self._mini_label("ПОЛЕЗНО ЗНАТЬ"),
            ft.Divider(height=1, thickness=1, color=EDGE),
            ft.Container(height=4),
            ft.Text("• Точные параметры проводки и задержек действуют "
                    "при выключенном Safe Mode.\n"
                    "• Настройки помощников лежат в "
                    "TrofPridi_data\\configs — можно править "
                    "и Блокнотом.", size=12, color=SOFT),
        ], spacing=0, expand=True)

    def _build_guide_how(self):
        """Выбор вида ловли для краткой инструкции (№55)."""
        rows = []
        for h in core.HELPERS:
            avail = h["available"]
            subtitle = ("Нажмите — откроется пошаговая инструкция"
                        if avail else "Появится в следующих обновлениях")
            card = ft.Container(
                expand=True, bgcolor=CARD,
                border=ft.border.all(1, EDGE),
                border_radius=ft.border_radius.all(12),
                padding=ft.padding.all(14),
                on_click=(lambda _e, k=h["key"]: self._guide(k))
                if avail else None,
                content=ft.Row([
                    ft.Icon(_ico(*HELPER_ICONS.get(h["key"], ("STAR",))),
                            size=24,
                            color=ACCENT if avail else DIM),
                    ft.Column([
                        ft.Text(h["title"], size=14, color=FG if avail
                                else DIM, weight=ft.FontWeight.W_600),
                        ft.Text(subtitle, size=11,
                                color=SOFT if avail else DIM),
                    ], spacing=2, expand=True),
                    ft.Icon(_ico("CHEVRON_RIGHT", "ARROW_FORWARD"),
                            size=18, color=SOFT if avail else DIM),
                ], spacing=12, vertical_alignment="center"))
            rows.append(card)
        grid = ft.Column([
            ft.Row(rows[0:2], spacing=12),
            ft.Row(rows[2:4], spacing=12),
        ], spacing=12)
        return ft.Column([
            self._link("← Справка", lambda _e: self._guide("main")),
            ft.Text("Краткая инструкция", size=21,
                    weight=ft.FontWeight.W_600, color=FG),
            ft.Container(height=2),
            ft.Text("Выберите вид ловли — внутри пошагово, что "
                    "подготовить, как запустить и как остановить.",
                    size=12, color=SOFT),
            ft.Container(height=14),
            grid,
        ], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO)

    def _guide_section(self, title, body):
        return [self._mini_label(title),
                ft.Divider(height=1, thickness=1, color=EDGE),
                ft.Container(height=4),
                ft.Text(body, size=12, color=SOFT),
                ft.Container(height=10)]

    def _build_guide_spin(self):
        """Подробная инструкция по спиннингу (№55)."""
        ctl = [self._link("← Краткая инструкция",
                          lambda _e: self._guide("how")),
               ft.Text("Спиннинг — инструкция", size=21,
                       weight=ft.FontWeight.W_600, color=FG),
               ft.Container(height=2),
               ft.Text("Активная ловля: подсечка и вываживание "
                       "помощником, мелочь отпускаем, зачётное "
                       "оставляем.", size=12, color=SOFT),
               ft.Container(height=12)]
        ctl += self._guide_section(
            "ПОДГОТОВКА",
            "1. Положите кофе и еду в слоты 4 и 5 — помощник\n"
            "   подкрепляется по таймеру.\n"
            "2. Встаньте на точку ловли, спиннинг в руках,\n"
            "   камерой смотрите на воду.\n"
            "3. Масштаб Windows — лучше 100% (проверка — F7).")
        ctl += self._guide_section(
            "ЛОВЛЯ",
            "1. Нажмите «Запустить» на карточке «Спиннинг» —\n"
            "   бот, статистика и менеджер откроются вместе.\n"
            "2. Вернитесь в игру и нажмите PgDn — ловля началась.\n"
            "3. Меню бота слева вверху показывает стадию, улов\n"
            "   и таймеры; выбор проводки — в настройках.")
        ctl += self._guide_section(
            "ОСТАНОВКА",
            "PgDn — пауза и продолжение.\n"
            "F8 — полный выход: бот, статистика и менеджер\n"
            "закроются вместе.")
        return ft.Column(ctl, spacing=0, expand=True,
                         scroll=ft.ScrollMode.AUTO)

    def _build_activation(self):
        pg = self.page
        hw = core.hwid()
        # №73: строка статуса честная — платная подписка со сроком,
        # а не «Активна до 31.12.9999 · 365000 дн.»
        active, lic_txt = core.license_display()

        key_field = _style_field(ft.TextField(
            label="Ключ активации", hint_text="TP-XXXX-XXXX-XXXX-XXXX",
            width=340))
        result = ft.Text("", size=12.5, color=SOFT)

        # --- №72: потайной генератор ключей (пароль в поле ключа) ---
        kg_hw = _style_field(ft.TextField(
            label="HWID покупателя", hint_text="XXXX-XXXX", width=190))
        KG_PLANS = [("1", "1 день"), ("7", "7 дней"), ("M", "30 дней"),
                    ("F", "навсегда")]
        kg_plan_val = "M"
        kg_plan_lbl = ft.Text("30 дней", size=12.5, color=FG)
        kg_out = _selectable("", size=14, color=GOLD)

        def pick_plan(v, t):
            nonlocal kg_plan_val
            kg_plan_val = v
            kg_plan_lbl.value = t
            pg.update()

        plan_pick = ft.Container(
            width=128, border=ft.border.all(1, EDGE),
            border_radius=ft.border_radius.all(8),
            padding=ft.padding.symmetric(horizontal=10, vertical=6),
            content=ft.PopupMenuButton(
                tooltip="Срок подписки",
                items=[ft.PopupMenuItem(
                       text=t,
                       on_click=(lambda _e, v=v, t=t: pick_plan(v, t)))
                       for v, t in KG_PLANS],
                content=ft.Row([
                    kg_plan_lbl,
                    ft.Icon(_ico("KEYBOARD_ARROW_DOWN",
                                 "ARROW_DROP_DOWN"), size=15, color=SOFT),
                ], spacing=6, vertical_alignment="center")))

        def gen_key(_e):
            k = core.keygen_make(kg_hw.value, kg_plan_val)
            if not k:
                kg_out.value = ("HWID должен быть вида XXXX-XXXX — как в "
                                "карточке покупателя, без пробелов")
                kg_out.color = RED
            else:
                kg_out.value = k
                kg_out.color = GREEN
            pg.update()

        keygen_box = ft.Container(
            visible=False, padding=ft.padding.all(10),
            border=ft.border.all(1, GOLD), border_radius=10,
            content=ft.Column([
                ft.Text("ГЕНЕРАТОР КЛЮЧЕЙ (только для тебя)", size=12,
                        color=GOLD, weight=ft.FontWeight.W_600),
                ft.Container(height=6),
                ft.Row([kg_hw, plan_pick,
                        ft.ElevatedButton("Выписать", height=32,
                                          bgcolor=GOLD, color="#08241C",
                                          style=_round_style(10, 12.5),
                                          on_click=gen_key)],
                       spacing=10, vertical_alignment="center"),
                ft.Container(height=4),
                kg_out]))

        def do_activate(_e):
            # №72: пароль генератора — открывает потайную панель
            if core.is_keygen_password(key_field.value):
                key_field.value = ""
                keygen_box.visible = True
                result.value = ("Генератор открыт: впиши HWID покупателя, "
                                "выбери срок — ключ просто отправь ему")
                result.color = GOLD
                pg.update()
                return
            ok, out = core.activate_key(key_field.value)
            if not ok:
                result.value = out
                result.color = RED
            else:
                result.value = ("Ключ принят! Подписка: "
                                + ("навсегда 🎉" if out >= 365000
                                   else "%d дн." % out))
                result.color = GREEN
                self._refresh_license()
            pg.update()

        status_body = dict(border=ft.border.all(1, EDGE),
                           border_radius=ft.border_radius.all(12),
                           padding=ft.padding.symmetric(horizontal=14,
                                                        vertical=11),
                           content=ft.Row([
                               ft.Icon(_ico("SHIELD", "VERIFIED", "KEY"),
                                       color=ACCENT, size=20),
                               ft.Text("Статус: " + lic_txt, size=13,
                                       color=GREEN if active else GOLD),
                           ], spacing=10, vertical_alignment="center"))
        g = _grad(CARD_TOP, CARD)
        if g is not None:
            status_body["gradient"] = g
        else:
            status_body["bgcolor"] = CARD
        status_bar = ft.Container(**status_body)

        # --- Telegram (№61): уловы с фото, фильтры и команды боту
        tg = core.telegram_config()
        token_tf = _style_field(ft.TextField(
            label="Токен бота", value=tg["token"], width=334,
            password=True, can_reveal_password=True))
        chat_tf = _style_field(ft.TextField(
            label="Chat ID", value=tg["chat_id"], width=196,
            hint_text="число — кнопка «Определить» ниже"))

        def _mw():
            try:
                return max(0.0, float(str(weight_tf.value).strip()
                                      .replace(",", ".") or 0))
            except Exception:
                return 0.0

        def save_tg(_e=None):
            try:
                core.set_telegram_config(
                    token_tf.value, chat_tf.value, bool(tg_sw.value),
                    photos=photos_val, min_weight_kg=_mw(),
                    commands=bool(cmd_sw.value),
                    proxy=str(proxy_tf.value or ""))
                # №62: ловим частую ошибку — вместо своего числового
                # Chat ID вписывают ник бота (@TrofPridiBot). С таким
                # Telegram ответит «chat not found».
                cid = str(chat_tf.value or "").strip()
                if cid and not cid.lstrip("-").isdigit():
                    self.note("Сохранено, но Chat ID обычно ЧИСЛО. "
                              "Нажми «Определить Chat ID» — найдётся сам")
                else:
                    self.note("Настройки Telegram сохранены")
            except Exception as e:
                self.note("Не удалось сохранить: %s" % e)

        tg_sw = _switch(value=tg["enabled"], on_change=save_tg)
        token_tf.on_submit = save_tg
        chat_tf.on_submit = save_tg

        # №62: у части пользователей API Telegram перекрыт — голый
        # HTTPS умирает по тайм-ауту. Прокси SOCKS5/HTTP спасает;
        # MTProto-прокси из Telegram Desktop НЕ подходит (это другой
        # протокол, Bot API через него не ходит).
        proxy_tf = _style_field(ft.TextField(
            label="Прокси (если Telegram заблокирован)",
            value=tg["proxy"], width=540,
            hint_text="socks5://127.0.0.1:9150  (Tor Browser) — или пусто"))
        proxy_tf.on_submit = save_tg
        proxy_tf.on_blur = save_tg

        # какие уловы присылать с фото (выбор в стиле «вид проводки»)
        PHOTO_MODES = [("all", "Все уловы"),
                       ("marks", "Только трофеи и зачётные"),
                       ("none", "Совсем без фото")]
        photos_val = tg["photos"]
        photo_lbl = ft.Text(dict(PHOTO_MODES).get(photos_val, "Все уловы"),
                            size=12.5, color=FG, expand=True)

        def pick_photo(v, t):
            nonlocal photos_val
            photos_val = v
            photo_lbl.value = t
            save_tg()
            try:
                pg.update()
            except Exception:
                pass

        photo_pick = ft.Container(
            width=270, height=32, bgcolor=FIELD_FILL,
            border=ft.border.all(1, EDGE),
            border_radius=ft.border_radius.all(8),
            padding=ft.padding.only(left=10, right=8),
            content=ft.PopupMenuButton(
                items=[ft.PopupMenuItem(
                    text=t,
                    on_click=(lambda _e, v=v, t=t: pick_photo(v, t)))
                    for v, t in PHOTO_MODES],
                tooltip="Какие уловы присылать с фото",
                content=ft.Row([
                    photo_lbl,
                    ft.Icon(_ico("KEYBOARD_ARROW_DOWN", "ARROW_DROP_DOWN"),
                            size=15, color=SOFT),
                ], spacing=6, vertical_alignment="center")))

        wv = ("%.3f" % tg["min_weight_kg"]).rstrip("0").rstrip(".")
        weight_tf = _style_field(ft.TextField(
            label="мин. вес, кг (0 — все)", value=(wv or "0"), width=260))
        weight_tf.on_submit = save_tg
        weight_tf.on_blur = save_tg

        cmd_sw = _switch(value=tg["commands"], on_change=save_tg)

        tg_test_res = ft.Text("", size=12, color=SOFT)

        def test_tg(_e):
            save_tg()                       # сначала сохранить поля
            tg_test_res.value = "Проверяем…"
            tg_test_res.color = DIM
            try:
                pg.update()
            except Exception:
                pass

            def _do():
                ok, err = core.telegram_test()
                # №68: ядро возвращает подробный итог («подставил чат
                # сам» и т.п.) — показываем его, а не сухое «успех».
                tg_test_res.value = (err if ok
                                     else "Не вышло: %s" % err)
                tg_test_res.color = GREEN if ok else RED
                # тест мог сам подставить Chat ID и живой прокси
                # (цепочка) — сразу показываем это в полях
                try:
                    cfg = core.telegram_config()
                    chat_tf.value = cfg["chat_id"]
                    proxy_tf.value = cfg["proxy"]
                except Exception:
                    pass
                try:
                    pg.update()
                except Exception:
                    pass
            threading.Thread(target=_do, daemon=True).start()

        test_btn = ft.ElevatedButton(
            "Проверить связь", icon=_ico("SEND", "CHECK"),
            bgcolor=BLUE, color="#FFFFFF", height=32, width=173,
            style=_round_style(10, 12.5), on_click=test_tg)

        def detect_chat(_e):
            """№62: Chat ID достаём сами из сообщений бота — не все
            знают про @userinfobot, а ник бота вместо числа вписывают
            постоянно."""
            save_tg()
            tg_test_res.value = "Спрашиваю бота, кто ему уже писал…"
            tg_test_res.color = DIM
            try:
                pg.update()
            except Exception:
                pass

            def _do():
                ok, found, err = core.telegram_find_chat()
                if ok and found:
                    chat_tf.value = found[0][0]
                    save_tg()
                    txt = "Подставлен Chat ID %s (%s)" % found[0]
                    if len(found) > 1:
                        txt += " · писали ещё: " + ", ".join(
                            "@%s" % u.split("@")[-1] if "@" in u else u
                            for _i, u in found[1:])
                    tg_test_res.value = txt
                    tg_test_res.color = GREEN
                elif ok:
                    tg_test_res.value = (err or
                                         "Боту пока никто не писал — "
                                         "отправьте ему /start")
                    tg_test_res.color = GOLD
                else:
                    tg_test_res.value = "Не вышло: %s" % err
                    tg_test_res.color = RED
                try:
                    pg.update()
                except Exception:
                    pass
            threading.Thread(target=_do, daemon=True).start()

        detect_btn = ft.ElevatedButton(
            "Определить Chat ID", icon=_ico("PERSON_SEARCH", "SEARCH"),
            bgcolor="#2A313B", color=FG, height=32, width=173,
            style=_round_style(10, 12.5), on_click=detect_chat)

        def scan_proxy(_e):
            """№74: ОДНА кнопка поиска (было две — лишнее): сперва
            локальные программы (TgWsProxy, Tor, Clash — если антени,
            у части людей Telegram живёт только так), не отозвались —
            сразу публичные списки с GitHub, без скачиваний (№66)."""
            save_tg()
            tg_test_res.value = ("Ищу локальные прокси (TgWsProxy, "
                                 "Tor, Clash…) — проверяю каждый…")
            tg_test_res.color = DIM
            try:
                pg.update()
            except Exception:
                pass

            def _do():
                found, _tried = core.telegram_scan_proxies()
                if found:
                    url, label = found
                    proxy_tf.value = url
                    save_tg()
                    tg_test_res.value = ("✔ Telegram отвечает через %s "
                                         "(%s) — подставлено! Жмите "
                                         "«Проверить связь»"
                                         % (url, label or "прокси"))
                    tg_test_res.color = GREEN
                    try:
                        pg.update()
                    except Exception:
                        pass
                    return
                # локальных нет — сразу ищем публичные
                tg_test_res.value = ("Локальных не видно — ищу "
                                     "публичные (без скачиваний)…")
                tg_test_res.color = DIM
                try:
                    pg.update()
                except Exception:
                    pass
                scan_public(_e)          # готовый сценарий №66/№67
            threading.Thread(target=_do, daemon=True).start()

        scan_btn = ft.ElevatedButton(
            "Найти прокси", icon=_ico("TRAVEL_EXPLORE", "SEARCH"),
            bgcolor="#2A313B", color=FG, height=32, width=173,
            style=_round_style(10, 12.5), on_click=scan_proxy)

        def scan_public(_e):
            """№66: без скачиваний вообще — качаем свежие публичные
            списки с GitHub и проверяем каждый запросом до Bot API."""
            save_tg()

            def progress(msg):
                tg_test_res.value = "Публичные прокси: " + msg
                tg_test_res.color = DIM
                try:
                    pg.update()
                except Exception:
                    pass

            progress("скачиваю свежие списки…")

            def _do():
                urls, label, total, alive = core.telegram_scan_public(
                    on_progress=progress)
                if urls:
                    proxy_tf.value = urls[0]
                    spare = (" · +%d в запасе" % (len(urls) - 1)
                             if len(urls) > 1 else "")
                    tg_test_res.value = ("✔ Telegram отвечает через %s%s "
                                         "(проверено %d адресов). При "
                                         "отказе перескочу на запасной "
                                         "сам. Жмите «Проверить связь»"
                                         % (urls[0], spare, total))
                    tg_test_res.color = GREEN
                elif not total:
                    tg_test_res.value = ("Не удалось скачать списки "
                                         "прокси — проверьте, открывается "
                                         "ли github.com на этом ПК.")
                    tg_test_res.color = GOLD
                else:
                    tg_test_res.value = ("Из %d публичных откликнулись %d, "
                                         "но Telegram ни через один. "
                                         "Списки обновляются ежедневно — "
                                         "попробуйте нажать ещё раз."
                                         % (total, alive))
                    tg_test_res.color = GOLD
                try:
                    pg.update()
                except Exception:
                    pass
            threading.Thread(target=_do, daemon=True).start()

        # №79: магазин из менеджера ВЫНЕСЕН — всё в Телеграме
        # (кнопка «🛒 Магазин подписки» в меню бота; юзер попросил).
        return ft.Column([
            ft.Text("Активация", size=21, weight=ft.FontWeight.W_600,
                    color=FG),
            ft.Container(height=2),
            ft.Text("Ключ привязывается к этому компьютеру и действует "
                    "весь оплаченный срок.", size=12, color=SOFT),
            ft.Container(height=12),
            status_bar,
            ft.Container(height=14),
            self._mini_label("ЭТОТ КОМПЬЮТЕР (HWID)"),
            ft.Container(height=4),
            _selectable(hw, size=15),
            ft.Container(height=8),
            key_field,
            ft.Container(height=2),
            ft.Row([
                ft.ElevatedButton("Активировать", icon=_ico("CHECK",
                                                           "STAR"),
                                  bgcolor=GREEN, color="#08241C",
                                  height=32, style=_round_style(10,
                                                                12.5),
                                  on_click=do_activate),
            ], spacing=12, vertical_alignment="center"),
            result,
            keygen_box,
            ft.Container(height=8),
            ft.Divider(height=1, thickness=1, color=EDGE),
            ft.Container(height=4),
            self._mini_label("УВЕДОМЛЕНИЯ В TELEGRAM"),
            ft.Container(height=2),
            # №64: вся карточка — ровная колонка 540: поля, подсказки,
            # тумблеры и кнопки по одной линейке (было вразнобой).
            ft.Container(width=540, content=ft.Column([
                # №65: без дублирующей подписи и С ВОЗДУХОМ между
                # строками — всплывающие лейблы полей наезжали на
                # соседние строки, когда всё стояло вплотную.
                ft.Row([
                    ft.Text("Уведомления об улове в бота",
                            size=13, color=FG,
                            weight=ft.FontWeight.W_500, expand=True),
                    tg_sw,
                ], vertical_alignment="center"),
                ft.Container(height=10),
                ft.Row([token_tf, chat_tf], spacing=10),
                ft.Container(height=8),
                proxy_tf,
                ft.Container(height=6),
                ft.Text("Токен даёт @BotFather (/newbot). Chat ID — "
                        "число: напишите боту /start → «Определить "
                        "Chat ID» подставит его сам. Прокси — SOCKS5/"
                        "HTTP, если Telegram заблокирован.",
                        size=11, color=DIM),
                ft.Container(height=12),
                self._mini_label("ЧТО ПРИСЫЛАТЬ"),
                ft.Container(height=4),
                ft.Row([photo_pick, weight_tf], spacing=10,
                       vertical_alignment="center"),
                ft.Container(height=10),
                ft.Row([
                    ft.Column([
                        ft.Text("Команды боту из Telegram",
                                size=13, color=FG,
                                weight=ft.FontWeight.W_500),
                        ft.Text("/pause · /resume · /status · /last",
                                size=11, color=DIM),
                    ], spacing=2, expand=True),
                    cmd_sw,
                ], vertical_alignment="center"),
                ft.Container(height=10),
                ft.Row([test_btn, detect_btn, scan_btn], spacing=10,
                       vertical_alignment="center"),
                ft.Container(height=6),
                tg_test_res,
            ], spacing=0)),
        ], spacing=0, expand=True, scroll=ft.ScrollMode.AUTO)

    # -------------------------------------------------- статусы
    def _cached_status(self):
        st, txt = getattr(self, "_last_status", ("stopped", "Не запущен"))
        return st, txt

    def _stats_is_alive(self):
        """Статистика открывается пару секунд — на это время честно
        показываем «Запускается…», а не мигаем «Не запущена»."""
        try:
            if core.stats_alive():
                return True, "Запущена", GREEN
        except Exception:
            pass
        until = getattr(self, "_stats_optimistic_until", 0)
        if time.time() < until:
            return True, "Запускается…", GOLD
        return False, "Не запущена", DIM

    def _paint_action_buttons(self, st):
        """№57: кнопки отвечают на состояние бота видом, а не только
        кликабельностью. Бот работает → «Запустить» гаснет, а
        «Остановить» зажигается красным; бот стоит → наоборот:
        яркая синяя «Запустить», потухшая «Остановить». Переход —
        мягкий, кнопки умеют анимировать прозрачность."""
        run_b = self.live.get("run_b")
        stop_b = self.live.get("stop_b")
        if run_b is None or stop_b is None:
            return
        stopped = (st == "stopped")
        try:
            run_b.disabled = not stopped
            run_b.opacity = 1 if stopped else 0.45
            if stopped:
                run_b.bgcolor = BLUE
                run_b.color = "#FFFFFF"
            else:
                run_b.bgcolor = "#2A313B"
                run_b.color = DIM
        except Exception:
            pass
        try:
            stop_b.disabled = stopped
            stop_b.opacity = 1 if not stopped else 0.5
            if stopped:
                stop_b.bgcolor = BTN_DARK
                stop_b.color = DIM
            else:
                stop_b.bgcolor = "#E54848"
                stop_b.color = "#FFFFFF"
        except Exception:
            pass

    def _apply_status(self, st, txt):
        """Раскладывает статус бота по живым контролам (№53)."""
        self._last_status = (st, txt)
        col = STATUS_COLOR.get(st, DIM)
        it = self.nav.get("spin")
        if it is not None and it["dot"] is not None:
            try:
                it["dot"].bgcolor = col
            except Exception:
                pass
        if "st_dot" in self.live:
            try:
                self.live["st_dot"].bgcolor = col
                self.live["st_dot"].visible = True
                self.live["st_txt"].value = txt
                self.live["st_txt"].color = SOFT
                self._paint_action_buttons(st)
            except Exception:
                pass
        if "stats_dot" in self.live:
            try:
                _a, msg, col2 = self._stats_is_alive()
                self.live["stats_dot"].bgcolor = col2
                self.live["stats_txt"].value = msg
            except Exception:
                pass

    def _refresh_license(self):
        try:
            active, txt, _l = core.activation_status()
        except Exception:
            active, txt = False, "Не активирована"
        try:
            self.lic_dot.bgcolor = GREEN if active else RED
            self.lic_text.value = ("Лицензия активна" if active
                                    else "Лицензия не активирована")
            self.lic_text.color = GREEN if active else RED
        except Exception:
            pass

    def refresh_status(self):
        """Синхронное обновление (из обработчиков кнопок)."""
        try:
            st, txt = core.bot_status()
        except Exception:
            st, txt = "stopped", "Не запущен"
        self._apply_status(st, txt)
        self._refresh_license()
        try:
            self.page.update()
        except Exception:
            pass

    async def _refresh_async(self):
        """Обновление из тикера: тяжёлый опрос процессов — в пуле,
        чтобы окно не подвисало на долю секунды каждые 2 такта."""
        try:
            loop = asyncio.get_running_loop()
            st, txt = await loop.run_in_executor(None, core.bot_status)
        except Exception:
            st, txt = "stopped", "Не запущен"
        self._apply_status(st, txt)
        self._refresh_license()
        core.touch_manager_alive()
        try:
            self.page.update()
        except Exception:
            raise

    async def _ticker(self):
        await asyncio.sleep(0.4)
        # правило связки: менеджер поднимает статистику (№53)
        try:
            loop = asyncio.get_running_loop()
            launched, msg = await loop.run_in_executor(
                None, core.ensure_stats_running)
            if launched:                    # окно открывается пару секунд
                self._stats_optimistic_until = time.time() + 8
            elif msg:                       # №57: тихий старт — в строке
                self.note(msg)              # только то, о чём спрашивали
        except Exception:
            pass
        while True:                          # №56: такты неубиваемые
            try:
                if not self._icon_done:     # значок таскбара (№54)
                    self._icon_tries += 1
                    if self._apply_taskbar_icon() or self._icon_tries > 10:
                        self._icon_done = True
            except Exception:
                pass
            try:
                if not getattr(self, "_drag_ready", False):
                    self._drag_tries = getattr(self, "_drag_tries", 0) + 1
                    if self._patch_native_drag() or self._drag_tries > 12:
                        self._drag_ready = True
            except Exception:
                pass
            try:
                self._apply_capture_guard()  # защита от скриншотов
            except Exception:
                pass
            try:
                await self._refresh_async()
            except Exception:
                pass
            await asyncio.sleep(2.0)

    # -------------------------------------------------- действия
    def _launch(self, key):
        self._paint_action_buttons("running")  # мгновенный отклик (№57)
        try:
            self.page.update()
        except Exception:
            pass
        ok, msg = core.launch_bot(key)
        core.clear_status_cache()           # статус — свежий сразу
        self.note(msg)
        self.refresh_status()

    def _stop(self):
        self._paint_action_buttons("stopped")  # мгновенный отклик (№57)
        try:
            self.page.update()
        except Exception:
            pass
        ok, msg = core.stop_bot()
        core.clear_status_cache()
        self.note(msg)
        self.refresh_status()

    def _open_stats(self):
        launched, msg = core.ensure_stats_running()
        self.note(msg)
        if launched:                        # окно открывается пару секунд
            self._stats_optimistic_until = time.time() + 6
        self.refresh_status()

    # -------------------------------------------------- корневой вид
    def view_main(self):
        pg = self.page
        pg.clean()
        self.sidebar = self._build_sidebar()
        self.body = ft.Container(
            expand=True,
            padding=ft.padding.only(left=26, top=16, right=26, bottom=6),
            content=self._build_view(self.view_key))
        self.status_line = ft.Text(self._note or
                                   "Менеджер готов к работе",
                                   size=11, color=DIM)
        # №56: нижняя строка — на ВСЮ ширину окна. Полоска сверху —
        # отдельным Divider: рисуется ровно и бежит от края до края.
        status_bar = ft.Container(
            padding=ft.padding.symmetric(horizontal=26, vertical=7),
            content=self.status_line)
        right = ft.Column([self.body], spacing=0, expand=True)
        main_row = ft.Row([self.sidebar, right], spacing=0, expand=True)
        parts = []
        if self.frameless:                  # №54: своя шапка вместо Windows
            parts.append(self._build_titlebar())
        parts.append(main_row)
        parts.append(ft.Divider(height=1, thickness=1, color=EDGE))
        parts.append(status_bar)
        pg.add(ft.Column(parts, spacing=0, expand=True))
        self._paint_selection()
        self._apply_status(*self._cached_status())
        pg.update()
        try:
            pg.run_task(self._glow_loop)     # «змейки» рамок (№57)
        except Exception:
            pass
        try:
            pg.run_task(self._ticker)
        except Exception:
            # старые flet: статистику поднимем хотя бы синхронно,
            # а статусы обновятся на действиях
            try:
                launched, msg = core.ensure_stats_running()
                if launched or msg:
                    self.note(msg)
            except Exception:
                pass
            self.refresh_status()


def main(page):
    app = ManagerApp(page)
    app.window_setup()
    app.view_main()


def launch():
    """Точка входа (её зовёт manager.pyw).

    №58 — открываемся ВСЕГДА: замок через mutex (система сама
    отпускает его при любом падении — залочка «вообще не открывается»
    ушла), попытка своего окна с маркером-самолечением и журнал
    каждого шага в TrofPridi_data\\manager_boot.log.
    """
    core.boot_log("=== запуск менеджера %s, python %s"
                  % (core.APP_VERSION, sys.version.split()[0]))
    try:
        core.sync_license_state()      # №72: маяк замка для бота (AHK)
    except Exception:
        pass
    # №61: свой AppUserModelID — ДО появления любого окна процесса.
    # Без него панель задач склеивала наше окно с ярлыком самого
    # Питона и показывала ЕГО значок, сколько ни шли WM_SETICON.
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "TrofPridi.Manager")
        except Exception:
            pass
    # одно окно менеджера: бот поднимает нас вместе с собой, и без
    # замка двойной щелчок по manager.pyw плодил бы близнецов (№53)
    if not core.single_instance_guard("manager"):
        core.boot_log("уже запущен (mutex) — выход")
        return
    if not ensure_runtime():
        # совсем без пакетов окна не будет — скажем честно, без консоли
        core.release_instance("manager")
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0, "Нужные пакеты поставить не удалось.\n"
                   "Проверь интернет и запусти менеджер ещё раз.\n"
                   "(Подробности — TrofPridi_data\\manager_boot.log)",
                "TrofPridi Manager", 0x40)
        except Exception:
            print("Установи: pip install", FLET_SPEC)
        return
    ran_webview = False
    try:
        state = core.wv_state()
        if state == "try":
            # №58: прошлая попытка своего окна умерла до открытия —
            # второй раз не мучаем: откат на прежний режим навсегда.
            core.wv_state_set("off")
            core.boot_log("прошлое своё окно умерло до показа — "
                          "переходим в совместимый режим")
            state = "off"
        if state != "off":
            # №58: маркер «попытка» ставим ДО рискованных импортов
            # (import clr/pythonnet способен уронить процесс мгновенно,
            # и тогда «try» зафиксирует эту смерть — второй шанс не
            # дадим, откроемся совместимым режимом).
            global WEB_MODE, WEB_VIEW
            core.wv_state_set("try")
            ready = _webview2_ready()
            if not ready:
                # пакета/рантайма нет — это не падение: вернём маркер
                core.wv_state_set("ok" if state == "ok" else "")
                core.boot_log("webview недоступен (нет пакета или "
                              "WebView2) — совместимый режим")
            if ready:
                # №57: основной режим — своё окно (прячется от
                # скриншотов). Вернётся после закрытия; упадёт — откат.
                core.boot_log("режим: своё окно (webview)")
                try:
                    _run_webview_host()
                    ran_webview = True
                except Exception as e:
                    core.boot_log("webview упал: %r — откат на движок"
                                  % e)
                    WEB_MODE, WEB_VIEW = False, None
                    ran_webview = False
        if not ran_webview:                  # откат: окно движка flet
            core.boot_log("режим: окно движка flet (своя защита "
                          "от снимков тут не действует)")
            ft.app(target=main, assets_dir="assets")
    finally:
        core.boot_log("менеджер выходит")
        core.release_instance("manager")
        core.clear_manager_alive()
        if ran_webview:
            # внутри остались серверные потоки — выходим сразу
            os._exit(0)


if __name__ == "__main__":
    launch()

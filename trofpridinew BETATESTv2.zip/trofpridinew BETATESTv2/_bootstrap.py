# -*- coding: utf-8 -*-
"""
Автоустановка недостающих пакетов.

Подключается первой строкой в скриптах: проверяет, что нужное есть,
недостающее ставит через pip и показывает окно с ходом установки.
Если интернета нет — объясняет, что делать, а не падает с трассировкой.

Использование:
    from _bootstrap import ensure
    ensure({"PIL": "pillow", "mss": "mss"})
"""

import importlib
import os
import subprocess
import sys

MARKER = "_deps_ok.txt"          # чтобы не проверять каждый раз


def _dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _missing(pkgs):
    """Каких пакетов не хватает.

    Ловим ЛЮБОЕ исключение, а не только ImportError: тяжёлые пакеты
    вроде onnxruntime при неудачной установке падают с OSError или
    RuntimeError, и такой пакет тоже нужно считать отсутствующим.

    invalidate_caches обязателен: сразу после pip интерпретатор ещё
    помнит старое содержимое папок и не находит только что
    установленный пакет. Из-за этого маркер не записывался, и окно
    установки выскакивало при каждом запуске заново.
    """
    importlib.invalidate_caches()
    out = []
    for mod, pip_name in pkgs.items():
        try:
            importlib.import_module(mod)
        except Exception:
            out.append((mod, pip_name))
    return out


def ocr_deps():
    """Пакеты распознавания улова с учётом версии Python.

    Вынесено сюда, чтобы и распознавание (ocr_watch), и заставка
    статистики проверяли ОДИН и тот же набор. Раньше список строился
    в ocr_watch отдельно: статистика проверяла только Pillow, запуск
    ставил недостающее через своё окно, потом появлялась заставка —
    и выходило окно загрузки ЗА окном загрузки.

    rapidocr-onnxruntime нужен для точного чтения опыта по плашкам.
    Он весит около 380 МБ вместе с ONNX Runtime, поэтому ставится
    последним: если установка не пройдёт, всё остальное уже работает,
    а опыт будет читаться прежним способом.
    Привязка к Windows Runtime называется по-разному в зависимости от
    версии Python: старый winsdk собран только под 3.8-3.12, для 3.13
    и новее нужны раздельные пакеты winrt-*.
    """
    need = {"PIL": "pillow", "mss": "mss"}
    if sys.version_info >= (3, 13):
        need.update({
            "winrt.windows.media.ocr": "winrt-Windows.Media.Ocr",
            "winrt.windows.globalization": "winrt-Windows.Globalization",
            "winrt.windows.graphics.imaging":
                "winrt-Windows.Graphics.Imaging",
            "winrt.windows.storage.streams":
                "winrt-Windows.Storage.Streams",
        })
    else:
        need["winsdk"] = "winsdk"
    need["rapidocr_onnxruntime"] = "rapidocr-onnxruntime"
    return need


def _pip_install(names, log=None):
    """Ставит пакеты. Возвращает (успех, текст вывода)."""
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
           "--no-input", *names]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True,
                           timeout=600,
                           creationflags=getattr(subprocess,
                                                 "CREATE_NO_WINDOW", 0))
        ok = p.returncode == 0
        return ok, (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        return False, "Не найден pip. Переустанови Python с python.org."
    except subprocess.TimeoutExpired:
        return False, "Установка заняла слишком долго — проверь интернет."
    except Exception as e:
        return False, str(e)


def _install_ui(missing, ui):
    """Установка пакетов в чужом окне загрузки.

    pip работает в фоновом потоке, а ui (мост из окна статистики)
    из ГЛАВНОГО потока крутит свою заставку по звонкам tick():
    рыба продолжает качаться, полоса ползёт. Второго окна нет.
    """
    import threading
    names = [p for _, p in missing]
    try:
        ui.busy(names)
    except Exception:
        pass
    res = [None]

    def work():
        res[0] = _pip_install(names)

    th = threading.Thread(target=work, daemon=True)
    th.start()
    step = 0
    try:
        while th.is_alive():
            ui.tick(step)
            step += 1
    except Exception:
        # окно-получатель умерло или больше не отвечает
        th.join(timeout=5)
        return False
    th.join()
    ok = bool(res[0] and res[0][0])
    msg = res[0][1] if res[0] else ""
    try:
        ui.done(ok, names, msg)
    except Exception:
        pass
    return ok


def _gui_install(missing):
    """Окно с ходом установки. Возвращает True, если всё поставилось.

    Выглядит ровно как заставка статистики: одна и та же рыба,
    заголовок, капсула прогресса. Пользователь видит единый экран
    загрузки, а не два разных окна подряд.
    """
    try:
        import tkinter as tk
    except ImportError:
        # tkinter нет — ставим молча в консоли
        ok, _ = _pip_install([p for _, p in missing])
        return ok

    # Цвета заставок — одним словарём (как SPLASH_THEME в stats_app):
    # будущий переключатель светлой/тёмной темы поменяет только его.
    THEME = {
        "bg": "#0B0E12", "edge": "#1E2730", "edge_hi": "#25303C",
        "fg": "#FFFFFF", "dim": "#6C7B8B", "accent": "#00A2FF",
        "accent_hi": "#4FCBFF", "accent_lo": "#0077DE",
        "gold": "#FFB300", "ok": "#00E6B8", "err": "#FF5555",
        "track": "#121924", "track_sh": "#06090E", "track_hi": "#2B3B4C",
        "card": "#1A2027", "sink": "#182230", "tip": "#5A6773",
    }
    TIPS = (
        "Совет: PgDn — пауза и запуск бота",
        "Совет: F6 прячет окно статистики и возвращает обратно",
        "Совет: Safe Mode в настройках делает бота живее",
        "Совет: клик по снимку в галерее открывает его крупно",
        "Совет: клик по рыбе в журнале показывает её фото",
        "Совет: F5 — обновить данные вручную",
    )
    import ctypes as _ct
    import math as _math
    import random as _rnd
    import threading
    import time as _time

    def mixx(c1, c2, k):
        a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
        b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
        return "#%02X%02X%02X" % tuple(
            min(255, max(0, int(a[i] + (b[i] - a[i]) * k)))
            for i in range(3))

    win = tk.Tk()
    win.title("TrofPridi")
    w, h = 560, 330
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    win.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2 - 40}")
    try:
        win.overrideredirect(True)
        win.attributes("-topmost", True)
    except Exception:
        pass

    cv = tk.Canvas(win, width=w, height=h, bg=THEME["bg"],
                   highlightthickness=0)
    cv.pack(fill="both", expand=True)
    cv.create_rectangle(1, 1, w - 2, h - 2, outline=THEME["edge"])
    cv.create_line(2, 2, w - 2, 2, fill=THEME["edge_hi"])

    # Скруглённые углы — ПОСЛЕ того, как окно реально создано.
    # Раньше регион ставился сразу после geometry(), когда настоящий
    # дескриптор окна ещё не появился, и по углам оставались едва
    # заметные квадратные уголки фона. update_idletasks материализует
    # окно — и только теперь скругление применяется по-настоящему.
    # Помимо этого НЕ используем -alpha: смена прозрачности у такого
    # окна пересоздаёт дескриптор и применённый регион слетает.
    try:
        win.update_idletasks()
        rgn = _ct.windll.gdi32.CreateRoundRectRgn(0, 0, w + 1, h + 1,
                                                  26, 26)
        _ct.windll.user32.SetWindowRgn(win.winfo_id(), rgn, True)
    except Exception:
        pass

    # Тот же логотип и градиентный заголовок, что и на заставке —
    # Tk читает готовые PNG сам, Pillow здесь не нужен
    # (его-то мы, может быть, как раз и ставим).
    def _img(name):
        try:
            fp = os.path.join(_dir(), "assets", name)
            return tk.PhotoImage(file=fp) if os.path.exists(fp) else None
        except Exception:
            return None

    logo = _img("splash_fish.png")
    titles = [x for x in (_img(f"title_{i}.png") for i in range(4))
              if x is not None]

    cx, cy = w // 2, 118
    cv.create_oval(cx - 64, cy - 64, cx + 64, cy + 64,
                   outline=THEME["sink"], width=2, tags="ring_in")
    ring_id = cv.create_oval(cx - 53, cy - 53, cx + 53, cy + 53,
                             outline="#1E2A36", width=2)
    logo_id = None
    if logo:
        logo_id = cv.create_image(cx, cy, image=logo)

    title_id = None
    if titles:
        title_id = cv.create_image(cx, 202, image=titles[0])
    else:
        cv.create_text(cx, 196, anchor="c", fill=THEME["fg"],
                       font=("Segoe UI", 24, "bold"), text="TROFPRIDI")
    cv.create_text(cx, 230, anchor="c", fill=THEME["dim"],
                   font=("Segoe UI", 10), text="УСАДЬБА РЫБАКА  •  v3.5")
    cv.create_text(cx, 251, anchor="c", fill=THEME["gold"],
                   font=("Segoe UI", 9),
                   text="Подготовка к первому запуску — "
                        "это делается один раз")

    # «вдавленная» дорожка прогресса-капсула
    x1, x2, y = 90, w - 90, 266
    bar_w = x2 - x1
    r = 4
    cv.create_oval(x1 - r, y, x1 + r, y + 8, fill=THEME["track"],
                   outline="", tags="track")
    cv.create_rectangle(x1, y, x2, y + 8, fill=THEME["track"],
                        outline="", tags="track")
    cv.create_oval(x2 - r, y, x2 + r, y + 8, fill=THEME["track"],
                   outline="", tags="track")
    cv.create_line(x1, y + 1, x2, y + 1, fill=THEME["track_sh"])
    cv.create_line(x1, y + 8, x2, y + 8, fill=THEME["track_hi"])
    seg_w = 110
    status = cv.create_text(cx, y + 27, anchor="c", fill=THEME["accent"],
                            font=("Segoe UI", 11),
                            text="Загружаем компоненты распознавания улова…")
    cv.create_text(cx, h - 20, anchor="c", fill=THEME["tip"],
                   font=("Segoe UI", 9), text=_rnd.choice(TIPS))
    cv.create_text(w - 12, h - 8, anchor="se", fill="#3A4550",
                   font=("Segoe UI", 7), text="by tg/flkn69")

    state = {"done": False, "ok": False, "msg": ""}
    t0 = _time.time()
    seg_steps = 14

    def draw_segment():
        """Бегунок-капсула с переливающимся градиентом (как в Spotify)."""
        cv.delete("seg")
        t = _time.time() - t0
        if state["done"]:
            k = 1.0 if state["ok"] else (_math.sin(t * 2.0) + 1) / 2
        else:
            k = (_math.sin(t * 2.0) + 1) / 2
        if state["done"] and state["ok"]:
            sx, ew = x1, bar_w
            colf = lambda ph: mixx(THEME["ok"], "#5CF2CE", 0.5 + 0.5 * ph)
        elif state["done"]:
            sx, ew = x1, bar_w
            colf = lambda ph: mixx(THEME["err"], "#FF8A7A", 0.5 + 0.5 * ph)
        else:
            sx = x1 + k * (bar_w - seg_w)
            ew = seg_w
            colf = lambda ph: mixx(THEME["accent"], THEME["accent_hi"],
                                   0.5 + 0.5 * ph)
        step = ew / seg_steps
        for i in range(seg_steps):
            ph = _math.sin(t * 2.2 + i * 0.55)
            cv.create_rectangle(sx + i * step, y + 2,
                                sx + (i + 1) * step + 1, y + 6,
                                fill=colf(ph), outline="", tags="seg")
        cv.create_oval(sx - r + 2, y + 1, sx + r + 2, y + 7,
                       fill=colf(-0.9), outline="", tags="seg")
        ex = sx + ew
        cv.create_oval(ex - r - 2, y + 1, ex + r - 2, y + 7,
                       fill=colf(0.9), outline="", tags="seg")

    def animate():
        # Окно могли уже закрыть — тогда просто перестаём звонить.
        try:
            t = _time.time() - t0
            if logo_id is not None:
                cv.coords(logo_id, cx, cy + _math.sin(t * 2.4) * 5)
            if title_id is not None:
                cv.itemconfig(title_id,
                              image=titles[int(t * 3.2) % len(titles)])
            pulse = (_math.sin(t * 2.1) + 1) / 2
            cv.itemconfig(ring_id,
                          outline=mixx(THEME["sink"], THEME["accent"],
                                       0.25 + 0.45 * pulse))
            draw_segment()
            win.after(40, animate)
        except tk.TclError:
            return

    def work():
        ok, msg = _pip_install([p for _, p in missing])
        state.update(done=True, ok=ok, msg=msg)

    threading.Thread(target=work, daemon=True).start()
    animate()

    def poll():
        if state["done"]:
            if state["ok"]:
                cv.itemconfig(status, text="Готово — открываем Усадьбу…",
                              fill=THEME["ok"])
                win.after(700, win.destroy)
            else:
                cv.itemconfig(status,
                              text="Часть компонентов недоступна",
                              fill=THEME["err"])
                names = " ".join(p for _, p in missing)
                cv.create_text(cx, h - 44, anchor="c", fill=THEME["dim"],
                               font=("Segoe UI", 8),
                               text="Проверь интернет или выполни вручную: "
                                    f"pip install {names}")
                tk.Button(win, text="Закрыть", command=win.destroy,
                          bg=THEME["card"], fg=THEME["fg"], relief="flat",
                          bd=0, padx=16, pady=3,
                          activebackground=THEME["accent"],
                          activeforeground=THEME["fg"]).place(
                              x=x1, y=h - 40)
            return
        win.after(120, poll)

    poll()
    win.mainloop()
    return state["ok"]


def _marker_read(path):
    """Какие пакеты уже проверены. Возвращает множество имён."""
    try:
        with open(path, encoding="utf-8") as f:
            return {ln.strip() for ln in f if ln.strip()}
    except OSError:
        return set()


def _marker_write(path, names):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write("\n".join(sorted(names)) + "\n")
    except OSError:
        pass


def ensure(pkgs, silent_ok=True, ui=None):
    """Гарантирует наличие пакетов. pkgs = {"модуль": "имя-для-pip"}.

    Возвращает True, если всё на месте (или доустановилось).

    ui — необязательное «чужое окно загрузки» (объект с методами
    busy/tick/done). С ним установка рисуется в ЕГО окне и своё
    отдельно не открывается: у программы одно окно загрузки, а не
    два подряд.

    БЕЗ ui никакого окна теперь нет вообще: наблюдатель улова
    (ocr_watch) ставит недостающее молча в фоне. Раньше тут
    открывалось отдельное окно — и у пользователя шло «сначала одна
    загрузка, потом другая», это напрягало.
    """
    # Маркер держим в папке данных, чтобы рядом со скриптами
    # не появлялись служебные файлы.
    dd = os.path.join(_dir(), "TrofPridi_data")
    try:
        os.makedirs(dd, exist_ok=True)
        marker = os.path.join(dd, MARKER)
    except OSError:
        marker = os.path.join(_dir(), MARKER)
    # В маркере храним КАЖДЫЙ проверенный пакет отдельной строкой.
    #
    # Раньше писался общий набор одной строкой — и это ломалось: окно
    # статистики требует только pillow, а распознавание ещё и mss с
    # rapidocr. Два процесса записывали разные наборы и бесконечно
    # затирали отметку друг друга, поэтому окно подготовки выскакивало
    # при каждом запуске. Теперь каждый дописывает своё, ничего не
    # стирая, и повторные проверки не нужны никому.
    want = set(pkgs.values())
    done = _marker_read(marker)
    if want <= done:
        return True

    missing = _missing(pkgs)
    if not missing:
        _marker_write(marker, done | want)
        return True

    if ui is not None:
        ok = _install_ui(missing, ui)
    else:
        ok = _silent_install(missing, marker, done | want)
    if ok and not _missing(pkgs):
        _marker_write(marker, done | want)
        return True
    return False


def _silent_install(missing, marker, want):
    """Тихая фоновая установка: ни одного окна.

    Наблюдатель улова стартует вместе с ботом, показывать ему нечего,
    а pip вертится минуты — поэтому работа уходит в фоновый поток и
    запуск НЕ тормозится. Замок на файле не даёт двум процессам
    (наблюдатель и статистика) качать одно и то же параллельно.
    """
    import threading
    import time as _t
    lock = marker + ".lock"
    try:
        fd = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.close(fd)
        locked = True
    except OSError:
        locked = False
    if not locked:
        try:
            # Замок старше 20 минут — прошлый установщик помер, смелее.
            if _t.time() - os.path.getmtime(lock) > 1200:
                os.remove(lock)
        except OSError:
            pass
        return True                     # кто-то уже ставит — не мешаем

    def work():
        try:
            ok, msg = _pip_install([p for _, p in missing])
            if ok:
                _marker_write(marker, want)
        finally:
            try:
                os.remove(lock)
            except OSError:
                pass

    threading.Thread(target=work, daemon=True).start()
    return True
